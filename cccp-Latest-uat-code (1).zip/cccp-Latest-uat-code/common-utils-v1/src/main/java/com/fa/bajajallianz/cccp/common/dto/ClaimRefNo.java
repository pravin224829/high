package com.fa.bajajallianz.cccp.common.dto;

public interface ClaimRefNo {
	
	 String REFNO="REF";
	 String YEAR1="22";


}
