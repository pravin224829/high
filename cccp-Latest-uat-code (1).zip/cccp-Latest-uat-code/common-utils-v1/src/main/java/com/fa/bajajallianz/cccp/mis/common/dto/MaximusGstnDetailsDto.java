package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

public class MaximusGstnDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String businessUnit;
	private String constitutionOfBusiness;
	private String effectiveDateOfCancellation;
	private String effectiveDateOfRegistration;
	private String gstinUINStatus;
	private String legalNameOfBusiness;
	private String principalPlaceOfBusiness;
	private String tradeName;
	private String checksum;

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getConstitutionOfBusiness() {
		return constitutionOfBusiness;
	}

	public void setConstitutionOfBusiness(String constitutionOfBusiness) {
		this.constitutionOfBusiness = constitutionOfBusiness;
	}

	public String getEffectiveDateOfCancellation() {
		return effectiveDateOfCancellation;
	}

	public void setEffectiveDateOfCancellation(String effectiveDateOfCancellation) {
		this.effectiveDateOfCancellation = effectiveDateOfCancellation;
	}

	public String getEffectiveDateOfRegistration() {
		return effectiveDateOfRegistration;
	}

	public void setEffectiveDateOfRegistration(String effectiveDateOfRegistration) {
		this.effectiveDateOfRegistration = effectiveDateOfRegistration;
	}

	public String getGstinUINStatus() {
		return gstinUINStatus;
	}

	public void setGstinUINStatus(String gstinUINStatus) {
		this.gstinUINStatus = gstinUINStatus;
	}

	public String getLegalNameOfBusiness() {
		return legalNameOfBusiness;
	}

	public void setLegalNameOfBusiness(String legalNameOfBusiness) {
		this.legalNameOfBusiness = legalNameOfBusiness;
	}

	public String getPrincipalPlaceOfBusiness() {
		return principalPlaceOfBusiness;
	}

	public void setPrincipalPlaceOfBusiness(String principalPlaceOfBusiness) {
		this.principalPlaceOfBusiness = principalPlaceOfBusiness;
	}

	public String getTradeName() {
		return tradeName;
	}

	public void setTradeName(String tradeName) {
		this.tradeName = tradeName;
	}

	public String getChecksum() {
		return checksum;
	}

	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

}