package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

public class ClaimEventDto implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String eventCode;
	private String eventDescription;
	public String getEventCode() {
		return eventCode;
	}
	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}
	public String getEventDescription() {
		return eventDescription;
	}
	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

}
