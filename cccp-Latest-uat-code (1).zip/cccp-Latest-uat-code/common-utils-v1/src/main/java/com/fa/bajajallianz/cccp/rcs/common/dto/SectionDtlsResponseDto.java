package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SectionDtlsResponseDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String selectionDescription;
	private String sectionid;
	private String sumInsured;
	private Boolean sectionSelection;
	private String petName;

	public String getSelectionDescription() {
		return selectionDescription;
	}

	public void setSelectionDescription(String selectionDescription) {
		this.selectionDescription = selectionDescription;
	}

	public String getSectionid() {
		return sectionid;
	}

	public void setSectionid(String sectionid) {
		this.sectionid = sectionid;
	}

	public String getSumInsured() {
		return sumInsured;
	}

	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}

	public Boolean getSectionSelection() {
		return sectionSelection;
	}

	public void setSectionSelection(Boolean sectionSelection) {
		this.sectionSelection = sectionSelection;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

}
