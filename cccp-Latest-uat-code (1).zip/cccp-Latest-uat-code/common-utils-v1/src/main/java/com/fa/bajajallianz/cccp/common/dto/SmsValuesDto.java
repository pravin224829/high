/**
 * 
 */
package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SmsValuesDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String name;
	private String value;
	
	public SmsValuesDto(String name, String value) {
		super();
		this.name = name;
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
