package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SettlementRatioDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String lob;
	private String totalClaims;
	private String closedClaims;
	private String closedIn5Days;
	private String closedIn9Days;
	private String fdrPercentage;
	private String sdrPercentage;
	private String onrPercentage;
	private String openClaims;

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getTotalClaims() {
		return totalClaims;
	}

	public void setTotalClaims(String totalClaims) {
		this.totalClaims = totalClaims;
	}

	public String getClosedClaims() {
		return closedClaims;
	}

	public void setClosedClaims(String closedClaims) {
		this.closedClaims = closedClaims;
	}

	public String getClosedIn5Days() {
		return closedIn5Days;
	}

	public void setClosedIn5Days(String closedIn5Days) {
		this.closedIn5Days = closedIn5Days;
	}

	public String getClosedIn9Days() {
		return closedIn9Days;
	}

	public void setClosedIn9Days(String closedIn9Days) {
		this.closedIn9Days = closedIn9Days;
	}

	public String getFdrPercentage() {
		return fdrPercentage;
	}

	public void setFdrPercentage(String fdrPercentage) {
		this.fdrPercentage = fdrPercentage;
	}

	public String getSdrPercentage() {
		return sdrPercentage;
	}

	public void setSdrPercentage(String sdrPercentage) {
		this.sdrPercentage = sdrPercentage;
	}

	public String getOnrPercentage() {
		return onrPercentage;
	}

	public void setOnrPercentage(String onrPercentage) {
		this.onrPercentage = onrPercentage;
	}

	public String getOpenClaims() {
		return openClaims;
	}

	public void setOpenClaims(String openClaims) {
		this.openClaims = openClaims;
	}

}
