package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusAddressesListDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<MaximusAddressDto> address;

	public List<MaximusAddressDto> getAddress() {
		return address;
	}

	public void setAddress(List<MaximusAddressDto> address) {
		this.address = address;
	}

	
}