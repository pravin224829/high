package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

public class LossPaymentDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String ip_type;
	private String paymentMode;
	private String paymentAmount;
	private String reinstatementPremium;
	private String transactionType;
	private String party_id;
	private String ip_no;
	private String approval_status;

	public LossPaymentDto(String ip_type, String paymentMode, String paymentAmount, String reinstatementPremium,
			String transactionType, String party_id, String ip_no, String approval_status) {
		super();
		this.ip_type = ip_type;
		this.paymentMode = paymentMode;
		this.paymentAmount = paymentAmount;
		this.reinstatementPremium = reinstatementPremium;
		this.transactionType = transactionType;
		this.party_id = party_id;
		this.ip_no = ip_no;
		this.approval_status = approval_status;

	}

	public String getPaymentType() {
		return ip_type;
	}

	public void setPaymentType(String paymentType) {
		this.ip_type = paymentType;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getReinstatementPremium() {
		return reinstatementPremium;
	}

	public void setReinstatementPremium(String reinstatementPremium) {
		this.reinstatementPremium = reinstatementPremium;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getIp_type() {
		return ip_type;
	}

	public void setIp_type(String ip_type) {
		this.ip_type = ip_type;
	}

	public String getParty_id() {
		return party_id;
	}

	public void setParty_id(String party_id) {
		this.party_id = party_id;
	}

	public String getIp_no() {
		return ip_no;
	}

	public void setIp_no(String ip_no) {
		this.ip_no = ip_no;
	}

	public String getApproval_status() {
		return approval_status;
	}

	public void setApproval_status(String approval_status) {
		this.approval_status = approval_status;
	}

	public LossPaymentDto() {
		super();

	}
}
