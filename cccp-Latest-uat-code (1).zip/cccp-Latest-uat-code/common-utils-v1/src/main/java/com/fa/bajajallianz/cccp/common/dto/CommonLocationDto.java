package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonLocationDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private LocationDto locationDetails;
	private ApplicationErrorDto applicationError;

	public LocationDto getLocationDetails() {
		return locationDetails;
	}

	public void setLocationDetails(LocationDto locationDetails) {
		this.locationDetails = locationDetails;
	}

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

}
