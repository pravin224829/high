package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties
public class UserCountDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5789332422841964060L;

	private String corporateCode;

	private Integer activeUser;

	private Integer inActiveUser;

	private Integer totalUser;

	private Date createDate;

	public String getCorporateCode() {
		return corporateCode;
	}

	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}

	public Integer getActiveUser() {
		return activeUser;
	}

	public void setActiveUser(Integer activeUser) {
		this.activeUser = activeUser;
	}

	public Integer getInActiveUser() {
		return inActiveUser;
	}

	public void setInActiveUser(Integer inActiveUser) {
		this.inActiveUser = inActiveUser;
	}

	public Integer getTotalUser() {
		return totalUser;
	}

	public void setTotalUser(Integer totalUser) {
		this.totalUser = totalUser;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

}
