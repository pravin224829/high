/**
 * 
 */
package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusPaymentReqDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String userCode;
	private String roleCode;
	private String claimNumber;
	private String policyNumber;
	private String riskCover;
	private String impactedCoverCode;
	private String reserveType;
	private String reserveSubType;
	private String purpose;
	private String purposeTDS;
	private String paymentType;
	private String payeeFunction;
	private String payeeCode;
	private String taxInvoiceNumber;
	private String taxInvoiceDate;
	private String paymentAmountTransactionCurrency;
	private String paymentAmountReserveCurrency;
	private String tdsAmount;
	private String igstAmount;
	private String cgstAmount;
	private String sgstAmount;
	private String ugstAmount;
	private String totalAmountIncludingTaxTransactionCurrency;
	private String transactionCurrency;
	private String reserveCurrency;
	private String remarks;
	private String paymentMode;
	private String paymentAuthorizationDate;
	private String referenceType;
	private String referenceId;
	private String interestAmount;
	private String tdsOnInterest;
	private String chequeNumber;
	private String chequeDate;
	private String paymentState;
	private String payableAt;
	private String printLocationCode;
	private String accountCategoryCode;
	private String referenceNumber;
	private String paymentOption;
	private String noOfInstallments;
	private String installmentMode;
	private String status;
	private String polCurrency;
	private String invoiceMode;
	private String bankName;
	private String bankCode;
	private String accountType;
	private String accNumber;
	private String aolNumber;
	private String typeOfDamage;
	private String electSolar;
	private String vatApplicable;
	private String vatNumber;
	private String paDate;
	private String hlBankName;
	private String hlBranchCode;
	private String hlsAccNumber;
	private String bondAcccNumber;
	private String ccExpiryDate;
	private String cvvNumber;
	private String creditCardNo;
	private String cashlessClaimType;
	private String woNo;
	private String section;
	private String rejectionReason;
	private String referenceAmount;
	private String printLocation;
	private String accountCode;
	private String paymentTransactionType;
	private String paymentStateTDS;
	private String payableAtTDS;
	private String printLocationCodeTDS;
	private String accountCategoryCodeTDS;
	private String printLocationTDS;
	private String gstPercentage;
	
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getRiskCover() {
		return riskCover;
	}
	public void setRiskCover(String riskCover) {
		this.riskCover = riskCover;
	}
	public String getImpactedCoverCode() {
		return impactedCoverCode;
	}
	public void setImpactedCoverCode(String impactedCoverCode) {
		this.impactedCoverCode = impactedCoverCode;
	}
	public String getReserveType() {
		return reserveType;
	}
	public void setReserveType(String reserveType) {
		this.reserveType = reserveType;
	}
	public String getReserveSubType() {
		return reserveSubType;
	}
	public void setReserveSubType(String reserveSubType) {
		this.reserveSubType = reserveSubType;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public String getPurposeTDS() {
		return purposeTDS;
	}
	public void setPurposeTDS(String purposeTDS) {
		this.purposeTDS = purposeTDS;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getPayeeFunction() {
		return payeeFunction;
	}
	public void setPayeeFunction(String payeeFunction) {
		this.payeeFunction = payeeFunction;
	}
	public String getPayeeCode() {
		return payeeCode;
	}
	public void setPayeeCode(String payeeCode) {
		this.payeeCode = payeeCode;
	}
	public String getTaxInvoiceNumber() {
		return taxInvoiceNumber;
	}
	public void setTaxInvoiceNumber(String taxInvoiceNumber) {
		this.taxInvoiceNumber = taxInvoiceNumber;
	}
	public String getTaxInvoiceDate() {
		return taxInvoiceDate;
	}
	public void setTaxInvoiceDate(String taxInvoiceDate) {
		this.taxInvoiceDate = taxInvoiceDate;
	}
	public String getPaymentAmountTransactionCurrency() {
		return paymentAmountTransactionCurrency;
	}
	public void setPaymentAmountTransactionCurrency(String paymentAmountTransactionCurrency) {
		this.paymentAmountTransactionCurrency = paymentAmountTransactionCurrency;
	}
	public String getPaymentAmountReserveCurrency() {
		return paymentAmountReserveCurrency;
	}
	public void setPaymentAmountReserveCurrency(String paymentAmountReserveCurrency) {
		this.paymentAmountReserveCurrency = paymentAmountReserveCurrency;
	}
	public String getTdsAmount() {
		return tdsAmount;
	}
	public void setTdsAmount(String tdsAmount) {
		this.tdsAmount = tdsAmount;
	}
	public String getIgstAmount() {
		return igstAmount;
	}
	public void setIgstAmount(String igstAmount) {
		this.igstAmount = igstAmount;
	}
	public String getCgstAmount() {
		return cgstAmount;
	}
	public void setCgstAmount(String cgstAmount) {
		this.cgstAmount = cgstAmount;
	}
	public String getSgstAmount() {
		return sgstAmount;
	}
	public void setSgstAmount(String sgstAmount) {
		this.sgstAmount = sgstAmount;
	}
	public String getUgstAmount() {
		return ugstAmount;
	}
	public void setUgstAmount(String ugstAmount) {
		this.ugstAmount = ugstAmount;
	}
	public String getTotalAmountIncludingTaxTransactionCurrency() {
		return totalAmountIncludingTaxTransactionCurrency;
	}
	public void setTotalAmountIncludingTaxTransactionCurrency(String totalAmountIncludingTaxTransactionCurrency) {
		this.totalAmountIncludingTaxTransactionCurrency = totalAmountIncludingTaxTransactionCurrency;
	}
	public String getTransactionCurrency() {
		return transactionCurrency;
	}
	public void setTransactionCurrency(String transactionCurrency) {
		this.transactionCurrency = transactionCurrency;
	}
	public String getReserveCurrency() {
		return reserveCurrency;
	}
	public void setReserveCurrency(String reserveCurrency) {
		this.reserveCurrency = reserveCurrency;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getPaymentAuthorizationDate() {
		return paymentAuthorizationDate;
	}
	public void setPaymentAuthorizationDate(String paymentAuthorizationDate) {
		this.paymentAuthorizationDate = paymentAuthorizationDate;
	}
	public String getReferenceType() {
		return referenceType;
	}
	public void setReferenceType(String referenceType) {
		this.referenceType = referenceType;
	}
	public String getReferenceId() {
		return referenceId;
	}
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}
	public String getInterestAmount() {
		return interestAmount;
	}
	public void setInterestAmount(String interestAmount) {
		this.interestAmount = interestAmount;
	}
	public String getTdsOnInterest() {
		return tdsOnInterest;
	}
	public void setTdsOnInterest(String tdsOnInterest) {
		this.tdsOnInterest = tdsOnInterest;
	}
	public String getChequeNumber() {
		return chequeNumber;
	}
	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}
	public String getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(String chequeDate) {
		this.chequeDate = chequeDate;
	}
	public String getPaymentState() {
		return paymentState;
	}
	public void setPaymentState(String paymentState) {
		this.paymentState = paymentState;
	}
	public String getPayableAt() {
		return payableAt;
	}
	public void setPayableAt(String payableAt) {
		this.payableAt = payableAt;
	}
	public String getPrintLocationCode() {
		return printLocationCode;
	}
	public void setPrintLocationCode(String printLocationCode) {
		this.printLocationCode = printLocationCode;
	}
	public String getAccountCategoryCode() {
		return accountCategoryCode;
	}
	public void setAccountCategoryCode(String accountCategoryCode) {
		this.accountCategoryCode = accountCategoryCode;
	}
	public String getReferenceNumber() {
		return referenceNumber;
	}
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	public String getPaymentOption() {
		return paymentOption;
	}
	public void setPaymentOption(String paymentOption) {
		this.paymentOption = paymentOption;
	}
	public String getNoOfInstallments() {
		return noOfInstallments;
	}
	public void setNoOfInstallments(String noOfInstallments) {
		this.noOfInstallments = noOfInstallments;
	}
	public String getInstallmentMode() {
		return installmentMode;
	}
	public void setInstallmentMode(String installmentMode) {
		this.installmentMode = installmentMode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPolCurrency() {
		return polCurrency;
	}
	public void setPolCurrency(String polCurrency) {
		this.polCurrency = polCurrency;
	}
	public String getInvoiceMode() {
		return invoiceMode;
	}
	public void setInvoiceMode(String invoiceMode) {
		this.invoiceMode = invoiceMode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
	public String getAolNumber() {
		return aolNumber;
	}
	public void setAolNumber(String aolNumber) {
		this.aolNumber = aolNumber;
	}
	public String getTypeOfDamage() {
		return typeOfDamage;
	}
	public void setTypeOfDamage(String typeOfDamage) {
		this.typeOfDamage = typeOfDamage;
	}
	public String getElectSolar() {
		return electSolar;
	}
	public void setElectSolar(String electSolar) {
		this.electSolar = electSolar;
	}
	public String getVatApplicable() {
		return vatApplicable;
	}
	public void setVatApplicable(String vatApplicable) {
		this.vatApplicable = vatApplicable;
	}
	public String getVatNumber() {
		return vatNumber;
	}
	public void setVatNumber(String vatNumber) {
		this.vatNumber = vatNumber;
	}
	public String getPaDate() {
		return paDate;
	}
	public void setPaDate(String paDate) {
		this.paDate = paDate;
	}
	public String getHlBankName() {
		return hlBankName;
	}
	public void setHlBankName(String hlBankName) {
		this.hlBankName = hlBankName;
	}
	public String getHlBranchCode() {
		return hlBranchCode;
	}
	public void setHlBranchCode(String hlBranchCode) {
		this.hlBranchCode = hlBranchCode;
	}
	public String getHlsAccNumber() {
		return hlsAccNumber;
	}
	public void setHlsAccNumber(String hlsAccNumber) {
		this.hlsAccNumber = hlsAccNumber;
	}
	public String getBondAcccNumber() {
		return bondAcccNumber;
	}
	public void setBondAcccNumber(String bondAcccNumber) {
		this.bondAcccNumber = bondAcccNumber;
	}
	public String getCcExpiryDate() {
		return ccExpiryDate;
	}
	public void setCcExpiryDate(String ccExpiryDate) {
		this.ccExpiryDate = ccExpiryDate;
	}
	public String getCvvNumber() {
		return cvvNumber;
	}
	public void setCvvNumber(String cvvNumber) {
		this.cvvNumber = cvvNumber;
	}
	public String getCreditCardNo() {
		return creditCardNo;
	}
	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}
	public String getCashlessClaimType() {
		return cashlessClaimType;
	}
	public void setCashlessClaimType(String cashlessClaimType) {
		this.cashlessClaimType = cashlessClaimType;
	}
	public String getWoNo() {
		return woNo;
	}
	public void setWoNo(String woNo) {
		this.woNo = woNo;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getRejectionReason() {
		return rejectionReason;
	}
	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}
	public String getReferenceAmount() {
		return referenceAmount;
	}
	public void setReferenceAmount(String referenceAmount) {
		this.referenceAmount = referenceAmount;
	}
	public String getPrintLocation() {
		return printLocation;
	}
	public void setPrintLocation(String printLocation) {
		this.printLocation = printLocation;
	}
	public String getAccountCode() {
		return accountCode;
	}
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}
	public String getPaymentTransactionType() {
		return paymentTransactionType;
	}
	public void setPaymentTransactionType(String paymentTransactionType) {
		this.paymentTransactionType = paymentTransactionType;
	}
	public String getPaymentStateTDS() {
		return paymentStateTDS;
	}
	public void setPaymentStateTDS(String paymentStateTDS) {
		this.paymentStateTDS = paymentStateTDS;
	}
	public String getPayableAtTDS() {
		return payableAtTDS;
	}
	public void setPayableAtTDS(String payableAtTDS) {
		this.payableAtTDS = payableAtTDS;
	}
	public String getPrintLocationCodeTDS() {
		return printLocationCodeTDS;
	}
	public void setPrintLocationCodeTDS(String printLocationCodeTDS) {
		this.printLocationCodeTDS = printLocationCodeTDS;
	}
	public String getAccountCategoryCodeTDS() {
		return accountCategoryCodeTDS;
	}
	public void setAccountCategoryCodeTDS(String accountCategoryCodeTDS) {
		this.accountCategoryCodeTDS = accountCategoryCodeTDS;
	}
	public String getPrintLocationTDS() {
		return printLocationTDS;
	}
	public void setPrintLocationTDS(String printLocationTDS) {
		this.printLocationTDS = printLocationTDS;
	}
	public String getGstPercentage() {
		return gstPercentage;
	}
	public void setGstPercentage(String gstPercentage) {
		this.gstPercentage = gstPercentage;
	}
	
}
