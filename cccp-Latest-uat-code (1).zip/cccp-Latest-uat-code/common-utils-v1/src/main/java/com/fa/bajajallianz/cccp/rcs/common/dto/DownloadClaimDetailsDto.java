package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DownloadClaimDetailsDto implements Serializable {
	/**
	* 
	*/
	private Long id;
	private String causeOffLoss;
	private String claimNumber;
    private Date lossDate;
	private Date closingDate;
	private Date intimationDate;
	private Date registrationDate;
	private String howLossOccured;
	private String deficiencyReason;
	private String fraudAlert;
	private Double lossEstmatedValue;
	private Boolean isActive;
	private String subStatus;
	private String locationCode;
	private String eventCode;
	private String salvageStatus;
	private Date lossTime;
	private Double reserveAmount;
	private String policyNumber;
	private String insuredName;
	private String productCode;
	private String lob;
    private String partnerId;
    private String name;
	private Double sumInsured;
	private String stakeType;
	private String partyId;	
	private String claimHandlerId;
	private String status;
	


	private String claimHandlerName;

	private String lossAddress;

	private String intimationSource;

	private String reOpenRemarks;

	private String closingReason;


	private Date reOpenDate;


	private Date createdDate;

	private String createdBy;

	private Date modifiedDate;

	private String modifiedBy;

	private Boolean isAllowColChange;

	private String reasonForDelay;

	private Double settlementAmount;

	private String closingComment;

	private String fraudDetails;



	private String productName;


	private Date policyStartDate;

	private Long insuredMobileNo;

	private Long insuredAlternateMobileNo;

	private String emailId;

	private String landmark;

	private String city;

	private Date policyEndDate;



	public DownloadClaimDetailsDto(Long id, String causeOffLoss, String claimNumber, Date lossDate, Date closingDate,
			Date intimationDate, Date registrationDate, String howLossOccured, String deficiencyReason,
			String fraudAlert, Double lossEstmatedValue, Boolean isActive, String subStatus, String locationCode,
			String eventCode, String salvageStatus, Date lossTime, Double reserveAmount, String policyNumber,
			String insuredName, String productCode, String lob, String partnerId, String name, Double sumInsured,
			String stakeType, String partyId, String claimHandlerId,String status) {
		this.id = id;
		this.causeOffLoss = causeOffLoss;
		this.claimNumber = claimNumber;
		this.lossDate = lossDate;
		this.closingDate = closingDate;
		this.intimationDate = intimationDate;
		this.registrationDate = registrationDate;
		this.howLossOccured = howLossOccured;
		this.deficiencyReason = deficiencyReason;
		this.fraudAlert = fraudAlert;
		this.lossEstmatedValue = lossEstmatedValue;
		this.isActive = isActive;
		this.subStatus = subStatus;
		this.locationCode = locationCode;
		this.eventCode = eventCode;
		this.salvageStatus = salvageStatus;
		this.lossTime = lossTime;
		this.reserveAmount = reserveAmount;
		this.policyNumber = policyNumber;
		this.insuredName = insuredName;
		this.productCode = productCode;
		this.lob = lob;
		this.partnerId = partnerId;
		this.name = name;
		this.sumInsured = sumInsured;
		this.stakeType = stakeType;
		this.partyId = partyId;
		this.claimHandlerId = claimHandlerId;
		this.status= status;
	}

	public DownloadClaimDetailsDto() {
		// TODO Auto-generated constructor stub
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStakeType() {
		return stakeType;
	}

	public void setStakeType(String stakeType) {
		this.stakeType = stakeType;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClaimHandlerId() {
		return claimHandlerId;
	}

	public void setClaimHandlerId(String claimHandlerId) {
		this.claimHandlerId = claimHandlerId;
	}

	public String getClaimHandlerName() {
		return claimHandlerName;
	}

	public void setClaimHandlerName(String claimHandlerName) {
		this.claimHandlerName = claimHandlerName;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public Date getLossDate() {
		return lossDate;
	}

	public void setLossDate(Date lossDate) {
		this.lossDate = lossDate;
	}

	public String getLossAddress() {
		return lossAddress;
	}

	public void setLossAddress(String lossAddress) {
		this.lossAddress = lossAddress;
	}

	public String getCauseOffLoss() {
		return causeOffLoss;
	}

	public void setCauseOffLoss(String causeOffLoss) {
		this.causeOffLoss = causeOffLoss;
	}

	public Date getIntimationDate() {
		return intimationDate;
	}

	public void setIntimationDate(Date intimationDate) {
		this.intimationDate = intimationDate;
	}

	public Date getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getIntimationSource() {
		return intimationSource;
	}

	public void setIntimationSource(String intimationSource) {
		this.intimationSource = intimationSource;
	}

	public Date getLossTime() {
		return lossTime;
	}

	public void setLossTime(Date lossTime) {
		this.lossTime = lossTime;
	}

	public String getFraudAlert() {
		return fraudAlert;
	}

	public void setFraudAlert(String fraudAlert) {
		this.fraudAlert = fraudAlert;
	}

	public Double getReserveAmount() {
		return reserveAmount;
	}

	public void setReserveAmount(Double reserveAmount) {
		this.reserveAmount = reserveAmount;
	}

	public Double getLossEstmatedValue() {
		return lossEstmatedValue;
	}

	public void setLossEstmatedValue(Double lossEstmatedValue) {
		this.lossEstmatedValue = lossEstmatedValue;
	}

	public String getHowLossOccured() {
		return howLossOccured;
	}

	public void setHowLossOccured(String howLossOccured) {
		this.howLossOccured = howLossOccured;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public String getSalvageStatus() {
		return salvageStatus;
	}

	public void setSalvageStatus(String salvageStatus) {
		this.salvageStatus = salvageStatus;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getReOpenRemarks() {
		return reOpenRemarks;
	}

	public void setReOpenRemarks(String reOpenRemarks) {
		this.reOpenRemarks = reOpenRemarks;
	}

	public String getClosingReason() {
		return closingReason;
	}

	public void setClosingReason(String closingReason) {
		this.closingReason = closingReason;
	}

	public Date getClosingDate() {
		return closingDate;
	}

	public void setClosingDate(Date closingDate) {
		this.closingDate = closingDate;
	}

	public Date getReOpenDate() {
		return reOpenDate;
	}

	public void setReOpenDate(Date reOpenDate) {
		this.reOpenDate = reOpenDate;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Boolean getIsAllowColChange() {
		return isAllowColChange;
	}

	public void setIsAllowColChange(Boolean isAllowColChange) {
		this.isAllowColChange = isAllowColChange;
	}

	public String getReasonForDelay() {
		return reasonForDelay;
	}

	public void setReasonForDelay(String reasonForDelay) {
		this.reasonForDelay = reasonForDelay;
	}

	public Double getSettlementAmount() {
		return settlementAmount;
	}

	public void setSettlementAmount(Double settlementAmount) {
		this.settlementAmount = settlementAmount;
	}

	public String getClosingComment() {
		return closingComment;
	}

	public void setClosingComment(String closingComment) {
		this.closingComment = closingComment;
	}

	public String getFraudDetails() {
		return fraudDetails;
	}

	public void setFraudDetails(String fraudDetails) {
		this.fraudDetails = fraudDetails;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Date getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(Date policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public Long getInsuredMobileNo() {
		return insuredMobileNo;
	}

	public void setInsuredMobileNo(Long insuredMobileNo) {
		this.insuredMobileNo = insuredMobileNo;
	}

	public Long getInsuredAlternateMobileNo() {
		return insuredAlternateMobileNo;
	}

	public void setInsuredAlternateMobileNo(Long insuredAlternateMobileNo) {
		this.insuredAlternateMobileNo = insuredAlternateMobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Date getPolicyEndDate() {
		return policyEndDate;
	}

	public void setPolicyEndDate(Date policyEndDate) {
		this.policyEndDate = policyEndDate;
	}

	public Double getSumInsured() {
		return sumInsured;
	}

	public void setSumInsured(Double sumInsured) {
		this.sumInsured = sumInsured;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

}
