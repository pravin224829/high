package com.fa.bajajallianz.cccp.surveyor.common.dto;

import java.util.Date;

public class ReserveDetailsDto {

	  private Long id;
		private String claimNumber ;
		private Double paidAmount;
		private Double outstandingReserveAmount;
		private String partyCode;
		private String reserveType;
		private Double reserveAmount;
		private Boolean isActive;
		private Date createdDate;
		private String createdBy;
		private Date modifiedDate;
		private String modifiedBy;
		
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getClaimNumber() {
			return claimNumber;
		}
		public void setClaimNumber(String claimNumber) {
			this.claimNumber = claimNumber;
		}
		public Double getPaidAmount() {
			return paidAmount;
		}
		public void setPaidAmount(Double paidAmount) {
			this.paidAmount = paidAmount;
		}
		public Double getOutstandingReserveAmount() {
			return outstandingReserveAmount;
		}
		public void setOutstandingReserveAmount(Double outstandingReserveAmount) {
			this.outstandingReserveAmount = outstandingReserveAmount;
		}
		public String getPartyCode() {
			return partyCode;
		}
		public void setPartyCode(String partyCode) {
			this.partyCode = partyCode;
		}
		public String getReserveType() {
			return reserveType;
		}
		public void setReserveType(String reserveType) {
			this.reserveType = reserveType;
		}
		public Double getReserveAmount() {
			return reserveAmount;
		}
		public void setReserveAmount(Double reserveAmount) {
			this.reserveAmount = reserveAmount;
		}
		public Boolean getIsActive() {
			return isActive;
		}
		public void setIsActive(Boolean isActive) {
			this.isActive = isActive;
		}
		public Date getCreatedDate() {
			return createdDate;
		}
		public void setCreatedDate(Date createdDate) {
			this.createdDate = createdDate;
		}
		public String getCreatedBy() {
			return createdBy;
		}
		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}
		public Date getModifiedDate() {
			return modifiedDate;
		}
		public void setModifiedDate(Date modifiedDate) {
			this.modifiedDate = modifiedDate;
		}
		public String getModifiedBy() {
			return modifiedBy;
		}
		public void setModifiedBy(String modifiedBy) {
			this.modifiedBy = modifiedBy;
		}
		
		
}
