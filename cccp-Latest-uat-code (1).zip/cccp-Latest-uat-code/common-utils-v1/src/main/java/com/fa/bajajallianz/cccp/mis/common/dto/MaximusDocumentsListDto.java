package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.List;

public class MaximusDocumentsListDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<MaximusDocumentDetailsDto> documentDetail;

	public List<MaximusDocumentDetailsDto> getDocumentDetail() {
		return documentDetail;
	}

	public void setDocumentDetail(List<MaximusDocumentDetailsDto> documentDetail) {
		this.documentDetail = documentDetail;
	}

}
