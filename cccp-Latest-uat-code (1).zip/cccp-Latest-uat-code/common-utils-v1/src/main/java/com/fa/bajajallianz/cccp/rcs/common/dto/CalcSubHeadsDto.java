package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

public class CalcSubHeadsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private String code;
	private String name;
	private String objName;
	private String attributes;
	private String authorityCode;
	private String subCalcType;
	private String category;
	private Integer orderNo;
	private String boldString;
	private List<CalcHeadsAttributesDto> calcHeadsAttributes;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getAttributes() {
		return attributes;
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

	public String getAuthorityCode() {
		return authorityCode;
	}

	public void setAuthorityCode(String authorityCode) {
		this.authorityCode = authorityCode;
	}

	public String getSubCalcType() {
		return subCalcType;
	}

	public void setSubCalcType(String subCalcType) {
		this.subCalcType = subCalcType;
	}

	public List<CalcHeadsAttributesDto> getCalcHeadsAttributes() {
		return calcHeadsAttributes;
	}

	public void setCalcHeadsAttributes(List<CalcHeadsAttributesDto> calcHeadsAttributes) {
		this.calcHeadsAttributes = calcHeadsAttributes;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Integer getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}

	public String getBoldString() {
		return boldString;
	}

	public void setBoldString(String boldString) {
		this.boldString = boldString;
	}

}
