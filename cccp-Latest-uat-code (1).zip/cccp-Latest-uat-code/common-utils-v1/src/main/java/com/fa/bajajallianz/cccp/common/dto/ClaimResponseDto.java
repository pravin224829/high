package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimResponseDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private ClaimDetailsDto claimDetails;
	private ClaimDetailsListDto claimDetailsList;
	private List<ClaimDetailsListResponseDto> claimDetailsListResponse;

	public ClaimDetailsListDto getClaimDetailsList() {
		return claimDetailsList;
	}

	public void setClaimDetailsList(ClaimDetailsListDto claimDetailsList) {
		this.claimDetailsList = claimDetailsList;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private ApplicationErrorDto applicationError;

	public ClaimDetailsDto getClaimDetails() {
		return claimDetails;
	}

	public void setClaimDetails(ClaimDetailsDto claimDetails) {
		this.claimDetails = claimDetails;
	}

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public List<ClaimDetailsListResponseDto> getClaimDetailsListResponse() {
		return claimDetailsListResponse;
	}

	public void setClaimDetailsListResponse(List<ClaimDetailsListResponseDto> claimDetailsListResponse) {
		this.claimDetailsListResponse = claimDetailsListResponse;
	}

}
