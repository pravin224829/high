package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String policyNumber;
	private String insuredName;
	private String inspectionDate;
	private String expiryDate;
	private String productCode;
	private String productName;
	private String productDescription;
	private String imdChannel;
	private String sumInsured;
	private String policyStatus;
	private String lovType;
	private String agentCode;
	private String createdDate;
	private String claimNumber;
	private String claimHandler;
	private String pendingAge;
	private String lossReserveAmount;
	private String mainStatus;
	private String deficiencyReason;
	private String imdCode;
	private String subImdCode;
	private String telephoneNo;
	private String insuredAddress;
	private String partnerType;
	private String phiPartnerId;
	private String startDate;
	private String lineOfBusiness;
	private String coInsuranceType;
	private String imdName;
	private String subImdName;
	private String mobileNumber;
	private String city;
	private String panNumber;
	private String ckycStatus;
	private String policyEndDate;
	private String product;
	private String coInsuranceSharing;
	private String subImdChannel;
	private String emailId;
	private String pinCode;
	private String gstIn;
	private String neftStatus;
	private String explainHowLossOccured;
	private String customerLoyalityCategory;
	private String insuredProfileRating;
	private String lob;
	private String policyStartDate;
	private ApplicationErrorDto applicationError;
	private String insuredMobileNo;
	private String insuredAlternateMobileNo;
	private String landMark;
	private String telephone;

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getInspectionDate() {
		return inspectionDate;
	}

	public void setInspectionDate(String inspectionDate) {
		this.inspectionDate = inspectionDate;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getImdChannel() {
		return imdChannel;
	}

	public void setImdChannel(String imdChannel) {
		this.imdChannel = imdChannel;
	}

	public String getSumInsured() {
		return sumInsured;
	}

	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}

	public String getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getLovType() {
		return lovType;
	}

	public void setLovType(String lovType) {
		this.lovType = lovType;
	}

	public String getAgentCode() {
		return agentCode;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getClaimHandler() {
		return claimHandler;
	}

	public void setClaimHandler(String claimHandler) {
		this.claimHandler = claimHandler;
	}

	public String getPendingAge() {
		return pendingAge;
	}

	public void setPendingAge(String pendingAge) {
		this.pendingAge = pendingAge;
	}

	public String getLossReserveAmount() {
		return lossReserveAmount;
	}

	public void setLossReserveAmount(String lossReserveAmount) {
		this.lossReserveAmount = lossReserveAmount;
	}

	public String getMainStatus() {
		return mainStatus;
	}

	public void setMainStatus(String mainStatus) {
		this.mainStatus = mainStatus;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getImdCode() {
		return imdCode;
	}

	public void setImdCode(String imdCode) {
		this.imdCode = imdCode;
	}

	public String getSubImdCode() {
		return subImdCode;
	}

	public void setSubImdCode(String subImdCode) {
		this.subImdCode = subImdCode;
	}

	public String getInsuredAddress() {
		return insuredAddress;
	}

	public void setInsuredAddress(String insuredAddress) {
		this.insuredAddress = insuredAddress;
	}

	public String getPartnerType() {
		return partnerType;
	}

	public void setPartnerType(String partnerType) {
		this.partnerType = partnerType;
	}

	public String getPhiPartnerId() {
		return phiPartnerId;
	}

	public void setPhiPartnerId(String phiPartnerId) {
		this.phiPartnerId = phiPartnerId;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getCoInsuranceType() {
		return coInsuranceType;
	}

	public void setCoInsuranceType(String coInsuranceType) {
		this.coInsuranceType = coInsuranceType;
	}

	public String getImdName() {
		return imdName;
	}

	public void setImdName(String imdName) {
		this.imdName = imdName;
	}

	public String getSubImdName() {
		return subImdName;
	}

	public void setSubImdName(String subImdName) {
		this.subImdName = subImdName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getCkycStatus() {
		return ckycStatus;
	}

	public void setCkycStatus(String ckycStatus) {
		this.ckycStatus = ckycStatus;
	}

	public String getPolicyEndDate() {
		return policyEndDate;
	}

	public void setPolicyEndDate(String policyEndDate) {
		this.policyEndDate = policyEndDate;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getCoInsuranceSharing() {
		return coInsuranceSharing;
	}

	public void setCoInsuranceSharing(String coInsuranceSharing) {
		this.coInsuranceSharing = coInsuranceSharing;
	}

	public String getSubImdChannel() {
		return subImdChannel;
	}

	public void setSubImdChannel(String subImdChannel) {
		this.subImdChannel = subImdChannel;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getGstIn() {
		return gstIn;
	}

	public void setGstIn(String gstIn) {
		this.gstIn = gstIn;
	}

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public String getExplainHowLossOccured() {
		return explainHowLossOccured;
	}

	public void setExplainHowLossOccured(String explainHowLossOccured) {
		this.explainHowLossOccured = explainHowLossOccured;
	}

	public String getTelephoneNo() {
		return telephoneNo;
	}

	public void setTelephoneNo(String telephoneNo) {
		this.telephoneNo = telephoneNo;
	}

	public String getCustomerLoyalityCategory() {
		return customerLoyalityCategory;
	}

	public void setCustomerLoyalityCategory(String customerLoyalityCategory) {
		this.customerLoyalityCategory = customerLoyalityCategory;
	}

	public String getInsuredProfileRating() {
		return insuredProfileRating;
	}

	public void setInsuredProfileRating(String insuredProfileRating) {
		this.insuredProfileRating = insuredProfileRating;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(String policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public String getInsuredMobileNo() {
		return insuredMobileNo;
	}

	public void setInsuredMobileNo(String insuredMobileNo) {
		this.insuredMobileNo = insuredMobileNo;
	}

	public String getInsuredAlternateMobileNo() {
		return insuredAlternateMobileNo;
	}

	public void setInsuredAlternateMobileNo(String insuredAlternateMobileNo) {
		this.insuredAlternateMobileNo = insuredAlternateMobileNo;
	}

	public String getLandMark() {
		return landMark;
	}

	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

}
