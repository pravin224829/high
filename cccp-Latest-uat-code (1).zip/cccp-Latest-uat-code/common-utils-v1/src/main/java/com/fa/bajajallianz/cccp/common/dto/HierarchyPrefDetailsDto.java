package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;


public class HierarchyPrefDetailsDto implements Serializable{

	private static final long serialVersionUID = 1L;
	private Long id;
	private String code;
	private String teamName;
	private String position;
	private Long corporateId;
	private String isActive;
	private Date createdDate;
	private String createdBy;
	private Date modifiedDate;
	private String modifiedBy;
	private List<HierarchyPrefDetailsDto> hierarchyPrefDetails; 
	private List<UserHierarchyDto> userHierarchy;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public Long getCorporateId() {
		return corporateId;
	}
	public void setCorporateId(Long corporateId) {
		this.corporateId = corporateId;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public List<HierarchyPrefDetailsDto> getHierarchyPrefDetails() {
		return hierarchyPrefDetails;
	}
	public void setHierarchyPrefDetails(List<HierarchyPrefDetailsDto> hierarchyPrefDetails) {
		this.hierarchyPrefDetails = hierarchyPrefDetails;
	}
	public List<UserHierarchyDto> getUserHierarchy() {
		return userHierarchy;
	}
	public void setUserHierarchy(List<UserHierarchyDto> userHierarchy) {
		this.userHierarchy = userHierarchy;
	}
	
	
}
