/**
 * 
 */
package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimMisDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String claimNumber;
	private String claimbranch;
	private String claimStatus;
	private String policyNumber;
	private String intimationDate;
	private String lossDate;
	private String lossDesc;
	private List<MaximusClaimPartyDto> claimParty;
	private ClaimAttributeDto claimAttribute;
	private List<ClaimReserveDetailsDto> claimReserve;
	private ClaimEventFollowupDto claimEventFollowup;
	
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public String getClaimbranch() {
		return claimbranch;
	}
	public void setClaimbranch(String claimbranch) {
		this.claimbranch = claimbranch;
	}
	public String getClaimStatus() {
		return claimStatus;
	}
	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getIntimationDate() {
		return intimationDate;
	}
	public void setIntimationDate(String intimationDate) {
		this.intimationDate = intimationDate;
	}
	public String getLossDate() {
		return lossDate;
	}
	public void setLossDate(String lossDate) {
		this.lossDate = lossDate;
	}
	public List<MaximusClaimPartyDto> getClaimParty() {
		return claimParty;
	}
	public void setClaimParty(List<MaximusClaimPartyDto> claimParty) {
		this.claimParty = claimParty;
	}
	public ClaimAttributeDto getClaimAttribute() {
		return claimAttribute;
	}
	public void setClaimAttribute(ClaimAttributeDto claimAttribute) {
		this.claimAttribute = claimAttribute;
	}
	public List<ClaimReserveDetailsDto> getClaimReserve() {
		return claimReserve;
	}
	public void setClaimReserve(List<ClaimReserveDetailsDto> claimReserve) {
		this.claimReserve = claimReserve;
	}
	public String getLossDesc() {
		return lossDesc;
	}
	public void setLossDesc(String lossDesc) {
		this.lossDesc = lossDesc;
	}
	public ClaimEventFollowupDto getClaimEventFollowup() {
		return claimEventFollowup;
	}
	public void setClaimEventFollowup(ClaimEventFollowupDto claimEventFollowup) {
		this.claimEventFollowup = claimEventFollowup;
	}
	
}
