package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DocListDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String DocumentName;
	private String UploadDate;
	private String UploadStatus;

	public String getDocumentName() {
		return DocumentName;
	}

	public void setDocumentName(String documentName) {
		DocumentName = documentName;
	}

	public String getUploadDate() {
		return UploadDate;
	}

	public void setUploadDate(String uploadDate) {
		UploadDate = uploadDate;
	}

	public String getUploadStatus() {
		return UploadStatus;
	}

	public void setUploadStatus(String uploadStatus) {
		UploadStatus = uploadStatus;
	}

}
