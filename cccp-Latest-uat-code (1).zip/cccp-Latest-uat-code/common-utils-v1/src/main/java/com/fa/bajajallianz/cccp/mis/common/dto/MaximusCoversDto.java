package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.List;

public class MaximusCoversDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<MaximusCoverDetailsDto> coverDetails;

	public List<MaximusCoverDetailsDto> getCoverDetails() {
		return coverDetails;
	}

	public void setCoverDetails(List<MaximusCoverDetailsDto> coverDetails) {
		this.coverDetails = coverDetails;
	}
}
