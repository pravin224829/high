package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SurveryorInfoDtlsObj implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String reserveAmt;
	private String supplierId;
	private String partnerId;
	private String dateOfLoss;

	public String getReserveAmt() {
		return reserveAmt;
	}

	public void setReserveAmt(String reserveAmt) {
		this.reserveAmt = reserveAmt;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getDateOfLoss() {
		return dateOfLoss;
	}

	public void setDateOfLoss(String dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}

}
