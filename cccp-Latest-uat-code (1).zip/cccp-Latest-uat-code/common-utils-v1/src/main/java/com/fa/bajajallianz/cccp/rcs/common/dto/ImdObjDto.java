package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ImdObjDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String stringVal1;
	private String stringVal2;
	private String stringVal3;
	private String stringVal4;
	private String stringVal5;
	private String stringVal6;
	private String stringVal7;
	private String stringVal8;
	private String stringVal9;
	private String stringVal10;
	
	public String getStringVal1() {
		return stringVal1;
	}
	public void setStringVal1(String stringVal1) {
		this.stringVal1 = stringVal1;
	}
	public String getStringVal2() {
		return stringVal2;
	}
	public void setStringVal2(String stringVal2) {
		this.stringVal2 = stringVal2;
	}
	public String getStringVal3() {
		return stringVal3;
	}
	public void setStringVal3(String stringVal3) {
		this.stringVal3 = stringVal3;
	}
	public String getStringVal4() {
		return stringVal4;
	}
	public void setStringVal4(String stringVal4) {
		this.stringVal4 = stringVal4;
	}
	public String getStringVal5() {
		return stringVal5;
	}
	public void setStringVal5(String stringVal5) {
		this.stringVal5 = stringVal5;
	}
	public String getStringVal6() {
		return stringVal6;
	}
	public void setStringVal6(String stringVal6) {
		this.stringVal6 = stringVal6;
	}
	public String getStringVal7() {
		return stringVal7;
	}
	public void setStringVal7(String stringVal7) {
		this.stringVal7 = stringVal7;
	}
	public String getStringVal8() {
		return stringVal8;
	}
	public void setStringVal8(String stringVal8) {
		this.stringVal8 = stringVal8;
	}
	public String getStringVal9() {
		return stringVal9;
	}
	public void setStringVal9(String stringVal9) {
		this.stringVal9 = stringVal9;
	}
	public String getStringVal10() {
		return stringVal10;
	}
	public void setStringVal10(String stringVal10) {
		this.stringVal10 = stringVal10;
	}
	
	
}
