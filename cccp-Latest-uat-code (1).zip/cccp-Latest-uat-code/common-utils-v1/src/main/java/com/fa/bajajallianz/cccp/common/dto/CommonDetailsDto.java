package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fa.bajajallianz.cccp.rcs.common.dto.BenificiaryDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcParamValuesDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CkycDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimHandlerDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimPartiesDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CountryDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CoverCodeDtlsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.DdPaymentDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.DiaDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.DiaQuotationDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.DiaRequestDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.EndorsementDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.FdrPaymentDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.GeneralDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.GstDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.IlmClaimDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.IlmTriggerDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.InsuredCommunicationDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.IntermidiaryDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.PaymentDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.PaymentDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.TaskDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.WorkFlowDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.RcsClaimDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.RcsClaimantDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.RemittanceDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.RiskCoverDetailsDto;
import com.fa.bajajallianz.cccp.surveyor.common.dto.ClaimReviewDetailsDto;
import com.fa.bajajallianz.cccp.surveyor.common.dto.InsurerdBankDetailsDto;
import com.fa.bajajallianz.cccp.surveyor.common.dto.NeftDetails;
import com.fa.bajajallianz.cccp.surveyor.common.dto.ServiceRatingDetailsDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String userId;
	private String mobileNo;
	private String email;
	private String roleCode;
	private String pageCode;
	private String sectionCode;
	private String actionCode;
	private String invoiceNumber;
	private String claimNumber;
	private String docType;
	private String referenceType;
	private String templateType;
	private String source;
	private String documentName;
	private String partyId;
	private String productCode;
	private String currentStepId;
	private AppdetailsDto appDetails;
	private CommunicationDetailsDto communicationDetails;
	private SurveyDetailsDto surveyDetails;
	private InvoiceDetailsDto invoiceDetails;
	private String surveyorNo;
	private PanDetailsDto panDetails;
	private List<GstDetailsDto> gstpayable;
	private GSTDetailsDto gstDetails;
	private List<ClaimantDetailsDto> claimantDetails;
	private ServiceRatingDetailsDto serviceRatingDetails;
	private ClaimReviewDetailsDto claimReviewDetails;
	private NeftDetails neftDetails;
	private InsurerdBankDetailsDto insurerdBankDetails;
	private ClaimHistoryDto claimHistoryDetails;
	private String insuredName;
	private String subStatus;
	private String policyNumber;
	private Date createdDate;
	private GeneralDetailsDto generalDetails;
	private ClaimDetailsDto claimDetails;
	private RcsClaimDetailsDto rcsClaimDetails;
	private List<TaskDetailsDto> taskDetails;
	private List<CoverCodeDtlsDto> coverCodeDetails;
	private List<RiskCoverDetailsDto> riskCoverDetails;
	private List<WorkFlowDto> workflowDetails;
	private String causeOffLoss;
	private String status;
	private String lossTime;
	private RcsClaimDetailsDto lossEventDetails;
	private DiaDetailsDto basicDetails;
	private DiaRequestDetailsDto diaRequestDetails;


	public List<CoverCodeDtlsDto> getCoverCodeDetails() {
		return coverCodeDetails;
	}

	public void setCoverCodeDetails(List<CoverCodeDtlsDto> coverCodeDetails) {
		this.coverCodeDetails = coverCodeDetails;
	}

	private List<DiaQuotationDetailsDto> diaQuotationDetails;
	private List<CalcParamValuesDto> calcParamValues;
	private PolicyDetailsDto policyDetails;
	private ClaimHandlerDetailsDto claimHandlerDetails;
	private List<DocumentDto> documentDetails;
	private List<ClaimPartiesDetailsDto> claimParties;
	private InsuredCommunicationDetailsDto insuredCommunicationDetails;
	private RcsClaimantDetailsDto partyRespObjDto;
	private ApplicationErrorDto applicationError;
	private String pendingAge;
	private PaymentDetailsDto approvalReq;
	private FdrPaymentDetailsDto fDRpayment;
	private DdPaymentDetailsDto ddPaymentDetails;
	private String claimProcessId;
	private BenificiaryDetailsDto beneficiaryDetails;
	private IntermidiaryDetailsDto intermidiaryBankDetails;
	private RemittanceDetailsDto remittanceDetails;
	private String deficiencyReason;
	private List<PaymentDto> claimantDtlsList;
	private String claimHandlerUserId;
	private String paymentRefNo;
	private String paymentType;
	private Boolean finalSubmit;
	private String docVerifyHolderName;
	private List<AreaRequestDto> stateList;
	private List<AreaRequestDto> districtList;
	private String errorCode;
	private List<PaymentDto> paymentDtlsRespDto;
	private DiaDetailsDto diaDetails;
	private String userName;
	private String processFlag;
	private String causeoOfLossCode;
	private IlmClaimDetailsDto ilmclaimdetails;
	private List<IlmTriggerDetailsDto> triggerDetailsDto;
	private List<CkycDetailsDto> ckycdetailsList;
	private List<CountryDto> countryListDto;
	private String transactionType;
	private String purposeOfUse;
	private String descriptonOfAnimal;
	private String otherCompanyName;
	private String identification;
	private String noOfLactation;
	private String ageTermUnit;
	private String age;
	private String typeOfTag;
	private String rightHorn;
	private String leftHorn;
	private String tailSwitchColor;
	private String bodyColor;
	private String animalSex;
	private String breedName;
	private String otherSpecies;
	private String species;
	private String tagNumber;
	private String  riskSumInsured;
	private String claimMainStatus;
	private String claimSubStatus;

	public String getUserId() {
		return userId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getPageCode() {
		return pageCode;
	}

	public void setPageCode(String pageCode) {
		this.pageCode = pageCode;
	}

	public String getSectionCode() {
		return sectionCode;
	}

	public void setSectionCode(String sectionCode) {
		this.sectionCode = sectionCode;
	}

	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getReferenceType() {
		return referenceType;
	}

	public void setReferenceType(String referenceType) {
		this.referenceType = referenceType;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getCurrentStepId() {
		return currentStepId;
	}

	public void setCurrentStepId(String currentStepId) {
		this.currentStepId = currentStepId;
	}

	public AppdetailsDto getAppDetails() {
		return appDetails;
	}

	public void setAppDetails(AppdetailsDto appDetails) {
		this.appDetails = appDetails;
	}

	public CommunicationDetailsDto getCommunicationDetails() {
		return communicationDetails;
	}

	public void setCommunicationDetails(CommunicationDetailsDto communicationDetails) {
		this.communicationDetails = communicationDetails;
	}

	public SurveyDetailsDto getSurveyDetails() {
		return surveyDetails;
	}

	public void setSurveyDetails(SurveyDetailsDto surveyDetails) {
		this.surveyDetails = surveyDetails;
	}

	public InvoiceDetailsDto getInvoiceDetails() {
		return invoiceDetails;
	}

	public void setInvoiceDetails(InvoiceDetailsDto invoiceDetails) {
		this.invoiceDetails = invoiceDetails;
	}

	public String getSurveyorNo() {
		return surveyorNo;
	}

	public void setSurveyorNo(String surveyorNo) {
		this.surveyorNo = surveyorNo;
	}

	public PanDetailsDto getPanDetails() {
		return panDetails;
	}

	public void setPanDetails(PanDetailsDto panDetails) {
		this.panDetails = panDetails;
	}

//	public List<GSTDetailsDto> getGstDetails() {
//		return gstDetails;
//	}
//	public void setGstDetails(List<GSTDetailsDto> gstDetails) {
//		this.gstDetails = gstDetails;
//	}
	public List<ClaimantDetailsDto> getClaimantDetails() {
		return claimantDetails;
	}

	public void setClaimantDetails(List<ClaimantDetailsDto> claimantDetails) {
		this.claimantDetails = claimantDetails;
	}

	public ServiceRatingDetailsDto getServiceRatingDetails() {
		return serviceRatingDetails;
	}

	public void setServiceRatingDetails(ServiceRatingDetailsDto serviceRatingDetails) {
		this.serviceRatingDetails = serviceRatingDetails;
	}

	public ClaimReviewDetailsDto getClaimReviewDetails() {
		return claimReviewDetails;
	}

	public void setClaimReviewDetails(ClaimReviewDetailsDto claimReviewDetails) {
		this.claimReviewDetails = claimReviewDetails;
	}

	public NeftDetails getNeftDetails() {
		return neftDetails;
	}

	public void setNeftDetails(NeftDetails neftDetails) {
		this.neftDetails = neftDetails;
	}

	public InsurerdBankDetailsDto getInsurerdBankDetails() {
		return insurerdBankDetails;
	}

	public void setInsurerdBankDetails(InsurerdBankDetailsDto insurerdBankDetails) {
		this.insurerdBankDetails = insurerdBankDetails;
	}

	public ClaimHistoryDto getClaimHistoryDetails() {
		return claimHistoryDetails;
	}

	public void setClaimHistoryDetails(ClaimHistoryDto claimHistoryDetails) {
		this.claimHistoryDetails = claimHistoryDetails;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public GeneralDetailsDto getGeneralDetails() {
		return generalDetails;
	}

	public void setGeneralDetails(GeneralDetailsDto generalDetails) {
		this.generalDetails = generalDetails;
	}

	public ClaimDetailsDto getClaimDetails() {
		return claimDetails;
	}

	public void setClaimDetails(ClaimDetailsDto claimDetails) {
		this.claimDetails = claimDetails;
	}

	public RcsClaimDetailsDto getRcsClaimDetails() {
		return rcsClaimDetails;
	}

	public void setRcsClaimDetails(RcsClaimDetailsDto rcsClaimDetails) {
		this.rcsClaimDetails = rcsClaimDetails;
	}

	public List<TaskDetailsDto> getTaskDetails() {
		return taskDetails;
	}

	public void setTaskDetails(List<TaskDetailsDto> taskDetails) {
		this.taskDetails = taskDetails;
	}

	public List<WorkFlowDto> getWorkflowDetails() {
		return workflowDetails;
	}

	public void setWorkflowDetails(List<WorkFlowDto> workflowDetails) {
		this.workflowDetails = workflowDetails;
	}

	public String getCauseOffLoss() {
		return causeOffLoss;
	}

	public void setCauseOffLoss(String causeOffLoss) {
		this.causeOffLoss = causeOffLoss;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLossTime() {
		return lossTime;
	}

	public void setLossTime(String lossTime) {
		this.lossTime = lossTime;
	}

	public RcsClaimDetailsDto getLossEventDetails() {
		return lossEventDetails;
	}

	public void setLossEventDetails(RcsClaimDetailsDto lossEventDetails) {
		this.lossEventDetails = lossEventDetails;
	}

	public DiaDetailsDto getBasicDetails() {
		return basicDetails;
	}

	public void setBasicDetails(DiaDetailsDto basicDetails) {
		this.basicDetails = basicDetails;
	}

	public DiaRequestDetailsDto getDiaRequestDetails() {
		return diaRequestDetails;
	}

	public void setDiaRequestDetails(DiaRequestDetailsDto diaRequestDetails) {
		this.diaRequestDetails = diaRequestDetails;
	}

	public List<DiaQuotationDetailsDto> getDiaQuotationDetails() {
		return diaQuotationDetails;
	}

	public void setDiaQuotationDetails(List<DiaQuotationDetailsDto> diaQuotationDetails) {
		this.diaQuotationDetails = diaQuotationDetails;
	}

	public List<CalcParamValuesDto> getCalcParamValues() {
		return calcParamValues;
	}

	public void setCalcParamValues(List<CalcParamValuesDto> calcParamValues) {
		this.calcParamValues = calcParamValues;
	}

	public PolicyDetailsDto getPolicyDetails() {
		return policyDetails;
	}

	public void setPolicyDetails(PolicyDetailsDto policyDetails) {
		this.policyDetails = policyDetails;
	}

	public ClaimHandlerDetailsDto getClaimHandlerDetails() {
		return claimHandlerDetails;
	}

	public void setClaimHandlerDetails(ClaimHandlerDetailsDto claimHandlerDetails) {
		this.claimHandlerDetails = claimHandlerDetails;
	}

	public List<DocumentDto> getDocumentDetails() {
		return documentDetails;
	}

	public void setDocumentDetails(List<DocumentDto> documentDetails) {
		this.documentDetails = documentDetails;
	}

	public List<ClaimPartiesDetailsDto> getClaimParties() {
		return claimParties;
	}

	public void setClaimParties(List<ClaimPartiesDetailsDto> claimParties) {
		this.claimParties = claimParties;
	}

	public InsuredCommunicationDetailsDto getInsuredCommunicationDetails() {
		return insuredCommunicationDetails;
	}

	public void setInsuredCommunicationDetails(InsuredCommunicationDetailsDto insuredCommunicationDetails) {
		this.insuredCommunicationDetails = insuredCommunicationDetails;
	}

	public RcsClaimantDetailsDto getPartyRespObjDto() {
		return partyRespObjDto;
	}

	public void setPartyRespObjDto(RcsClaimantDetailsDto partyRespObjDto) {
		this.partyRespObjDto = partyRespObjDto;
	}

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public String getPendingAge() {
		return pendingAge;
	}

	public void setPendingAge(String pendingAge) {
		this.pendingAge = pendingAge;
	}

	public PaymentDetailsDto getApprovalReq() {
		return approvalReq;
	}

	public void setApprovalReq(PaymentDetailsDto approvalReq) {
		this.approvalReq = approvalReq;
	}

	public FdrPaymentDetailsDto getfDRpayment() {
		return fDRpayment;
	}

	public void setfDRpayment(FdrPaymentDetailsDto fDRpayment) {
		this.fDRpayment = fDRpayment;
	}

	public DdPaymentDetailsDto getDdPaymentDetails() {
		return ddPaymentDetails;
	}

	public void setDdPaymentDetails(DdPaymentDetailsDto ddPaymentDetails) {
		this.ddPaymentDetails = ddPaymentDetails;
	}

	public String getClaimProcessId() {
		return claimProcessId;
	}

	public void setClaimProcessId(String claimProcessId) {
		this.claimProcessId = claimProcessId;
	}

	public BenificiaryDetailsDto getBeneficiaryDetails() {
		return beneficiaryDetails;
	}

	public void setBeneficiaryDetails(BenificiaryDetailsDto beneficiaryDetails) {
		this.beneficiaryDetails = beneficiaryDetails;
	}

	public IntermidiaryDetailsDto getIntermidiaryBankDetails() {
		return intermidiaryBankDetails;
	}

	public void setIntermidiaryBankDetails(IntermidiaryDetailsDto intermidiaryBankDetails) {
		this.intermidiaryBankDetails = intermidiaryBankDetails;
	}

	public RemittanceDetailsDto getRemittanceDetails() {
		return remittanceDetails;
	}

	public void setRemittanceDetails(RemittanceDetailsDto remittanceDetails) {
		this.remittanceDetails = remittanceDetails;
	}

	public GSTDetailsDto getGstDetails() {
		return gstDetails;
	}

	public void setGstDetails(GSTDetailsDto gstDetails) {
		this.gstDetails = gstDetails;
	}

	public List<GstDetailsDto> getGstpayable() {
		return gstpayable;
	}

	public void setGstpayable(List<GstDetailsDto> gstpayable) {
		this.gstpayable = gstpayable;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<PaymentDto> getClaimantDtlsList() {
		return claimantDtlsList;
	}

	public void setClaimantDtlsList(List<PaymentDto> claimantDtlsList) {
		this.claimantDtlsList = claimantDtlsList;
	}

	public String getClaimHandlerUserId() {
		return claimHandlerUserId;
	}

	public void setClaimHandlerUserId(String claimHandlerUserId) {
		this.claimHandlerUserId = claimHandlerUserId;
	}

	public String getPaymentRefNo() {
		return paymentRefNo;
	}

	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public Boolean getFinalSubmit() {
		return finalSubmit;
	}

	public void setFinalSubmit(Boolean finalSubmit) {
		this.finalSubmit = finalSubmit;
	}

	public String getDocVerifyHolderName() {
		return docVerifyHolderName;
	}

	public void setDocVerifyHolderName(String docVerifyHolderName) {
		this.docVerifyHolderName = docVerifyHolderName;
	}

	public List<AreaRequestDto> getStateList() {
		return stateList;
	}

	public void setStateList(List<AreaRequestDto> stateList) {
		this.stateList = stateList;
	}

	public List<AreaRequestDto> getDistrictList() {
		return districtList;
	}

	public void setDistrictList(List<AreaRequestDto> districtList) {
		this.districtList = districtList;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public List<PaymentDto> getPaymentDtlsRespDto() {
		return paymentDtlsRespDto;
	}

	public void setPaymentDtlsRespDto(List<PaymentDto> paymentDtlsRespDto) {
		this.paymentDtlsRespDto = paymentDtlsRespDto;
	}

	public DiaDetailsDto getDiaDetails() {
		return diaDetails;
	}

	public void setDiaDetails(DiaDetailsDto diaDetails) {
		this.diaDetails = diaDetails;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getProcessFlag() {
		return processFlag;
	}

	public void setProcessFlag(String processFlag) {
		this.processFlag = processFlag;
	}

	public IlmClaimDetailsDto getIlmclaimdetails() {
		return ilmclaimdetails;
	}

	public void setIlmclaimdetails(IlmClaimDetailsDto ilmclaimdetails) {
		this.ilmclaimdetails = ilmclaimdetails;
	}

	public List<IlmTriggerDetailsDto> getTriggerDetailsDto() {
		return triggerDetailsDto;
	}

	public void setTriggerDetailsDto(List<IlmTriggerDetailsDto> triggerDetailsDto) {
		this.triggerDetailsDto = triggerDetailsDto;
	}

	public List<CkycDetailsDto> getCkycdetailsList() {
		return ckycdetailsList;
	}

	public void setCkycdetailsList(List<CkycDetailsDto> ckycdetailsList) {
		this.ckycdetailsList = ckycdetailsList;
	}

	public List<CountryDto> getCountryListDto() {
		return countryListDto;
	}

	public void setCountryListDto(List<CountryDto> countryListDto) {
		this.countryListDto = countryListDto;
	}

	public String getCauseoOfLossCode() {
		return causeoOfLossCode;
	}

	public void setCauseoOfLossCode(String causeoOfLossCode) {
		this.causeoOfLossCode = causeoOfLossCode;
	}

	public String getPurposeOfUse() {
		return purposeOfUse;
	}

	public void setPurposeOfUse(String purposeOfUse) {
		this.purposeOfUse = purposeOfUse;
	}

	public String getDescriptonOfAnimal() {
		return descriptonOfAnimal;
	}

	public void setDescriptonOfAnimal(String descriptonOfAnimal) {
		this.descriptonOfAnimal = descriptonOfAnimal;
	}

	public String getOtherCompanyName() {
		return otherCompanyName;
	}

	public void setOtherCompanyName(String otherCompanyName) {
		this.otherCompanyName = otherCompanyName;
	}

	public String getIdentification() {
		return identification;
	}

	public void setIdentification(String identification) {
		this.identification = identification;
	}

	public String getNoOfLactation() {
		return noOfLactation;
	}

	public void setNoOfLactation(String noOfLactation) {
		this.noOfLactation = noOfLactation;
	}

	public String getAgeTermUnit() {
		return ageTermUnit;
	}

	public void setAgeTermUnit(String ageTermUnit) {
		this.ageTermUnit = ageTermUnit;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getTypeOfTag() {
		return typeOfTag;
	}

	public void setTypeOfTag(String typeOfTag) {
		this.typeOfTag = typeOfTag;
	}

	public String getRightHorn() {
		return rightHorn;
	}

	public void setRightHorn(String rightHorn) {
		this.rightHorn = rightHorn;
	}

	public String getLeftHorn() {
		return leftHorn;
	}

	public void setLeftHorn(String leftHorn) {
		this.leftHorn = leftHorn;
	}

	public String getTailSwitchColor() {
		return tailSwitchColor;
	}

	public void setTailSwitchColor(String tailSwitchColor) {
		this.tailSwitchColor = tailSwitchColor;
	}

	public String getBodyColor() {
		return bodyColor;
	}

	public void setBodyColor(String bodyColor) {
		this.bodyColor = bodyColor;
	}

	public String getAnimalSex() {
		return animalSex;
	}

	public void setAnimalSex(String animalSex) {
		this.animalSex = animalSex;
	}

	public String getBreedName() {
		return breedName;
	}

	public void setBreedName(String breedName) {
		this.breedName = breedName;
	}

	public String getOtherSpecies() {
		return otherSpecies;
	}

	public void setOtherSpecies(String otherSpecies) {
		this.otherSpecies = otherSpecies;
	}

	public String getSpecies() {
		return species;
	}

	public void setSpecies(String species) {
		this.species = species;
	}

	public String getTagNumber() {
		return tagNumber;
	}

	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}

	public List<RiskCoverDetailsDto> getRiskCoverDetails() {
		return riskCoverDetails;
	}

	public void setRiskCoverDetails(List<RiskCoverDetailsDto> riskCoverDetails) {
		this.riskCoverDetails = riskCoverDetails;
	}

	public String getRiskSumInsured() {
		return riskSumInsured;
	}

	public void setRiskSumInsured(String riskSumInsured) {
		this.riskSumInsured = riskSumInsured;
	}

	public String getClaimMainStatus() {
		return claimMainStatus;
	}

	public void setClaimMainStatus(String claimMainStatus) {
		this.claimMainStatus = claimMainStatus;
	}

	public String getClaimSubStatus() {
		return claimSubStatus;
	}

	public void setClaimSubStatus(String claimSubStatus) {
		this.claimSubStatus = claimSubStatus;
	}
	
	
}