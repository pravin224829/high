package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fa.bajajallianz.cccp.common.dto.CalcConditionValuesDto;

public class CalcConditionsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String code;

	private String fieldCode;

	private Double lowerLimit;

	private Double upperLimit;

	private Double staticAmount;

	private Double amount;

	private Double balanceCalcAmount;

	private Double percentage;

	private Boolean isBalCalcApply;

	private String categoryValue;

	private String categoryValueOne;

	private Boolean isConditional;

	private String conditionalValue;

	private String conditionalValueType;

	private String sourceField;

	private String sourceField2;

	private String operand;

	private List<CalcConditionValuesDto> calcConditionValues;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getFieldCode() {
		return fieldCode;
	}

	public void setFieldCode(String fieldCode) {
		this.fieldCode = fieldCode;
	}

	public Double getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(Double lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	public Double getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(Double upperLimit) {
		this.upperLimit = upperLimit;
	}

	public Double getStaticAmount() {
		return staticAmount;
	}

	public void setStaticAmount(Double staticAmount) {
		this.staticAmount = staticAmount;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Double getBalanceCalcAmount() {
		return balanceCalcAmount;
	}

	public void setBalanceCalcAmount(Double balanceCalcAmount) {
		this.balanceCalcAmount = balanceCalcAmount;
	}

	public Double getPercentage() {
		return percentage;
	}

	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}

	public Boolean getIsBalCalcApply() {
		return isBalCalcApply;
	}

	public void setIsBalCalcApply(Boolean isBalCalcApply) {
		this.isBalCalcApply = isBalCalcApply;
	}

	public String getCategoryValue() {
		return categoryValue;
	}

	public void setCategoryValue(String categoryValue) {
		this.categoryValue = categoryValue;
	}

	public String getCategoryValueOne() {
		return categoryValueOne;
	}

	public void setCategoryValueOne(String categoryValueOne) {
		this.categoryValueOne = categoryValueOne;
	}

	public Boolean getIsConditional() {
		return isConditional;
	}

	public void setIsConditional(Boolean isConditional) {
		this.isConditional = isConditional;
	}

	public String getConditionalValue() {
		return conditionalValue;
	}

	public void setConditionalValue(String conditionalValue) {
		this.conditionalValue = conditionalValue;
	}

	public String getConditionalValueType() {
		return conditionalValueType;
	}

	public void setConditionalValueType(String conditionalValueType) {
		this.conditionalValueType = conditionalValueType;
	}

	public String getSourceField() {
		return sourceField;
	}

	public void setSourceField(String sourceField) {
		this.sourceField = sourceField;
	}

	public String getOperand() {
		return operand;
	}

	public void setOperand(String operand) {
		this.operand = operand;
	}

	public String getSourceField2() {
		return sourceField2;
	}

	public void setSourceField2(String sourceField2) {
		this.sourceField2 = sourceField2;
	}

	public List<CalcConditionValuesDto> getCalcConditionValues() {
		return calcConditionValues;
	}

	public void setCalcConditionValues(List<CalcConditionValuesDto> calcConditionValues) {
		this.calcConditionValues = calcConditionValues;
	}

}
