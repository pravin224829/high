package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.Date;

public class ClaimHistoryDto implements Serializable {
private static final long serialVersionUID = 1L;

private String claimNumber;
private String policyNumber;
private Date registrationDate;
private String causeOffLoss;
private String status;
private String subStatus;
private String insuredName;
private String lossDate;

public String getClaimNumber() {
	return claimNumber;
}
public void setClaimNumber(String claimNumber) {
	this.claimNumber = claimNumber;
}
public String getPolicyNumber() {
	return policyNumber;
}
public void setPolicyNumber(String policyNumber) {
	this.policyNumber = policyNumber;
}
public Date getRegistrationDate() {
	return registrationDate;
}
public void setRegistrationDate(Date registrationDate) {
	this.registrationDate = registrationDate;
}
public String getCauseOffLoss() {
	return causeOffLoss;
}
public void setCauseOffLoss(String causeOffLoss) {
	this.causeOffLoss = causeOffLoss;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getSubStatus() {
	return subStatus;
}
public void setSubStatus(String subStatus) {
	this.subStatus = subStatus;
}
public String getInsuredName() {
	return insuredName;
}
public void setInsuredName(String insuredName) {
	this.insuredName = insuredName;
}
public String getLossDate() {
	return lossDate;
}
public void setLossDate(String lossDate) {
	this.lossDate = lossDate;
}


}
