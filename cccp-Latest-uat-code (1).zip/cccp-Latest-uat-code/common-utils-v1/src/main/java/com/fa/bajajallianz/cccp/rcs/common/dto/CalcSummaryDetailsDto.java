package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.Date;


public class CalcSummaryDetailsDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String claimNumber;

	private String supplierId;
	
	private String partyId;
	
	private String calculatedNetAmount;
	
	private String calculatedGstAmount;
	
	private String totalCalculatedAmount;
	
	private String allowedNetAmount;
	
	private String allowedGstAmount;
	
	private String totalAllowedAmount;
	
	private String remarks;
	
	private Boolean isGSTApplicable;
	
	private Boolean isActive;

	private Date createdDate;

	private String createdBy;

	private Date modifiedDate;

	private String modifiedBy;

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getCalculatedNetAmount() {
		return calculatedNetAmount;
	}

	public void setCalculatedNetAmount(String calculatedNetAmount) {
		this.calculatedNetAmount = calculatedNetAmount;
	}

	public String getCalculatedGstAmount() {
		return calculatedGstAmount;
	}

	public void setCalculatedGstAmount(String calculatedGstAmount) {
		this.calculatedGstAmount = calculatedGstAmount;
	}

	public String getTotalCalculatedAmount() {
		return totalCalculatedAmount;
	}

	public void setTotalCalculatedAmount(String totalCalculatedAmount) {
		this.totalCalculatedAmount = totalCalculatedAmount;
	}

	public String getAllowedNetAmount() {
		return allowedNetAmount;
	}

	public void setAllowedNetAmount(String allowedNetAmount) {
		this.allowedNetAmount = allowedNetAmount;
	}

	public String getAllowedGstAmount() {
		return allowedGstAmount;
	}

	public void setAllowedGstAmount(String allowedGstAmount) {
		this.allowedGstAmount = allowedGstAmount;
	}

	public String getTotalAllowedAmount() {
		return totalAllowedAmount;
	}

	public void setTotalAllowedAmount(String totalAllowedAmount) {
		this.totalAllowedAmount = totalAllowedAmount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	
	public Boolean getIsGSTApplicable() {
		return isGSTApplicable;
	}

	public void setIsGSTApplicable(Boolean isGSTApplicable) {
		this.isGSTApplicable = isGSTApplicable;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
