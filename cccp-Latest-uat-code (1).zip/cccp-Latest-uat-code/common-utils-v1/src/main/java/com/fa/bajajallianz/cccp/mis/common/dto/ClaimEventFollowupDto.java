/**
 * 
 */
package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimEventFollowupDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<ClaimEventFollowupDetails> claimEventFollowupDetails;

	public List<ClaimEventFollowupDetails> getClaimEventFollowupDetails() {
		return claimEventFollowupDetails;
	}

	public void setClaimEventFollowupDetails(List<ClaimEventFollowupDetails> claimEventFollowupDetails) {
		this.claimEventFollowupDetails = claimEventFollowupDetails;
	}
	
	

}
