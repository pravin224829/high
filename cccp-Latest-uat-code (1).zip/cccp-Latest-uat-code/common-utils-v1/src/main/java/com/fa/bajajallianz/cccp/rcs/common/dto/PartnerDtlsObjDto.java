package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PartnerDtlsObjDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String extnCol4;
	private String extnCol1;
	private String extnCol2;
	private String extnCol3;
	private String ecsStatus;
	
	public String getEcsStatus() {
		return ecsStatus;
	}
	public void setEcsStatus(String ecsStatus) {
		this.ecsStatus = ecsStatus;
	}
	public String getExtnCol4() {
		return extnCol4;
	}
	public void setExtnCol4(String extnCol4) {
		this.extnCol4 = extnCol4;
	}
	public String getExtnCol1() {
		return extnCol1;
	}
	public void setExtnCol1(String extnCol1) {
		this.extnCol1 = extnCol1;
	}
	public String getExtnCol2() {
		return extnCol2;
	}
	public void setExtnCol2(String extnCol2) {
		this.extnCol2 = extnCol2;
	}
	public String getExtnCol3() {
		return extnCol3;
	}
	public void setExtnCol3(String extnCol3) {
		this.extnCol3 = extnCol3;
	}
	
}
