package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

/**
 * @author arul
 *
 */
public class RcsClaimantDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String customerType;
	private String proposerName;
	private String firstName;
	private String middleName;
	private String lastName;
	private String gender;
	private String dob;
	private String houseNo;
	private String streetName;
	private String area;
	private String pincode;
	private String country;
	private String telephoneNumber;
	private String maritalStatus;
	private String employeeStatus;
	private String emailId;
	private String faxNumber;
	private String mobileNumber;
	private String partyCode;
	private String claimNumber;
	private String subType;
	private Boolean isActive;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private RcsBankDetailsDto bankDetailsDto;
	private String address;
	private String city;
	private String partnerType;
	private String panNumber;
	private String gstNumber;
	private String ckycStatus;
	private String policyNumber;
	private String lossReserveAmount;
	private String lossReserveBand;
	private String customerLoyalityCategory;
	private String policyStartDate;
	private String policyEndDate;
	private String insuredProfileRating;
	private String alternateNumber;
	private String customerEmailId;
	private String telephone1;
	private String insuredAddress;
	private String phiPartnerId;
	private String pinCode;
	private String gstIn;
	private String neftStatus;
	private String recordSeleted;
	private String partnerAs;
	private String id;
	private String placeOfLoss;
	private String state;
	private String estimateLossAmount;
	private String lossApprovalDate;
	private String closingClaimDate;
	private String claimReopenDate;
	private String sr;
	private String customerName;
	private String dateOfbirth;
	private String landmark;



	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getProposerName() {
		return proposerName;
	}

	public void setProposerName(String proposerName) {
		this.proposerName = proposerName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getEmployeeStatus() {
		return employeeStatus;
	}

	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public RcsBankDetailsDto getBankDetailsDto() {
		return bankDetailsDto;
	}

	public void setBankDetailsDto(RcsBankDetailsDto bankDetailsDto) {
		this.bankDetailsDto = bankDetailsDto;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPartnerType() {
		return partnerType;
	}

	public void setPartnerType(String partnerType) {
		this.partnerType = partnerType;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public String getCkycStatus() {
		return ckycStatus;
	}

	public void setCkycStatus(String ckycStatus) {
		this.ckycStatus = ckycStatus;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getLossReserveAmount() {
		return lossReserveAmount;
	}

	public void setLossReserveAmount(String lossReserveAmount) {
		this.lossReserveAmount = lossReserveAmount;
	}

	public String getLossReserveBand() {
		return lossReserveBand;
	}

	public void setLossReserveBand(String lossReserveBand) {
		this.lossReserveBand = lossReserveBand;
	}

	public String getCustomerLoyalityCategory() {
		return customerLoyalityCategory;
	}

	public void setCustomerLoyalityCategory(String customerLoyalityCategory) {
		this.customerLoyalityCategory = customerLoyalityCategory;
	}

	public String getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(String policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public String getPolicyEndDate() {
		return policyEndDate;
	}

	public void setPolicyEndDate(String policyEndDate) {
		this.policyEndDate = policyEndDate;
	}

	public String getInsuredProfileRating() {
		return insuredProfileRating;
	}

	public void setInsuredProfileRating(String insuredProfileRating) {
		this.insuredProfileRating = insuredProfileRating;
	}

	public String getAlternateNumber() {
		return alternateNumber;
	}

	public void setAlternateNumber(String alternateNumber) {
		this.alternateNumber = alternateNumber;
	}

	public String getCustomerEmailId() {
		return customerEmailId;
	}

	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}

	public String getTelephone1() {
		return telephone1;
	}

	public void setTelephone1(String telephone1) {
		this.telephone1 = telephone1;
	}

	public String getInsuredAddress() {
		return insuredAddress;
	}

	public void setInsuredAddress(String insuredAddress) {
		this.insuredAddress = insuredAddress;
	}

	public String getPhiPartnerId() {
		return phiPartnerId;
	}

	public void setPhiPartnerId(String phiPartnerId) {
		this.phiPartnerId = phiPartnerId;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getGstIn() {
		return gstIn;
	}

	public void setGstIn(String gstIn) {
		this.gstIn = gstIn;
	}

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	
	public String getRecordSeleted() {
		return recordSeleted;
	}

	public void setRecordSeleted(String recordSeleted) {
		this.recordSeleted = recordSeleted;
	}

	public String getPartnerAs() {
		return partnerAs;
	}

	public void setPartnerAs(String partnerAs) {
		this.partnerAs = partnerAs;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPlaceOfLoss() {
		return placeOfLoss;
	}

	public void setPlaceOfLoss(String placeOfLoss) {
		this.placeOfLoss = placeOfLoss;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getEstimateLossAmount() {
		return estimateLossAmount;
	}

	public void setEstimateLossAmount(String estimateLossAmount) {
		this.estimateLossAmount = estimateLossAmount;
	}

	public String getLossApprovalDate() {
		return lossApprovalDate;
	}

	public void setLossApprovalDate(String lossApprovalDate) {
		this.lossApprovalDate = lossApprovalDate;
	}

	public String getClosingClaimDate() {
		return closingClaimDate;
	}

	public void setClosingClaimDate(String closingClaimDate) {
		this.closingClaimDate = closingClaimDate;
	}

	public String getClaimReopenDate() {
		return claimReopenDate;
	}

	public void setClaimReopenDate(String claimReopenDate) {
		this.claimReopenDate = claimReopenDate;
	}

	public String getSr() {
		return sr;
	}

	public void setSr(String sr) {
		this.sr = sr;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getDateOfbirth() {
		return dateOfbirth;
	}

	public void setDateOfbirth(String dateOfbirth) {
		this.dateOfbirth = dateOfbirth;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

}
