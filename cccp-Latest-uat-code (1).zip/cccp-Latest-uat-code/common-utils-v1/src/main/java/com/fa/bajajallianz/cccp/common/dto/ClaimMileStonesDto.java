/**
 * 
 */
package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

/**
 * @author arul
 *
 */
public class ClaimMileStonesDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String name;
	private String code;
	private String description;
	private Boolean isActive;
	private String requestType;
	private String subRequestType;
	private String orderNo;
	private String createdDate;
	private String modifiedDate;
	private String mileStonesCode;
	private String mileStonesName;
	private String order;
	private List<LookUpValuesDto> lookUpValuesdto;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getSubRequestType() {
		return subRequestType;
	}

	public void setSubRequestType(String subRequestType) {
		this.subRequestType = subRequestType;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public List<LookUpValuesDto> getLookUpValuesdto() {
		return lookUpValuesdto;
	}

	public void setLookUpValuesdto(List<LookUpValuesDto> lookUpValuesdto) {
		this.lookUpValuesdto = lookUpValuesdto;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getMileStonesCode() {
		return mileStonesCode;
	}

	public void setMileStonesCode(String mileStonesCode) {
		this.mileStonesCode = mileStonesCode;
	}

	public String getMileStonesName() {
		return mileStonesName;
	}

	public void setMileStonesName(String mileStonesName) {
		this.mileStonesName = mileStonesName;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

}
