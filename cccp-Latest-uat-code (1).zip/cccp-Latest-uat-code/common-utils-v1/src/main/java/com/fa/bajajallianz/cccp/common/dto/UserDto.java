package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fa.bajajallianz.cccp.surveyor.common.dto.SurveyorDetailsDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long id;
	private String userId;
	private String userSearchId;
	private String email;
	private String firstName;
	private String lastName;
	private Boolean isActive;
	private Boolean isEnableSiteTutorial;
	private Long mobileNo;
	private String mobile;
	private Integer notifyUnreadCount;
	private Date dob;
	private String gender;
	private String deviceId;
	private String mPin;
	private Date createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private List<AddressDto> address;
	private List<RoleDto> roles;
	private List<MenuPagesDto> menupages;
	private List<AccessDetailsDto> accessDetails;
	private String userName;
	private String partnerId;
	private String partnerStatus;
	private String corporateId;
	private String corporateName;
	private String businessLogo;
	private String policyNumber;
	private String corporateUserId;
	private String userIsActive;
	private String imdCode;
	private String policyNo;
	private String roleCode;
	private String notifyCount;
	private String orgType;
	private String code;
	private String value;
	private List<String> userNameList;
	private List<String> locationCodeList;
	private PartiesDto parties; 
	private String locationCode;
//	private SurveyorDetailsDto surveyorDetails;
	private SurveyorDetailsDto resDto;
	private String locationName;
	private String profileLogo;
	private String designation;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean getIsEnableSiteTutorial() {
		return isEnableSiteTutorial;
	}

	public void setIsEnableSiteTutorial(Boolean isEnableSiteTutorial) {
		this.isEnableSiteTutorial = isEnableSiteTutorial;
	}

	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Integer getNotifyUnreadCount() {
		return notifyUnreadCount;
	}

	public void setNotifyUnreadCount(Integer notifyUnreadCount) {
		this.notifyUnreadCount = notifyUnreadCount;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public List<AddressDto> getAddress() {
		return address;
	}

	public void setAddress(List<AddressDto> address) {
		this.address = address;
	}

	public List<RoleDto> getRoles() {
		return roles;
	}

	public void setRoles(List<RoleDto> roles) {
		this.roles = roles;
	}

	public List<MenuPagesDto> getMenupages() {
		return menupages;
	}

	public void setMenupages(List<MenuPagesDto> menupages) {
		this.menupages = menupages;
	}

	public List<AccessDetailsDto> getAccessDetails() {
		return accessDetails;
	}

	public void setAccessDetails(List<AccessDetailsDto> accessDetails) {
		this.accessDetails = accessDetails;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getPartnerStatus() {
		return partnerStatus;
	}

	public void setPartnerStatus(String partnerStatus) {
		this.partnerStatus = partnerStatus;
	}

	public String getCorporateId() {
		return corporateId;
	}

	public void setCorporateId(String corporateId) {
		this.corporateId = corporateId;
	}

	public String getCorporateName() {
		return corporateName;
	}

	public void setCorporateName(String corporateName) {
		this.corporateName = corporateName;
	}

	public String getCorporateUserId() {
		return corporateUserId;
	}

	public void setCorporateUserId(String corporateUserId) {
		this.corporateUserId = corporateUserId;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getUserSearchId() {
		return userSearchId;
	}

	public void setUserSearchId(String userSearchId) {
		this.userSearchId = userSearchId;
	}

	public String getUserIsActive() {
		return userIsActive;
	}

	public void setUserIsActive(String userIsActive) {
		this.userIsActive = userIsActive;
	}

	public String getImdCode() {
		return imdCode;
	}

	public void setImdCode(String imdCode) {
		this.imdCode = imdCode;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getBusinessLogo() {
		return businessLogo;
	}

	public void setBusinessLogo(String businessLogo) {
		this.businessLogo = businessLogo;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getNotifyCount() {
		return notifyCount;
	}

	public void setNotifyCount(String notifyCount) {
		this.notifyCount = notifyCount;
	}

	public String getOrgType() {
		return orgType;
	}

	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public List<String> getUserNameList() {
		return userNameList;
	}

	public void setUserNameList(List<String> userNameList) {
		this.userNameList = userNameList;
	}

	public PartiesDto getParties() {
		return parties;
	}

	public void setParties(PartiesDto parties) {
		this.parties = parties;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public SurveyorDetailsDto getResDto() {
		return resDto;
	}

	public void setResDto(SurveyorDetailsDto resDto) {
		this.resDto = resDto;
	}

	public List<String> getLocationCodeList() {
		return locationCodeList;
	}

	public void setLocationCodeList(List<String> locationCodeList) {
		this.locationCodeList = locationCodeList;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getProfileLogo() {
		return profileLogo;
	}

	public void setProfileLogo(String profileLogo) {
		this.profileLogo = profileLogo;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getmPin() {
		return mPin;
	}

	public void setmPin(String mPin) {
		this.mPin = mPin;
	}

	
}
