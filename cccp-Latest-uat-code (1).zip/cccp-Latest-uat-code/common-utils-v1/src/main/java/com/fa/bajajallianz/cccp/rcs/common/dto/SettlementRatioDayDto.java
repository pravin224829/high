package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

public class SettlementRatioDayDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String day;
	private String totalClaimReg;
	private String settledClaimReg;
	private String percentage;

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getTotalClaimReg() {
		return totalClaimReg;
	}

	public void setTotalClaimReg(String totalClaimReg) {
		this.totalClaimReg = totalClaimReg;
	}

	public String getSettledClaimReg() {
		return settledClaimReg;
	}

	public void setSettledClaimReg(String settledClaimReg) {
		this.settledClaimReg = settledClaimReg;
	}

	public String getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}

}
