package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class WorkFlowDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String processType;
	private String currentStepCode;
	private Long currentStepId;
	private String nextStepCode;
	private String assignToRoleCode;
	private Boolean isNotificationRequired;
	private String wfStatusCode;
	private String wfStatusName;
	private String claimStatusCode;
	private String claimSubStatusCode;
	private String claimNumber;
	private String userId;
	private String roleCode;
	private String actionId;
	
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public String getCurrentStepCode() {
		return currentStepCode;
	}
	public void setCurrentStepCode(String currentStepCode) {
		this.currentStepCode = currentStepCode;
	}
	public Long getCurrentStepId() {
		return currentStepId;
	}
	public void setCurrentStepId(Long currentStepId) {
		this.currentStepId = currentStepId;
	}
	public String getNextStepCode() {
		return nextStepCode;
	}
	public void setNextStepCode(String nextStepCode) {
		this.nextStepCode = nextStepCode;
	}
	public String getAssignToRoleCode() {
		return assignToRoleCode;
	}
	public void setAssignToRoleCode(String assignToRoleCode) {
		this.assignToRoleCode = assignToRoleCode;
	}
	public Boolean getIsNotificationRequired() {
		return isNotificationRequired;
	}
	public void setIsNotificationRequired(Boolean isNotificationRequired) {
		this.isNotificationRequired = isNotificationRequired;
	}
	public String getWfStatusCode() {
		return wfStatusCode;
	}
	public void setWfStatusCode(String wfStatusCode) {
		this.wfStatusCode = wfStatusCode;
	}
	public String getClaimStatusCode() {
		return claimStatusCode;
	}
	public void setClaimStatusCode(String claimStatusCode) {
		this.claimStatusCode = claimStatusCode;
	}
	public String getClaimSubStatusCode() {
		return claimSubStatusCode;
	}
	public void setClaimSubStatusCode(String claimSubStatusCode) {
		this.claimSubStatusCode = claimSubStatusCode;
	}
	
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getWfStatusName() {
		return wfStatusName;
	}
	public void setWfStatusName(String wfStatusName) {
		this.wfStatusName = wfStatusName;
	}
	public String getActionId() {
		return actionId;
	}
	public void setActionId(String actionId) {
		this.actionId = actionId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	
}
