package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

public class ClaimIntimationDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String strClaimNumber;
	private String strClaimStatus;
	private String retClaimType;
	private String retReserveAmt;

	public String getStrClaimNumber() {
		return strClaimNumber;
	}

	public void setStrClaimNumber(String strClaimNumber) {
		this.strClaimNumber = strClaimNumber;
	}

	public String getStrClaimStatus() {
		return strClaimStatus;
	}

	public void setStrClaimStatus(String strClaimStatus) {
		this.strClaimStatus = strClaimStatus;
	}

	public String getRetClaimType() {
		return retClaimType;
	}

	public void setRetClaimType(String retClaimType) {
		this.retClaimType = retClaimType;
	}

	public String getRetReserveAmt() {
		return retReserveAmt;
	}

	public void setRetReserveAmt(String retReserveAmt) {
		this.retReserveAmt = retReserveAmt;
	}

}
