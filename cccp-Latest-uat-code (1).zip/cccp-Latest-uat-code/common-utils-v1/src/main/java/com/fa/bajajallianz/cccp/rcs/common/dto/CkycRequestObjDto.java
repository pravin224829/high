package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

public class CkycRequestObjDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String searchCategory;

	private String searchinput;

	private String fieldType;

	private String fieldValue;

	private String name;

	private String dob;

	private String gender;

	private String ckycnumber;

	public String getSearchCategory() {
		return searchCategory;
	}

	public void setSearchCategory(String searchCategory) {
		this.searchCategory = searchCategory;
	}

	public String getSearchinput() {
		return searchinput;
	}

	public void setSearchinput(String searchinput) {
		this.searchinput = searchinput;
	}

	public String getFieldType() {
		return fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCkycnumber() {
		return ckycnumber;
	}

	public void setCkycnumber(String ckycnumber) {
		this.ckycnumber = ckycnumber;
	}
}
