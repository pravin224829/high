package com.fa.bajajallianz.cccp.surveyor.common.dto;

import com.fa.bajajallianz.cccp.common.dto.SurveyDetailsDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SurveyorDetailsReqDto implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String userId;
	private String agentCode;
	private String roleCode;
	private String claimNo;
	private SurveyDetailsDto updateSurveyorReqDto;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getClaimNo() {
		return claimNo;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	public SurveyDetailsDto getUpdateSurveyorReqDto() {
		return updateSurveyorReqDto;
	}
	public void setUpdateSurveyorReqDto(SurveyDetailsDto updateSurveyorReqDto) {
		this.updateSurveyorReqDto = updateSurveyorReqDto;
	}

}
