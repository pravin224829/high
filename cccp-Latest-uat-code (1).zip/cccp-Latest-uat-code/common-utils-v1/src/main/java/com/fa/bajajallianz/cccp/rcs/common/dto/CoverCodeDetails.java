package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.ArrayList;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CoverCodeDtlsDto;

public class CoverCodeDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	public ApplicationErrorDto applicationError;

	public ArrayList<CoverCodeDtlsDto> coverCodeDtlsDto;

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public ArrayList<CoverCodeDtlsDto> getCoverCodeDtls() {
		return coverCodeDtlsDto;
	}

	public void setCoverCodeDtls(ArrayList<CoverCodeDtlsDto> coverCodeDtls) {
		this.coverCodeDtlsDto = coverCodeDtls;
	}
	
	

}
