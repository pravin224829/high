package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arul
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SupplierDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String claimNumber;
	private String partyId;
	private String referenceNo;
	private String supplierId;
	private String appointmentDate;
	private String initialVisitDate;
	private String initialVisitReason;
	private String interimReportDate;
	private String interimReportReason;
	private String finalReportDate;
	private String finalReportReason;
	private String expenseReserve;
	private String delayReason;
	private Boolean isActive;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private String paidAmount;
	private String outstandingReserveAmount;
	private String partnerId;
	private String panNumber;
	private String mobileNumber;
	private String licenseLob;
	private String licenseNumber;
	private String gstNumber;
	private String alternateNumber;
	private String city;
	private String supplierStatus;
	private String supplierCategory;
	private String emailId;
	private String outstandingAmount;
	private String dateOfLoss;
	private String intimationDate;
	private String registrationDate;
	private String taskid;
	private String taskNumber;
	private String extnCol3;
	private String accountNo;
	private String surveyRefNo;
	private String source;
	private String visitDate;
	private String visitTime;
	private String acceptedDate;
	private String acceptedBy;
	private String lastDocDate;

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getInitialVisitDate() {
		return initialVisitDate;
	}

	public void setInitialVisitDate(String initialVisitDate) {
		this.initialVisitDate = initialVisitDate;
	}

	public String getInitialVisitReason() {
		return initialVisitReason;
	}

	public void setInitialVisitReason(String initialVisitReason) {
		this.initialVisitReason = initialVisitReason;
	}

	public String getInterimReportDate() {
		return interimReportDate;
	}

	public void setInterimReportDate(String interimReportDate) {
		this.interimReportDate = interimReportDate;
	}

	public String getInterimReportReason() {
		return interimReportReason;
	}

	public void setInterimReportReason(String interimReportReason) {
		this.interimReportReason = interimReportReason;
	}

	public String getFinalReportDate() {
		return finalReportDate;
	}

	public void setFinalReportDate(String finalReportDate) {
		this.finalReportDate = finalReportDate;
	}

	public String getFinalReportReason() {
		return finalReportReason;
	}

	public void setFinalReportReason(String finalReportReason) {
		this.finalReportReason = finalReportReason;
	}

	public String getDelayReason() {
		return delayReason;
	}

	public void setDelayReason(String delayReason) {
		this.delayReason = delayReason;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getOutstandingReserveAmount() {
		return outstandingReserveAmount;
	}

	public void setOutstandingReserveAmount(String outstandingReserveAmount) {
		this.outstandingReserveAmount = outstandingReserveAmount;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getLicenseLob() {
		return licenseLob;
	}

	public void setLicenseLob(String licenseLob) {
		this.licenseLob = licenseLob;
	}

	public String getLicenseNumber() {
		return licenseNumber;
	}

	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public String getAlternateNumber() {
		return alternateNumber;
	}

	public void setAlternateNumber(String alternateNumber) {
		this.alternateNumber = alternateNumber;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getSupplierCategory() {
		return supplierCategory;
	}

	public void setSupplierCategory(String supplierCategory) {
		this.supplierCategory = supplierCategory;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmaiId(String emailId) {
		this.emailId = emailId;
	}

	public String getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(String outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public String getExpenseReserve() {
		return expenseReserve;
	}

	public void setExpenseReserve(String expenseReserve) {
		this.expenseReserve = expenseReserve;
	}

	public String getDateOfLoss() {
		return dateOfLoss;
	}

	public void setDateOfLoss(String dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}

	public String getIntimationDate() {
		return intimationDate;
	}

	public void setIntimationDate(String intimationDate) {
		this.intimationDate = intimationDate;
	}

	public String getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getTaskid() {
		return taskid;
	}

	public void setTaskid(String taskid) {
		this.taskid = taskid;
	}

	public String getTaskNumber() {
		return taskNumber;
	}

	public void setTaskNumber(String taskNumber) {
		this.taskNumber = taskNumber;
	}

	public String getSupplierStatus() {
		return supplierStatus;
	}

	public void setSupplierStatus(String supplierStatus) {
		this.supplierStatus = supplierStatus;
	}

	public String getExtnCol3() {
		return extnCol3;
	}

	public void setExtnCol3(String extnCol3) {
		this.extnCol3 = extnCol3;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getSurveyRefNo() {
		return surveyRefNo;
	}

	public void setSurveyRefNo(String surveyRefNo) {
		this.surveyRefNo = surveyRefNo;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}

	public String getVisitTime() {
		return visitTime;
	}

	public void setVisitTime(String visitTime) {
		this.visitTime = visitTime;
	}

	public String getAcceptedDate() {
		return acceptedDate;
	}

	public void setAcceptedDate(String acceptedDate) {
		this.acceptedDate = acceptedDate;
	}

	public String getAcceptedBy() {
		return acceptedBy;
	}

	public void setAcceptedBy(String acceptedBy) {
		this.acceptedBy = acceptedBy;
	}

	public String getLastDocDate() {
		return lastDocDate;
	}

	public void setLastDocDate(String lastDocDate) {
		this.lastDocDate = lastDocDate;
	}
	

}
