
package com.fa.bajajallianz.cccp.mis.common.dto;
import java.io.Serializable;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusCkycSearchRespDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ApplicationErrorDto applicationError;
	private String transactionId;
	private String ckycStatus;
	private String poaStatus;
	private String nameMatchingStatus;
	private String status;
	private String poiStatus;
	private String bagicKycId;
	private MaximusCkycSearchDetailsDto ckycSearchDetails;
	private MaximusPoiSearchDetailsDto poiSearchDetails;
	private MaximusPoaSearchDetailsDto poaSearchDetails;
	private ValidationStatusDto validationStatus;

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getCkycStatus() {
		return ckycStatus;
	}

	public void setCkycStatus(String ckycStatus) {
		this.ckycStatus = ckycStatus;
	}

	public String getPoaStatus() {
		return poaStatus;
	}

	public void setPoaStatus(String poaStatus) {
		this.poaStatus = poaStatus;
	}

	public String getNameMatchingStatus() {
		return nameMatchingStatus;
	}

	public void setNameMatchingStatus(String nameMatchingStatus) {
		this.nameMatchingStatus = nameMatchingStatus;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPoiStatus() {
		return poiStatus;
	}

	public void setPoiStatus(String poiStatus) {
		this.poiStatus = poiStatus;
	}

	public String getBagicKycId() {
		return bagicKycId;
	}

	public void setBagicKycId(String bagicKycId) {
		this.bagicKycId = bagicKycId;
	}

	public MaximusCkycSearchDetailsDto getCkycSearchDetails() {
		return ckycSearchDetails;
	}

	public void setCkycSearchDetails(MaximusCkycSearchDetailsDto ckycSearchDetails) {
		this.ckycSearchDetails = ckycSearchDetails;
	}

	public MaximusPoiSearchDetailsDto getPoiSearchDetails() {
		return poiSearchDetails;
	}

	public void setPoiSearchDetails(MaximusPoiSearchDetailsDto poiSearchDetails) {
		this.poiSearchDetails = poiSearchDetails;
	}

	public MaximusPoaSearchDetailsDto getPoaSearchDetails() {
		return poaSearchDetails;
	}

	public void setPoaSearchDetails(MaximusPoaSearchDetailsDto poaSearchDetails) {
		this.poaSearchDetails = poaSearchDetails;
	}

	public ValidationStatusDto getValidationStatus() {
		return validationStatus;
	}

	public void setValidationStatus(ValidationStatusDto validationStatus) {
		this.validationStatus = validationStatus;
	}

}