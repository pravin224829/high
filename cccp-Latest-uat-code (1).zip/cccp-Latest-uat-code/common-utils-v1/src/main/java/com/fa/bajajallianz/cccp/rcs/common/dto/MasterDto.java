package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
public class MasterDto implements Serializable{
	private static final long serialVersionUID = -5070981831714593768L;

	private Long id;

	private String code;

	private String name;
	
	private Integer orderNo;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}
}
