/**
 * 
 */
package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimAttributeDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String storedProductCode;
	private String estdLossAmt;
	private String storedLOBCode;

	public String getStoredProductCode() {
		return storedProductCode;
	}

	public void setStoredProductCode(String storedProductCode) {
		this.storedProductCode = storedProductCode;
	}

	public String getEstdLossAmt() {
		return estdLossAmt;
	}

	public void setEstdLossAmt(String estdLossAmt) {
		this.estdLossAmt = estdLossAmt;
	}

	public String getStoredLOBCode() {
		return storedLOBCode;
	}

	public void setStoredLOBCode(String storedLOBCode) {
		this.storedLOBCode = storedLOBCode;
	}
	
}
