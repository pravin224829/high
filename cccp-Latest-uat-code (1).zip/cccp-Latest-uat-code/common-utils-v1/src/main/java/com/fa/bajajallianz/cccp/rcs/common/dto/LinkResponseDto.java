package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

public class LinkResponseDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private String claimNumber;
	private String insuredPartyId;
	private String customerLink;
	private String partyLink;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public String getInsuredPartyId() {
		return insuredPartyId;
	}
	public void setInsuredPartyId(String insuredPartyId) {
		this.insuredPartyId = insuredPartyId;
	}
	public String getCustomerLink() {
		return customerLink;
	}
	public void setCustomerLink(String customerLink) {
		this.customerLink = customerLink;
	}
	public String getPartyLink() {
		return partyLink;
	}
	public void setPartyLink(String partyLink) {
		this.partyLink = partyLink;
	}
	
}
