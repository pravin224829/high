package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

public class MaximusPremCalcDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public String basicPremium;
	public String grossPremium;
	public String netPremium;
	public String discretionaryDiscount;
	public String discretionaryLoading;

	public String getBasicPremium() {
		return basicPremium;
	}

	public void setBasicPremium(String basicPremium) {
		this.basicPremium = basicPremium;
	}

	public String getGrossPremium() {
		return grossPremium;
	}

	public void setGrossPremium(String grossPremium) {
		this.grossPremium = grossPremium;
	}

	public String getNetPremium() {
		return netPremium;
	}

	public void setNetPremium(String netPremium) {
		this.netPremium = netPremium;
	}

	public String getDiscretionaryDiscount() {
		return discretionaryDiscount;
	}

	public void setDiscretionaryDiscount(String discretionaryDiscount) {
		this.discretionaryDiscount = discretionaryDiscount;
	}

	public String getDiscretionaryLoading() {
		return discretionaryLoading;
	}

	public void setDiscretionaryLoading(String discretionaryLoading) {
		this.discretionaryLoading = discretionaryLoading;
	}

}
