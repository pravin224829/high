package com.fa.bajajallianz.cccp.common.dto;
 
import java.io.Serializable;
 
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
 
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentLogDto implements Serializable {
 
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private String userId;
    private String roleCode;
    private String pageCode;
    private Long id;
    private String name;
    private String fileType;
    private String path;
    private String destination;
    private String docId;
    private String docType;
    private String docName;
    private String referenceNo;
    private String referenceType;
    private String templateType;
    private String uploadeddate;
    private String uploadStatus;
    private String fileName;
    private String claimNumber;
    private String sectionCode;
    private String menuSearchId;
    private String ipAddress;
    private String source;
    private String imdCode;
    private String code;
    private String value;
    private String docHeaderName;
    private String documentName;
    private String productCategory;
    private String workflowType;
    private String createdDate;
    private String createdBy;
    private Boolean isMandatory;
    private Integer orderNo;
    private String displayName;
    private String partyId;
    private String ifscCode;
    private String micrCode;
    private String accountType;
    private String accountNumber;
    private String productCode;
    private String filePath;
    private String activationStatus;
    private String slwProcessType;
    private String sawProcessType;
    private String inwProcessType;
    private String effectiveDate;
    private String policyNumber;
 
    public String getUserId() {
        return userId;
    }
 
    public void setUserId(String userId) {
        this.userId = userId;
    }
 
    public String getRoleCode() {
        return roleCode;
    }
 
    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }
 
    public String getPageCode() {
        return pageCode;
    }
 
    public void setPageCode(String pageCode) {
        this.pageCode = pageCode;
    }
 
    public Long getId() {
        return id;
    }
 
    public void setId(Long id) {
        this.id = id;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
    public String getFileType() {
        return fileType;
    }
 
    public void setFileType(String fileType) {
        this.fileType = fileType;
    }
 
    public String getPath() {
        return path;
    }
 
    public void setPath(String path) {
        this.path = path;
    }
 
    public String getDestination() {
        return destination;
    }
 
    public void setDestination(String destination) {
        this.destination = destination;
    }
 
    public String getDocId() {
        return docId;
    }
 
    public void setDocId(String docId) {
        this.docId = docId;
    }
 
    public String getDocType() {
        return docType;
    }
 
    public void setDocType(String docType) {
        this.docType = docType;
    }
 
    public String getReferenceNo() {
        return referenceNo;
    }
 
    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }
 
    public String getReferenceType() {
        return referenceType;
    }
 
    public void setReferenceType(String referenceType) {
        this.referenceType = referenceType;
    }
 
    public String getTemplateType() {
        return templateType;
    }
 
    public void setTemplateType(String templateType) {
        this.templateType = templateType;
    }
 
    public String getUploadeddate() {
        return uploadeddate;
    }
 
    public void setUploadeddate(String uploadeddate) {
        this.uploadeddate = uploadeddate;
    }
 
    public String getUploadStatus() {
        return uploadStatus;
    }
 
    public void setUploadStatus(String uploadStatus) {
        this.uploadStatus = uploadStatus;
    }
 
 
    public String getFileName() {
        return fileName;
    }
 
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
 
    public String getClaimNumber() {
        return claimNumber;
    }
 
    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }
 
    public String getSectionCode() {
        return sectionCode;
    }
 
    public void setSectionCode(String sectionCode) {
        this.sectionCode = sectionCode;
    }
 
    public String getMenuSearchId() {
        return menuSearchId;
    }
 
    public void setMenuSearchId(String menuSearchId) {
        this.menuSearchId = menuSearchId;
    }
 
    public String getIpAddress() {
        return ipAddress;
    }
 
    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }
 
    public String getSource() {
        return source;
    }
 
    public void setSource(String source) {
        this.source = source;
    }
 
    public String getImdCode() {
        return imdCode;
    }
 
    public void setImdCode(String imdCode) {
        this.imdCode = imdCode;
    }
 
    public String getCode() {
        return code;
    }
 
    public void setCode(String code) {
        this.code = code;
    }
 
    public String getValue() {
        return value;
    }
 
    public void setValue(String value) {
        this.value = value;
    }
 
    public String getDocHeaderName() {
        return docHeaderName;
    }
 
    public void setDocHeaderName(String docHeaderName) {
        this.docHeaderName = docHeaderName;
    }
 
    public String getDocumentName() {
        return documentName;
    }
 
    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }
 
    public String getProductCategory() {
        return productCategory;
    }
 
    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }
 
    public String getWorkflowType() {
        return workflowType;
    }
 
    public void setWorkflowType(String workflowType) {
        this.workflowType = workflowType;
    }
 
    public String getDocName() {
        return docName;
    }
 
    public void setDocName(String docName) {
        this.docName = docName;
    }
 
    public String getCreatedBy() {
        return createdBy;
    }
 
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
 
    public String getCreatedDate() {
        return createdDate;
    }
 
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }
 
    public Boolean getIsMandatory() {
        return isMandatory;
    }
 
    public void setIsMandatory(Boolean isMandatory) {
        this.isMandatory = isMandatory;
    }
 
    public Integer getOrderNo() {
        return orderNo;
    }
 
    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
 
    public String getDisplayName() {
        return displayName;
    }
 
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
 
    public String getPartyId() {
        return partyId;
    }
 
    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }
 
    public String getIfscCode() {
        return ifscCode;
    }
 
    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }
 
    public String getMicrCode() {
        return micrCode;
    }
 
    public void setMicrCode(String micrCode) {
        this.micrCode = micrCode;
    }
 
    public String getAccountType() {
        return accountType;
    }
 
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
 
    public String getAccountNumber() {
        return accountNumber;
    }
 
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
 
    public String getProductCode() {
        return productCode;
    }
 
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }
 
    public String getFilePath() {
        return filePath;
    }
 
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
 
    public String getActivationStatus() {
        return activationStatus;
    }
 
    public void setActivationStatus(String activationStatus) {
        this.activationStatus = activationStatus;
    }
 
    public String getSlwProcessType() {
        return slwProcessType;
    }
 
    public void setSlwProcessType(String slwProcessType) {
        this.slwProcessType = slwProcessType;
    }
 
    public String getSawProcessType() {
        return sawProcessType;
    }
 
    public void setSawProcessType(String sawProcessType) {
        this.sawProcessType = sawProcessType;
    }
 
    public String getInwProcessType() {
        return inwProcessType;
    }
 
    public void setInwProcessType(String inwProcessType) {
        this.inwProcessType = inwProcessType;
    }
 
    public String getEffectiveDate() {
        return effectiveDate;
    }
 
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }
 
    public String getPolicyNumber() {
        return policyNumber;
    }
 
    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }
 
}