package com.fa.bajajallianz.cccp.common.utils;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fa.bajajallianz.cccp.common.dto.ApiConfigDto;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * @author Karthik
 *
 */
public class CommonUtils implements Serializable {

	private static final long serialVersionUID = 1L;
	private static ObjectMapper mapper = new ObjectMapper();

	public static String ifCheckStringNull(String request) {
		try {
			request = request != null ? request : "";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return request;
	}

	public static String getStackTrace(final Throwable throwable) {
		final StringWriter sw = new StringWriter();
		final PrintWriter pw = new PrintWriter(sw, true);
		throwable.printStackTrace(pw);
		return sw.getBuffer().toString();
	}

	public static boolean getCode(List<String> list, String code) {
		String result = (list != null && list.size() > 0)
				? list.stream().filter(inCode -> code.equals(inCode)).findAny().orElse(null)
				: null;
		if (StringUtils.isNotBlank(result)) {
			return false;
		}
		return true;
	}

	public static List<String> list(List<String> list) {
		return list != null ? list : new ArrayList<String>();
	}

	public static List<String> errorDescription(List<String> errors, String error) {
		if (errors != null) {
			errors.add(error);
		} else {
			errors = new ArrayList<String>();
			errors.add(error);
		}
		return errors;
	}

	// Get the current line number in Java
	public static int getLineNumber() {
		return new Throwable().getStackTrace()[0].getLineNumber();
	}

	public static String getLogMessage(int lineNo, String className, String methodName) {
		return lineNo + "~" + className + "~" + methodName + "~ ";
	}

	public static String getLogMessage(Exception e) {
		if (e != null) {
			StackTraceElement[] stackTrace = e.getStackTrace();
			String className = stackTrace[0].getClassName();
			String methodName = stackTrace[0].getMethodName();
			int lineNo = stackTrace[0].getLineNumber();
			return lineNo + "~" + className + "~" + methodName + "~ ";
		}
		return CommonConstants.EMPTY_STRING;
	}

	public static String getClassName(Class<?> myClass) {
		return myClass.getName();
	}

	public static Properties applicationProperties(String jsonString) {
		JsonRequest<Properties> jsonRequest = new JsonRequest<Properties>();
		Properties appProps = null;
		try {
			appProps = jsonRequest.convertJsonStringToObject(jsonString, Properties.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return appProps;
	}

	public static Properties applicationProperties(String jsonString, String key) {
		JsonRequest<Properties> jsonRequest = new JsonRequest<Properties>();
		Properties appProps = new Properties();
		try {
			Map<String, LinkedHashMap<String, String>> mapProps = convertJsonStringToObjectMap(jsonString);

			if (StringUtils.isNotBlank(key)) {
				for (Entry<String, LinkedHashMap<String, String>> map : mapProps.entrySet()) {
					if (key.equalsIgnoreCase(map.getKey())) {
						LinkedHashMap<String, String> val = map.getValue();
						System.out.println(val);
						appProps.putAll(val);
						return appProps;
						// appProps = jsonRequest.convertJsonStringToObject(mapString,
						// Properties.class);
					}
				}
			} else {
				appProps = jsonRequest.convertJsonStringToObject(jsonString, Properties.class);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return appProps;
	}

	public static LinkedHashMap<String, String> applicationPropertiesAsMap(String jsonString, String key) {
		try {
			Map<String, LinkedHashMap<String, String>> mapProps = convertJsonStringToObjectMap(jsonString);

			if (StringUtils.isNotBlank(key)) {
				for (Entry<String, LinkedHashMap<String, String>> map : mapProps.entrySet()) {
					if (key.equalsIgnoreCase(map.getKey())) {
						LinkedHashMap<String, String> value = map.getValue();
						return value;
						// appProps = jsonRequest.convertJsonStringToObject(mapString,
						// Properties.class);
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static Properties applicationProperties(String jsonString, List<String> keys) {
		JsonRequest<Properties> jsonRequest = new JsonRequest<Properties>();
		Properties appProps = new Properties();
		try {
//			Map<String, LinkedHashMap<String, String>> mapProps = convertJsonStringToObjectMap(jsonString);

			if (keys != null && keys.size() > 0) {
				Map<String, String> map = new LinkedHashMap<String, String>();
//				for (String key : keys) {
//					LinkedHashMap<String, String> mapString = mapProps.get(key);
//				}
				appProps.putAll(map);
				return appProps;
			} else {
				appProps = jsonRequest.convertJsonStringToObject(jsonString, Properties.class);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return appProps;
	}

	public static Map<String, LinkedHashMap<String, String>> convertJsonStringToObjectMap(String json)
			throws JsonParseException, JsonMappingException, IOException {
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		return mapper.readValue(json, Map.class);
	}

	public static Map<String, String> convertJsonObjectToMap(Object jsonOb)
			throws JsonParseException, JsonMappingException, IOException {
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		return mapper.readValue(String.valueOf(jsonOb), Map.class);
	}

	public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
		Set<Object> seen = ConcurrentHashMap.newKeySet();
		return t -> (t != null ? seen.add(keyExtractor.apply(t)) : null);
	}

	public static String getDisplayName(String value) {
		if (StringUtils.isNotBlank(value)) {
			String[] split = value.split("-");
			if (split != null && split.length > 1) {
				return split[1];
			}
		}
		return null;
	}

	// Decodes a URL encoded string using `UTF-8`
	public static String decodeValue(String value) {
		try {
			if (StringUtils.isNotBlank(value)) {
				return URLDecoder.decode(value, StandardCharsets.UTF_8.toString());
			}
		} catch (UnsupportedEncodingException ex) {
			throw new RuntimeException(ex.getCause());
		}
		return null;
	}

	public static List<Long> stringToLongList(Set<String> keys) {
		return keys.stream().map(s -> NumericUtils.convertStringToLong(s)).collect(Collectors.toList());
	}

//	public static void main(String[] args) {
//		System.out.println(Integer.MAX_VALUE);
//	}

	public static List<String> getArray(String value, String delimit) {
		if (StringUtils.isNotBlank(value)) {
			String[] split = value.split(delimit);
			List<String> asList = Arrays.asList(split);
			return asList;
		}
		return null;
	}

	public static String getBase64String(String plainString) {
		String encodeString = null;
		try {
			encodeString = new String(java.util.Base64.getEncoder().encodeToString(plainString.getBytes()));
		} catch (Exception e) {
			e.printStackTrace();
			encodeString = null;
		}
		return encodeString;
	}

	public static boolean isPresentArray(List<String> list, String code) {
		String result = (list != null && list.size() > 0 && StringUtils.isNotBlank(code))
				? list.stream().filter(inCode -> code.equals(inCode)).findFirst().orElse(null)
				: null;
		if (StringUtils.isNotBlank(result)) {
			return true;
		}
		return false;
	}

	public static boolean isPresentInString(String value, String delimit, String code) {
		if (StringUtils.isNotBlank(value)) {
			String[] split = value.split(delimit);
			List<String> list = Arrays.asList(split);
			String result = (list != null && list.size() > 0)
					? list.stream().filter(inCode -> code.equals(inCode)).findFirst().orElse(null)
					: null;
			if (StringUtils.isNotBlank(result)) {
				return true;
			}
		}
		return false;
	}

	public static boolean isNullBool(Boolean val) {
		if (val == null) {
			return CommonConstants.FALSE;
		}
		return val;
	}

	public static boolean isFalseTrue(Boolean val) {
		if (val == null || (val != null && !val)) {
			return CommonConstants.TRUE;
		}
		return CommonConstants.FALSE;
	}

	public static boolean isTrue(Boolean val) {
		if (val != null && val) {
			return CommonConstants.TRUE;
		}
		return CommonConstants.FALSE;
	}

	public static String fetchApi(String apiCode, String apiUrl) {
		RestTemplate restTemplate = new RestTemplate();
		UriComponentsBuilder url = UriComponentsBuilder.fromUriString(apiUrl);
		url.queryParam("code", apiCode);
		ApiConfigDto responseDto = restTemplate
				.exchange(url.toUriString(), HttpMethod.GET, null, new ParameterizedTypeReference<ApiConfigDto>() {
				}).getBody();
		return responseDto != null
				? (com.fa.bajajallianz.cccp.common.utils.StringUtils.checkNull(responseDto.getUrl())
						+ com.fa.bajajallianz.cccp.common.utils.StringUtils.checkNull(responseDto.getEndpoint()))
				: CommonConstants.EMPTY_STRING;
	}

	public static Integer calculateOffset(Integer pageCount, Integer limit) {
		Integer offset = (pageCount * limit) - limit;
		return offset;
	}

	public static String StringArrayToCommaSeparatedString(String[] StringArray) {
		String value = null;
		if (StringArray != null && StringArray.length > 0) {
			value = String.join("~", StringArray);
		}
		return value;
	}

	public static String[] CommaSeparatedStringToStringArray(String value) {
		String[] StringArray = null;
		if (value != null) {
			StringArray = value.split("~");
		}
		return StringArray;
	}

	public static String ordinalSuffixOf(Integer number) {
		String value = "";
		try {
			final Integer j = number % 10;
			final Integer k = number % 100;
			if (j == 1 && k != 11) {
				value = number + " st";
			} else if (j == 2 && k != 12) {
				value = number + " nd";
			} else if (j == 3 && k != 13) {
				value = number + " rd";
			} else {
				value = number + " th";
			}
		} catch (Exception e) {
			System.out.println("OrdinalSuffixOf \t" + e);
		}
		return value;
	}

	public static void errorInfo(HttpServletRequest request, String string, String string2, String string3,
			String string4, String message, String stackTrace, String string5, String string6, String string7,
			String string8) {
		// TODO Auto-generated method stub
		
	}
	
	public static String getCorelationId(HttpServletRequest request) {
		if (request != null) {

			Enumeration<String> headersNmaes = request.getHeaderNames();
			ArrayList<String> list1 = new ArrayList<String>();
			while (headersNmaes.hasMoreElements()) {
				String nextElement = headersNmaes.nextElement();
				list1.add(nextElement + ":" + request.getHeader(nextElement));

				;
			}
			return list1.toString();
		}
		return "";
	}
}
