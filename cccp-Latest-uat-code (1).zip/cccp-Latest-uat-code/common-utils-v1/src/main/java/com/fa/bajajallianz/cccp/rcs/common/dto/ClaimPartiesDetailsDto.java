package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimPartiesDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private String claimNumber;
	private String partyId;
	private String stakeType;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private String partyName;
	private String ipNo;
	private String neftStatus;
	private String neftEnableDate;
	private String subType;
	private String partyCode;
	private String firstName;
	private String verificationStatus;
	private String verificationDateAndTime;
	private String verifiedBy;
	private String claimantRemark;
	private String code;
	private String name;
	private String paymentStatus;
	private String neftMethod;

	public String getNeftMethod() {
		return neftMethod;
	}

	public void setNeftMethod(String neftMethod) {
		this.neftMethod = neftMethod;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getStakeType() {
		return stakeType;
	}

	public void setStakeType(String stakeType) {
		this.stakeType = stakeType;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getIpNo() {
		return ipNo;
	}

	public void setIpNo(String ipNo) {
		this.ipNo = ipNo;
	}

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public String getNeftEnableDate() {
		return neftEnableDate;
	}

	public void setNeftEnableDate(String neftEnableDate) {
		this.neftEnableDate = neftEnableDate;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getVerificationStatus() {
		return verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

	public String getVerificationDateAndTime() {
		return verificationDateAndTime;
	}

	public void setVerificationDateAndTime(String verificationDateAndTime) {
		this.verificationDateAndTime = verificationDateAndTime;
	}

	public String getVerifiedBy() {
		return verifiedBy;
	}

	public void setVerifiedBy(String verifiedBy) {
		this.verifiedBy = verifiedBy;
	}

	public String getClaimantRemark() {
		return claimantRemark;
	}

	public void setClaimantRemark(String claimantRemark) {
		this.claimantRemark = claimantRemark;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
