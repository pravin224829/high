package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LossDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private String lossDate;
	private String lossTime;
	private String lossAddress;
	private String landmark;
	private String lossAmount;
	private String pincode;
	private String state;
	private String city;
	private String area;
	private String section;
	private String causeOfLoss;
	private String notificationDate;
	private String lossDescription;
	private String goodsDamagedDetails;
	private String lossEstmatedValue;
	private String invoiceNumber;
	private String invoiceDate;
	private String blRrLrAwbNo;
	private String lorryReceiptDate;
	private String journeyFrom;
	private String journeyTo;
	private String consigneeName;
	private String consignerName;
	private String consigneeAddress;
	private String consigneePhoneNo;
	private String claimServicingOffice;
	private String areaClaimBehalfOffInsure;
	private String claimNotifiedBy;
	private Boolean areClaimBehalfOfInsured;
	private String lossDetails;
	private String deficiencyReason;
	private String reasonForDelay;
	private String claimHandler;
	private String createdDate;
	private String modifiedDate;
	private String createdBy;
	private String modifiedBy;
	private Boolean chReviewChange;
	private String nextReviewDate;
	private Boolean nextReviewChange;
	private String surveyLocation;
	private String modeOfTransport;
	private String transactionType;
	private String goodsDetails;
	private String typeOfLoad;
	private String typeOfVehicle;
	private String typeOfClaim;
	private String cargoDescription;
	private String lossPeril;
	private String panNumber;
	private String gstnNumber;
	private String specialRemark;

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLossDate() {
		return lossDate;
	}

	public void setLossDate(String lossDate) {
		this.lossDate = lossDate;
	}

	public String getLossTime() {
		return lossTime;
	}

	public void setLossTime(String lossTime) {
		this.lossTime = lossTime;
	}

	public String getLossAddress() {
		return lossAddress;
	}

	public void setLossAddress(String lossAddress) {
		this.lossAddress = lossAddress;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getLossAmount() {
		return lossAmount;
	}

	public void setLossAmount(String lossAmount) {
		this.lossAmount = lossAmount;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public Boolean getAreClaimBehalfOfInsured() {
		return areClaimBehalfOfInsured;
	}

	public void setAreClaimBehalfOfInsured(Boolean areClaimBehalfOfInsured) {
		this.areClaimBehalfOfInsured = areClaimBehalfOfInsured;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getCauseOfLoss() {
		return causeOfLoss;
	}

	public void setCauseOfLoss(String causeOfLoss) {
		this.causeOfLoss = causeOfLoss;
	}

	public String getNotificationDate() {
		return notificationDate;
	}

	public void setNotificationDate(String notificationDate) {
		this.notificationDate = notificationDate;
	}

	public String getClaimNotifiedBy() {
		return claimNotifiedBy;
	}

	public void setClaimNotifiedBy(String claimNotifiedBy) {
		this.claimNotifiedBy = claimNotifiedBy;
	}

	public String getLossDescription() {
		return lossDescription;
	}

	public void setLossDescription(String lossDescription) {
		this.lossDescription = lossDescription;
	}

	public String getGoodsDamagedDetails() {
		return goodsDamagedDetails;
	}

	public void setGoodsDamagedDetails(String goodsDamagedDetails) {
		this.goodsDamagedDetails = goodsDamagedDetails;
	}

	public String getLossEstmatedValue() {
		return lossEstmatedValue;
	}

	public void setLossEstmatedValue(String lossEstmatedValue) {
		this.lossEstmatedValue = lossEstmatedValue;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getBlRrLrAwbNo() {
		return blRrLrAwbNo;
	}

	public void setBlRrLrAwbNo(String blRrLrAwbNo) {
		this.blRrLrAwbNo = blRrLrAwbNo;
	}

	public String getLorryReceiptDate() {
		return lorryReceiptDate;
	}

	public void setLorryReceiptDate(String lorryReceiptDate) {
		this.lorryReceiptDate = lorryReceiptDate;
	}

	public String getJourneyFrom() {
		return journeyFrom;
	}

	public void setJourneyFrom(String journeyFrom) {
		this.journeyFrom = journeyFrom;
	}

	public String getJourneyTo() {
		return journeyTo;
	}

	public void setJourneyTo(String journeyTo) {
		this.journeyTo = journeyTo;
	}

	public String getConsigneeName() {
		return consigneeName;
	}

	public void setConsigneeName(String consigneeName) {
		this.consigneeName = consigneeName;
	}

	public String getConsigneeAddress() {
		return consigneeAddress;
	}

	public void setConsigneeAddress(String consigneeAddress) {
		this.consigneeAddress = consigneeAddress;
	}

	public String getConsigneePhoneNo() {
		return consigneePhoneNo;
	}

	public void setConsigneePhoneNo(String consigneePhoneNo) {
		this.consigneePhoneNo = consigneePhoneNo;
	}

	public String getClaimServicingOffice() {
		return claimServicingOffice;
	}

	public void setClaimServicingOffice(String claimServicingOffice) {
		this.claimServicingOffice = claimServicingOffice;
	}

	public String getAreaClaimBehalfOffInsure() {
		return areaClaimBehalfOffInsure;
	}

	public void setAreaClaimBehalfOffInsure(String areaClaimBehalfOffInsure) {
		this.areaClaimBehalfOffInsure = areaClaimBehalfOffInsure;
	}

	public String getLossDetails() {
		return lossDetails;
	}

	public void setLossDetails(String lossDetails) {
		this.lossDetails = lossDetails;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getReasonForDelay() {
		return reasonForDelay;
	}

	public void setReasonForDelay(String reasonForDelay) {
		this.reasonForDelay = reasonForDelay;
	}

	public String getClaimHandler() {
		return claimHandler;
	}

	public void setClaimHandler(String claimHandler) {
		this.claimHandler = claimHandler;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Boolean getChReviewChange() {
		return chReviewChange;
	}

	public void setChReviewChange(Boolean chReviewChange) {
		this.chReviewChange = chReviewChange;
	}

	public String getNextReviewDate() {
		return nextReviewDate;
	}

	public void setNextReviewDate(String nextReviewDate) {
		this.nextReviewDate = nextReviewDate;
	}

	public Boolean getNextReviewChange() {
		return nextReviewChange;
	}

	public void setNextReviewChange(Boolean nextReviewChange) {
		this.nextReviewChange = nextReviewChange;
	}

	public String getConsignerName() {
		return consignerName;
	}

	public void setConsignerName(String consignerName) {
		this.consignerName = consignerName;
	}

	public String getSurveyLocation() {
		return surveyLocation;
	}

	public void setSurveyLocation(String surveyLocation) {
		this.surveyLocation = surveyLocation;
	}

	public String getModeOfTransport() {
		return modeOfTransport;
	}

	public void setModeOfTransport(String modeOfTransport) {
		this.modeOfTransport = modeOfTransport;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getGoodsDetails() {
		return goodsDetails;
	}

	public void setGoodsDetails(String goodsDetails) {
		this.goodsDetails = goodsDetails;
	}

	public String getTypeOfLoad() {
		return typeOfLoad;
	}

	public void setTypeOfLoad(String typeOfLoad) {
		this.typeOfLoad = typeOfLoad;
	}

	public String getTypeOfVehicle() {
		return typeOfVehicle;
	}

	public void setTypeOfVehicle(String typeOfVehicle) {
		this.typeOfVehicle = typeOfVehicle;
	}

	public String getTypeOfClaim() {
		return typeOfClaim;
	}

	public void setTypeOfClaim(String typeOfClaim) {
		this.typeOfClaim = typeOfClaim;
	}

	public String getCargoDescription() {
		return cargoDescription;
	}

	public void setCargoDescription(String cargoDescription) {
		this.cargoDescription = cargoDescription;
	}

	public String getLossPeril() {
		return lossPeril;
	}

	public void setLossPeril(String lossPeril) {
		this.lossPeril = lossPeril;
	}

	public String getGstnNumber() {
		return gstnNumber;
	}

	public void setGstnNumber(String gstnNumber) {
		this.gstnNumber = gstnNumber;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getSpecialRemark() {
		return specialRemark;
	}

	public void setSpecialRemark(String specialRemark) {
		this.specialRemark = specialRemark;
	}

}
