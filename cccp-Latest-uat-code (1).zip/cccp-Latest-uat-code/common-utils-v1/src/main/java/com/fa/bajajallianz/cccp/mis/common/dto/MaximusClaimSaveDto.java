package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusClaimSaveDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String strPolicyQuoteNumber;
	private String strState;
	private String strLOB;
	private String strProductCode;
	private String strCountryCode;
	private String strCompany;
	private String strInsuredName;
	private String strPolicyHolderCode;
	private String strPremiumCurrency;
	private String strprivilegeCode;
	private String strApplicationCode;
	private String strBaseCurrency;
	private String policyBranch;
	private String claimType;
	private String claimIntimationDate;
	private String lossDate;
	private String lossTime;
	private Object eventCode;
	private String claimCause;
	private String lossNature;
	private String claimSubStatus;
	private String estimatedLossAmount;
	private Object claimCircumstances;
	private String claimIntTime;
	private String insContactNo;
	private String polRiskCovList;
	private String riskSerialNo;
	private String riskCode;
	private String riskDesc;
	private Object intClaimComments;
	private String claimBranch;
	private String bankIFSCCode;
	private String registeredMobileNumber;
	private String lossDescription;
	private String nameOfPerson;
	private String mobileNumber;
	private String email;
	private String telephoneNumber;
	private String identificationNumber;
	 private String anySpecialremarks;
	private String lossAddress;
	private String gstnNumber;
	private String city;
	private String areaCode;
	private String state;
	private String panNumber;
	private String bankAccountNumber;

	public String getStrPolicyQuoteNumber() {
		return strPolicyQuoteNumber;
	}

	public void setStrPolicyQuoteNumber(String strPolicyQuoteNumber) {
		this.strPolicyQuoteNumber = strPolicyQuoteNumber;
	}

	public String getStrState() {
		return strState;
	}

	public void setStrState(String strState) {
		this.strState = strState;
	}

	public String getStrLOB() {
		return strLOB;
	}

	public void setStrLOB(String strLOB) {
		this.strLOB = strLOB;
	}

	public String getStrProductCode() {
		return strProductCode;
	}

	public void setStrProductCode(String strProductCode) {
		this.strProductCode = strProductCode;
	}

	public String getStrCountryCode() {
		return strCountryCode;
	}

	public void setStrCountryCode(String strCountryCode) {
		this.strCountryCode = strCountryCode;
	}

	public String getStrCompany() {
		return strCompany;
	}

	public void setStrCompany(String strCompany) {
		this.strCompany = strCompany;
	}

	public String getStrInsuredName() {
		return strInsuredName;
	}

	public void setStrInsuredName(String strInsuredName) {
		this.strInsuredName = strInsuredName;
	}

	public String getStrPolicyHolderCode() {
		return strPolicyHolderCode;
	}

	public void setStrPolicyHolderCode(String strPolicyHolderCode) {
		this.strPolicyHolderCode = strPolicyHolderCode;
	}

	public String getStrPremiumCurrency() {
		return strPremiumCurrency;
	}

	public void setStrPremiumCurrency(String strPremiumCurrency) {
		this.strPremiumCurrency = strPremiumCurrency;
	}

	public String getStrprivilegeCode() {
		return strprivilegeCode;
	}

	public void setStrprivilegeCode(String strprivilegeCode) {
		this.strprivilegeCode = strprivilegeCode;
	}

	public String getStrApplicationCode() {
		return strApplicationCode;
	}

	public void setStrApplicationCode(String strApplicationCode) {
		this.strApplicationCode = strApplicationCode;
	}

	public String getStrBaseCurrency() {
		return strBaseCurrency;
	}

	public void setStrBaseCurrency(String strBaseCurrency) {
		this.strBaseCurrency = strBaseCurrency;
	}

	public String getPolicyBranch() {
		return policyBranch;
	}

	public void setPolicyBranch(String policyBranch) {
		this.policyBranch = policyBranch;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getClaimIntimationDate() {
		return claimIntimationDate;
	}

	public void setClaimIntimationDate(String claimIntimationDate) {
		this.claimIntimationDate = claimIntimationDate;
	}

	public String getLossDate() {
		return lossDate;
	}

	public void setLossDate(String lossDate) {
		this.lossDate = lossDate;
	}

	public String getLossTime() {
		return lossTime;
	}

	public void setLossTime(String lossTime) {
		this.lossTime = lossTime;
	}

	public Object getEventCode() {
		return eventCode;
	}

	public void setEventCode(Object eventCode) {
		this.eventCode = eventCode;
	}

	public String getClaimCause() {
		return claimCause;
	}

	public void setClaimCause(String claimCause) {
		this.claimCause = claimCause;
	}

	public String getLossNature() {
		return lossNature;
	}

	public void setLossNature(String lossNature) {
		this.lossNature = lossNature;
	}

	public String getClaimSubStatus() {
		return claimSubStatus;
	}

	public void setClaimSubStatus(String claimSubStatus) {
		this.claimSubStatus = claimSubStatus;
	}

	public String getEstimatedLossAmount() {
		return estimatedLossAmount;
	}

	public void setEstimatedLossAmount(String estimatedLossAmount) {
		this.estimatedLossAmount = estimatedLossAmount;
	}

	public Object getClaimCircumstances() {
		return claimCircumstances;
	}

	public void setClaimCircumstances(Object claimCircumstances) {
		this.claimCircumstances = claimCircumstances;
	}

	public String getClaimIntTime() {
		return claimIntTime;
	}

	public void setClaimIntTime(String claimIntTime) {
		this.claimIntTime = claimIntTime;
	}

	public String getInsContactNo() {
		return insContactNo;
	}

	public void setInsContactNo(String insContactNo) {
		this.insContactNo = insContactNo;
	}

	public String getPolRiskCovList() {
		return polRiskCovList;
	}

	public void setPolRiskCovList(String polRiskCovList) {
		this.polRiskCovList = polRiskCovList;
	}

	public String getRiskSerialNo() {
		return riskSerialNo;
	}

	public void setRiskSerialNo(String riskSerialNo) {
		this.riskSerialNo = riskSerialNo;
	}

	public String getRiskCode() {
		return riskCode;
	}

	public void setRiskCode(String riskCode) {
		this.riskCode = riskCode;
	}

	public String getRiskDesc() {
		return riskDesc;
	}

	public void setRiskDesc(String riskDesc) {
		this.riskDesc = riskDesc;
	}

	public Object getIntClaimComments() {
		return intClaimComments;
	}

	public void setIntClaimComments(Object intClaimComments) {
		this.intClaimComments = intClaimComments;
	}

	public String getClaimBranch() {
		return claimBranch;
	}

	public void setClaimBranch(String claimBranch) {
		this.claimBranch = claimBranch;
	}

	public String getBankIFSCCode() {
		return bankIFSCCode;
	}

	public void setBankIFSCCode(String bankIFSCCode) {
		this.bankIFSCCode = bankIFSCCode;
	}

	public String getRegisteredMobileNumber() {
		return registeredMobileNumber;
	}

	public void setRegisteredMobileNumber(String registeredMobileNumber) {
		this.registeredMobileNumber = registeredMobileNumber;
	}

	public String getLossDescription() {
		return lossDescription;
	}

	public void setLossDescription(String lossDescription) {
		this.lossDescription = lossDescription;
	}

	public String getNameOfPerson() {
		return nameOfPerson;
	}

	public void setNameOfPerson(String nameOfPerson) {
		this.nameOfPerson = nameOfPerson;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public String getIdentificationNumber() {
		return identificationNumber;
	}

	public void setIdentificationNumber(String identificationNumber) {
		this.identificationNumber = identificationNumber;
	}

	public String getLossAddress() {
		return lossAddress;
	}

	public void setLossAddress(String lossAddress) {
		this.lossAddress = lossAddress;
	}

	public String getGstnNumber() {
		return gstnNumber;
	}

	public void setGstnNumber(String gstnNumber) {
		this.gstnNumber = gstnNumber;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAnySpecialremarks() {
		return anySpecialremarks;
	}

	public void setAnySpecialremarks(String anySpecialremarks) {
		this.anySpecialremarks = anySpecialremarks;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

}
