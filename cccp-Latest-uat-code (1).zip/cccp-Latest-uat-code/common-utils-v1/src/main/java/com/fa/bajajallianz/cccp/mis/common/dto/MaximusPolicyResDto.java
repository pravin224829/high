package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.ArrayList;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusPolicyResDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private ApplicationErrorDto applicationError;
	private ArrayList<MaximusCommonSearchDto> commonSearchDetails;

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public ArrayList<MaximusCommonSearchDto> getCommonSearchDetails() {
		return commonSearchDetails;
	}

	public void setCommonSearchDetails(ArrayList<MaximusCommonSearchDto> commonSearchDetails) {
		this.commonSearchDetails = commonSearchDetails;
	}

}
