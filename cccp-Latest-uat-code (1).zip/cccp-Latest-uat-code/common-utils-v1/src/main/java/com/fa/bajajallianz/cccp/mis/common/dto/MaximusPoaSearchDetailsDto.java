package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusPoaSearchDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private MaximusVoterIdDetailsDto voterIdDetails;
	private MaximusDlDetailsDto dlDetails;
	private MaximusPassportDetailsDto passportDetails;
	private MaximusGstnDetailsDto gstnDetails;

	public MaximusVoterIdDetailsDto getVoterIdDetails() {
		return voterIdDetails;
	}

	public void setVoterIdDetails(MaximusVoterIdDetailsDto voterIdDetails) {
		this.voterIdDetails = voterIdDetails;
	}

	public MaximusDlDetailsDto getDlDetails() {
		return dlDetails;
	}

	public void setDlDetails(MaximusDlDetailsDto dlDetails) {
		this.dlDetails = dlDetails;
	}

	public MaximusPassportDetailsDto getPassportDetails() {
		return passportDetails;
	}

	public void setPassportDetails(MaximusPassportDetailsDto passportDetails) {
		this.passportDetails = passportDetails;
	}

	public MaximusGstnDetailsDto getGstnDetails() {
		return gstnDetails;
	}

	public void setGstnDetails(MaximusGstnDetailsDto gstnDetails) {
		this.gstnDetails = gstnDetails;
	}

}
