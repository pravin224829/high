package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class InsuredCommunicationDetailsDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String claimNumber;
	private String partyId;
	private String mobile;
	private String mnoAutoAlert;
	private String autoCommunication;
	private String alterMnoAutoAlert;
	private String autoCommunicationChanges;
	private String contactPersonName;
	private String eventCode;
	private String lossOccuredDetails;
	private String status;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private String policyNumber;
	private String lossReserveAmount;
	private String lossReserveBand;
	private String customerLoyalityCategory;
	private String policyStartDate;
	private String policyEndDate;
	private String insuredProfileRating;
	private String alternateNumber;
	private String email;
	private String telephone1;
	private String insuredAddress;
	private String partnerType;
	private String phiPartnerId;
	private String city;
	private String panNumber;
	private String ckycStatus;
	private String pinCode;
	private String gstIn;
	private String neftStatus;
	private String alertChanges;
	private String chVerification;
	private String causeOfLoss;
	private String claimWorkFlow;
	private String deficiencyReason;
	private String chReviewComment;
	private String claimHandler;
	private String nextReviewDate;
	private String forInfoComment;
	private String pendingAge;
	private String claimWorkflow;

	public String getClaimWorkflow() {
		return claimWorkflow;
	}

	public void setClaimWorkflow(String claimWorkflow) {
		this.claimWorkflow = claimWorkflow;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	public String getLossOccuredDetails() {
		return lossOccuredDetails;
	}

	public void setLossOccuredDetails(String lossOccuredDetails) {
		this.lossOccuredDetails = lossOccuredDetails;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	private String subStatus;

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getMnoAutoAlert() {
		return mnoAutoAlert;
	}

	public void setMnoAutoAlert(String mnoAutoAlert) {
		this.mnoAutoAlert = mnoAutoAlert;
	}

	public String getAutoCommunication() {
		return autoCommunication;
	}

	public void setAutoCommunication(String autoCommunication) {
		this.autoCommunication = autoCommunication;
	}

	public String getAlterMnoAutoAlert() {
		return alterMnoAutoAlert;
	}

	public void setAlterMnoAutoAlert(String alterMnoAutoAlert) {
		this.alterMnoAutoAlert = alterMnoAutoAlert;
	}

	public String getAutoCommunicationChanges() {
		return autoCommunicationChanges;
	}

	public void setAutoCommunicationChanges(String autoCommunicationChanges) {
		this.autoCommunicationChanges = autoCommunicationChanges;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getLossReserveAmount() {
		return lossReserveAmount;
	}

	public void setLossReserveAmount(String lossReserveAmount) {
		this.lossReserveAmount = lossReserveAmount;
	}

	public String getLossReserveBand() {
		return lossReserveBand;
	}

	public void setLossReserveBand(String lossReserveBand) {
		this.lossReserveBand = lossReserveBand;
	}

	public String getCustomerLoyalityCategory() {
		return customerLoyalityCategory;
	}

	public void setCustomerLoyalityCategory(String customerLoyalityCategory) {
		this.customerLoyalityCategory = customerLoyalityCategory;
	}

	public String getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(String policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public String getPolicyEndDate() {
		return policyEndDate;
	}

	public void setPolicyEndDate(String policyEndDate) {
		this.policyEndDate = policyEndDate;
	}

	public String getInsuredProfileRating() {
		return insuredProfileRating;
	}

	public void setInsuredProfileRating(String insuredProfileRating) {
		this.insuredProfileRating = insuredProfileRating;
	}

	public String getAlternateNumber() {
		return alternateNumber;
	}

	public void setAlternateNumber(String alternateNumber) {
		this.alternateNumber = alternateNumber;
	}

	public String getTelephone1() {
		return telephone1;
	}

	public void setTelephone1(String telephone1) {
		this.telephone1 = telephone1;
	}

	public String getInsuredAddress() {
		return insuredAddress;
	}

	public void setInsuredAddress(String insuredAddress) {
		this.insuredAddress = insuredAddress;
	}

	public String getPartnerType() {
		return partnerType;
	}

	public void setPartnerType(String partnerType) {
		this.partnerType = partnerType;
	}

	public String getPhiPartnerId() {
		return phiPartnerId;
	}

	public void setPhiPartnerId(String phiPartnerId) {
		this.phiPartnerId = phiPartnerId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getCkycStatus() {
		return ckycStatus;
	}

	public void setCkycStatus(String ckycStatus) {
		this.ckycStatus = ckycStatus;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getGstIn() {
		return gstIn;
	}

	public void setGstIn(String gstIn) {
		this.gstIn = gstIn;
	}

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public String getAlertChanges() {
		return alertChanges;
	}

	public void setAlertChanges(String alertChanges) {
		this.alertChanges = alertChanges;
	}

	public String getChVerification() {
		return chVerification;
	}

	public void setChVerification(String chVerification) {
		this.chVerification = chVerification;
	}

	public String getCauseOfLoss() {
		return causeOfLoss;
	}

	public void setCauseOfLoss(String causeOfLoss) {
		this.causeOfLoss = causeOfLoss;
	}

	public String getClaimWorkFlow() {
		return claimWorkFlow;
	}

	public void setClaimWorkFlow(String claimWorkFlow) {
		this.claimWorkFlow = claimWorkFlow;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getChReviewComment() {
		return chReviewComment;
	}

	public void setChReviewComment(String chReviewComment) {
		this.chReviewComment = chReviewComment;
	}

	public String getClaimHandler() {
		return claimHandler;
	}

	public void setClaimHandler(String claimHandler) {
		this.claimHandler = claimHandler;
	}

	public String getNextReviewDate() {
		return nextReviewDate;
	}

	public void setNextReviewDate(String nextReviewDate) {
		this.nextReviewDate = nextReviewDate;
	}

	public String getForInfoComment() {
		return forInfoComment;
	}

	public void setForInfoComment(String forInfoComment) {
		this.forInfoComment = forInfoComment;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPendingAge() {
		return pendingAge;
	}

	public void setPendingAge(String pendingAge) {
		this.pendingAge = pendingAge;
	}

}
