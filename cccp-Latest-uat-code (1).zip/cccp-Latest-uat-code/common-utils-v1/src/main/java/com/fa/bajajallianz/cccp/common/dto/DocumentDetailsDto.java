package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<DocListDto> claimDocList;
	private ApplicationErrorDto applicationError;
	private List<DocListDto> data;

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public List<DocListDto> getClaimDocList() {
		return claimDocList;
	}

	public void setClaimDocList(List<DocListDto> claimDocList) {
		this.claimDocList = claimDocList;
	}

	public List<DocListDto> getData() {
		return data;
	}

	public void setData(List<DocListDto> data) {
		this.data = data;
	}

}
