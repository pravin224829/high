package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DamageEquipmentDetailsDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String mechDescription;
	private String mechSerialNo;
	private String mechCapacityUnit;
	private String mechCapacity;
	private String yearOfManufacturing;

	public String getMechDescription() {
		return mechDescription;
	}

	public void setMechDescription(String mechDescription) {
		this.mechDescription = mechDescription;
	}

	public String getMechSerialNo() {
		return mechSerialNo;
	}

	public void setMechSerialNo(String mechSerialNo) {
		this.mechSerialNo = mechSerialNo;
	}

	public String getMechCapacityUnit() {
		return mechCapacityUnit;
	}

	public void setMechCapacityUnit(String mechCapacityUnit) {
		this.mechCapacityUnit = mechCapacityUnit;
	}

	public String getMechCapacity() {
		return mechCapacity;
	}

	public void setMechCapacity(String mechCapacity) {
		this.mechCapacity = mechCapacity;
	}

	public String getYearOfManufacturing() {
		return yearOfManufacturing;
	}

	public void setYearOfManufacturing(String yearOfManufacturing) {
		this.yearOfManufacturing = yearOfManufacturing;
	}
	

}
