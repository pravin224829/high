package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fa.bajajallianz.cccp.common.dto.InvoiceDetailsDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RcsClaimDetailsDto implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	private String claimNumber;
	private String registrationDate;
	private String locationCode;
	private String lossOccuredDetails;
	private String status;
	private String subStatus;
	private String handlerName;
	private WorkFlowDetailsDto workFlowDetails;
	private String eventCode;
	private String causeOffLoss;
	private String lossTime;
	private String lossDate;
	private String intimationSource;
	private String fraudAlert;
	private String reserveAmount;
	private String howLossOccured;
	private String salvageStatus;
	private String deficiencyReason;
	private InvoiceDetailsDto invoiceDetails;
	private String claimRefNo;
	private String policyNumber;
	private String insuredName;
	private String intimationDate;
	private String zoneCode;
	private String pendingAge;
	private String pendingAgeSlab;
	private String lossDescription;
	private String supplierName;
	private String surveyorAppoinedOn;
	private String recieptPsrOn;
	private String initialSurveyDate;
	private String recieptFsrOn;
	private String surveyorReportRefNo;
	private String investigatorName;
	private String imdCode;
	private String productCode;
	private String lineOfBussiness;
	private String imdName;
	private String legalCategory;
	private String coInsurenceType;
	private String kindOfLoss;
	private String lastReviewedDate;
	private String lastReviewedRemarks;
	private String latestRemarks;
	private String nextReviewDate;
	private String paidAmount;
	private String outstandingAmount;
	private String partnerId;
	private String payeeType;
	private String neftPayeeStatus;
	private String payeeId;
	private String nextPayeeStatus;
	private String dateOfLoss;
	private TaskDetailsDto taskDetails;
	private String placeOfLoss;
	private String pincode;
	private String state;
	private String city;
	private String area;
	private String landmark;
	private String mobileNumber;
	private String alternateNumber;
	private String customerEmailId;
	private String claimHandler;
	private String timeOfLoss;
	private String closingDate;
	private String productCategory;
	private ClaimDataDetailsDto claimDataDetails;
	private String sumInsured;
	private String claimWorkflow;
	private String closingReason;
	private String userId;
	private String firstDocReceivedDate;
	private String lastDocReceivedDate;
	private String chVerification;
	private String reOpenDate;
	private String reOpenRemarks;
	private String reOpenStatus;
	private String updatedBy;
	private String diaType;
	private String diaId;
	private String diaAmt;
	private String surDelayReason;
	private String surDelayDays;
	private String regDelayReason;
	private String regDelayDays;
	private String policyStartDate;
	private String policyEndDate;
	private String specialComment;

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getLossOccuredDetails() {
		return lossOccuredDetails;
	}

	public void setLossOccuredDetails(String lossOccuredDetails) {
		this.lossOccuredDetails = lossOccuredDetails;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public String getHandlerName() {
		return handlerName;
	}

	public void setHandlerName(String handlerName) {
		this.handlerName = handlerName;
	}

	public WorkFlowDetailsDto getWorkFlowDetails() {
		return workFlowDetails;
	}

	public void setWorkFlowDetails(WorkFlowDetailsDto workFlowDetails) {
		this.workFlowDetails = workFlowDetails;
	}

	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	public String getCauseOffLoss() {
		return causeOffLoss;
	}

	public void setCauseOffLoss(String causeOffLoss) {
		this.causeOffLoss = causeOffLoss;
	}

	public String getLossTime() {
		return lossTime;
	}

	public void setLossTime(String lossTime) {
		this.lossTime = lossTime;
	}

	public String getLossDate() {
		return lossDate;
	}

	public void setLossDate(String lossDate) {
		this.lossDate = lossDate;
	}

	public String getIntimationSource() {
		return intimationSource;
	}

	public void setIntimationSource(String intimationSource) {
		this.intimationSource = intimationSource;
	}

	public String getFraudAlert() {
		return fraudAlert;
	}

	public void setFraudAlert(String fraudAlert) {
		this.fraudAlert = fraudAlert;
	}

	public String getReserveAmount() {
		return reserveAmount;
	}

	public void setReserveAmount(String reserveAmount) {
		this.reserveAmount = reserveAmount;
	}

	public String getHowLossOccured() {
		return howLossOccured;
	}

	public void setHowLossOccured(String howLossOccured) {
		this.howLossOccured = howLossOccured;
	}

	public String getSalvageStatus() {
		return salvageStatus;
	}

	public void setSalvageStatus(String salvageStatus) {
		this.salvageStatus = salvageStatus;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public InvoiceDetailsDto getInvoiceDetails() {
		return invoiceDetails;
	}

	public void setInvoiceDetails(InvoiceDetailsDto invoiceDetails) {
		this.invoiceDetails = invoiceDetails;
	}

	public String getClaimRefNo() {
		return claimRefNo;
	}

	public void setClaimRefNo(String claimRefNo) {
		this.claimRefNo = claimRefNo;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getIntimationDate() {
		return intimationDate;
	}

	public void setIntimationDate(String intimationDate) {
		this.intimationDate = intimationDate;
	}

	public String getZoneCode() {
		return zoneCode;
	}

	public void setZoneCode(String zoneCode) {
		this.zoneCode = zoneCode;
	}

	public String getPendingAge() {
		return pendingAge;
	}

	public void setPendingAge(String pendingAge) {
		this.pendingAge = pendingAge;
	}

	public String getPendingAgeSlab() {
		return pendingAgeSlab;
	}

	public void setPendingAgeSlab(String pendingAgeSlab) {
		this.pendingAgeSlab = pendingAgeSlab;
	}

	public String getLossDescription() {
		return lossDescription;
	}

	public void setLossDescription(String lossDescription) {
		this.lossDescription = lossDescription;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getSurveyorAppoinedOn() {
		return surveyorAppoinedOn;
	}

	public void setSurveyorAppoinedOn(String surveyorAppoinedOn) {
		this.surveyorAppoinedOn = surveyorAppoinedOn;
	}

	public String getRecieptPsrOn() {
		return recieptPsrOn;
	}

	public void setRecieptPsrOn(String recieptPsrOn) {
		this.recieptPsrOn = recieptPsrOn;
	}

	public String getInitialSurveyDate() {
		return initialSurveyDate;
	}

	public void setInitialSurveyDate(String initialSurveyDate) {
		this.initialSurveyDate = initialSurveyDate;
	}

	public String getRecieptFsrOn() {
		return recieptFsrOn;
	}

	public void setRecieptFsrOn(String recieptFsrOn) {
		this.recieptFsrOn = recieptFsrOn;
	}

	public String getSurveyorReportRefNo() {
		return surveyorReportRefNo;
	}

	public void setSurveyorReportRefNo(String surveyorReportRefNo) {
		this.surveyorReportRefNo = surveyorReportRefNo;
	}

	public String getInvestigatorName() {
		return investigatorName;
	}

	public void setInvestigatorName(String investigatorName) {
		this.investigatorName = investigatorName;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getLineOfBussiness() {
		return lineOfBussiness;
	}

	public void setLineOfBussiness(String lineOfBussiness) {
		this.lineOfBussiness = lineOfBussiness;
	}

	public String getLegalCategory() {
		return legalCategory;
	}

	public void setLegalCategory(String legalCategory) {
		this.legalCategory = legalCategory;
	}

	public String getCoInsurenceType() {
		return coInsurenceType;
	}

	public void setCoInsurenceType(String coInsurenceType) {
		this.coInsurenceType = coInsurenceType;
	}

	public String getKindOfLoss() {
		return kindOfLoss;
	}

	public void setKindOfLoss(String kindOfLoss) {
		this.kindOfLoss = kindOfLoss;
	}

	public String getLastReviewedDate() {
		return lastReviewedDate;
	}

	public void setLastReviewedDate(String lastReviewedDate) {
		this.lastReviewedDate = lastReviewedDate;
	}

	public String getLastReviewedRemarks() {
		return lastReviewedRemarks;
	}

	public void setLastReviewedRemarks(String lastReviewedRemarks) {
		this.lastReviewedRemarks = lastReviewedRemarks;
	}

	public String getLatestRemarks() {
		return latestRemarks;
	}

	public void setLatestRemarks(String latestRemarks) {
		this.latestRemarks = latestRemarks;
	}

	public String getNextReviewDate() {
		return nextReviewDate;
	}

	public void setNextReviewDate(String nextReviewDate) {
		this.nextReviewDate = nextReviewDate;
	}

	public String getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(String outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getPayeeType() {
		return payeeType;
	}

	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	public String getNeftPayeeStatus() {
		return neftPayeeStatus;
	}

	public void setNeftPayeeStatus(String neftPayeeStatus) {
		this.neftPayeeStatus = neftPayeeStatus;
	}

	public String getPayeeId() {
		return payeeId;
	}

	public void setPayeeId(String payeeId) {
		this.payeeId = payeeId;
	}

	public String getNextPayeeStatus() {
		return nextPayeeStatus;
	}

	public void setNextPayeeStatus(String nextPayeeStatus) {
		this.nextPayeeStatus = nextPayeeStatus;
	}

	public String getDateOfLoss() {
		return dateOfLoss;
	}

	public void setDateOfLoss(String dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}

	public TaskDetailsDto getTaskDetails() {
		return taskDetails;
	}

	public void setTaskDetails(TaskDetailsDto taskDetails) {
		this.taskDetails = taskDetails;
	}

	public String getPlaceOfLoss() {
		return placeOfLoss;
	}

	public void setPlaceOfLoss(String placeOfLoss) {
		this.placeOfLoss = placeOfLoss;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAlternateNumber() {
		return alternateNumber;
	}

	public void setAlternateNumber(String alternateNumber) {
		this.alternateNumber = alternateNumber;
	}

	public String getCustomerEmailId() {
		return customerEmailId;
	}

	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}

	public String getImdCode() {
		return imdCode;
	}

	public void setImdCode(String imdCode) {
		this.imdCode = imdCode;
	}

	public String getImdName() {
		return imdName;
	}

	public void setImdName(String imdName) {
		this.imdName = imdName;
	}

	public String getClaimHandler() {
		return claimHandler;
	}

	public void setClaimHandler(String claimHandler) {
		this.claimHandler = claimHandler;
	}

	public String getTimeOfLoss() {
		return timeOfLoss;
	}

	public void setTimeOfLoss(String timeOfLoss) {
		this.timeOfLoss = timeOfLoss;
	}

	public String getClosingDate() {
		return closingDate;
	}

	public void setClosingDate(String closingDate) {
		this.closingDate = closingDate;
	}

	public ClaimDataDetailsDto getClaimDataDetails() {
		return claimDataDetails;
	}

	public void setClaimDataDetails(ClaimDataDetailsDto claimDataDetails) {
		this.claimDataDetails = claimDataDetails;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getSumInsured() {
		return sumInsured;
	}

	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}

	public String getClaimWorkflow() {
		return claimWorkflow;
	}

	public void setClaimWorkflow(String claimWorkflow) {
		this.claimWorkflow = claimWorkflow;
	}

	public String getClosingReason() {
		return closingReason;
	}

	public void setClosingReason(String closingReason) {
		this.closingReason = closingReason;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstDocReceivedDate() {
		return firstDocReceivedDate;
	}

	public void setFirstDocReceivedDate(String firstDocReceivedDate) {
		this.firstDocReceivedDate = firstDocReceivedDate;
	}

	public String getLastDocReceivedDate() {
		return lastDocReceivedDate;
	}

	public void setLastDocReceivedDate(String lastDocReceivedDate) {
		this.lastDocReceivedDate = lastDocReceivedDate;
	}

	public String getChVerification() {
		return chVerification;
	}

	public void setChVerification(String chVerification) {
		this.chVerification = chVerification;
	}

	public String getReOpenDate() {
		return reOpenDate;
	}

	public void setReOpenDate(String reOpenDate) {
		this.reOpenDate = reOpenDate;
	}

	public String getReOpenRemarks() {
		return reOpenRemarks;
	}

	public void setReOpenRemarks(String reOpenRemarks) {
		this.reOpenRemarks = reOpenRemarks;
	}

	public String getReOpenStatus() {
		return reOpenStatus;
	}

	public void setReOpenStatus(String reOpenStatus) {
		this.reOpenStatus = reOpenStatus;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getDiaType() {
		return diaType;
	}

	public void setDiaType(String diaType) {
		this.diaType = diaType;
	}

	public String getDiaId() {
		return diaId;
	}

	public void setDiaId(String diaId) {
		this.diaId = diaId;
	}

	public String getDiaAmt() {
		return diaAmt;
	}

	public void setDiaAmt(String diaAmt) {
		this.diaAmt = diaAmt;
	}

	public String getSurDelayReason() {
		return surDelayReason;
	}

	public void setSurDelayReason(String surDelayReason) {
		this.surDelayReason = surDelayReason;
	}

	public String getSurDelayDays() {
		return surDelayDays;
	}

	public void setSurDelayDays(String surDelayDays) {
		this.surDelayDays = surDelayDays;
	}

	public String getRegDelayReason() {
		return regDelayReason;
	}

	public void setRegDelayReason(String regDelayReason) {
		this.regDelayReason = regDelayReason;
	}

	public String getRegDelayDays() {
		return regDelayDays;
	}

	public void setRegDelayDays(String regDelayDays) {
		this.regDelayDays = regDelayDays;
	}

	public String getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(String policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public String getPolicyEndDate() {
		return policyEndDate;
	}

	public void setPolicyEndDate(String policyEndDate) {
		this.policyEndDate = policyEndDate;
	}

	public String getSpecialComment() {
		return specialComment;
	}

	public void setSpecialComment(String specialComment) {
		this.specialComment = specialComment;
	}

}
