package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

public class WfStepsDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String description;
	private String wfStatusCode;
	private String claimStatusCode;
	private String claimSubStatusCode;
	private Boolean isNotificationRequired;
	private Boolean isActive;
	private String createdDate;
	private String modifiedDate;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getWfStatusCode() {
		return wfStatusCode;
	}

	public void setWfStatusCode(String wfStatusCode) {
		this.wfStatusCode = wfStatusCode;
	}

	public String getClaimStatusCode() {
		return claimStatusCode;
	}

	public void setClaimStatusCode(String claimStatusCode) {
		this.claimStatusCode = claimStatusCode;
	}

	public String getClaimSubStatusCode() {
		return claimSubStatusCode;
	}

	public void setClaimSubStatusCode(String claimSubStatusCode) {
		this.claimSubStatusCode = claimSubStatusCode;
	}

	public Boolean getIsNotificationRequired() {
		return isNotificationRequired;
	}

	public void setIsNotificationRequired(Boolean isNotificationRequired) {
		this.isNotificationRequired = isNotificationRequired;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

}
