package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GeneralDetailsDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String claimNumber;
	private String dateOfLoss;
	private String eventCode;
	private String claimHandlerUserId;
	private String intimationSource;
	private String fraudAlert;
	private String pendingAge;
	private String intimationDate;
	private String neftStatus;
	private String policyNumber;
	private String registrationDate;
	private String causeOffLoss;
	private String lossTime;
	private String salvageStatus;
	private String deficiencyReason;
	private String reserveAmount;
	private String estimatedLossAmount;
	private String insuredPanNumber;
	private String customerLink;
	private String locationCode;
	private String placeOfLoss;
	private String createdDate;
	private String zoneCode;
	private String policyStartDate;
	private String policyEndDate;
	public String getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(String policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public String getPolicyEndDate() {
		return policyEndDate;
	}

	public void setPolicyEndDate(String policyEndDate) {
		this.policyEndDate = policyEndDate;
	}


	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getDateOfLoss() {
		return dateOfLoss;
	}

	public void setDateOfLoss(String dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}

	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	public String getClaimHandlerUserId() {
		return claimHandlerUserId;
	}

	public void setClaimHandlerUserId(String claimHandlerUserId) {
		this.claimHandlerUserId = claimHandlerUserId;
	}

	public String getIntimationSource() {
		return intimationSource;
	}

	public void setIntimationSource(String intimationSource) {
		this.intimationSource = intimationSource;
	}

	public String getFraudAlert() {
		return fraudAlert;
	}

	public void setFraudAlert(String fraudAlert) {
		this.fraudAlert = fraudAlert;
	}

	public String getPendingAge() {
		return pendingAge;
	}

	public void setPendingAge(String pendingAge) {
		this.pendingAge = pendingAge;
	}

	public String getIntimationDate() {
		return intimationDate;
	}

	public void setIntimationDate(String intimationDate) {
		this.intimationDate = intimationDate;
	}

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getCauseOffLoss() {
		return causeOffLoss;
	}

	public void setCauseOffLoss(String causeOffLoss) {
		this.causeOffLoss = causeOffLoss;
	}

	public String getLossTime() {
		return lossTime;
	}

	public void setLossTime(String lossTime) {
		this.lossTime = lossTime;
	}

	public String getSalvageStatus() {
		return salvageStatus;
	}

	public void setSalvageStatus(String salvageStatus) {
		this.salvageStatus = salvageStatus;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getReserveAmount() {
		return reserveAmount;
	}

	public void setReserveAmount(String reserveAmount) {
		this.reserveAmount = reserveAmount;
	}

	public String getEstimatedLossAmount() {
		return estimatedLossAmount;
	}

	public void setEstimatedLossAmount(String estimatedLossAmount) {
		this.estimatedLossAmount = estimatedLossAmount;
	}

	public String getInsuredPanNumber() {
		return insuredPanNumber;
	}

	public void setInsuredPanNumber(String insuredPanNumber) {
		this.insuredPanNumber = insuredPanNumber;
	}

	public String getCustomerLink() {
		return customerLink;
	}

	public void setCustomerLink(String customerLink) {
		this.customerLink = customerLink;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getPlaceOfLoss() {
		return placeOfLoss;
	}

	public void setPlaceOfLoss(String placeOfLoss) {
		this.placeOfLoss = placeOfLoss;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getZoneCode() {
		return zoneCode;
	}

	public void setZoneCode(String zoneCode) {
		this.zoneCode = zoneCode;
	}
}
