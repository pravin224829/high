/**
 * 
 */
package com.fa.bajajallianz.cccp.surveyor.common.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author praveen
 *
 */
public class NotifyUserDto implements Serializable{

	private static final long serialVersionUID = 1L;
	private String notifyConfigId;
	private String claimNumber;
	private String surveyNumber;
	private String taskId;
	private String subject;
	private String content;
	private String type;
	private Boolean isRead;
	private String userId;
	private String createdDate;
	private String modifiedDate;
	private String unreadCount;
	public String getNotifyConfigId() {
		return notifyConfigId;
	}
	public void setNotifyConfigId(String notifyConfigId) {
		this.notifyConfigId = notifyConfigId;
	}
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public String getSurveyNumber() {
		return surveyNumber;
	}
	public void setSurveyNumber(String surveyNumber) {
		this.surveyNumber = surveyNumber;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Boolean getIsRead() {
		return isRead;
	}
	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getUnreadCount() {
		return unreadCount;
	}
	public void setUnreadCount(String unreadCount) {
		this.unreadCount = unreadCount;
	}

	
}
