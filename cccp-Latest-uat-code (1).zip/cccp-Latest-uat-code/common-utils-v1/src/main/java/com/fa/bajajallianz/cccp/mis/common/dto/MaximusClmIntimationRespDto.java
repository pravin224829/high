package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusClmIntimationRespDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private ApplicationErrorDto applicationError;
	private ClaimIntimationDetailsDto claimIntimationDetails;

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public ClaimIntimationDetailsDto getClaimIntimationDetails() {
		return claimIntimationDetails;
	}

	public void setClaimIntimationDetails(ClaimIntimationDetailsDto claimIntimationDetails) {
		this.claimIntimationDetails = claimIntimationDetails;
	}

}
