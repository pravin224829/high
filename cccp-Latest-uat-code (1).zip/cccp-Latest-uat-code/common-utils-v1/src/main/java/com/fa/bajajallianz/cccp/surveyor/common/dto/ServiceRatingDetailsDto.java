package com.fa.bajajallianz.cccp.surveyor.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceRatingDetailsDto  implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String partyId;
	private String surveyorNo;
	private String claimNumber;
	private String overAllRating;
	private String totalCollectedWeightage;
	private Boolean isActive;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;	
	private String modifiedBy;
	private List<GradeQuestionDetailsDto> questionnaireDetails;
	
	
	public String getPartyId() {
		return partyId;
	}
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}
	public String getSurveyorNo() {
		return surveyorNo;
	}
	public void setSurveyorNo(String surveyorNo) {
		this.surveyorNo = surveyorNo;
	}
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public String getOverAllRating() {
		return overAllRating;
	}
	public void setOverAllRating(String overAllRating) {
		this.overAllRating = overAllRating;
	}
	public String getTotalCollectedWeightage() {
		return totalCollectedWeightage;
	}
	public void setTotalCollectedWeightage(String totalCollectedWeightage) {
		this.totalCollectedWeightage = totalCollectedWeightage;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public List<GradeQuestionDetailsDto> getQuestionnaireDetails() {
		return questionnaireDetails;
	}
	public void setQuestionnaireDetails(List<GradeQuestionDetailsDto> questionnaireDetails) {
		this.questionnaireDetails = questionnaireDetails;
	}

}
