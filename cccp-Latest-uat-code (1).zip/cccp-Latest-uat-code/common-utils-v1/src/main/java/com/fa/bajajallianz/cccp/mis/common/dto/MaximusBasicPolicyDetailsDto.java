package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusBasicPolicyDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String strBaseCurrencyRate;
	private String strPolicyBranchName;
	private String strPolicyTermUnit;
	private String strPolicyInceptionDate;
	private String strProductCode;
	private String strPremiumCurrencyRate;
	private String strPremiumMode;
	private String strNewPremIndicator;
	private String strPremiumFrequency;
	private String strPolicyQuoteNumber;
	private String strPolicyHolderCode;
	private String strPolicyDetailsChangeIndicator;
	private String strPolicyExpiryDate;
	private String strAgentCode;
	private String strCommission;
	private String strIntimationDate;
	private String strPolicyTerm;
	private String strBaseCurrency;
	private String strPremiumCurrency;
	private String strTotalLoadingAmount;
	private String strTotalDiscountAmount;
	private String strRetCode;
	private String strRetError;
	private String strApplicationCode;
	private String strprivilegeCode;
	private String strCalculatePremiumIndicator;
	private String strUpdatePartyIndicator;
	private String strMultithreadIndicator;
	private String strPolicyStatusCode;
	private String strPolicyStatusDesc;
	private String strRiskIdForRemoval;
	private String strReferIndicator;
	private String strBillingStake;
	private String strBusinessEvent;
	private String strPolicyNumber;
	private String productName;
	
	public String getStrBaseCurrencyRate() {
		return strBaseCurrencyRate;
	}
	public void setStrBaseCurrencyRate(String strBaseCurrencyRate) {
		this.strBaseCurrencyRate = strBaseCurrencyRate;
	}
	public String getStrPolicyBranchName() {
		return strPolicyBranchName;
	}
	public void setStrPolicyBranchName(String strPolicyBranchName) {
		this.strPolicyBranchName = strPolicyBranchName;
	}
	public String getStrPolicyTermUnit() {
		return strPolicyTermUnit;
	}
	public void setStrPolicyTermUnit(String strPolicyTermUnit) {
		this.strPolicyTermUnit = strPolicyTermUnit;
	}
	public String getStrPolicyInceptionDate() {
		return strPolicyInceptionDate;
	}
	public void setStrPolicyInceptionDate(String strPolicyInceptionDate) {
		this.strPolicyInceptionDate = strPolicyInceptionDate;
	}
	public String getStrProductCode() {
		return strProductCode;
	}
	public void setStrProductCode(String strProductCode) {
		this.strProductCode = strProductCode;
	}
	public String getStrPremiumCurrencyRate() {
		return strPremiumCurrencyRate;
	}
	public void setStrPremiumCurrencyRate(String strPremiumCurrencyRate) {
		this.strPremiumCurrencyRate = strPremiumCurrencyRate;
	}
	public String getStrPremiumMode() {
		return strPremiumMode;
	}
	public void setStrPremiumMode(String strPremiumMode) {
		this.strPremiumMode = strPremiumMode;
	}
	public String getStrNewPremIndicator() {
		return strNewPremIndicator;
	}
	public void setStrNewPremIndicator(String strNewPremIndicator) {
		this.strNewPremIndicator = strNewPremIndicator;
	}
	public String getStrPremiumFrequency() {
		return strPremiumFrequency;
	}
	public void setStrPremiumFrequency(String strPremiumFrequency) {
		this.strPremiumFrequency = strPremiumFrequency;
	}
	public String getStrPolicyQuoteNumber() {
		return strPolicyQuoteNumber;
	}
	public void setStrPolicyQuoteNumber(String strPolicyQuoteNumber) {
		this.strPolicyQuoteNumber = strPolicyQuoteNumber;
	}
	public String getStrPolicyHolderCode() {
		return strPolicyHolderCode;
	}
	public void setStrPolicyHolderCode(String strPolicyHolderCode) {
		this.strPolicyHolderCode = strPolicyHolderCode;
	}
	public String getStrPolicyDetailsChangeIndicator() {
		return strPolicyDetailsChangeIndicator;
	}
	public void setStrPolicyDetailsChangeIndicator(String strPolicyDetailsChangeIndicator) {
		this.strPolicyDetailsChangeIndicator = strPolicyDetailsChangeIndicator;
	}
	public String getStrPolicyExpiryDate() {
		return strPolicyExpiryDate;
	}
	public void setStrPolicyExpiryDate(String strPolicyExpiryDate) {
		this.strPolicyExpiryDate = strPolicyExpiryDate;
	}
	public String getStrAgentCode() {
		return strAgentCode;
	}
	public void setStrAgentCode(String strAgentCode) {
		this.strAgentCode = strAgentCode;
	}
	public String getStrCommission() {
		return strCommission;
	}
	public void setStrCommission(String strCommission) {
		this.strCommission = strCommission;
	}
	public String getStrIntimationDate() {
		return strIntimationDate;
	}
	public void setStrIntimationDate(String strIntimationDate) {
		this.strIntimationDate = strIntimationDate;
	}
	public String getStrPolicyTerm() {
		return strPolicyTerm;
	}
	public void setStrPolicyTerm(String strPolicyTerm) {
		this.strPolicyTerm = strPolicyTerm;
	}
	public String getStrBaseCurrency() {
		return strBaseCurrency;
	}
	public void setStrBaseCurrency(String strBaseCurrency) {
		this.strBaseCurrency = strBaseCurrency;
	}
	public String getStrPremiumCurrency() {
		return strPremiumCurrency;
	}
	public void setStrPremiumCurrency(String strPremiumCurrency) {
		this.strPremiumCurrency = strPremiumCurrency;
	}
	public String getStrTotalLoadingAmount() {
		return strTotalLoadingAmount;
	}
	public void setStrTotalLoadingAmount(String strTotalLoadingAmount) {
		this.strTotalLoadingAmount = strTotalLoadingAmount;
	}
	public String getStrTotalDiscountAmount() {
		return strTotalDiscountAmount;
	}
	public void setStrTotalDiscountAmount(String strTotalDiscountAmount) {
		this.strTotalDiscountAmount = strTotalDiscountAmount;
	}
	public String getStrRetCode() {
		return strRetCode;
	}
	public void setStrRetCode(String strRetCode) {
		this.strRetCode = strRetCode;
	}
	public String getStrRetError() {
		return strRetError;
	}
	public void setStrRetError(String strRetError) {
		this.strRetError = strRetError;
	}
	public String getStrApplicationCode() {
		return strApplicationCode;
	}
	public void setStrApplicationCode(String strApplicationCode) {
		this.strApplicationCode = strApplicationCode;
	}
	public String getStrprivilegeCode() {
		return strprivilegeCode;
	}
	public void setStrprivilegeCode(String strprivilegeCode) {
		this.strprivilegeCode = strprivilegeCode;
	}
	public String getStrCalculatePremiumIndicator() {
		return strCalculatePremiumIndicator;
	}
	public void setStrCalculatePremiumIndicator(String strCalculatePremiumIndicator) {
		this.strCalculatePremiumIndicator = strCalculatePremiumIndicator;
	}
	public String getStrUpdatePartyIndicator() {
		return strUpdatePartyIndicator;
	}
	public void setStrUpdatePartyIndicator(String strUpdatePartyIndicator) {
		this.strUpdatePartyIndicator = strUpdatePartyIndicator;
	}
	public String getStrMultithreadIndicator() {
		return strMultithreadIndicator;
	}
	public void setStrMultithreadIndicator(String strMultithreadIndicator) {
		this.strMultithreadIndicator = strMultithreadIndicator;
	}
	public String getStrPolicyStatusCode() {
		return strPolicyStatusCode;
	}
	public void setStrPolicyStatusCode(String strPolicyStatusCode) {
		this.strPolicyStatusCode = strPolicyStatusCode;
	}
	public String getStrPolicyStatusDesc() {
		return strPolicyStatusDesc;
	}
	public void setStrPolicyStatusDesc(String strPolicyStatusDesc) {
		this.strPolicyStatusDesc = strPolicyStatusDesc;
	}
	public String getStrRiskIdForRemoval() {
		return strRiskIdForRemoval;
	}
	public void setStrRiskIdForRemoval(String strRiskIdForRemoval) {
		this.strRiskIdForRemoval = strRiskIdForRemoval;
	}
	public String getStrReferIndicator() {
		return strReferIndicator;
	}
	public void setStrReferIndicator(String strReferIndicator) {
		this.strReferIndicator = strReferIndicator;
	}
	public String getStrBillingStake() {
		return strBillingStake;
	}
	public void setStrBillingStake(String strBillingStake) {
		this.strBillingStake = strBillingStake;
	}
	public String getStrBusinessEvent() {
		return strBusinessEvent;
	}
	public void setStrBusinessEvent(String strBusinessEvent) {
		this.strBusinessEvent = strBusinessEvent;
	}
	public String getStrPolicyNumber() {
		return strPolicyNumber;
	}
	public void setStrPolicyNumber(String strPolicyNumber) {
		this.strPolicyNumber = strPolicyNumber;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
}
