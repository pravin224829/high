package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusCityDto implements Serializable {

/**
 * 
 */
private static final long serialVersionUID = 1L;

private List<MaximusCityDetailsDto> cityDetails;

public List<MaximusCityDetailsDto> getCityDetails() {
	return cityDetails;
}

public void setCityDetails(List<MaximusCityDetailsDto> cityDetails) {
	this.cityDetails = cityDetails;
}



}
