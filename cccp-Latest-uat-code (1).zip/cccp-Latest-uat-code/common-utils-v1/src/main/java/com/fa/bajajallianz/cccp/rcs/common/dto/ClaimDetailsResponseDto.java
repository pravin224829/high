package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimDetailsResponseDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private GeneralDetailsDto generalDetails;
	private RcsClaimDetailsDto claimDetails;
	private List<TaskDetailsDto> taskDetails;
	
	public GeneralDetailsDto getGeneralDetails() {
		return generalDetails;
	}
	public void setGeneralDetails(GeneralDetailsDto generalDetails) {
		this.generalDetails = generalDetails;
	}
	public RcsClaimDetailsDto getClaimDetails() {
		return claimDetails;
	}
	public void setClaimDetails(RcsClaimDetailsDto claimDetails) {
		this.claimDetails = claimDetails;
	}
	public List<TaskDetailsDto> getTaskDetails() {
		return taskDetails;
	}
	public void setTaskDetails(List<TaskDetailsDto> taskDetails) {
		this.taskDetails = taskDetails;
	}
	
	
}
