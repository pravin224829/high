package com.fa.bajajallianz.cccp.common.dto;

import java.util.List;

public class ClientsFieldsConfigDto {
	private static final long serialVersionUID = 1L;
	private String partnerId;
	private String policyNumber;
	private String effectiveFromDate;
	private String effectiveToDate;
	private List<RuntimeFields> fieldDetails;
	private List<ClientsFieldsConfigDto> clientsFieldsConfigDto;
//	private String isActive;
	
	public String getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getEffectiveFromDate() {
		return effectiveFromDate;
	}
	public void setEffectiveFromDate(String effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}
	public String getEffectiveToDate() {
		return effectiveToDate;
	}
	public void setEffectiveToDate(String effectiveToDate) {
		this.effectiveToDate = effectiveToDate;
	}
//	public String getIsActive() {
//		return isActive;
//	}
//	public void setIsActive(String isActive) {
//		this.isActive = isActive;
//	}
	public List<RuntimeFields> getFieldDetails() {
		return fieldDetails;
	}
	public void setFieldDetails(List<RuntimeFields> fieldDetails) {
		this.fieldDetails = fieldDetails;
	}
	public List<ClientsFieldsConfigDto> getClientsFieldsConfigDto() {
		return clientsFieldsConfigDto;
	}
	public void setClientsFieldsConfigDto(List<ClientsFieldsConfigDto> clientsFieldsConfigDto) {
		this.clientsFieldsConfigDto = clientsFieldsConfigDto;
	}
	
	
}
