/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author santhosh
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RemittanceDetailsDto implements Serializable{

	private static final long serialVersionUID = 1L;
	private String currency;
	private String country;
	private String natureOfPayment;
	private String surveyorRefNo;
	private String frgnCurAmount;
	private String exchangeRate;
	private String exchangeRateDate;
	private String amountInInr;
	private String paymentAmt;
	private String sysCalculatedInrAmt;
	private String principalPlaceOfBusinessOfRecipient;
	
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getNatureOfPayment() {
		return natureOfPayment;
	}
	public void setNatureOfPayment(String natureOfPayment) {
		this.natureOfPayment = natureOfPayment;
	}
	public String getSurveyorRefNo() {
		return surveyorRefNo;
	}
	public void setSurveyorRefNo(String surveyorRefNo) {
		this.surveyorRefNo = surveyorRefNo;
	}
	public String getFrgnCurAmount() {
		return frgnCurAmount;
	}
	public void setFrgnCurAmount(String frgnCurAmount) {
		this.frgnCurAmount = frgnCurAmount;
	}
	public String getExchangeRate() {
		return exchangeRate;
	}
	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}
	public String getExchangeRateDate() {
		return exchangeRateDate;
	}
	public void setExchangeRateDate(String exchangeRateDate) {
		this.exchangeRateDate = exchangeRateDate;
	}
	public String getAmountInInr() {
		return amountInInr;
	}
	public void setAmountInInr(String amountInInr) {
		this.amountInInr = amountInInr;
	}
	public String getPaymentAmt() {
		return paymentAmt;
	}
	public void setPaymentAmt(String paymentAmt) {
		this.paymentAmt = paymentAmt;
	}
	public String getSysCalculatedInrAmt() {
		return sysCalculatedInrAmt;
	}
	public void setSysCalculatedInrAmt(String sysCalculatedInrAmt) {
		this.sysCalculatedInrAmt = sysCalculatedInrAmt;
	}
	public String getPrincipalPlaceOfBusinessOfRecipient() {
		return principalPlaceOfBusinessOfRecipient;
	}
	public void setPrincipalPlaceOfBusinessOfRecipient(String principalPlaceOfBusinessOfRecipient) {
		this.principalPlaceOfBusinessOfRecipient = principalPlaceOfBusinessOfRecipient;
	}
	
}
