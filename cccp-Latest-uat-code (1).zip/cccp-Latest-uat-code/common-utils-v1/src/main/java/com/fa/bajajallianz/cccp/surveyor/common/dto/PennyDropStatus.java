package com.fa.bajajallianz.cccp.surveyor.common.dto;
 
import java.io.Serializable;
 
import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
 
@JsonIgnoreProperties(ignoreUnknown = true)
public class PennyDropStatus implements Serializable {
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String bennyName;
	private ApplicationErrorDto applicationError;
 
	
	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}
 
	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}
 
	public String getBennyName() {
		return bennyName;
	}
 
	public void setBennyName(String bennyName) {
		this.bennyName = bennyName;
	}
 
 
}
