/**
 * 
 */
package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author santhosh
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SurveyDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String surveyorNo;
	private String claimNumber;
	private String surveyorId;
	private String actionCode;
	private String dateOfVisit;
	private String timeofVisit;
	private String surveyorMobileNo;
	private String surveyorEmailId;
	private String message;
	private String modifiedDate;
	private String status;
	private String surveyorName;
	private String supplierId;
	private String surveyorCategory;
	private String reserveFees;
	private String delayReason;
	private String appoinmentDate;
	private String name;
	private String userId;
	private String roleCode;
	private String partyId;
	private String surveyNumber;
	private String declineReason;
	private Boolean isFirst;
	private List<String> categoryList;
	private String supplierName;
	private String id;
	private String surveyNo;
	private String policyNo;
	private String insuredName;
	private String claimStatus;
	private String claimSubStatus;
	private String deficiencyReason;
	private String policyNumber;
	private String claimHandlerName;
	private String claimHandlerId;
	private String claimLocationCode;
	private String initialSurveyDate;
	private String reasonForInitialDate;
	private String psrIlaDate;
	private String reasonForPsrDate;
	private String fsrDate;
	private String surveyRefNo;
	private String reasonForFsrDate;
	private Boolean isActive;
	private String stakeCode;
	private String stakeName;

	public String getSurveyorNo() {
		return surveyorNo;
	}

	public void setSurveyorNo(String surveyorNo) {
		this.surveyorNo = surveyorNo;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getClaimHandlerName() {
		return claimHandlerName;
	}

	public void setClaimHandlerName(String claimHandlerName) {
		this.claimHandlerName = claimHandlerName;
	}

	public String getClaimHandlerId() {
		return claimHandlerId;
	}

	public void setClaimHandlerId(String claimHandlerId) {
		this.claimHandlerId = claimHandlerId;
	}

	public String getClaimLocationCode() {
		return claimLocationCode;
	}

	public void setClaimLocationCode(String claimLocationCode) {
		this.claimLocationCode = claimLocationCode;
	}

	public String getInitialSurveyDate() {
		return initialSurveyDate;
	}

	public void setInitialSurveyDate(String initialSurveyDate) {
		this.initialSurveyDate = initialSurveyDate;
	}

	public String getReasonForInitialDate() {
		return reasonForInitialDate;
	}

	public void setReasonForInitialDate(String reasonForInitialDate) {
		this.reasonForInitialDate = reasonForInitialDate;
	}

	public String getPsrIlaDate() {
		return psrIlaDate;
	}

	public void setPsrIlaDate(String psrIlaDate) {
		this.psrIlaDate = psrIlaDate;
	}

	public String getReasonForPsrDate() {
		return reasonForPsrDate;
	}

	public void setReasonForPsrDate(String reasonForPsrDate) {
		this.reasonForPsrDate = reasonForPsrDate;
	}

	public String getFsrDate() {
		return fsrDate;
	}

	public void setFsrDate(String fsrDate) {
		this.fsrDate = fsrDate;
	}

	public String getSurveyRefNo() {
		return surveyRefNo;
	}

	public void setSurveyRefNo(String surveyRefNo) {
		this.surveyRefNo = surveyRefNo;
	}

	public String getReasonForFsrDate() {
		return reasonForFsrDate;
	}

	public void setReasonForFsrDate(String reasonForFsrDate) {
		this.reasonForFsrDate = reasonForFsrDate;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getSurveyorId() {
		return surveyorId;
	}

	public void setSurveyorId(String surveyorId) {
		this.surveyorId = surveyorId;
	}

	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public String getDateOfVisit() {
		return dateOfVisit;
	}

	public void setDateOfVisit(String dateOfVisit) {
		this.dateOfVisit = dateOfVisit;
	}

	public String getSurveyorMobileNo() {
		return surveyorMobileNo;
	}

	public void setSurveyorMobileNo(String surveyorMobileNo) {
		this.surveyorMobileNo = surveyorMobileNo;
	}

	public String getSurveyorEmailId() {
		return surveyorEmailId;
	}

	public void setSurveyorEmailId(String surveyorEmailId) {
		this.surveyorEmailId = surveyorEmailId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSurveyorName() {
		return surveyorName;
	}

	public void setSurveyorName(String surveyorName) {
		this.surveyorName = surveyorName;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getSurveyorCategory() {
		return surveyorCategory;
	}

	public void setSurveyorCategory(String surveyorCategory) {
		this.surveyorCategory = surveyorCategory;
	}

	public String getReserveFees() {
		return reserveFees;
	}

	public void setReserveFees(String reserveFees) {
		this.reserveFees = reserveFees;
	}

	public String getDelayReason() {
		return delayReason;
	}

	public void setDelayReason(String delayReason) {
		this.delayReason = delayReason;
	}

	public String getAppoinmentDate() {
		return appoinmentDate;
	}

	public void setAppoinmentDate(String appoinmentDate) {
		this.appoinmentDate = appoinmentDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getSurveyNumber() {
		return surveyNumber;
	}

	public void setSurveyNumber(String surveyNumber) {
		this.surveyNumber = surveyNumber;
	}

	public String getDeclineReason() {
		return declineReason;
	}

	public void setDeclineReason(String declineReason) {
		this.declineReason = declineReason;
	}

	public Boolean getIsFirst() {
		return isFirst;
	}

	public void setIsFirst(Boolean isFirst) {
		this.isFirst = isFirst;
	}

	public List<String> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<String> categoryList) {
		this.categoryList = categoryList;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSurveyNo() {
		return surveyNo;
	}

	public void setSurveyNo(String surveyNo) {
		this.surveyNo = surveyNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public String getClaimSubStatus() {
		return claimSubStatus;
	}

	public void setClaimSubStatus(String claimSubStatus) {
		this.claimSubStatus = claimSubStatus;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getTimeofVisit() {
		return timeofVisit;
	}

	public void setTimeofVisit(String timeofVisit) {
		this.timeofVisit = timeofVisit;
	}

	public String getStakeCode() {
		return stakeCode;
	}

	public void setStakeCode(String stakeCode) {
		this.stakeCode = stakeCode;
	}

	public String getStakeName() {
		return stakeName;
	}

	public void setStakeName(String stakeName) {
		this.stakeName = stakeName;
	}

}
