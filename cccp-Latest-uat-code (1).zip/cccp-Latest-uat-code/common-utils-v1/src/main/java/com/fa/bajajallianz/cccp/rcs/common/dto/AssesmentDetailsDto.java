/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

/**
 * @author Arul
 *
 */
public class AssesmentDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;
	private String claimNumber;
	private String calcRefId;
	private String netAmount;
	private List<LossAssesmentDetailsDto> assesmentValueDetails;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getCalcRefId() {
		return calcRefId;
	}

	public void setCalcRefId(String calcRefId) {
		this.calcRefId = calcRefId;
	}

	public List<LossAssesmentDetailsDto> getAssesmentValueDetails() {
		return assesmentValueDetails;
	}

	public void setAssesmentValueDetails(List<LossAssesmentDetailsDto> assesmentValueDetails) {
		this.assesmentValueDetails = assesmentValueDetails;
	}

	public String getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}

}
