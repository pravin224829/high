package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimHandlerDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimPartiesDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ReserveDetailsDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Karthik
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5306607339056305609L;

	private Long id;
	private String code;
	private String status;
	private String message;
	private String error;
	private String type;
	private String result;
	private boolean flag;
	private String userId;
	private PolicyDetailsDto policyDetails;
	private ClaimHandlerDetailsDto claimHandlerDetails;
	private List<DocumentDto> documentDetails;
	private List<ClaimPartiesDetailsDto> claimParties;
	private ClaimDetailsDto claimDetails;
	private List<ReserveDetailsDto> reserveDetails;
	private ClaimantDetailsDto claimantDetails;

	public CommonDto() {
	}

	public CommonDto(String code, boolean flag) {
		super();
		this.code = code;
		this.flag = flag;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public PolicyDetailsDto getPolicyDetails() {
		return policyDetails;
	}

	public void setPolicyDetails(PolicyDetailsDto policyDetails) {
		this.policyDetails = policyDetails;
	}

	public ClaimHandlerDetailsDto getClaimHandlerDetails() {
		return claimHandlerDetails;
	}

	public void setClaimHandlerDetails(ClaimHandlerDetailsDto claimHandlerDetails) {
		this.claimHandlerDetails = claimHandlerDetails;
	}

	public List<DocumentDto> getDocumentDetails() {
		return documentDetails;
	}

	public void setDocumentDetails(List<DocumentDto> documentDetails) {
		this.documentDetails = documentDetails;
	}

	public List<ClaimPartiesDetailsDto> getClaimParties() {
		return claimParties;
	}

	public void setClaimParties(List<ClaimPartiesDetailsDto> claimParties) {
		this.claimParties = claimParties;
	}

	public ClaimDetailsDto getClaimDetails() {
		return claimDetails;
	}

	public void setClaimDetails(ClaimDetailsDto claimDetails) {
		this.claimDetails = claimDetails;
	}

	public ClaimantDetailsDto getClaimantDetails() {
		return claimantDetails;
	}

	public void setClaimantDetails(ClaimantDetailsDto claimantDetails) {
		this.claimantDetails = claimantDetails;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<ReserveDetailsDto> getReserveDetails() {
		return reserveDetails;
	}

	public void setReserveDetails(List<ReserveDetailsDto> reserveDetails) {
		this.reserveDetails = reserveDetails;
	}

}
