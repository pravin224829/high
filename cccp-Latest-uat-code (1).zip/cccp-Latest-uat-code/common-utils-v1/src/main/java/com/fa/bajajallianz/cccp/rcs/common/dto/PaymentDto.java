package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String sendForApproval;
	private String approvedAmount;
	private String outstandingAmount;
	private String expensesOutstanding;
	private String lossOutstanding;
	private String expensesPaid;
	private String lossPaid;
	private String overallExpensesReserve;
	private String overallLossReserve;
	private String claimReferenceNo;
	private String rejectedAmount;
	private String reserveAmount;
	private String neftStatus;
	private String partnerId;
	private String approvalAmount;
	private String paymentType;
	private String transactionType;
	private String transactionDate;
	private String reinstatementPremium;
	private String paidAmount;
	private String approvalNo;
	private String approvalStatus;
	private String claimType;
	private String stakeType;
	private String partyType;
	private String neftEnableDate;
	private String ipNo;
	private String ipType;
	private String docLabelName;
	private String paymentRefNo;
	private String partyName;

	public String getSendForApproval() {
		return sendForApproval;
	}

	public void setSendForApproval(String sendForApproval) {
		this.sendForApproval = sendForApproval;
	}

	public String getApprovedAmount() {
		return approvedAmount;
	}

	public void setApprovedAmount(String approvedAmount) {
		this.approvedAmount = approvedAmount;
	}

	public String getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(String outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public String getExpensesOutstanding() {
		return expensesOutstanding;
	}

	public void setExpensesOutstanding(String expensesOutstanding) {
		this.expensesOutstanding = expensesOutstanding;
	}

	public String getLossOutstanding() {
		return lossOutstanding;
	}

	public void setLossOutstanding(String lossOutstanding) {
		this.lossOutstanding = lossOutstanding;
	}

	public String getExpensesPaid() {
		return expensesPaid;
	}

	public void setExpensesPaid(String expensesPaid) {
		this.expensesPaid = expensesPaid;
	}

	public String getLossPaid() {
		return lossPaid;
	}

	public void setLossPaid(String lossPaid) {
		this.lossPaid = lossPaid;
	}

	public String getOverallExpensesReserve() {
		return overallExpensesReserve;
	}

	public void setOverallExpensesReserve(String overallExpensesReserve) {
		this.overallExpensesReserve = overallExpensesReserve;
	}

	public String getOverallLossReserve() {
		return overallLossReserve;
	}

	public void setOverallLossReserve(String overallLossReserve) {
		this.overallLossReserve = overallLossReserve;
	}

	public String getClaimReferenceNo() {
		return claimReferenceNo;
	}

	public void setClaimReferenceNo(String claimReferenceNo) {
		this.claimReferenceNo = claimReferenceNo;
	}

	public String getRejectedAmount() {
		return rejectedAmount;
	}

	public void setRejectedAmount(String rejectedAmount) {
		this.rejectedAmount = rejectedAmount;
	}

	public String getReserveAmount() {
		return reserveAmount;
	}

	public void setReserveAmount(String reserveAmount) {
		this.reserveAmount = reserveAmount;
	}

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getApprovalAmount() {
		return approvalAmount;
	}

	public void setApprovalAmount(String approvalAmount) {
		this.approvalAmount = approvalAmount;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getReinstatementPremium() {
		return reinstatementPremium;
	}

	public void setReinstatementPremium(String reinstatementPremium) {
		this.reinstatementPremium = reinstatementPremium;
	}

	public String getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getApprovalNo() {
		return approvalNo;
	}

	public void setApprovalNo(String approvalNo) {
		this.approvalNo = approvalNo;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getStakeType() {
		return stakeType;
	}

	public void setStakeType(String stakeType) {
		this.stakeType = stakeType;
	}

	public String getPartyType() {
		return partyType;
	}

	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}

	public String getNeftEnableDate() {
		return neftEnableDate;
	}

	public void setNeftEnableDate(String neftEnableDate) {
		this.neftEnableDate = neftEnableDate;
	}

	public String getIpNo() {
		return ipNo;
	}

	public void setIpNo(String ipNo) {
		this.ipNo = ipNo;
	}

	public String getIpType() {
		return ipType;
	}

	public void setIpType(String ipType) {
		this.ipType = ipType;
	}

	public String getDocLabelName() {
		return docLabelName;
	}

	public void setDocLabelName(String docLabelName) {
		this.docLabelName = docLabelName;
	}

	public String getPaymentRefNo() {
		return paymentRefNo;
	}

	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

}
