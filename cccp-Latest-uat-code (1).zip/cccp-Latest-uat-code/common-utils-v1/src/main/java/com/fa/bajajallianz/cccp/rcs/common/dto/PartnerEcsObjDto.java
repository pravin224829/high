package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PartnerEcsObjDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String accountNo;
	private String partnerId;
	private String micrCode;
	private String ifscCode;
	private String accType;
	private String ecsStatus;
	private String bankName;
	private String branchAddress;
	private String extnCol5;
	private String branchName;
	private String branchContactNo;
	private String extnCol1;
	private String extnCol2;
	private String extnCol3;
	
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}
	public String getEcsStatus() {
		return ecsStatus;
	}
	public void setEcsStatus(String ecsStatus) {
		this.ecsStatus = ecsStatus;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBranchAddress() {
		return branchAddress;
	}
	public void setBranchAddress(String branchAddress) {
		this.branchAddress = branchAddress;
	}
	public String getExtnCol5() {
		return extnCol5;
	}
	public void setExtnCol5(String extnCol5) {
		this.extnCol5 = extnCol5;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getBranchContactNo() {
		return branchContactNo;
	}
	public void setBranchContactNo(String branchContactNo) {
		this.branchContactNo = branchContactNo;
	}
	public String getExtnCol1() {
		return extnCol1;
	}
	public void setExtnCol1(String extnCol1) {
		this.extnCol1 = extnCol1;
	}
	public String getExtnCol2() {
		return extnCol2;
	}
	public void setExtnCol2(String extnCol2) {
		this.extnCol2 = extnCol2;
	}
	public String getExtnCol3() {
		return extnCol3;
	}
	public void setExtnCol3(String extnCol3) {
		this.extnCol3 = extnCol3;
	}
	public String getMicrCode() {
		return micrCode;
	}
	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	
	
}
