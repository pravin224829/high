package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

public class ExcelResponseDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8456207074184280914L;
	private List<UserDto> userDto;
	private List<UserDetailsDto> userDetailsDto;
	private String status;
	private String message;
	private List<ClientsFieldsConfigDto> clientsFieldsConfigDto;
	private PolicyConfigDto policyConfigDto;

	public List<UserDto> getUserDto() {
		return userDto;
	}

	public void setUserDto(List<UserDto> userDto) {
		this.userDto = userDto;
	}
	
	public List<UserDetailsDto> getUserDetailsDto() {
		return userDetailsDto;
	}

	public void setUserDetailsDto(List<UserDetailsDto> userDetailsDto) {
		this.userDetailsDto = userDetailsDto;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<ClientsFieldsConfigDto> getClientsFieldsConfigDto() {
		return clientsFieldsConfigDto;
	}

	public void setClientsFieldsConfigDto(List<ClientsFieldsConfigDto> clientsFieldsConfigDto) {
		this.clientsFieldsConfigDto = clientsFieldsConfigDto;
	}

	public PolicyConfigDto getPolicyConfigDto() {
		return policyConfigDto;
	}

	public void setPolicyConfigDto(PolicyConfigDto policyConfigDto) {
		this.policyConfigDto = policyConfigDto;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
