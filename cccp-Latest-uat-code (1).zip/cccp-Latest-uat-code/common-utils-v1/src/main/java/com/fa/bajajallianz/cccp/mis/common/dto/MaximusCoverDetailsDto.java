package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.Map;

public class MaximusCoverDetailsDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private String riskSerialNo;
	private String covercode;
	private String inceptionDate;
	private String expiryDate;
//	private MaximusCoverParamMapDto coverParamMap;
	private Map<String, String> coverParamMap;
//	private SubCover subCover;
	private String eventCode;
	private String sumInsured;
	private String tripCoverage;
	private String coverLevelTransactionCurrencyForSumInsured;
	private String coverSumInsuredInTransactionCurrency;
	private String basisOfDeductible;
	private String deductibleValue;
	private String forexRateAtCoverLevel;
	private String coverSumInsuredInBaseCurrency;
	private String coverPremiumInBaseCurrency;
	private String coverPremiumInTransactionCurrency;
	private String sumInsuredINR;
	private String sumInsuredUSD;
	private String numberofDays;
	private String numberofWeeks;
	private String deductibleValueforIndia;
	private String deductibleValueforAbroad;
	private String subLimit;
	private String coverPlan;
	private String coverName;
	private String netPremium;
	private String totalPremium;

	public String getSumInsured() {
		return sumInsured;
	}

	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}

	public String getTripCoverage() {
		return tripCoverage;
	}

	public void setTripCoverage(String tripCoverage) {
		this.tripCoverage = tripCoverage;
	}

	public String getCoverLevelTransactionCurrencyForSumInsured() {
		return coverLevelTransactionCurrencyForSumInsured;
	}

	public void setCoverLevelTransactionCurrencyForSumInsured(String coverLevelTransactionCurrencyForSumInsured) {
		this.coverLevelTransactionCurrencyForSumInsured = coverLevelTransactionCurrencyForSumInsured;
	}

	public String getCoverSumInsuredInTransactionCurrency() {
		return coverSumInsuredInTransactionCurrency;
	}

	public void setCoverSumInsuredInTransactionCurrency(String coverSumInsuredInTransactionCurrency) {
		this.coverSumInsuredInTransactionCurrency = coverSumInsuredInTransactionCurrency;
	}

	public String getBasisOfDeductible() {
		return basisOfDeductible;
	}

	public void setBasisOfDeductible(String basisOfDeductible) {
		this.basisOfDeductible = basisOfDeductible;
	}

	public String getDeductibleValue() {
		return deductibleValue;
	}

	public void setDeductibleValue(String deductibleValue) {
		this.deductibleValue = deductibleValue;
	}

	public String getForexRateAtCoverLevel() {
		return forexRateAtCoverLevel;
	}

	public void setForexRateAtCoverLevel(String forexRateAtCoverLevel) {
		this.forexRateAtCoverLevel = forexRateAtCoverLevel;
	}

	public String getCoverSumInsuredInBaseCurrency() {
		return coverSumInsuredInBaseCurrency;
	}

	public void setCoverSumInsuredInBaseCurrency(String coverSumInsuredInBaseCurrency) {
		this.coverSumInsuredInBaseCurrency = coverSumInsuredInBaseCurrency;
	}

	public String getCoverPremiumInBaseCurrency() {
		return coverPremiumInBaseCurrency;
	}

	public void setCoverPremiumInBaseCurrency(String coverPremiumInBaseCurrency) {
		this.coverPremiumInBaseCurrency = coverPremiumInBaseCurrency;
	}

	public String getCoverPremiumInTransactionCurrency() {
		return coverPremiumInTransactionCurrency;
	}

	public void setCoverPremiumInTransactionCurrency(String coverPremiumInTransactionCurrency) {
		this.coverPremiumInTransactionCurrency = coverPremiumInTransactionCurrency;
	}

	public String getSumInsuredINR() {
		return sumInsuredINR;
	}

	public void setSumInsuredINR(String sumInsuredINR) {
		this.sumInsuredINR = sumInsuredINR;
	}

	public String getSumInsuredUSD() {
		return sumInsuredUSD;
	}

	public void setSumInsuredUSD(String sumInsuredUSD) {
		this.sumInsuredUSD = sumInsuredUSD;
	}

	public String getNumberofDays() {
		return numberofDays;
	}

	public void setNumberofDays(String numberofDays) {
		this.numberofDays = numberofDays;
	}

	public String getNumberofWeeks() {
		return numberofWeeks;
	}

	public void setNumberofWeeks(String numberofWeeks) {
		this.numberofWeeks = numberofWeeks;
	}

	public String getDeductibleValueforIndia() {
		return deductibleValueforIndia;
	}

	public void setDeductibleValueforIndia(String deductibleValueforIndia) {
		this.deductibleValueforIndia = deductibleValueforIndia;
	}

	public String getDeductibleValueforAbroad() {
		return deductibleValueforAbroad;
	}

	public void setDeductibleValueforAbroad(String deductibleValueforAbroad) {
		this.deductibleValueforAbroad = deductibleValueforAbroad;
	}

	public String getSubLimit() {
		return subLimit;
	}

	public void setSubLimit(String subLimit) {
		this.subLimit = subLimit;
	}

	public String getCoverPlan() {
		return coverPlan;
	}

	public void setCoverPlan(String coverPlan) {
		this.coverPlan = coverPlan;
	}

	public String getCoverName() {
		return coverName;
	}

	public void setCoverName(String coverName) {
		this.coverName = coverName;
	}

	public String getNetPremium() {
		return netPremium;
	}

	public void setNetPremium(String netPremium) {
		this.netPremium = netPremium;
	}

	public String getTotalPremium() {
		return totalPremium;
	}

	public void setTotalPremium(String totalPremium) {
		this.totalPremium = totalPremium;
	}

	public String getRiskSerialNo() {
		return riskSerialNo;
	}

	public void setRiskSerialNo(String riskSerialNo) {
		this.riskSerialNo = riskSerialNo;
	}

	public String getCovercode() {
		return covercode;
	}

	public void setCovercode(String covercode) {
		this.covercode = covercode;
	}

	public String getInceptionDate() {
		return inceptionDate;
	}

	public void setInceptionDate(String inceptionDate) {
		this.inceptionDate = inceptionDate;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	public Map<String, String> getCoverParamMap() {
		return coverParamMap;
	}

	public void setCoverParamMap(Map<String, String> coverParamMap) {
		this.coverParamMap = coverParamMap;
	}

	

}