package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimEventDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CoInsuranceListDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.LossAssessmentSummaryDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.LossPaymentDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.PaymentDetailsDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private String roleCode;
	private Long id;
	private String claimRefNo;
	private Boolean isFinalSubmission;
	private String userId;
	private String imdCode;
	private String claimNumber;
	private String claimStatus;
	private String policyNumber;
	private String claimHandler;
	private String insuredName;
	private Integer pendingAge;
	private String status;
	private String supplierCode;
	private String dateOfLoss;
	private String placeOfLoss;
	private String descriptionOfLoss;
	private String intimationDate;
	private String registrationDate;
	private String surveyorName;
	private String surveyorAppointmentDate;
	private String surveyRefNo;
	private String partnerId;
	private String partnerName;
	private String bagicGSTNo;
	private String supplierGSTIN;
	private String neftStatus;
	private String typeofTaxApplicable;
	private String productCode;
	private String locationCode;
	private String reserveAmt;
	private String certificateNo;
	private String mobileNo;
	private String custEmailId;
	private String cibilScore;
	private String customerLoyaltyCategory;
	private String riskEvalution;
	private String financialHealth;
	private String insuredProfileRating;
	private List<ClaimEventDto> claimEvents;
	public List<ClaimEventDto> getClaimEvents() {
		return claimEvents;
	}

	public void setClaimEvents(List<ClaimEventDto> claimEvents) {
		this.claimEvents = claimEvents;
	}

	public String getCertificateNo() {
		return certificateNo;
	}

	public void setCertificateNo(String certificateNo) {
		this.certificateNo = certificateNo;
	}

	private LossDetailsDto lossDetails;
	private BankDetailsDto bankDetails;
	private InsuredDetails insuredDetails;
	private ClaimIntimatedDto intimatedDetails;
	private AdditionalDetailsDto additionalDetails;
	private ApplicationErrorDto applicationErr;
	private String email;
	private String mobileNumber;
	private String eventCode;
	private String causeOfLoss;
	private String fraudAlert;
	private String howLossOccured;
	private String intimationSource;
	private String lossDate;
	private String lossTime;
	private String salvageStatus;
	private String subStatus;
	private String base64String;
	private InvoiceDetailsDto invoiceDetailsDto;
	private Boolean defaultLoad;
	private String timeOfLoss;
	private String reserveAmount;
	private String deficiencyReason;
	private String delayReason;
	private String surveyorCategory;
	private String insuredNEFT;
	private String payeeType;
	private String neftBankStatus;
	private String outstandingAmount;
	private String supplierNumber;
	private String branchName;
	private String supplierName;
	private String modifiedBy;
	private String modifiedDate;
	private String action;
	private String remarks;
	private String closingDate;
	private String kindOfLoss;
	private String paidAmount;
	private String payeeID;
	private String neftPayeeStatus;
	private String lossReserveAmount;
	private String lossReserveBand;
	private String alternateNumber;
	private String customerEmailId;
	private String insuredAddress;
	private String sourceOfIntimation;
	private String lossApprovalDate;
	private String claimClosingDate;
	private String estimatedLossAmount;
	private String claimReopenDate;
	private String istimateLossAmount;
	private SurveyDetailsDto surveyDetails;
	private String claimWorkflow;
	private String landmark;
	private String pincode;
	private String state;
	private String city;
	private String area;
	private String lob;
	private PolicyDetailsDto policyDetails;
	private String bagicState;
	private String supplierGstNo;
	private String supplierState;
	private String taxType;
	private String partyName;
	private String paymentType;
	private String paymentMode;
	private String paymentAmount;
	private String gstAmount;
	private String totalAmount;
	private String paymentStatus;
	private String totalCalculatedAmount;
	private String createdDate;
	private String paymentInitiatedBy;
	private String gstBaseAmount;
	private String causeoOfLossCode;
	private String lossEstmatedValue;
	private LossAssessmentSummaryDetailsDto assesmentDetails;
	private String causeOffLoss;
	private String insuredPanNumber;
	private String legalCategory;
	private String surveyorAppoinedOn;
	private String recieptPsrOn;
	private String initialSurveyDate;
	private String recieptFsrOn;
	private String surveyorReportRefNo;
	private String transactionMessage;
	private String reasonForDelay;
	private PaymentDetailsDto paymentDetails;
	private String notificationDate;
	private String lossDetail;
	private String closingReason;
	private String reOpenRemarks;
	private String closingComment;
	private String firstDocReceivedDate;
	private String lastDocReceivedDate;
	private List<CoInsuranceListDto> coInsuranceList;
	private String dateAndTime;
	private String clmRef;
	private String firstRevDocDate;
	private String lastDocDate;
	private String colCode;
	public String transactionType;
	private List<LossPaymentDto> LossPaymentDtoList;
	private String claimMainStatus;
	private String claimSubStatus;

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getCustEmailId() {
		return custEmailId;
	}

	public void setCustEmailId(String custEmailId) {
		this.custEmailId = custEmailId;
	}

	public List<LossPaymentDto> getLossPaymentDtoList() {
		return LossPaymentDtoList;
	}

	public void setLossPaymentDtoList(List<LossPaymentDto> lossPaymentDtoList) {
		LossPaymentDtoList = lossPaymentDtoList;
	}

	public String getClmRef() {
		return clmRef;
	}

	public void setClmRef(String clmRef) {
		this.clmRef = clmRef;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getImdCode() {
		return imdCode;
	}

	public void setImdCode(String imdCode) {
		this.imdCode = imdCode;
	}

	public String getClaimRefNo() {
		return claimRefNo;
	}

	public void setClaimRefNo(String claimRefNo) {
		this.claimRefNo = claimRefNo;
	}

	public Boolean getIsFinalSubmission() {
		return isFinalSubmission;
	}

	public void setIsFinalSubmission(Boolean isFinalSubmission) {
		this.isFinalSubmission = isFinalSubmission;
	}

	public Long getId() {
		return id;
	}

	public String getCibilScore() {
		return cibilScore;
	}

	public void setCibilScore(String cibilScore) {
		this.cibilScore = cibilScore;
	}

	public String getCustomerLoyaltyCategory() {
		return customerLoyaltyCategory;
	}

	public void setCustomerLoyaltyCategory(String customerLoyaltyCategory) {
		this.customerLoyaltyCategory = customerLoyaltyCategory;
	}

	public String getRiskEvalution() {
		return riskEvalution;
	}

	public void setRiskEvalution(String riskEvalution) {
		this.riskEvalution = riskEvalution;
	}

	public String getFinancialHealth() {
		return financialHealth;
	}

	public void setFinancialHealth(String financialHealth) {
		this.financialHealth = financialHealth;
	}

	public String getInsuredProfileRating() {
		return insuredProfileRating;
	}

	public void setInsuredProfileRating(String insuredProfileRating) {
		this.insuredProfileRating = insuredProfileRating;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public InsuredDetails getInsuredDetails() {
		return insuredDetails;
	}

	public void setInsuredDetails(InsuredDetails insuredDetails) {
		this.insuredDetails = insuredDetails;
	}

	public LossDetailsDto getLossDetails() {
		return lossDetails;
	}

	public void setLossDetails(LossDetailsDto lossDetails) {
		this.lossDetails = lossDetails;
	}

	public BankDetailsDto getBankDetails() {
		return bankDetails;
	}

	public void setBankDetails(BankDetailsDto bankDetails) {
		this.bankDetails = bankDetails;
	}

	public ClaimIntimatedDto getIntimatedDetails() {
		return intimatedDetails;
	}

	public void setIntimatedDetails(ClaimIntimatedDto intimatedDetails) {
		this.intimatedDetails = intimatedDetails;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getClaimHandler() {
		return claimHandler;
	}

	public void setClaimHandler(String claimHandler) {
		this.claimHandler = claimHandler;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public Integer getPendingAge() {
		return pendingAge;
	}

	public void setPendingAge(Integer pendingAge) {
		this.pendingAge = pendingAge;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public ApplicationErrorDto getApplicationErr() {
		return applicationErr;
	}

	public void setApplicationErr(ApplicationErrorDto applicationErr) {
		this.applicationErr = applicationErr;
	}

	public AdditionalDetailsDto getAdditionalDetails() {
		return additionalDetails;
	}

	public void setAdditionalDetails(AdditionalDetailsDto additionalDetails) {
		this.additionalDetails = additionalDetails;
	}

	public String getSupplierCode() {
		return supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public String getDateOfLoss() {
		return dateOfLoss;
	}

	public void setDateOfLoss(String dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}

	public String getPlaceOfLoss() {
		return placeOfLoss;
	}

	public void setPlaceOfLoss(String placeOfLoss) {
		this.placeOfLoss = placeOfLoss;
	}

	public String getDescriptionOfLoss() {
		return descriptionOfLoss;
	}

	public void setDescriptionOfLoss(String descriptionOfLoss) {
		this.descriptionOfLoss = descriptionOfLoss;
	}

	public String getIntimationDate() {
		return intimationDate;
	}

	public void setIntimationDate(String intimationDate) {
		this.intimationDate = intimationDate;
	}

	public String getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getSurveyorName() {
		return surveyorName;
	}

	public void setSurveyorName(String surveyorName) {
		this.surveyorName = surveyorName;
	}

	public String getSurveyorAppointmentDate() {
		return surveyorAppointmentDate;
	}

	public void setSurveyorAppointmentDate(String surveyorAppointmentDate) {
		this.surveyorAppointmentDate = surveyorAppointmentDate;
	}

	public String getSurveyRefNo() {
		return surveyRefNo;
	}

	public void setSurveyRefNo(String surveyRefNo) {
		this.surveyRefNo = surveyRefNo;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getReserveAmt() {
		return reserveAmt;
	}

	public void setReserveAmt(String reserveAmt) {
		this.reserveAmt = reserveAmt;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	public String getCauseOfLoss() {
		return causeOfLoss;
	}

	public void setCauseOfLoss(String causeOfLoss) {
		this.causeOfLoss = causeOfLoss;
	}

	public String getFraudAlert() {
		return fraudAlert;
	}

	public void setFraudAlert(String fraudAlert) {
		this.fraudAlert = fraudAlert;
	}

	public String getIntimationSource() {
		return intimationSource;
	}

	public void setIntimationSource(String intimationSource) {
		this.intimationSource = intimationSource;
	}

	public String getLossDate() {
		return lossDate;
	}

	public void setLossDate(String lossDate) {
		this.lossDate = lossDate;
	}

	public String getSalvageStatus() {
		return salvageStatus;
	}

	public void setSalvageStatus(String salvageStatus) {
		this.salvageStatus = salvageStatus;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public String getBase64String() {
		return base64String;
	}

	public void setBase64String(String base64String) {
		this.base64String = base64String;
	}

	public InvoiceDetailsDto getInvoiceDetailsDto() {
		return invoiceDetailsDto;
	}

	public void setInvoiceDetailsDto(InvoiceDetailsDto invoiceDetailsDto) {
		this.invoiceDetailsDto = invoiceDetailsDto;
	}

	public Boolean getDefaultLoad() {
		return defaultLoad;
	}

	public void setDefaultLoad(Boolean defaultLoad) {
		this.defaultLoad = defaultLoad;
	}

	public String getTimeOfLoss() {
		return timeOfLoss;
	}

	public void setTimeOfLoss(String timeOfLoss) {
		this.timeOfLoss = timeOfLoss;
	}

	public String getReserveAmount() {
		return reserveAmount;
	}

	public void setReserveAmount(String reserveAmount) {
		this.reserveAmount = reserveAmount;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getDelayReason() {
		return delayReason;
	}

	public void setDelayReason(String delayReason) {
		this.delayReason = delayReason;
	}

	public String getSurveyorCategory() {
		return surveyorCategory;
	}

	public void setSurveyorCategory(String surveyorCategory) {
		this.surveyorCategory = surveyorCategory;
	}

	public String getInsuredNEFT() {
		return insuredNEFT;
	}

	public void setInsuredNEFT(String insuredNEFT) {
		this.insuredNEFT = insuredNEFT;
	}

	public String getSupplierGSTIN() {
		return supplierGSTIN;
	}

	public void setSupplierGSTIN(String supplierGSTIN) {
		this.supplierGSTIN = supplierGSTIN;
	}

	public String getTypeofTaxApplicable() {
		return typeofTaxApplicable;
	}

	public void setTypeofTaxApplicable(String typeofTaxApplicable) {
		this.typeofTaxApplicable = typeofTaxApplicable;
	}

	public String getPayeeType() {
		return payeeType;
	}

	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	public String getNeftBankStatus() {
		return neftBankStatus;
	}

	public void setNeftBankStatus(String neftBankStatus) {
		this.neftBankStatus = neftBankStatus;
	}

	public String getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(String outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public String getSupplierNumber() {
		return supplierNumber;
	}

	public void setSupplierNumber(String supplierNumber) {
		this.supplierNumber = supplierNumber;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getClosingDate() {
		return closingDate;
	}

	public void setClosingDate(String closingDate) {
		this.closingDate = closingDate;
	}

	public String getKindOfLoss() {
		return kindOfLoss;
	}

	public void setKindOfLoss(String kindOfLoss) {
		this.kindOfLoss = kindOfLoss;
	}

	public String getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getPayeeID() {
		return payeeID;
	}

	public void setPayeeID(String payeeID) {
		this.payeeID = payeeID;
	}

	public String getNeftPayeeStatus() {
		return neftPayeeStatus;
	}

	public void setNeftPayeeStatus(String neftPayeeStatus) {
		this.neftPayeeStatus = neftPayeeStatus;
	}

	public String getLossReserveAmount() {
		return lossReserveAmount;
	}

	public void setLossReserveAmount(String lossReserveAmount) {
		this.lossReserveAmount = lossReserveAmount;
	}

	public String getLossReserveBand() {
		return lossReserveBand;
	}

	public void setLossReserveBand(String lossReserveBand) {
		this.lossReserveBand = lossReserveBand;
	}

	public String getAlternateNumber() {
		return alternateNumber;
	}

	public void setAlternateNumber(String alternateNumber) {
		this.alternateNumber = alternateNumber;
	}

	public String getCustomerEmailId() {
		return customerEmailId;
	}

	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}

	public String getInsuredAddress() {
		return insuredAddress;
	}

	public void setInsuredAddress(String insuredAddress) {
		this.insuredAddress = insuredAddress;
	}

	public String getSourceOfIntimation() {
		return sourceOfIntimation;
	}

	public void setSourceOfIntimation(String sourceOfIntimation) {
		this.sourceOfIntimation = sourceOfIntimation;
	}

	public String getLossApprovalDate() {
		return lossApprovalDate;
	}

	public void setLossApprovalDate(String lossApprovalDate) {
		this.lossApprovalDate = lossApprovalDate;
	}

	public String getEstimatedLossAmount() {
		return estimatedLossAmount;
	}

	public void setEstimatedLossAmount(String estimatedLossAmount) {
		this.estimatedLossAmount = estimatedLossAmount;
	}

	public String getClaimReopenDate() {
		return claimReopenDate;
	}

	public void setClaimReopenDate(String claimReopenDate) {
		this.claimReopenDate = claimReopenDate;
	}

	public String getIstimateLossAmount() {
		return istimateLossAmount;
	}

	public void setIstimateLossAmount(String istimateLossAmount) {
		this.istimateLossAmount = istimateLossAmount;
	}

	public SurveyDetailsDto getSurveyDetails() {
		return surveyDetails;
	}

	public void setSurveyDetails(SurveyDetailsDto surveyDetails) {
		this.surveyDetails = surveyDetails;
	}

	public String getHowLossOccured() {
		return howLossOccured;
	}

	public void setHowLossOccured(String howLossOccured) {
		this.howLossOccured = howLossOccured;
	}

	public String getLossTime() {
		return lossTime;
	}

	public void setLossTime(String lossTime) {
		this.lossTime = lossTime;
	}

	public String getClaimWorkflow() {
		return claimWorkflow;
	}

	public void setClaimWorkflow(String claimWorkflow) {
		this.claimWorkflow = claimWorkflow;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getClaimClosingDate() {
		return claimClosingDate;
	}

	public void setClaimClosingDate(String claimClosingDate) {
		this.claimClosingDate = claimClosingDate;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public PolicyDetailsDto getPolicyDetails() {
		return policyDetails;
	}

	public void setPolicyDetails(PolicyDetailsDto policyDetails) {
		this.policyDetails = policyDetails;
	}

	public String getBagicState() {
		return bagicState;
	}

	public void setBagicState(String bagicState) {
		this.bagicState = bagicState;
	}

	public String getSupplierGstNo() {
		return supplierGstNo;
	}

	public void setSupplierGstNo(String supplierGstNo) {
		this.supplierGstNo = supplierGstNo;
	}

	public String getSupplierState() {
		return supplierState;
	}

	public void setSupplierState(String supplierState) {
		this.supplierState = supplierState;
	}

	public String getTaxType() {
		return taxType;
	}

	public void setTaxType(String taxType) {
		this.taxType = taxType;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getGstAmount() {
		return gstAmount;
	}

	public void setGstAmount(String gstAmount) {
		this.gstAmount = gstAmount;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getTotalCalculatedAmount() {
		return totalCalculatedAmount;
	}

	public void setTotalCalculatedAmount(String totalCalculatedAmount) {
		this.totalCalculatedAmount = totalCalculatedAmount;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getPaymentInitiatedBy() {
		return paymentInitiatedBy;
	}

	public void setPaymentInitiatedBy(String paymentInitiatedBy) {
		this.paymentInitiatedBy = paymentInitiatedBy;
	}

	public String getGstBaseAmount() {
		return gstBaseAmount;
	}

	public void setGstBaseAmount(String gstBaseAmount) {
		this.gstBaseAmount = gstBaseAmount;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getCauseoOfLossCode() {
		return causeoOfLossCode;
	}

	public void setCauseoOfLossCode(String causeoOfLossCode) {
		this.causeoOfLossCode = causeoOfLossCode;
	}

	public String getLossEstmatedValue() {
		return lossEstmatedValue;
	}

	public void setLossEstmatedValue(String lossEstmatedValue) {
		this.lossEstmatedValue = lossEstmatedValue;
	}

	public String getBagicGSTNo() {
		return bagicGSTNo;
	}

	public void setBagicGSTNo(String bagicGSTNo) {
		this.bagicGSTNo = bagicGSTNo;
	}

	public LossAssessmentSummaryDetailsDto getAssesmentDetails() {
		return assesmentDetails;
	}

	public void setAssesmentDetails(LossAssessmentSummaryDetailsDto assesmentDetails) {
		this.assesmentDetails = assesmentDetails;
	}

	public String getCauseOffLoss() {
		return causeOffLoss;
	}

	public void setCauseOffLoss(String causeOffLoss) {
		this.causeOffLoss = causeOffLoss;
	}

	public String getInsuredPanNumber() {
		return insuredPanNumber;
	}

	public void setInsuredPanNumber(String insuredPanNumber) {
		this.insuredPanNumber = insuredPanNumber;
	}

	public String getLegalCategory() {
		return legalCategory;
	}

	public void setLegalCategory(String legalCategory) {
		this.legalCategory = legalCategory;
	}

	public String getSurveyorAppoinedOn() {
		return surveyorAppoinedOn;
	}

	public void setSurveyorAppoinedOn(String surveyorAppoinedOn) {
		this.surveyorAppoinedOn = surveyorAppoinedOn;
	}

	public String getRecieptPsrOn() {
		return recieptPsrOn;
	}

	public void setRecieptPsrOn(String recieptPsrOn) {
		this.recieptPsrOn = recieptPsrOn;
	}

	public String getInitialSurveyDate() {
		return initialSurveyDate;
	}

	public void setInitialSurveyDate(String initialSurveyDate) {
		this.initialSurveyDate = initialSurveyDate;
	}

	public String getRecieptFsrOn() {
		return recieptFsrOn;
	}

	public void setRecieptFsrOn(String recieptFsrOn) {
		this.recieptFsrOn = recieptFsrOn;
	}

	public String getSurveyorReportRefNo() {
		return surveyorReportRefNo;
	}

	public void setSurveyorReportRefNo(String surveyorReportRefNo) {
		this.surveyorReportRefNo = surveyorReportRefNo;
	}

	public String getTransactionMessage() {
		return transactionMessage;
	}

	public void setTransactionMessage(String transactionMessage) {
		this.transactionMessage = transactionMessage;
	}

	public String getReasonForDelay() {
		return reasonForDelay;
	}

	public void setReasonForDelay(String reasonForDelay) {
		this.reasonForDelay = reasonForDelay;
	}

	public PaymentDetailsDto getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(PaymentDetailsDto paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	public List<CoInsuranceListDto> getCoInsuranceList() {
		return coInsuranceList;
	}

	public void setCoInsuranceList(List<CoInsuranceListDto> coInsuranceList) {
		this.coInsuranceList = coInsuranceList;
	}

	public String getNotificationDate() {
		return notificationDate;
	}

	public void setNotificationDate(String notificationDate) {
		this.notificationDate = notificationDate;
	}

	public String getLossDetail() {
		return lossDetail;
	}

	public void setLossDetail(String lossDetail) {
		this.lossDetail = lossDetail;
	}

	public String getClosingReason() {
		return closingReason;
	}

	public void setClosingReason(String closingReason) {
		this.closingReason = closingReason;
	}

	public String getReOpenRemarks() {
		return reOpenRemarks;
	}

	public void setReOpenRemarks(String reOpenRemarks) {
		this.reOpenRemarks = reOpenRemarks;
	}

	public String getClosingComment() {
		return closingComment;
	}

	public void setClosingComment(String closingComment) {
		this.closingComment = closingComment;
	}

	public String getDateAndTime() {
		return dateAndTime;
	}

	public void setDateAndTime(String dateAndTime) {
		this.dateAndTime = dateAndTime;
	}

	public String getFirstDocReceivedDate() {
		return firstDocReceivedDate;
	}

	public void setFirstDocReceivedDate(String firstDocReceivedDate) {
		this.firstDocReceivedDate = firstDocReceivedDate;
	}

	public String getLastDocReceivedDate() {
		return lastDocReceivedDate;
	}

	public void setLastDocReceivedDate(String lastDocReceivedDate) {
		this.lastDocReceivedDate = lastDocReceivedDate;
	}

	public String getFirstRevDocDate() {
		return firstRevDocDate;
	}

	public void setFirstRevDocDate(String firstRevDocDate) {
		this.firstRevDocDate = firstRevDocDate;
	}

	public String getLastDocDate() {
		return lastDocDate;
	}

	public void setLastDocDate(String lastDocDate) {
		this.lastDocDate = lastDocDate;
	}

	public String getColCode() {
		return colCode;
	}

	public void setColCode(String colCode) {
		this.colCode = colCode;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getClaimMainStatus() {
		return claimMainStatus;
	}

	public void setClaimMainStatus(String claimMainStatus) {
		this.claimMainStatus = claimMainStatus;
	}

	public String getClaimSubStatus() {
		return claimSubStatus;
	}

	public void setClaimSubStatus(String claimSubStatus) {
		this.claimSubStatus = claimSubStatus;
	}
	

}