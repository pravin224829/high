package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusDomainDetailsResponseDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<MaximusDomainDetailsDto> domainDetails;
	private ApplicationErrorDto applicationError;

	public List<MaximusDomainDetailsDto> getDomainDetails() {
		return domainDetails;
	}

	public void setDomainDetails(List<MaximusDomainDetailsDto> domainDetails) {
		this.domainDetails = domainDetails;
	}

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

}