package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ReasonDelayObj implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String surveyorAppOn;
	private String recptPsrOn;
	private String surveyOn;
	private String recptFsrOn;
	private String surReportRefNo;
	private String delayReasonSurAppt;
	private String delayReasonInitialSur;
	private String delayReasonPsr;
	private String addSurveyorCategory;
	private String oldReserveAmount;
	private String delayReasonFsr;

	public String getSurveyorAppOn() {
		return surveyorAppOn;
	}

	public void setSurveyorAppOn(String surveyorAppOn) {
		this.surveyorAppOn = surveyorAppOn;
	}

	public String getRecptPsrOn() {
		return recptPsrOn;
	}

	public void setRecptPsrOn(String recptPsrOn) {
		this.recptPsrOn = recptPsrOn;
	}

	public String getSurveyOn() {
		return surveyOn;
	}

	public void setSurveyOn(String surveyOn) {
		this.surveyOn = surveyOn;
	}

	public String getRecptFsrOn() {
		return recptFsrOn;
	}

	public void setRecptFsrOn(String recptFsrOn) {
		this.recptFsrOn = recptFsrOn;
	}

	public String getSurReportRefNo() {
		return surReportRefNo;
	}

	public void setSurReportRefNo(String surReportRefNo) {
		this.surReportRefNo = surReportRefNo;
	}

	public String getDelayReasonSurAppt() {
		return delayReasonSurAppt;
	}

	public void setDelayReasonSurAppt(String delayReasonSurAppt) {
		this.delayReasonSurAppt = delayReasonSurAppt;
	}

	public String getDelayReasonInitialSur() {
		return delayReasonInitialSur;
	}

	public void setDelayReasonInitialSur(String delayReasonInitialSur) {
		this.delayReasonInitialSur = delayReasonInitialSur;
	}

	public String getDelayReasonPsr() {
		return delayReasonPsr;
	}

	public void setDelayReasonPsr(String delayReasonPsr) {
		this.delayReasonPsr = delayReasonPsr;
	}

	public String getAddSurveyorCategory() {
		return addSurveyorCategory;
	}

	public void setAddSurveyorCategory(String addSurveyorCategory) {
		this.addSurveyorCategory = addSurveyorCategory;
	}

	public String getOldReserveAmount() {
		return oldReserveAmount;
	}

	public void setOldReserveAmount(String oldReserveAmount) {
		this.oldReserveAmount = oldReserveAmount;
	}

	public String getDelayReasonFsr() {
		return delayReasonFsr;
	}

	public void setDelayReasonFsr(String delayReasonFsr) {
		this.delayReasonFsr = delayReasonFsr;
	}

}
