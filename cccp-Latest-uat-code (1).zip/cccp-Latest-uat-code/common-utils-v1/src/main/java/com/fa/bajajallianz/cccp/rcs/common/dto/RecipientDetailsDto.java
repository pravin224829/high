/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

/**
 * @author santhosh
 *
 */
public class RecipientDetailsDto implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String accountNo;
	private String remittanceRecipientPan;
	private String status;
	private String emailId;
	private String phoneNo;
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getRemittanceRecipientPan() {
		return remittanceRecipientPan;
	}
	public void setRemittanceRecipientPan(String remittanceRecipientPan) {
		this.remittanceRecipientPan = remittanceRecipientPan;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	

}

