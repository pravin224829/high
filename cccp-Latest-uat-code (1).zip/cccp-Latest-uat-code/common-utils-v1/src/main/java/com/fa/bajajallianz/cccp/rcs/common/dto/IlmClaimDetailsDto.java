package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class IlmClaimDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String claimId;
	private String claimNumber;
	private String kindOfLoss;
	private String extCol1;
	private String processFlag;

	public String getClaimId() {
		return claimId;
	}

	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getKindOfLoss() {
		return kindOfLoss;
	}

	public void setKindOfLoss(String kindOfLoss) {
		this.kindOfLoss = kindOfLoss;
	}

	public String getExtCol1() {
		return extCol1;
	}

	public void setExtCol1(String extCol1) {
		this.extCol1 = extCol1;
	}

	public String getProcessFlag() {
		return processFlag;
	}

	public void setProcessFlag(String processFlag) {
		this.processFlag = processFlag;
	}

}
