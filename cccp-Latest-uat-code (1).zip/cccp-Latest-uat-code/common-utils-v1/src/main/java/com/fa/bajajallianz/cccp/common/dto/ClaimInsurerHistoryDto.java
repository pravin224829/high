package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.Date;

public class ClaimInsurerHistoryDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private String claimNumber;
private String insuredName;
private String claimHandler;
private String status;
private Date lossDate;
private String causeOffLoss;
private Date createdDate;
private String policyNumber;

public String getClaimNumber() {
	return claimNumber;
}
public void setClaimNumber(String claimNumber) {
	this.claimNumber = claimNumber;
}
public String getInsuredName() {
	return insuredName;
}
public void setInsuredName(String insuredName) {
	this.insuredName = insuredName;
}
public String getClaimHandler() {
	return claimHandler;
}
public void setClaimHandler(String claimHandler) {
	this.claimHandler = claimHandler;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public Date getLossDate() {
	return lossDate;
}
public void setLossDate(Date lossDate) {
	this.lossDate = lossDate;
}
public String getCauseOffLoss() {
	return causeOffLoss;
}
public void setCauseOffLoss(String causeOffLoss) {
	this.causeOffLoss = causeOffLoss;
}
public Date getCreatedDate() {
	return createdDate;
}
public void setCreatedDate(Date createdDate) {
	this.createdDate = createdDate;
}
public String getPolicyNumber() {
	return policyNumber;
}
public void setPolicyNumber(String policyNumber) {
	this.policyNumber = policyNumber;
}
	

}
