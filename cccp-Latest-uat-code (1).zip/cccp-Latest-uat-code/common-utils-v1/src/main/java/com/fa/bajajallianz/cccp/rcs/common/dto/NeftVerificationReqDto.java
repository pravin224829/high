package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NeftVerificationReqDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String userName;
	private String location;
	private String mode;
	private List<String> micrDto;
	private PartnerEcsObjDto partnerEcsObjDto;
	private PartnerDtlsObjDto partnerDtlsObjDto;
	private PartnerNeftObjDto partnerNeftObjDto;
	private ImdObjDto imdObjDto;
	private SupplierDetailsDto supplierObjDto;
	private EmailObjDto emailObjDto;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public List<String> getMicrDto() {
		return micrDto;
	}
	public void setMicrDto(List<String> micrDto) {
		this.micrDto = micrDto;
	}
	public PartnerEcsObjDto getPartnerEcsObjDto() {
		return partnerEcsObjDto;
	}
	public void setPartnerEcsObjDto(PartnerEcsObjDto partnerEcsObjDto) {
		this.partnerEcsObjDto = partnerEcsObjDto;
	}
	public PartnerDtlsObjDto getPartnerDtlsObjDto() {
		return partnerDtlsObjDto;
	}
	public void setPartnerDtlsObjDto(PartnerDtlsObjDto partnerDtlsObjDto) {
		this.partnerDtlsObjDto = partnerDtlsObjDto;
	}
	public PartnerNeftObjDto getPartnerNeftObjDto() {
		return partnerNeftObjDto;
	}
	public void setPartnerNeftObjDto(PartnerNeftObjDto partnerNeftObjDto) {
		this.partnerNeftObjDto = partnerNeftObjDto;
	}
	public ImdObjDto getImdObjDto() {
		return imdObjDto;
	}
	public void setImdObjDto(ImdObjDto imdObjDto) {
		this.imdObjDto = imdObjDto;
	}
	public SupplierDetailsDto getSupplierObjDto() {
		return supplierObjDto;
	}
	public void setSupplierObjDto(SupplierDetailsDto supplierObjDto) {
		this.supplierObjDto = supplierObjDto;
	}
	public EmailObjDto getEmailObjDto() {
		return emailObjDto;
	}
	public void setEmailObjDto(EmailObjDto emailObjDto) {
		this.emailObjDto = emailObjDto;
	}
	
	
	

}
