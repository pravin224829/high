package com.fa.bajajallianz.cccp.mis.common.dto;
 
import java.io.Serializable;
 
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
 
@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusPartyDetailsDto implements Serializable {
 
	private static final long serialVersionUID = 1L;
	private String filedITLast2Years;
	private String panAadhaarLinked;
	private String voterId;
	private String preferredModeOfCommunication;
	private String nameAadhaar;
	private String motherMaidenName;
	private String aadhaarEnrollment;
	private String panNumber;
	private String aadhaarNumber;
	private String maritalStatus;
	private String preferredLanguage;
	private String reasonForBlacklisting;
	private String dateOfBlacklisting;
	private String monthlyIncome;
	private String isBlacklisted;
	private String passportDetails;
	private String preferredModeOfAlert;
	private String kycDetails;
	private String gstinuin;
	private String isCkycComplete;
	private String ckycNumber;
	private String ckycStatus;
	private String poiStatus;
	private String poaStatus;
	private String nameAsPerCkyc;
	private String nregaJobCard;
	private String refundToPidOfBgHolderAc;
	private String hniFlag;
	private String calculatorURNNumber;
	private String relationshipWithHNI;
	//private String isTheOrganisationARegisteredBusinessTrust;
	private String languagesPreferred;
	//private String partnerRef;
	private String referenceCode;
	private String typeofEndorsement;
	private String blacklisted;
	private String hcompany;
	private String surLicenseNo;
    private String surLicenseExpiryDate;
 
	public String getFiledITLast2Years() {
		return filedITLast2Years;
	}
 
	public void setFiledITLast2Years(String filedITLast2Years) {
		this.filedITLast2Years = filedITLast2Years;
	}
 
	public String getPanAadhaarLinked() {
		return panAadhaarLinked;
	}
 
	public void setPanAadhaarLinked(String panAadhaarLinked) {
		this.panAadhaarLinked = panAadhaarLinked;
	}
 
	public String getVoterId() {
		return voterId;
	}
 
	public void setVoterId(String voterId) {
		this.voterId = voterId;
	}
 
	public String getPreferredModeOfCommunication() {
		return preferredModeOfCommunication;
	}
 
	public void setPreferredModeOfCommunication(String preferredModeOfCommunication) {
		this.preferredModeOfCommunication = preferredModeOfCommunication;
	}
 
	public String getNameAadhaar() {
		return nameAadhaar;
	}
 
	public void setNameAadhaar(String nameAadhaar) {
		this.nameAadhaar = nameAadhaar;
	}
 
	public String getMotherMaidenName() {
		return motherMaidenName;
	}
 
	public void setMotherMaidenName(String motherMaidenName) {
		this.motherMaidenName = motherMaidenName;
	}
 
	public String getAadhaarEnrollment() {
		return aadhaarEnrollment;
	}
 
	public void setAadhaarEnrollment(String aadhaarEnrollment) {
		this.aadhaarEnrollment = aadhaarEnrollment;
	}
 
	public String getPanNumber() {
		return panNumber;
	}
 
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
 
	public String getAadhaarNumber() {
		return aadhaarNumber;
	}
 
	public void setAadhaarNumber(String aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}
 
	public String getMaritalStatus() {
		return maritalStatus;
	}
 
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
 
	public String getPreferredLanguage() {
		return preferredLanguage;
	}
 
	public void setPreferredLanguage(String preferredLanguage) {
		this.preferredLanguage = preferredLanguage;
	}
 
	public String getReasonForBlacklisting() {
		return reasonForBlacklisting;
	}
 
	public void setReasonForBlacklisting(String reasonForBlacklisting) {
		this.reasonForBlacklisting = reasonForBlacklisting;
	}
 
	public String getDateOfBlacklisting() {
		return dateOfBlacklisting;
	}
 
	public void setDateOfBlacklisting(String dateOfBlacklisting) {
		this.dateOfBlacklisting = dateOfBlacklisting;
	}
 
	public String getMonthlyIncome() {
		return monthlyIncome;
	}
 
	public void setMonthlyIncome(String monthlyIncome) {
		this.monthlyIncome = monthlyIncome;
	}
 
	public String getIsBlacklisted() {
		return isBlacklisted;
	}
 
	public void setIsBlacklisted(String isBlacklisted) {
		this.isBlacklisted = isBlacklisted;
	}
 
	public String getPassportDetails() {
		return passportDetails;
	}
 
	public void setPassportDetails(String passportDetails) {
		this.passportDetails = passportDetails;
	}
 
	public String getPreferredModeOfAlert() {
		return preferredModeOfAlert;
	}
 
	public void setPreferredModeOfAlert(String preferredModeOfAlert) {
		this.preferredModeOfAlert = preferredModeOfAlert;
	}
 
	public String getKycDetails() {
		return kycDetails;
	}
 
	public void setKycDetails(String kycDetails) {
		this.kycDetails = kycDetails;
	}
 
	public String getGstinuin() {
		return gstinuin;
	}
 
	public void setGstinuin(String gstinuin) {
		this.gstinuin = gstinuin;
	}
 
	public String getIsCkycComplete() {
		return isCkycComplete;
	}
 
	public void setIsCkycComplete(String isCkycComplete) {
		this.isCkycComplete = isCkycComplete;
	}
 
	public String getCkycNumber() {
		return ckycNumber;
	}
 
	public void setCkycNumber(String ckycNumber) {
		this.ckycNumber = ckycNumber;
	}
 
	public String getCkycStatus() {
		return ckycStatus;
	}
 
	public void setCkycStatus(String ckycStatus) {
		this.ckycStatus = ckycStatus;
	}
 
	public String getPoiStatus() {
		return poiStatus;
	}
 
	public void setPoiStatus(String poiStatus) {
		this.poiStatus = poiStatus;
	}
 
	public String getPoaStatus() {
		return poaStatus;
	}
 
	public void setPoaStatus(String poaStatus) {
		this.poaStatus = poaStatus;
	}
 
	public String getNameAsPerCkyc() {
		return nameAsPerCkyc;
	}
 
	public void setNameAsPerCkyc(String nameAsPerCkyc) {
		this.nameAsPerCkyc = nameAsPerCkyc;
	}
 
	public String getNregaJobCard() {
		return nregaJobCard;
	}
 
	public void setNregaJobCard(String nregaJobCard) {
		this.nregaJobCard = nregaJobCard;
	}
 
	public String getRefundToPidOfBgHolderAc() {
		return refundToPidOfBgHolderAc;
	}
 
	public void setRefundToPidOfBgHolderAc(String refundToPidOfBgHolderAc) {
		this.refundToPidOfBgHolderAc = refundToPidOfBgHolderAc;
	}
 
	public String getHniFlag() {
		return hniFlag;
	}
 
	public void setHniFlag(String hniFlag) {
		this.hniFlag = hniFlag;
	}
 
	public String getCalculatorURNNumber() {
		return calculatorURNNumber;
	}
 
	public void setCalculatorURNNumber(String calculatorURNNumber) {
		this.calculatorURNNumber = calculatorURNNumber;
	}
 
	public String getRelationshipWithHNI() {
		return relationshipWithHNI;
	}
 
	public void setRelationshipWithHNI(String relationshipWithHNI) {
		this.relationshipWithHNI = relationshipWithHNI;
	}
 
//	public String getIsTheOrganisationARegisteredBusinessTrust() {
//		return isTheOrganisationARegisteredBusinessTrust;
//	}
// 
//	public void setIsTheOrganisationARegisteredBusinessTrust(String isTheOrganisationARegisteredBusinessTrust) {
//		this.isTheOrganisationARegisteredBusinessTrust = isTheOrganisationARegisteredBusinessTrust;
//	}
 
	public String getLanguagesPreferred() {
		return languagesPreferred;
	}
 
	public void setLanguagesPreferred(String languagesPreferred) {
		this.languagesPreferred = languagesPreferred;
	}
 
//	public String getPartnerRef() {
//		return partnerRef;
//	}
// 
//	public void setPartnerRef(String partnerRef) {
//		this.partnerRef = partnerRef;
//	}
 
	public String getReferenceCode() {
		return referenceCode;
	}
 
	public void setReferenceCode(String referenceCode) {
		this.referenceCode = referenceCode;
	}
 
	public String getTypeofEndorsement() {
		return typeofEndorsement;
	}
 
	public void setTypeofEndorsement(String typeofEndorsement) {
		this.typeofEndorsement = typeofEndorsement;
	}
 
	public String getBlacklisted() {
		return blacklisted;
	}
 
	public void setBlacklisted(String blacklisted) {
		this.blacklisted = blacklisted;
	}
 
	public String getHcompany() {
		return hcompany;
	}
 
	public void setHcompany(String hcompany) {
		this.hcompany = hcompany;
	}

	public String getSurLicenseNo() {
		return surLicenseNo;
	}

	public void setSurLicenseNo(String surLicenseNo) {
		this.surLicenseNo = surLicenseNo;
	}

	public String getSurLicenseExpiryDate() {
		return surLicenseExpiryDate;
	}

	public void setSurLicenseExpiryDate(String surLicenseExpiryDate) {
		this.surLicenseExpiryDate = surLicenseExpiryDate;
	}
	
 
}
