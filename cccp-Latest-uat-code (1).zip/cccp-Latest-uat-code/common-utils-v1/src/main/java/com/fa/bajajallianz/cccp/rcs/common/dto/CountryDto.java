package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

public class CountryDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private String countryName;

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

}
