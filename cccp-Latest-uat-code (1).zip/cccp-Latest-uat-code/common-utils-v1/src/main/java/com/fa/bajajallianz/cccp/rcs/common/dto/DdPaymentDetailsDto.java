/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author santhosh
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DdPaymentDetailsDto implements Serializable{

	private static final long serialVersionUID = 1L;
	private String bankName;
	private String locationCode;
	private String payLocation;
	private String printLocation;
	private String printLocationCode;
	
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getPayLocation() {
		return payLocation;
	}
	public void setPayLocation(String payLocation) {
		this.payLocation = payLocation;
	}
	public String getPrintLocation() {
		return printLocation;
	}
	public void setPrintLocation(String printLocation) {
		this.printLocation = printLocation;
	}
	public String getPrintLocationCode() {
		return printLocationCode;
	}
	public void setPrintLocationCode(String printLocationCode) {
		this.printLocationCode = printLocationCode;
	}
	
	
	
}
