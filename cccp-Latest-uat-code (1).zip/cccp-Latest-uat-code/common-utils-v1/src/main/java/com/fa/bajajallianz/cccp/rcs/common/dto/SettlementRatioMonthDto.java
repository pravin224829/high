package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

public class SettlementRatioMonthDto implements Serializable {
	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;
	private String month;
	private String totalClaimReg;
	private String settledClaimReg;
	private String percentage;
	private List<SettlementRatioDayDto> day;

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getTotalClaimReg() {
		return totalClaimReg;
	}

	public void setTotalClaimReg(String totalClaimReg) {
		this.totalClaimReg = totalClaimReg;
	}

	public String getSettledClaimReg() {
		return settledClaimReg;
	}

	public void setSettledClaimReg(String settledClaimReg) {
		this.settledClaimReg = settledClaimReg;
	}

	public String getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}

	public List<SettlementRatioDayDto> getDay() {
		return day;
	}

	public void setDay(List<SettlementRatioDayDto> day) {
		this.day = day;
	}

}
