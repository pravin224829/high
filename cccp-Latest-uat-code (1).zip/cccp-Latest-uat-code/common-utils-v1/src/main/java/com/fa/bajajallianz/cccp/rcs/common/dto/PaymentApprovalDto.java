package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentApprovalDto implements Serializable{

	private static final long serialVersionUID = 1L;

	private String claimNumber;
	private String claimType;
	private String ipNo;
	private String ipType;
	private String transType;
	private String paymentType;
	private String paymentAmount;
	private String paymentMode;
	private String partyName;
	private String state;
	private String payableAt;
	private String payeeName;
	private String gstAmount;
	private Boolean isGSTPayable;
	private String isGstPayable;
	private String outstandingReserveAmount;
	private String reserveAmount;
	private String totalAmount;
	private String reasonForChequePayment;
	private String invoiceType;
	private String invReferenceText;
	private String reinstatementPremium;
	private Boolean isForeignCurrency;
	private String isFrgnCurrency;
	private String typeOfRecovery;
	private String typeOfSalvage;
	private String interestPercentage;
	private String exchangeRate;
	private String exchangeRateCurrency;
	private String recoveryAmount;
	private String salvageAmount;
	private String interestAmount;
	private String typeOfLoss;
	private String specialComments;
	private String bagicGstIn;
	private String bagicState;
	private String supplierGstIn;
	private String supplierState;
	private String typeofTaxApplicable;
	private String paymentRefNo;
	private String gstPercentage;
	private String overallLossReserve;
	private String overallExpensesReserve;
	private String lossOutstanding;
	private String expensesOutstanding;
	private String psubIpNo;
	
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public String getClaimType() {
		return claimType;
	}
	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}
	public String getIpNo() {
		return ipNo;
	}
	public void setIpNo(String ipNo) {
		this.ipNo = ipNo;
	}
	public String getIpType() {
		return ipType;
	}
	public void setIpType(String ipType) {
		this.ipType = ipType;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPayableAt() {
		return payableAt;
	}
	public void setPayableAt(String payableAt) {
		this.payableAt = payableAt;
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public String getGstAmount() {
		return gstAmount;
	}
	public void setGstAmount(String gstAmount) {
		this.gstAmount = gstAmount;
	}
	public Boolean getIsGSTPayable() {
		return isGSTPayable;
	}
	public void setIsGSTPayable(Boolean isGSTPayable) {
		this.isGSTPayable = isGSTPayable;
	}
	public String getOutstandingReserveAmount() {
		return outstandingReserveAmount;
	}
	public void setOutstandingReserveAmount(String outstandingReserveAmount) {
		this.outstandingReserveAmount = outstandingReserveAmount;
	}
	public String getReserveAmount() {
		return reserveAmount;
	}
	public void setReserveAmount(String reserveAmount) {
		this.reserveAmount = reserveAmount;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getReasonForChequePayment() {
		return reasonForChequePayment;
	}
	public void setReasonForChequePayment(String reasonForChequePayment) {
		this.reasonForChequePayment = reasonForChequePayment;
	}
	public String getInvoiceType() {
		return invoiceType;
	}
	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}
	public String getInvReferenceText() {
		return invReferenceText;
	}
	public void setInvReferenceText(String invReferenceText) {
		this.invReferenceText = invReferenceText;
	}
	public String getReinstatementPremium() {
		return reinstatementPremium;
	}
	public void setReinstatementPremium(String reinstatementPremium) {
		this.reinstatementPremium = reinstatementPremium;
	}
	public String getTypeOfRecovery() {
		return typeOfRecovery;
	}
	public void setTypeOfRecovery(String typeOfRecovery) {
		this.typeOfRecovery = typeOfRecovery;
	}
	public String getTypeOfSalvage() {
		return typeOfSalvage;
	}
	public void setTypeOfSalvage(String typeOfSalvage) {
		this.typeOfSalvage = typeOfSalvage;
	}
	public String getInterestPercentage() {
		return interestPercentage;
	}
	public void setInterestPercentage(String interestPercentage) {
		this.interestPercentage = interestPercentage;
	}
	public String getExchangeRate() {
		return exchangeRate;
	}
	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}
	public String getExchangeRateCurrency() {
		return exchangeRateCurrency;
	}
	public void setExchangeRateCurrency(String exchangeRateCurrency) {
		this.exchangeRateCurrency = exchangeRateCurrency;
	}
	public String getRecoveryAmount() {
		return recoveryAmount;
	}
	public void setRecoveryAmount(String recoveryAmount) {
		this.recoveryAmount = recoveryAmount;
	}
	public String getSalvageAmount() {
		return salvageAmount;
	}
	public void setSalvageAmount(String salvageAmount) {
		this.salvageAmount = salvageAmount;
	}
	public String getInterestAmount() {
		return interestAmount;
	}
	public void setInterestAmount(String interestAmount) {
		this.interestAmount = interestAmount;
	}
	public String getTypeOfLoss() {
		return typeOfLoss;
	}
	public void setTypeOfLoss(String typeOfLoss) {
		this.typeOfLoss = typeOfLoss;
	}
	public String getSpecialComments() {
		return specialComments;
	}
	public void setSpecialComments(String specialComments) {
		this.specialComments = specialComments;
	}
	public String getBagicGstIn() {
		return bagicGstIn;
	}
	public void setBagicGstIn(String bagicGstIn) {
		this.bagicGstIn = bagicGstIn;
	}
	public String getBagicState() {
		return bagicState;
	}
	public void setBagicState(String bagicState) {
		this.bagicState = bagicState;
	}
	public String getSupplierGstIn() {
		return supplierGstIn;
	}
	public void setSupplierGstIn(String supplierGstIn) {
		this.supplierGstIn = supplierGstIn;
	}
	public String getSupplierState() {
		return supplierState;
	}
	public void setSupplierState(String supplierState) {
		this.supplierState = supplierState;
	}
	public String getTypeofTaxApplicable() {
		return typeofTaxApplicable;
	}
	public void setTypeofTaxApplicable(String typeofTaxApplicable) {
		this.typeofTaxApplicable = typeofTaxApplicable;
	}
	public String getPaymentRefNo() {
		return paymentRefNo;
	}
	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}
	public String getGstPercentage() {
		return gstPercentage;
	}
	public void setGstPercentage(String gstPercentage) {
		this.gstPercentage = gstPercentage;
	}
	public String getOverallLossReserve() {
		return overallLossReserve;
	}
	public void setOverallLossReserve(String overallLossReserve) {
		this.overallLossReserve = overallLossReserve;
	}
	public String getOverallExpensesReserve() {
		return overallExpensesReserve;
	}
	public void setOverallExpensesReserve(String overallExpensesReserve) {
		this.overallExpensesReserve = overallExpensesReserve;
	}
	public String getLossOutstanding() {
		return lossOutstanding;
	}
	public void setLossOutstanding(String lossOutstanding) {
		this.lossOutstanding = lossOutstanding;
	}
	public String getExpensesOutstanding() {
		return expensesOutstanding;
	}
	public void setExpensesOutstanding(String expensesOutstanding) {
		this.expensesOutstanding = expensesOutstanding;
	}
	public String getPartyName() {
		return partyName;
	}
	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}
	public String getPsubIpNo() {
		return psubIpNo;
	}
	public void setPsubIpNo(String psubIpNo) {
		this.psubIpNo = psubIpNo;
	}
	public Boolean getIsForeignCurrency() {
		return isForeignCurrency;
	}
	public void setIsForeignCurrency(Boolean isForeignCurrency) {
		this.isForeignCurrency = isForeignCurrency;
	}
	public String getIsGstPayable() {
		return isGstPayable;
	}
	public void setIsGstPayable(String isGstPayable) {
		this.isGstPayable = isGstPayable;
	}
	public String getIsFrgnCurrency() {
		return isFrgnCurrency;
	}
	public void setIsFrgnCurrency(String isFrgnCurrency) {
		this.isFrgnCurrency = isFrgnCurrency;
	}
	
}
