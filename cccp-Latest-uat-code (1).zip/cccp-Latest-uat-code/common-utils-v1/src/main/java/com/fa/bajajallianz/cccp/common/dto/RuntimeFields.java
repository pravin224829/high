package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RuntimeFields implements Serializable {

	private static final long serialVersionUID = 1L;
	private String fieldName;
	private String fieldCode;
	private String fieldValue;
	private String fieldType;
	private Boolean isActive;
	private String claimNumber;
	private String email;
	private String mobileNo;
	private String policyNumber;
	private String createdDate;
	private String createdBy;
	private String blRrLrAwbNo;
	private String orderNo;
	private List<RunTimeFieldsValueDto> runTimeFieldsValue;

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldCode() {
		return fieldCode;
	}

	public void setFieldCode(String fieldCode) {
		this.fieldCode = fieldCode;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public String getFieldType() {
		return fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;						
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public List<RunTimeFieldsValueDto> getRunTimeFieldsValue() {
		return runTimeFieldsValue;
	}

	public void setRunTimeFieldsValue(List<RunTimeFieldsValueDto> runTimeFieldsValue) {
		this.runTimeFieldsValue = runTimeFieldsValue;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getBlRrLrAwbNo() {
		return blRrLrAwbNo;
	}

	public void setBlRrLrAwbNo(String blRrLrAwbNo) {
		this.blRrLrAwbNo = blRrLrAwbNo;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
}
