package com.fa.bajajallianz.cccp.rcs.common.dto;
 
import java.io.Serializable;
 
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
 
@JsonIgnoreProperties(ignoreUnknown = true)
public class RiskCoverDetailsDto implements Serializable {
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String coverCode;
	private String coverName;
	private String sumInsured;
	private String totalPremium;
	private Boolean isSelect;
 
	public Boolean getIsSelect() {
		return isSelect;
	}

	public void setIsSelect(Boolean isSelect) {
		this.isSelect = isSelect;
	}

	public String getCoverCode() {
		return coverCode;
	}
 
	public void setCoverCode(String coverCode) {
		this.coverCode = coverCode;
	}
 
	public String getCoverName() {
		return coverName;
	}
 
	public void setCoverName(String coverName) {
		this.coverName = coverName;
	}
 
	public String getSumInsured() {
		return sumInsured;
	}
 
	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}

	public String getTotalPremium() {
		return totalPremium;
	}

	public void setTotalPremium(String totalPremium) {
		this.totalPremium = totalPremium;
	}
	
 
}
