package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimReserveDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String totalAmount;
	private String reserveSubType;
	private String partyCode;
	private String reserveType;
	private String reserveAmount;
	private String paidAmount;
	private String pendingAmount;
	private String partyStake;
	private String claimNumber;
	private String reserveStake;
	private String reserveParty;
	private String expenseAmount;
	private String claimTypes;
	private String coInsuranceExpenseAmount;
	private String roleCode;
	private String partyName;
	private String partyNameStake;
	private String userCode;
	private String remarks;
	private String expenseFeeHeads;
	private String partyNameCode;
	private String typeOfRecovery;
	private String typeOfLoss;
	private String recoveryAmount;
	private String modifiedReserveAgainstLossCompensation;
	private String policyNumber;
	private String typeofExpenses;
	
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getReserveSubType() {
		return reserveSubType;
	}
	public void setReserveSubType(String reserveSubType) {
		this.reserveSubType = reserveSubType;
	}
	public String getPartyCode() {
		return partyCode;
	}
	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}
	public String getReserveType() {
		return reserveType;
	}
	public void setReserveType(String reserveType) {
		this.reserveType = reserveType;
	}
	public String getReserveAmount() {
		return reserveAmount;
	}
	public void setReserveAmount(String reserveAmount) {
		this.reserveAmount = reserveAmount;
	}
	public String getPaidAmount() {
		return paidAmount;
	}
	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}
	public String getPendingAmount() {
		return pendingAmount;
	}
	public void setPendingAmount(String pendingAmount) {
		this.pendingAmount = pendingAmount;
	}
	public String getPartyStake() {
		return partyStake;
	}
	public void setPartyStake(String partyStake) {
		this.partyStake = partyStake;
	}
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public String getReserveStake() {
		return reserveStake;
	}
	public void setReserveStake(String reserveStake) {
		this.reserveStake = reserveStake;
	}
	public String getReserveParty() {
		return reserveParty;
	}
	public void setReserveParty(String reserveParty) {
		this.reserveParty = reserveParty;
	}
	public String getExpenseAmount() {
		return expenseAmount;
	}
	public void setExpenseAmount(String expenseAmount) {
		this.expenseAmount = expenseAmount;
	}
	public String getClaimTypes() {
		return claimTypes;
	}
	public void setClaimTypes(String claimTypes) {
		this.claimTypes = claimTypes;
	}
	public String getCoInsuranceExpenseAmount() {
		return coInsuranceExpenseAmount;
	}
	public void setCoInsuranceExpenseAmount(String coInsuranceExpenseAmount) {
		this.coInsuranceExpenseAmount = coInsuranceExpenseAmount;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getPartyName() {
		return partyName;
	}
	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}
	public String getPartyNameStake() {
		return partyNameStake;
	}
	public void setPartyNameStake(String partyNameStake) {
		this.partyNameStake = partyNameStake;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getExpenseFeeHeads() {
		return expenseFeeHeads;
	}
	public void setExpenseFeeHeads(String expenseFeeHeads) {
		this.expenseFeeHeads = expenseFeeHeads;
	}
	public String getPartyNameCode() {
		return partyNameCode;
	}
	public void setPartyNameCode(String partyNameCode) {
		this.partyNameCode = partyNameCode;
	}
	public String getTypeOfRecovery() {
		return typeOfRecovery;
	}
	public void setTypeOfRecovery(String typeOfRecovery) {
		this.typeOfRecovery = typeOfRecovery;
	}
	public String getTypeOfLoss() {
		return typeOfLoss;
	}
	public void setTypeOfLoss(String typeOfLoss) {
		this.typeOfLoss = typeOfLoss;
	}
	public String getRecoveryAmount() {
		return recoveryAmount;
	}
	public void setRecoveryAmount(String recoveryAmount) {
		this.recoveryAmount = recoveryAmount;
	}
	public String getModifiedReserveAgainstLossCompensation() {
		return modifiedReserveAgainstLossCompensation;
	}
	public void setModifiedReserveAgainstLossCompensation(String modifiedReserveAgainstLossCompensation) {
		this.modifiedReserveAgainstLossCompensation = modifiedReserveAgainstLossCompensation;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getTypeofExpenses() {
		return typeofExpenses;
	}
	public void setTypeofExpenses(String typeofExpenses) {
		this.typeofExpenses = typeofExpenses;
	}
	
}
