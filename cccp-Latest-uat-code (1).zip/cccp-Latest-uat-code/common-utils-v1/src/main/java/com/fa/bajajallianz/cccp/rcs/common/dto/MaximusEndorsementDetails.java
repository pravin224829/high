package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.ArrayList;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fa.bajajallianz.cccp.mis.common.dto.PolicyEndorsementDetailDto;

public class MaximusEndorsementDetails implements Serializable {

	public ApplicationErrorDto applicationError;
	public ArrayList<PolicyEndorsementDetailDto> policyEndorsementDetails;

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public ArrayList<PolicyEndorsementDetailDto> getPolicyEndorsementDetails() {
		return policyEndorsementDetails;
	}

	public void setPolicyEndorsementDetails(ArrayList<PolicyEndorsementDetailDto> policyEndorsementDetails) {
		this.policyEndorsementDetails = policyEndorsementDetails;
	}

}