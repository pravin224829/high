package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusPolicyReqDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String chassisNumber;
	private String bankCustomerId;
	private String corporateId;
	private String crossReferenceNumber;
	private String dateOfBirth;
	private String emailAddress;
	private String employeeId;
	private String endDate;
	private String firstName;
	private String imdCode;
	private String lastName;
	private String lob;
	private String locationCode;
	private String maximumRowNumber;
	private String memberInfoRequired;
	private String minimumRowNumber;
	private String mobileNumber;
	private String partyCode;
	private String passportNumber;
	private String policyBranch;
	private String policyNumber;
	private String policyPlan;
	private String policyStatus;
	private String previousPolicyNumber;
	private String productCode;
	private String quoteCreatedFrom;
	private String quoteCreatedTo;
	private String registrationNumber;
	private String renewalFromDate;
	private String renewalToDate;
	private String startDate;
	private String subIMDCode;
	private String vehicleMake;

	public String getChassisNumber() {
		return chassisNumber;
	}

	public void setChassisNumber(String chassisNumber) {
		this.chassisNumber = chassisNumber;
	}

	public String getBankCustomerId() {
		return bankCustomerId;
	}

	public void setBankCustomerId(String bankCustomerId) {
		this.bankCustomerId = bankCustomerId;
	}

	public String getCorporateId() {
		return corporateId;
	}

	public void setCorporateId(String corporateId) {
		this.corporateId = corporateId;
	}

	public String getCrossReferenceNumber() {
		return crossReferenceNumber;
	}

	public void setCrossReferenceNumber(String crossReferenceNumber) {
		this.crossReferenceNumber = crossReferenceNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getImdCode() {
		return imdCode;
	}

	public void setImdCode(String imdCode) {
		this.imdCode = imdCode;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getMaximumRowNumber() {
		return maximumRowNumber;
	}

	public void setMaximumRowNumber(String maximumRowNumber) {
		this.maximumRowNumber = maximumRowNumber;
	}

	public String getMemberInfoRequired() {
		return memberInfoRequired;
	}

	public void setMemberInfoRequired(String memberInfoRequired) {
		this.memberInfoRequired = memberInfoRequired;
	}

	public String getMinimumRowNumber() {
		return minimumRowNumber;
	}

	public void setMinimumRowNumber(String minimumRowNumber) {
		this.minimumRowNumber = minimumRowNumber;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getPolicyBranch() {
		return policyBranch;
	}

	public void setPolicyBranch(String policyBranch) {
		this.policyBranch = policyBranch;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getPolicyPlan() {
		return policyPlan;
	}

	public void setPolicyPlan(String policyPlan) {
		this.policyPlan = policyPlan;
	}

	public String getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	public String getPreviousPolicyNumber() {
		return previousPolicyNumber;
	}

	public void setPreviousPolicyNumber(String previousPolicyNumber) {
		this.previousPolicyNumber = previousPolicyNumber;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getQuoteCreatedFrom() {
		return quoteCreatedFrom;
	}

	public void setQuoteCreatedFrom(String quoteCreatedFrom) {
		this.quoteCreatedFrom = quoteCreatedFrom;
	}

	public String getQuoteCreatedTo() {
		return quoteCreatedTo;
	}

	public void setQuoteCreatedTo(String quoteCreatedTo) {
		this.quoteCreatedTo = quoteCreatedTo;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getRenewalFromDate() {
		return renewalFromDate;
	}

	public void setRenewalFromDate(String renewalFromDate) {
		this.renewalFromDate = renewalFromDate;
	}

	public String getRenewalToDate() {
		return renewalToDate;
	}

	public void setRenewalToDate(String renewalToDate) {
		this.renewalToDate = renewalToDate;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getSubIMDCode() {
		return subIMDCode;
	}

	public void setSubIMDCode(String subIMDCode) {
		this.subIMDCode = subIMDCode;
	}

	public String getVehicleMake() {
		return vehicleMake;
	}

	public void setVehicleMake(String vehicleMake) {
		this.vehicleMake = vehicleMake;
	}

}
