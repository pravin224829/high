package com.fa.bajajallianz.cccp.surveyor.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NotifyConfigDto implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String id;
	private String action;
	private Boolean isActive;
	private String createdDate;
	private NotifyMsgTemplateDto notifyMsgTemplate;
	private NotifySmsTemplateDto notifySmsTemplate;
	private NotifyEmailTemplateDto notifyEmailTemplate;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public NotifyMsgTemplateDto getNotifyMsgTemplate() {
		return notifyMsgTemplate;
	}
	public void setNotifyMsgTemplate(NotifyMsgTemplateDto notifyMsgTemplate) {
		this.notifyMsgTemplate = notifyMsgTemplate;
	}
	public NotifySmsTemplateDto getNotifySmsTemplate() {
		return notifySmsTemplate;
	}
	public void setNotifySmsTemplate(NotifySmsTemplateDto notifySmsTemplate) {
		this.notifySmsTemplate = notifySmsTemplate;
	}
	public NotifyEmailTemplateDto getNotifyEmailTemplate() {
		return notifyEmailTemplate;
	}
	public void setNotifyEmailTemplate(NotifyEmailTemplateDto notifyEmailTemplate) {
		this.notifyEmailTemplate = notifyEmailTemplate;
	}

}
