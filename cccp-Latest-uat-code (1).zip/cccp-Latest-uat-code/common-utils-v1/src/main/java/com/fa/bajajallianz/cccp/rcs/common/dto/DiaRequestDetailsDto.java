/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author Arul
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DiaRequestDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;
	private String comments;
	private String assignTo;
	private String declaredBy;
	private String diaApprovalAuthority;
	private String diaRefNumber;
	private String diaStatus;
	private String createdDate;
	private String createdBy;

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getAssignTo() {
		return assignTo;
	}

	public void setAssignTo(String assignTo) {
		this.assignTo = assignTo;
	}

	public String getDiaStatus() {
		return diaStatus;
	}

	public void setDiaStatus(String diaStatus) {
		this.diaStatus = diaStatus;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDeclaredBy() {
		return declaredBy;
	}

	public void setDeclaredBy(String declaredBy) {
		this.declaredBy = declaredBy;
	}

	public String getDiaApprovalAuthority() {
		return diaApprovalAuthority;
	}

	public void setDiaApprovalAuthority(String diaApprovalAuthority) {
		this.diaApprovalAuthority = diaApprovalAuthority;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getDiaRefNumber() {
		return diaRefNumber;
	}

	public void setDiaRefNumber(String diaRefNumber) {
		this.diaRefNumber = diaRefNumber;
	}

}
