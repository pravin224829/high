package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DiaCreationDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String estimatedDamageValue;
	private String estimatedLossAmount;
	private String lossReserveAmt;
	private String diDetailDescription;
	public String getEstimatedDamageValue() {
		return estimatedDamageValue;
	}
	public void setEstimatedDamageValue(String estimatedDamageValue) {
		this.estimatedDamageValue = estimatedDamageValue;
	}
	public String getEstimatedLossAmount() {
		return estimatedLossAmount;
	}
	public void setEstimatedLossAmount(String estimatedLossAmount) {
		this.estimatedLossAmount = estimatedLossAmount;
	}
	public String getLossReserveAmt() {
		return lossReserveAmt;
	}
	public void setLossReserveAmt(String lossReserveAmt) {
		this.lossReserveAmt = lossReserveAmt;
	}
	public String getDiDetailDescription() {
		return diDetailDescription;
	}
	public void setDiDetailDescription(String diDetailDescription) {
		this.diDetailDescription = diDetailDescription;
	}
	
	
}
