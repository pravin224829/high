package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FcBankDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String name;

	private String address1;

	private String address2;

	private String city;

	private String country;

	private String swiftCode;

	private String iban;

	private Boolean isActive;

	private String createdDate;

	private String createdBy;

	private String modifiedDate;

	private String modifiedBy;
	
	private String expensePaymentDetailsId;
	
	private String lossPaymentDetailsId;

	private String beneficiaryBankName;
	
	private String bankAddressLine1;
	
	private String bankAddressLine2;

	private String bankAddressCity;

	private String bankAddressCountry;


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getSwiftCode() {
		return swiftCode;
	}

	public void setSwiftCode(String swiftCode) {
		this.swiftCode = swiftCode;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getExpensePaymentDetailsId() {
		return expensePaymentDetailsId;
	}

	public void setExpensePaymentDetailsId(String expensePaymentDetailsId) {
		this.expensePaymentDetailsId = expensePaymentDetailsId;
	}

	public String getLossPaymentDetailsId() {
		return lossPaymentDetailsId;
	}

	public void setLossPaymentDetailsId(String lossPaymentDetailsId) {
		this.lossPaymentDetailsId = lossPaymentDetailsId;
	}

	public String getBeneficiaryBankName() {
		return beneficiaryBankName;
	}

	public void setBeneficiaryBankName(String beneficiaryBankName) {
		this.beneficiaryBankName = beneficiaryBankName;
	}

	public String getBankAddressLine1() {
		return bankAddressLine1;
	}

	public void setBankAddressLine1(String bankAddressLine1) {
		this.bankAddressLine1 = bankAddressLine1;
	}

	public String getBankAddressLine2() {
		return bankAddressLine2;
	}

	public void setBankAddressLine2(String bankAddressLine2) {
		this.bankAddressLine2 = bankAddressLine2;
	}

	public String getBankAddressCity() {
		return bankAddressCity;
	}

	public void setBankAddressCity(String bankAddressCity) {
		this.bankAddressCity = bankAddressCity;
	}

	public String getBankAddressCountry() {
		return bankAddressCountry;
	}

	public void setBankAddressCountry(String bankAddressCountry) {
		this.bankAddressCountry = bankAddressCountry;
	}

}
