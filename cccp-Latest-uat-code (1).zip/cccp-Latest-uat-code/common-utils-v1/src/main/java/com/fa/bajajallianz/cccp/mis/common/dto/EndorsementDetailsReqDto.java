package com.fa.bajajallianz.cccp.mis.common.dto;

public class EndorsementDetailsReqDto {

	private String policyNumber;

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public EndorsementDetailsReqDto(String policyNumber) {
		super();
		this.policyNumber = policyNumber;
	}

	public EndorsementDetailsReqDto() {
		super();
		// TODO Auto-generated constructor stub
	}

}
