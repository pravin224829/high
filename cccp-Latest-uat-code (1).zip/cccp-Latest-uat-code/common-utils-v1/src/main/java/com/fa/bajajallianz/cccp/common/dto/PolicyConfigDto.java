/**
 * 
 */
package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyConfigDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userId;
	private String agentCode;
	private String roleCode;
    private List<PolicyConfigListDto> policyConfigListDto;
    
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public List<PolicyConfigListDto> getPolicyConfigListDto() {
		return policyConfigListDto;
	}
	public void setPolicyConfigListDto(List<PolicyConfigListDto> policyConfigListDto) {
		this.policyConfigListDto = policyConfigListDto;
	}
    
    

}
