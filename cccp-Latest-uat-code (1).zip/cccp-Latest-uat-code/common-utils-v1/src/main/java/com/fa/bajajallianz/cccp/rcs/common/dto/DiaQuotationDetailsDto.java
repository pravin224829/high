package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DiaQuotationDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private String quotationName;
	private String quotationAmount;
	private String quotationMno;
	private String damageItemDetails;
	private Boolean delete;

	public String getQuotationName() {
		return quotationName;
	}

	public void setQuotationName(String quotationName) {
		this.quotationName = quotationName;
	}

	public String getQuotationAmount() {
		return quotationAmount;
	}

	public void setQuotationAmount(String quotationAmount) {
		this.quotationAmount = quotationAmount;
	}

	public String getQuotationMno() {
		return quotationMno;
	}

	public void setQuotationMno(String quotationMno) {
		this.quotationMno = quotationMno;
	}

	public String getDamageItemDetails() {
		return damageItemDetails;
	}

	public void setDamageItemDetails(String damageItemDetails) {
		this.damageItemDetails = damageItemDetails;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Boolean getDelete() {
		return delete;
	}

	public void setDelete(Boolean delete) {
		this.delete = delete;
	}

}
