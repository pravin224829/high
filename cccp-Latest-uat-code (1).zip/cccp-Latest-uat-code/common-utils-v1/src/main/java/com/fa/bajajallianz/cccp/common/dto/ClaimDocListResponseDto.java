package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimDocListResponseDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<DocumentDto> docClaimListDto;
	private String claimNo;
	private ApplicationErrorDto applicationError;
	
	public List<DocumentDto> getDocClaimListDto() {
		return docClaimListDto;
	}
	public void setDocClaimListDto(List<DocumentDto> docClaimListDto) {
		this.docClaimListDto = docClaimListDto;
	}
	public String getClaimNo() {
		return claimNo;
	}
	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}
	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}
	
	
}
