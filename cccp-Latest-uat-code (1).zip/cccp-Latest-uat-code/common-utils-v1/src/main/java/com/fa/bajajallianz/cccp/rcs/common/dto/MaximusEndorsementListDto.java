package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;

public class MaximusEndorsementListDto implements Serializable {
	 
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
 
	private List<MaximusEndorsementDetails>  endorsementDetails;
	
	private ApplicationErrorDto applicationError;
 
	public List<MaximusEndorsementDetails> getEndorsementDetails() {
		return endorsementDetails;
	}
 
	public void setEndorsementDetails(List<MaximusEndorsementDetails> endorsementDetails) {
		this.endorsementDetails = endorsementDetails;
	}

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}
	
	
}
