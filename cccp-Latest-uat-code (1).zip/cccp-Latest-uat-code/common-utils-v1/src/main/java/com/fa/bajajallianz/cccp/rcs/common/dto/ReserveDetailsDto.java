package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ReserveDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private String ipNo;
	private String claimNumber;
	private String paidAmount;
	private String outstandingReserveAmount;
	private String partyCode;
	private String reserveType;
	private String earlierReserveAmount;
	private String reserveAmount;
	private Boolean isActive;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private String partyId;
	private String partyType;
	private String partyName;
	private String currencyCode;
	private String currencyRate;
	private String foreignCurrencyAmount;
	private String inrAmount;
	private String amount;
	private String approvalNo;
	private String remarks;
	private String sumInsured;
	private String neftStatus;
	private String ckycStatus;
	private String subType;
	private String partnerID;
	private String nameOfInterestedParties;
	private String reserveSection;
	private String outstandingAmount;
	private String newReserveAmount;
	private String reasonForChange;
	private String reqNumber;

	private String userId;
	private String lossRreserve;
	private String normalReserveCurrency;
	private String normalReserveCurrencyReserve;
	private String otherReserveCurrency;
	private String otherReserveConversionRate;
	private String otherReserveCurrencyReserve;
	private String normalReason;
	private String earlierlossRreserve;
	private String otherReserveEarlier;
	private String otherReason;
	private SurveryorInfoDtlsObj surveryorInfoDtlsObj;
	private ReasonDelayObj reasonDelayObj;
	private ApplicationErrorDto applicationError;
	private String status;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getOutstandingReserveAmount() {
		return outstandingReserveAmount;
	}

	public void setOutstandingReserveAmount(String outstandingReserveAmount) {
		this.outstandingReserveAmount = outstandingReserveAmount;
	}

	public String getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public String getReserveType() {
		return reserveType;
	}

	public void setReserveType(String reserveType) {
		this.reserveType = reserveType;
	}

	public String getEarlierReserveAmount() {
		return earlierReserveAmount;
	}

	public void setEarlierReserveAmount(String earlierReserveAmount) {
		this.earlierReserveAmount = earlierReserveAmount;
	}

	public String getReserveAmount() {
		return reserveAmount;
	}

	public void setReserveAmount(String reserveAmount) {
		this.reserveAmount = reserveAmount;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getPartyType() {
		return partyType;
	}

	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getCurrencyRate() {
		return currencyRate;
	}

	public void setCurrencyRate(String currencyRate) {
		this.currencyRate = currencyRate;
	}

	public String getForeignCurrencyAmount() {
		return foreignCurrencyAmount;
	}

	public void setForeignCurrencyAmount(String foreignCurrencyAmount) {
		this.foreignCurrencyAmount = foreignCurrencyAmount;
	}

	public String getInrAmount() {
		return inrAmount;
	}

	public void setInrAmount(String inrAmount) {
		this.inrAmount = inrAmount;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getApprovalNo() {
		return approvalNo;
	}

	public void setApprovalNo(String approvalNo) {
		this.approvalNo = approvalNo;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getSumInsured() {
		return sumInsured;
	}

	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}

	public String getIpNo() {
		return ipNo;
	}

	public void setIpNo(String ipNo) {
		this.ipNo = ipNo;
	}

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public String getCkycStatus() {
		return ckycStatus;
	}

	public void setCkycStatus(String ckycStatus) {
		this.ckycStatus = ckycStatus;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getPartnerID() {
		return partnerID;
	}

	public void setPartnerID(String partnerID) {
		this.partnerID = partnerID;
	}

	public String getNameOfInterestedParties() {
		return nameOfInterestedParties;
	}

	public void setNameOfInterestedParties(String nameOfInterestedParties) {
		this.nameOfInterestedParties = nameOfInterestedParties;
	}

	public String getReserveSection() {
		return reserveSection;
	}

	public void setReserveSection(String reserveSection) {
		this.reserveSection = reserveSection;
	}

	public String getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(String outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public String getNewReserveAmount() {
		return newReserveAmount;
	}

	public void setNewReserveAmount(String newReserveAmount) {
		this.newReserveAmount = newReserveAmount;
	}

	public String getReasonForChange() {
		return reasonForChange;
	}

	public void setReasonForChange(String reasonForChange) {
		this.reasonForChange = reasonForChange;
	}

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getLossRreserve() {
		return lossRreserve;
	}

	public void setLossRreserve(String lossRreserve) {
		this.lossRreserve = lossRreserve;
	}

	public String getNormalReserveCurrency() {
		return normalReserveCurrency;
	}

	public void setNormalReserveCurrency(String normalReserveCurrency) {
		this.normalReserveCurrency = normalReserveCurrency;
	}

	public String getNormalReserveCurrencyReserve() {
		return normalReserveCurrencyReserve;
	}

	public void setNormalReserveCurrencyReserve(String normalReserveCurrencyReserve) {
		this.normalReserveCurrencyReserve = normalReserveCurrencyReserve;
	}

	public String getNormalReason() {
		return normalReason;
	}

	public void setNormalReason(String normalReason) {
		this.normalReason = normalReason;
	}

	public String getEarlierlossRreserve() {
		return earlierlossRreserve;
	}

	public void setEarlierlossRreserve(String earlierlossRreserve) {
		this.earlierlossRreserve = earlierlossRreserve;
	}

	public String getOtherReserveCurrency() {
		return otherReserveCurrency;
	}

	public void setOtherReserveCurrency(String otherReserveCurrency) {
		this.otherReserveCurrency = otherReserveCurrency;
	}

	public String getOtherReserveConversionRate() {
		return otherReserveConversionRate;
	}

	public void setOtherReserveConversionRate(String otherReserveConversionRate) {
		this.otherReserveConversionRate = otherReserveConversionRate;
	}

	public String getOtherReserveCurrencyReserve() {
		return otherReserveCurrencyReserve;
	}

	public void setOtherReserveCurrencyReserve(String otherReserveCurrencyReserve) {
		this.otherReserveCurrencyReserve = otherReserveCurrencyReserve;
	}

	public String getOtherReserveEarlier() {
		return otherReserveEarlier;
	}

	public void setOtherReserveEarlier(String otherReserveEarlier) {
		this.otherReserveEarlier = otherReserveEarlier;
	}

	public String getOtherReason() {
		return otherReason;
	}

	public void setOtherReason(String otherReason) {
		this.otherReason = otherReason;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReqNumber() {
		return reqNumber;
	}

	public void setReqNumber(String reqNumber) {
		this.reqNumber = reqNumber;
	}

	public SurveryorInfoDtlsObj getSurveryorInfoDtlsObj() {
		return surveryorInfoDtlsObj;
	}

	public void setSurveryorInfoDtlsObj(SurveryorInfoDtlsObj surveryorInfoDtlsObj) {
		this.surveryorInfoDtlsObj = surveryorInfoDtlsObj;
	}

	public ReasonDelayObj getReasonDelayObj() {
		return reasonDelayObj;
	}

	public void setReasonDelayObj(ReasonDelayObj reasonDelayObj) {
		this.reasonDelayObj = reasonDelayObj;
	}

}