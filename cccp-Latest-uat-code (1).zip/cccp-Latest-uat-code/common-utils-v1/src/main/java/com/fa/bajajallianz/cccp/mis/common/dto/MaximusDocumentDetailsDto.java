package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

public class MaximusDocumentDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private String documentType;
	private String documentName;
	private String documentGenerationDate;
	private String documentId;

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentGenerationDate() {
		return documentGenerationDate;
	}

	public void setDocumentGenerationDate(String documentGenerationDate) {
		this.documentGenerationDate = documentGenerationDate;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

}
