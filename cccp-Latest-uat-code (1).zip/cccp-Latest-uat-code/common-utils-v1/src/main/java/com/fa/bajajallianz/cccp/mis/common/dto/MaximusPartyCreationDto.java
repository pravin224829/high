package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusPartyCreationDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private MaximusAddressesListDto addresses;
	private MaximusBasicDetailsDto basicDetails;
	private MaximusMiscellaneousDto miscellaneous;
	private MaximusPartyDetailsDto partyDetails;
	private MaximusBankAccountsDto bankAccounts;
	
	public MaximusBankAccountsDto getBankAccounts() {
		return bankAccounts;
	}
	public void setBankAccounts(MaximusBankAccountsDto bankAccounts) {
		this.bankAccounts = bankAccounts;
	}
	public MaximusAddressesListDto getAddresses() {
		return addresses;
	}
	public void setAddresses(MaximusAddressesListDto addresses) {
		this.addresses = addresses;
	}
	public MaximusBasicDetailsDto getBasicDetails() {
		return basicDetails;
	}
	public void setBasicDetails(MaximusBasicDetailsDto basicDetails) {
		this.basicDetails = basicDetails;
	}
	public MaximusMiscellaneousDto getMiscellaneous() {
		return miscellaneous;
	}
	public void setMiscellaneous(MaximusMiscellaneousDto miscellaneous) {
		this.miscellaneous = miscellaneous;
	}
	public MaximusPartyDetailsDto getPartyDetails() {
		return partyDetails;
	}
	public void setPartyDetails(MaximusPartyDetailsDto partyDetails) {
		this.partyDetails = partyDetails;
	}
		
}
