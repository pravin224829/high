package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GstDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String gstNo;
	private String bagicGstNo;
	private String bagicState;
	private String supplierGstNo;
	private String supplierState;
	private String taxType;
	private String billNo;
	private String isBagicRaise;
	private String remarks;
	private String billDate;
	private String grossBilledAmount;
	private String gstBaseAmount;
	private String bagicRaiseGstAmount;
	private String totalCalculatedBillAmount;
	private String calculatedGstAmount;
	private String totalCalculatedAmount;
	private String totalAllowedBillAmt;
	private String allowedGstAmt;
	private String allowedTotalAmt;
	private String expensePaymentDetailsId;
	private String lossPaymentDetailsId;
	private String gstIn;
	private String baseAmountOfGst;
	private String raiseOnBagic;
	private String gstAmt;
	private String docId;

	public String getGstNo() {
		return gstNo;
	}

	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}

	public String getBagicGstNo() {
		return bagicGstNo;
	}

	public void setBagicGstNo(String bagicGstNo) {
		this.bagicGstNo = bagicGstNo;
	}

	public String getBagicState() {
		return bagicState;
	}

	public void setBagicState(String bagicState) {
		this.bagicState = bagicState;
	}

	public String getSupplierGstNo() {
		return supplierGstNo;
	}

	public void setSupplierGstNo(String supplierGstNo) {
		this.supplierGstNo = supplierGstNo;
	}

	public String getSupplierState() {
		return supplierState;
	}

	public void setSupplierState(String supplierState) {
		this.supplierState = supplierState;
	}

	public String getTaxType() {
		return taxType;
	}

	public void setTaxType(String taxType) {
		this.taxType = taxType;
	}

	public String getBillNo() {
		return billNo;
	}

	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}

	public String getIsBagicRaise() {
		return isBagicRaise;
	}

	public void setIsBagicRaise(String isBagicRaise) {
		this.isBagicRaise = isBagicRaise;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getBillDate() {
		return billDate;
	}

	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}

	public String getGrossBilledAmount() {
		return grossBilledAmount;
	}

	public void setGrossBilledAmount(String grossBilledAmount) {
		this.grossBilledAmount = grossBilledAmount;
	}

	public String getGstBaseAmount() {
		return gstBaseAmount;
	}

	public void setGstBaseAmount(String gstBaseAmount) {
		this.gstBaseAmount = gstBaseAmount;
	}

	public String getTotalCalculatedBillAmount() {
		return totalCalculatedBillAmount;
	}

	public void setTotalCalculatedBillAmount(String totalCalculatedBillAmount) {
		this.totalCalculatedBillAmount = totalCalculatedBillAmount;
	}

	public String getCalculatedGstAmount() {
		return calculatedGstAmount;
	}

	public void setCalculatedGstAmount(String calculatedGstAmount) {
		this.calculatedGstAmount = calculatedGstAmount;
	}

	public String getTotalCalculatedAmount() {
		return totalCalculatedAmount;
	}

	public void setTotalCalculatedAmount(String totalCalculatedAmount) {
		this.totalCalculatedAmount = totalCalculatedAmount;
	}

	public String getTotalAllowedBillAmt() {
		return totalAllowedBillAmt;
	}

	public void setTotalAllowedBillAmt(String totalAllowedBillAmt) {
		this.totalAllowedBillAmt = totalAllowedBillAmt;
	}

	public String getAllowedGstAmt() {
		return allowedGstAmt;
	}

	public void setAllowedGstAmt(String allowedGstAmt) {
		this.allowedGstAmt = allowedGstAmt;
	}

	public String getAllowedTotalAmt() {
		return allowedTotalAmt;
	}

	public void setAllowedTotalAmt(String allowedTotalAmt) {
		this.allowedTotalAmt = allowedTotalAmt;
	}

	public String getExpensePaymentDetailsId() {
		return expensePaymentDetailsId;
	}

	public void setExpensePaymentDetailsId(String expensePaymentDetailsId) {
		this.expensePaymentDetailsId = expensePaymentDetailsId;
	}

	public String getLossPaymentDetailsId() {
		return lossPaymentDetailsId;
	}

	public void setLossPaymentDetailsId(String lossPaymentDetailsId) {
		this.lossPaymentDetailsId = lossPaymentDetailsId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getBagicRaiseGstAmount() {
		return bagicRaiseGstAmount;
	}

	public void setBagicRaiseGstAmount(String bagicRaiseGstAmount) {
		this.bagicRaiseGstAmount = bagicRaiseGstAmount;
	}

	public String getGstIn() {
		return gstIn;
	}

	public void setGstIn(String gstIn) {
		this.gstIn = gstIn;
	}

	public String getRaiseOnBagic() {
		return raiseOnBagic;
	}

	public void setRaiseOnBagic(String raiseOnBagic) {
		this.raiseOnBagic = raiseOnBagic;
	}

	public String getGstAmt() {
		return gstAmt;
	}

	public void setGstAmt(String gstAmt) {
		this.gstAmt = gstAmt;
	}

	public String getBaseAmountOfGst() {
		return baseAmountOfGst;
	}

	public void setBaseAmountOfGst(String baseAmountOfGst) {
		this.baseAmountOfGst = baseAmountOfGst;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}
}
