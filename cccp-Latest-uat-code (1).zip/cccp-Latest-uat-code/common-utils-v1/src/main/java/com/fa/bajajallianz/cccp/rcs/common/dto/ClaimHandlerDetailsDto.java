package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arul
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimHandlerDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String claimHandlerUserId;
	private String claimHandlerName;
	private String assignedDate;
	private Boolean isActive;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private Boolean active;

	public String getClaimHandlerUserId() {
		return claimHandlerUserId;
	}

	public void setClaimHandlerUserId(String claimHandlerUserId) {
		this.claimHandlerUserId = claimHandlerUserId;
	}

	public String getClaimHandlerName() {
		return claimHandlerName;
	}

	public void setClaimHandlerName(String claimHandlerName) {
		this.claimHandlerName = claimHandlerName;
	}

	public String getAssignedDate() {
		return assignedDate;
	}

	public void setAssignedDate(String assignedDate) {
		this.assignedDate = assignedDate;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

}
