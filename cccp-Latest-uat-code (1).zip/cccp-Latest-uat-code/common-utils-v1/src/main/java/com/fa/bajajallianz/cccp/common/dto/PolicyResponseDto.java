package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyResponseDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<PolicyDetailsDto> policyDetails;
	private List<PolicyDetailsDto> policyDetailsList;
	private List<ApplicationErrorDto> applicationError;
	private String total;

	public List<PolicyDetailsDto> getPolicyDetails() {
		return policyDetails;
	}

	public void setPolicyDetails(List<PolicyDetailsDto> policyDetails) {
		this.policyDetails = policyDetails;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public List<PolicyDetailsDto> getPolicyDetailsList() {
		return policyDetailsList;
	}

	public void setPolicyDetailsList(List<PolicyDetailsDto> policyDetailsList) {
		this.policyDetailsList = policyDetailsList;
	}

	public List<ApplicationErrorDto> getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(List<ApplicationErrorDto> applicationError) {
		this.applicationError = applicationError;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}
	

}
