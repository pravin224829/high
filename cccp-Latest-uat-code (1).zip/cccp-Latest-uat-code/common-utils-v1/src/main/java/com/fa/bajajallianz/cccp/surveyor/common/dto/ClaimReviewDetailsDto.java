/**
 * 
 */
package com.fa.bajajallianz.cccp.surveyor.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimReviewDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String referenceNo;
	private String chVerification;
	private String causeOfLoss;
	private String claimWorkFlow;
	private String mainStatus;
	private String subStatus;
	private String deficiencyReason;
	private String chReviewComment;
	private String claimHandler;
	private String chUserId;
	private String nextReviewDate;
	private Boolean isActive;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private String chName;
	private String modifiedRemarks;
	private String existingRemarks;
	private String claimNumber;
	private String userId;
	private String roleCode;

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getChVerification() {
		return chVerification;
	}

	public void setChVerification(String chVerification) {
		this.chVerification = chVerification;
	}

	public String getCauseOfLoss() {
		return causeOfLoss;
	}

	public void setCauseOfLoss(String causeOfLoss) {
		this.causeOfLoss = causeOfLoss;
	}

	public String getMainStatus() {
		return mainStatus;
	}

	public void setMainStatus(String mainStatus) {
		this.mainStatus = mainStatus;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getChReviewComment() {
		return chReviewComment;
	}

	public void setChReviewComment(String chReviewComment) {
		this.chReviewComment = chReviewComment;
	}

	public String getClaimHandler() {
		return claimHandler;
	}

	public void setClaimHandler(String claimHandler) {
		this.claimHandler = claimHandler;
	}

	public String getChUserId() {
		return chUserId;
	}

	public void setChUserId(String chUserId) {
		this.chUserId = chUserId;
	}

	public String getNextReviewDate() {
		return nextReviewDate;
	}

	public void setNextReviewDate(String nextReviewDate) {
		this.nextReviewDate = nextReviewDate;
	}

	public String getChName() {
		return chName;
	}

	public void setChName(String chName) {
		this.chName = chName;
	}

	public String getModifiedRemarks() {
		return modifiedRemarks;
	}

	public void setModifiedRemarks(String modifiedRemarks) {
		this.modifiedRemarks = modifiedRemarks;
	}

	public String getExistingRemarks() {
		return existingRemarks;
	}

	public void setExistingRemarks(String existingRemarks) {
		this.existingRemarks = existingRemarks;
	}

	public String getClaimWorkFlow() {
		return claimWorkFlow;
	}

	public void setClaimWorkFlow(String claimWorkFlow) {
		this.claimWorkFlow = claimWorkFlow;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

}
