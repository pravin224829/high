package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimCycleDetailsDto implements Serializable {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String claimNumber ;
	private String milestonesCode;
	private String milestonesName ;
	private String status;
	private String order ;
	private Boolean isVisible ;
	private Boolean isActive ;
	private String createdDate ;
	private ClaimCycleDetailsDto claimCycleDetails;
	
	public ClaimCycleDetailsDto getClaimCycleDetails() {
		return claimCycleDetails;
	}
	public void setClaimCycleDetails(ClaimCycleDetailsDto claimCycleDetails) {
		this.claimCycleDetails = claimCycleDetails;
	}
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public String getMilestonesCode() {
		return milestonesCode;
	}
	public void setMilestonesCode(String milestonesCode) {
		this.milestonesCode = milestonesCode;
	}
	public String getMilestonesName() {
		return milestonesName;
	}
	public void setMilestonesName(String milestonesName) {
		this.milestonesName = milestonesName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public Boolean getIsVisible() {
		return isVisible;
	}
	public void setIsVisible(Boolean isVisible) {
		this.isVisible = isVisible;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	
}
