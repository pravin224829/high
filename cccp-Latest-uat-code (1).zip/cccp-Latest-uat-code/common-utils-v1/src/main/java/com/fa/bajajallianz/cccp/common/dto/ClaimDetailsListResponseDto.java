package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimDetailsListResponseDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<ClaimDetailsListDto> claimDetailsListResponseDto;
	private List<ClaimDetailsListDto> unallocatedClaimsList;
	private ApplicationErrorDto applicationError;
	private String total;
	private String totalCount;
	
	public List<ClaimDetailsListDto> getClaimDetailsListResponseDto() {
		return claimDetailsListResponseDto;
	}
	public void setClaimDetailsListResponseDto(List<ClaimDetailsListDto> claimDetailsListResponseDto) {
		this.claimDetailsListResponseDto = claimDetailsListResponseDto;
	}
	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}
	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public List<ClaimDetailsListDto> getUnallocatedClaimsList() {
		return unallocatedClaimsList;
	}
	public void setUnallocatedClaimsList(List<ClaimDetailsListDto> unallocatedClaimsList) {
		this.unallocatedClaimsList = unallocatedClaimsList;
	}
	public String getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}

}
