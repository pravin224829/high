/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Arul
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimDataDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String referenceNo;
	private String vas;
	private String externalServiceType;
	private String serviceProvideName;
	private String claimFileRemarks;
	private String claimFileType;
	private String sections;
	private String loanAc;
	private String invoiceValue;
	private String scName;
	private String scGstNo;
	private String scPin;
	private String scJobCardNo;
	private String scInvoiceNo;
	private String equipmentMake;
	private String equipmentModel;
	private String marketValue;
	private String equipmentId;
	private String repairEstimate;
	private String purchaseInvoiceNo;
	private String assessedLossAmount;
	private String invoiceDate;
	private String noOfItems;
	private String typeOfLoss;
	private String depreciationDeduction;
	private String policyExcessDeduction;
	private String salvageDeduction;
	private String settlementDeduction;
	private String reinstatementPremium;
	private String netPayableAmount;
	private String mechDescription;
	private String mechSerialNo;
	private String mechCapacityUnit;
	private String mechCapacity;
	private String policyNumber;
	private String claimNumber;
	private String claimAmount;
	private String branchName;
	private String branchCode;
	private String causeOffLoss;
	private String otherItemDescription;
	private Boolean isActive;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private String coInsuranceType;
	private String companyName;
	private String sharingPercentage;
	private String selectionDescription;
	private String sectionid;
	private String sumInsured;
	private String financerName;
	private String damageInvoiceValue;
	private String damageAssessedLossAmount;
	private String branchAddress;
	private String transporterName;
	private String journeyFrom;
	private String blrrlrrawb;
	private String invoiceNumber;
	private String transportAddress;
	private String journeyTo;
	private String lorryReceiptDate;
	private String damageInvoiceDate;
	private String consigneeName;
	private String consignerName;
	private String surveyLocation;
	private String consigneeAddress;
	private String modeOfTransport;
	private String transactionType;
	private String goodsDetails;
	private String typeOfLoad;
	private String typeOfVehicle;
	private String typeOfPackaging;
	private String typeOfClaim;
	private String cargoDescription;
	private String nonStdAmt;
	private String nonStandardPercentage;
	private String netLossAmount;
	private String reasonForNonStandard;
	private String claimSettlementType;
	private String netAmountPayment;
	private String placeOfLoss;
	private String estimatedLossAmount;
	private String fraudAndmisrepresentation;
	private String area;
	private String city;
	private String pincode;
	private String lossPeril;
	private String panNumber;
	private String gstnNumber;
	private String specialRemark;
	private String consigneePhoneNo;
	private List<SectionDtlsResponseDto> sectionDetails;
	private List<CoInsuranceListDto> coInsuranceList;
	private List<HomeLossDetailsDto> lossDetails;
	private List<DamageEquipmentDetailsDto> damageEquipmentDetails;
	private String litigationFlag;
	private String fraudDetails;
	private String yearOfManufacturing;
	private String deductibleBasedOn;
	private String deductiblePercentNonAOG;
	private String deductiblePercentAOG;
	private String timeExcessDays;
	private String interruptionPeriod;
	private String isDamageOccurred;
	private String locationOfLossOceanVoyage;
	private String portOfLossOceanVoyage;
	private String underinsurancePercentage;
	private String lossPaidTowardsCostOfMaterial;
	private String lossPaidTowardsLabour;
	private String lossPaidOthers;
	private String lossPaidBuilding;
	private String lossPaidPandM;
	private String lossPaidStocks;
	private String events;


	public String getEvents() {
		return events;
	}

	public void setEvents(String events) {
		this.events = events;
	}

	public String getLossLocAsPerPolicy() {
		return lossLocAsPerPolicy;
	}

	public void setLossLocAsPerPolicy(String lossLocAsPerPolicy) {
		this.lossLocAsPerPolicy = lossLocAsPerPolicy;
	}

	private String lossLocAsPerPolicy;

	public String getLossPaidBuilding() {
		return lossPaidBuilding;
	}

	public void setLossPaidBuilding(String lossPaidBuilding) {
		this.lossPaidBuilding = lossPaidBuilding;
	}

	public String getLossPaidPandM() {
		return lossPaidPandM;
	}

	public void setLossPaidPandM(String lossPaidPandM) {
		this.lossPaidPandM = lossPaidPandM;
	}

	public String getLossPaidStocks() {
		return lossPaidStocks;
	}

	public void setLossPaidStocks(String lossPaidStocks) {
		this.lossPaidStocks = lossPaidStocks;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getVas() {
		return vas;
	}

	public void setVas(String vas) {
		this.vas = vas;
	}

	public String getExternalServiceType() {
		return externalServiceType;
	}

	public void setExternalServiceType(String externalServiceType) {
		this.externalServiceType = externalServiceType;
	}

	public String getServiceProvideName() {
		return serviceProvideName;
	}

	public void setServiceProvideName(String serviceProvideName) {
		this.serviceProvideName = serviceProvideName;
	}

	public String getClaimFileRemarks() {
		return claimFileRemarks;
	}

	public void setClaimFileRemarks(String claimFileRemarks) {
		this.claimFileRemarks = claimFileRemarks;
	}

	public String getClaimFileType() {
		return claimFileType;
	}

	public void setClaimFileType(String claimFileType) {
		this.claimFileType = claimFileType;
	}

	public String getSections() {
		return sections;
	}

	public void setSections(String sections) {
		this.sections = sections;
	}

	public String getLoanAc() {
		return loanAc;
	}

	public void setLoanAc(String loanAc) {
		this.loanAc = loanAc;
	}

	public String getInvoiceValue() {
		return invoiceValue;
	}

	public void setInvoiceValue(String invoiceValue) {
		this.invoiceValue = invoiceValue;
	}

	public String getScName() {
		return scName;
	}

	public void setScName(String scName) {
		this.scName = scName;
	}

	public String getScGstNo() {
		return scGstNo;
	}

	public void setScGstNo(String scGstNo) {
		this.scGstNo = scGstNo;
	}

	public String getScPin() {
		return scPin;
	}

	public void setScPin(String scPin) {
		this.scPin = scPin;
	}

	public String getScJobCardNo() {
		return scJobCardNo;
	}

	public void setScJobCardNo(String scJobCardNo) {
		this.scJobCardNo = scJobCardNo;
	}

	public String getScInvoiceNo() {
		return scInvoiceNo;
	}

	public void setScInvoiceNo(String scInvoiceNo) {
		this.scInvoiceNo = scInvoiceNo;
	}

	public String getEquipmentMake() {
		return equipmentMake;
	}

	public void setEquipmentMake(String equipmentMake) {
		this.equipmentMake = equipmentMake;
	}

	public String getEquipmentModel() {
		return equipmentModel;
	}

	public void setEquipmentModel(String equipmentModel) {
		this.equipmentModel = equipmentModel;
	}

	public String getMarketValue() {
		return marketValue;
	}

	public void setMarketValue(String marketValue) {
		this.marketValue = marketValue;
	}

	public String getEquipmentId() {
		return equipmentId;
	}

	public void setEquipmentId(String equipmentId) {
		this.equipmentId = equipmentId;
	}

	public String getRepairEstimate() {
		return repairEstimate;
	}

	public void setRepairEstimate(String repairEstimate) {
		this.repairEstimate = repairEstimate;
	}

	public String getPurchaseInvoiceNo() {
		return purchaseInvoiceNo;
	}

	public void setPurchaseInvoiceNo(String purchaseInvoiceNo) {
		this.purchaseInvoiceNo = purchaseInvoiceNo;
	}

	public String getAssessedLossAmount() {
		return assessedLossAmount;
	}

	public void setAssessedLossAmount(String assessedLossAmount) {
		this.assessedLossAmount = assessedLossAmount;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getNoOfItems() {
		return noOfItems;
	}

	public void setNoOfItems(String noOfItems) {
		this.noOfItems = noOfItems;
	}

	public String getTypeOfLoss() {
		return typeOfLoss;
	}

	public void setTypeOfLoss(String typeOfLoss) {
		this.typeOfLoss = typeOfLoss;
	}

	public String getDepreciationDeduction() {
		return depreciationDeduction;
	}

	public void setDepreciationDeduction(String depreciationDeduction) {
		this.depreciationDeduction = depreciationDeduction;
	}

	public String getPolicyExcessDeduction() {
		return policyExcessDeduction;
	}

	public void setPolicyExcessDeduction(String policyExcessDeduction) {
		this.policyExcessDeduction = policyExcessDeduction;
	}

	public String getSalvageDeduction() {
		return salvageDeduction;
	}

	public void setSalvageDeduction(String salvageDeduction) {
		this.salvageDeduction = salvageDeduction;
	}

	public String getSettlementDeduction() {
		return settlementDeduction;
	}

	public void setSettlementDeduction(String settlementDeduction) {
		this.settlementDeduction = settlementDeduction;
	}

	public String getReinstatementPremium() {
		return reinstatementPremium;
	}

	public void setReinstatementPremium(String reinstatementPremium) {
		this.reinstatementPremium = reinstatementPremium;
	}

	public String getNetPayableAmount() {
		return netPayableAmount;
	}

	public void setNetPayableAmount(String netPayableAmount) {
		this.netPayableAmount = netPayableAmount;
	}

	public String getMechDescription() {
		return mechDescription;
	}

	public void setMechDescription(String mechDescription) {
		this.mechDescription = mechDescription;
	}

	public String getMechSerialNo() {
		return mechSerialNo;
	}

	public void setMechSerialNo(String mechSerialNo) {
		this.mechSerialNo = mechSerialNo;
	}

	public String getMechCapacityUnit() {
		return mechCapacityUnit;
	}

	public void setMechCapacityUnit(String mechCapacityUnit) {
		this.mechCapacityUnit = mechCapacityUnit;
	}

	public String getMechCapacity() {
		return mechCapacity;
	}

	public void setMechCapacity(String mechCapacity) {
		this.mechCapacity = mechCapacity;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getClaimAmount() {
		return claimAmount;
	}

	public void setClaimAmount(String claimAmount) {
		this.claimAmount = claimAmount;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getCauseOffLoss() {
		return causeOffLoss;
	}

	public void setCauseOffLoss(String causeOffLoss) {
		this.causeOffLoss = causeOffLoss;
	}

	public String getOtherItemDescription() {
		return otherItemDescription;
	}

	public void setOtherItemDescription(String otherItemDescription) {
		this.otherItemDescription = otherItemDescription;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCoInsuranceType() {
		return coInsuranceType;
	}

	public void setCoInsuranceType(String coInsuranceType) {
		this.coInsuranceType = coInsuranceType;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getSharingPercentage() {
		return sharingPercentage;
	}

	public void setSharingPercentage(String sharingPercentage) {
		this.sharingPercentage = sharingPercentage;
	}

	public String getSelectionDescription() {
		return selectionDescription;
	}

	public void setSelectionDescription(String selectionDescription) {
		this.selectionDescription = selectionDescription;
	}

	public String getSectionid() {
		return sectionid;
	}

	public void setSectionid(String sectionid) {
		this.sectionid = sectionid;
	}

	public String getSumInsured() {
		return sumInsured;
	}

	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}

	public String getFinancerName() {
		return financerName;
	}

	public void setFinancerName(String financerName) {
		this.financerName = financerName;
	}

	public String getDamageInvoiceValue() {
		return damageInvoiceValue;
	}

	public void setDamageInvoiceValue(String damageInvoiceValue) {
		this.damageInvoiceValue = damageInvoiceValue;
	}

	public String getDamageAssessedLossAmount() {
		return damageAssessedLossAmount;
	}

	public void setDamageAssessedLossAmount(String damageAssessedLossAmount) {
		this.damageAssessedLossAmount = damageAssessedLossAmount;
	}

	public String getBranchAddress() {
		return branchAddress;
	}

	public void setBranchAddress(String branchAddress) {
		this.branchAddress = branchAddress;
	}

	public String getTransporterName() {
		return transporterName;
	}

	public void setTransporterName(String transporterName) {
		this.transporterName = transporterName;
	}

	public String getJourneyFrom() {
		return journeyFrom;
	}

	public void setJourneyFrom(String journeyFrom) {
		this.journeyFrom = journeyFrom;
	}

	public String getBlrrlrrawb() {
		return blrrlrrawb;
	}

	public void setBlrrlrrawb(String blrrlrrawb) {
		this.blrrlrrawb = blrrlrrawb;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getTransportAddress() {
		return transportAddress;
	}

	public void setTransportAddress(String transportAddress) {
		this.transportAddress = transportAddress;
	}

	public String getJourneyTo() {
		return journeyTo;
	}

	public void setJourneyTo(String journeyTo) {
		this.journeyTo = journeyTo;
	}

	public String getLorryReceiptDate() {
		return lorryReceiptDate;
	}

	public void setLorryReceiptDate(String lorryReceiptDate) {
		this.lorryReceiptDate = lorryReceiptDate;
	}

	public String getDamageInvoiceDate() {
		return damageInvoiceDate;
	}

	public void setDamageInvoiceDate(String damageInvoiceDate) {
		this.damageInvoiceDate = damageInvoiceDate;
	}

	public String getConsigneeName() {
		return consigneeName;
	}

	public void setConsigneeName(String consigneeName) {
		this.consigneeName = consigneeName;
	}

	public String getConsignerName() {
		return consignerName;
	}

	public void setConsignerName(String consignerName) {
		this.consignerName = consignerName;
	}

	public String getSurveyLocation() {
		return surveyLocation;
	}

	public void setSurveyLocation(String surveyLocation) {
		this.surveyLocation = surveyLocation;
	}

	public String getConsigneeAddress() {
		return consigneeAddress;
	}

	public void setConsigneeAddress(String consigneeAddress) {
		this.consigneeAddress = consigneeAddress;
	}

	public String getModeOfTransport() {
		return modeOfTransport;
	}

	public void setModeOfTransport(String modeOfTransport) {
		this.modeOfTransport = modeOfTransport;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getGoodsDetails() {
		return goodsDetails;
	}

	public void setGoodsDetails(String goodsDetails) {
		this.goodsDetails = goodsDetails;
	}

	public String getTypeOfLoad() {
		return typeOfLoad;
	}

	public void setTypeOfLoad(String typeOfLoad) {
		this.typeOfLoad = typeOfLoad;
	}

	public String getTypeOfVehicle() {
		return typeOfVehicle;
	}

	public void setTypeOfVehicle(String typeOfVehicle) {
		this.typeOfVehicle = typeOfVehicle;
	}

	public String getTypeOfPackaging() {
		return typeOfPackaging;
	}

	public void setTypeOfPackaging(String typeOfPackaging) {
		this.typeOfPackaging = typeOfPackaging;
	}

	public String getTypeOfClaim() {
		return typeOfClaim;
	}

	public void setTypeOfClaim(String typeOfClaim) {
		this.typeOfClaim = typeOfClaim;
	}

	public String getCargoDescription() {
		return cargoDescription;
	}

	public void setCargoDescription(String cargoDescription) {
		this.cargoDescription = cargoDescription;
	}

	public String getNonStdAmt() {
		return nonStdAmt;
	}

	public void setNonStdAmt(String nonStdAmt) {
		this.nonStdAmt = nonStdAmt;
	}

	public String getNonStandardPercentage() {
		return nonStandardPercentage;
	}

	public void setNonStandardPercentage(String nonStandardPercentage) {
		this.nonStandardPercentage = nonStandardPercentage;
	}

	public String getNetLossAmount() {
		return netLossAmount;
	}

	public void setNetLossAmount(String netLossAmount) {
		this.netLossAmount = netLossAmount;
	}

	public String getReasonForNonStandard() {
		return reasonForNonStandard;
	}

	public void setReasonForNonStandard(String reasonForNonStandard) {
		this.reasonForNonStandard = reasonForNonStandard;
	}

	public String getClaimSettlementType() {
		return claimSettlementType;
	}

	public void setClaimSettlementType(String claimSettlementType) {
		this.claimSettlementType = claimSettlementType;
	}

	public String getNetAmountPayment() {
		return netAmountPayment;
	}

	public void setNetAmountPayment(String netAmountPayment) {
		this.netAmountPayment = netAmountPayment;
	}

	public List<SectionDtlsResponseDto> getSectionDetails() {
		return sectionDetails;
	}

	public void setSectionDetails(List<SectionDtlsResponseDto> sectionDetails) {
		this.sectionDetails = sectionDetails;
	}

	public List<CoInsuranceListDto> getCoInsuranceList() {
		return coInsuranceList;
	}

	public void setCoInsuranceList(List<CoInsuranceListDto> coInsuranceList) {
		this.coInsuranceList = coInsuranceList;
	}

	public List<HomeLossDetailsDto> getLossDetails() {
		return lossDetails;
	}

	public void setLossDetails(List<HomeLossDetailsDto> lossDetails) {
		this.lossDetails = lossDetails;
	}

	public List<DamageEquipmentDetailsDto> getDamageEquipmentDetails() {
		return damageEquipmentDetails;
	}

	public void setDamageEquipmentDetails(List<DamageEquipmentDetailsDto> damageEquipmentDetails) {
		this.damageEquipmentDetails = damageEquipmentDetails;
	}

	public String getPlaceOfLoss() {
		return placeOfLoss;
	}

	public void setPlaceOfLoss(String placeOfLoss) {
		this.placeOfLoss = placeOfLoss;
	}

	public String getEstimatedLossAmount() {
		return estimatedLossAmount;
	}

	public void setEstimatedLossAmount(String estimatedLossAmount) {
		this.estimatedLossAmount = estimatedLossAmount;
	}

	public String getFraudAndmisrepresentation() {
		return fraudAndmisrepresentation;
	}

	public void setFraudAndmisrepresentation(String fraudAndmisrepresentation) {
		this.fraudAndmisrepresentation = fraudAndmisrepresentation;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getLossPeril() {
		return lossPeril;
	}

	public void setLossPeril(String lossPeril) {
		this.lossPeril = lossPeril;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getGstnNumber() {
		return gstnNumber;
	}

	public void setGstnNumber(String gstnNumber) {
		this.gstnNumber = gstnNumber;
	}

	public String getSpecialRemark() {
		return specialRemark;
	}

	public void setSpecialRemark(String specialRemark) {
		this.specialRemark = specialRemark;
	}

	public String getConsigneePhoneNo() {
		return consigneePhoneNo;
	}

	public void setConsigneePhoneNo(String consigneePhoneNo) {
		this.consigneePhoneNo = consigneePhoneNo;
	}

	public String getLitigationFlag() {
		return litigationFlag;
	}

	public void setLitigationFlag(String litigationFlag) {
		this.litigationFlag = litigationFlag;
	}

	public String getFraudDetails() {
		return fraudDetails;
	}

	public void setFraudDetails(String fraudDetails) {
		this.fraudDetails = fraudDetails;
	}

	public String getYearOfManufacturing() {
		return yearOfManufacturing;
	}

	public void setYearOfManufacturing(String yearOfManufacturing) {
		this.yearOfManufacturing = yearOfManufacturing;
	}

	public String getDeductibleBasedOn() {
		return deductibleBasedOn;
	}

	public void setDeductibleBasedOn(String deductibleBasedOn) {
		this.deductibleBasedOn = deductibleBasedOn;
	}

	public String getDeductiblePercentNonAOG() {
		return deductiblePercentNonAOG;
	}

	public void setDeductiblePercentNonAOG(String deductiblePercentNonAOG) {
		this.deductiblePercentNonAOG = deductiblePercentNonAOG;
	}

	public String getDeductiblePercentAOG() {
		return deductiblePercentAOG;
	}

	public void setDeductiblePercentAOG(String deductiblePercentAOG) {
		this.deductiblePercentAOG = deductiblePercentAOG;
	}

	public String getTimeExcessDays() {
		return timeExcessDays;
	}

	public void setTimeExcessDays(String timeExcessDays) {
		this.timeExcessDays = timeExcessDays;
	}

	public String getInterruptionPeriod() {
		return interruptionPeriod;
	}

	public void setInterruptionPeriod(String interruptionPeriod) {
		this.interruptionPeriod = interruptionPeriod;
	}

	public String getIsDamageOccurred() {
		return isDamageOccurred;
	}

	public void setIsDamageOccurred(String isDamageOccurred) {
		this.isDamageOccurred = isDamageOccurred;
	}

	public String getLocationOfLossOceanVoyage() {
		return locationOfLossOceanVoyage;
	}

	public void setLocationOfLossOceanVoyage(String locationOfLossOceanVoyage) {
		this.locationOfLossOceanVoyage = locationOfLossOceanVoyage;
	}

	public String getPortOfLossOceanVoyage() {
		return portOfLossOceanVoyage;
	}

	public void setPortOfLossOceanVoyage(String portOfLossOceanVoyage) {
		this.portOfLossOceanVoyage = portOfLossOceanVoyage;
	}

	public String getUnderinsurancePercentage() {
		return underinsurancePercentage;
	}

	public void setUnderinsurancePercentage(String underinsurancePercentage) {
		this.underinsurancePercentage = underinsurancePercentage;
	}

	public String getLossPaidTowardsCostOfMaterial() {
		return lossPaidTowardsCostOfMaterial;
	}

	public void setLossPaidTowardsCostOfMaterial(String lossPaidTowardsCostOfMaterial) {
		this.lossPaidTowardsCostOfMaterial = lossPaidTowardsCostOfMaterial;
	}

	public String getLossPaidTowardsLabour() {
		return lossPaidTowardsLabour;
	}

	public void setLossPaidTowardsLabour(String lossPaidTowardsLabour) {
		this.lossPaidTowardsLabour = lossPaidTowardsLabour;
	}

	public String getLossPaidOthers() {
		return lossPaidOthers;
	}

	public void setLossPaidOthers(String lossPaidOthers) {
		this.lossPaidOthers = lossPaidOthers;
	}
	

}
