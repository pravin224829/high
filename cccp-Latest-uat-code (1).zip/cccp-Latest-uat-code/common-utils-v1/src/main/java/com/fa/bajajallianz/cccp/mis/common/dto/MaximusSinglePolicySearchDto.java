package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.MaximusEndorsementListDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusSinglePolicySearchDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private ApplicationErrorDto applicationError;
	private MaximusBasicPolicyDetailsDto basicPolicyDetails;
	private MaximusAdditionalPolicyDetailsDto additionalPolicyDetails;
//	private References references;
//	private Destinations destinations;
//	private ExcludedEvents excludedEvents;
//	private ExcludedCountries excludedCountries;
	private MaximusInsuredsListDto insureds;
	private MaximusBasicDetailsDto basicDetails;
	private MaximusDocumentsListDto documents;
	private MaximusPremiumBreakupDto premiumBreakup;
	private MaximusAddressesListDto addresses;
	private MaximusPolicyPaymentInformationDto policyPaymentInformations;
	private MaximusEndorsementListDto endorsement;

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public MaximusBasicPolicyDetailsDto getBasicPolicyDetails() {
		return basicPolicyDetails;
	}

	public void setBasicPolicyDetails(MaximusBasicPolicyDetailsDto basicPolicyDetails) {
		this.basicPolicyDetails = basicPolicyDetails;
	}

	public MaximusAdditionalPolicyDetailsDto getAdditionalPolicyDetails() {
		return additionalPolicyDetails;
	}

	public void setAdditionalPolicyDetails(MaximusAdditionalPolicyDetailsDto additionalPolicyDetails) {
		this.additionalPolicyDetails = additionalPolicyDetails;
	}

	public MaximusInsuredsListDto getInsureds() {
		return insureds;
	}

	public void setInsureds(MaximusInsuredsListDto insureds) {
		this.insureds = insureds;
	}

	public MaximusBasicDetailsDto getBasicDetails() {
		return basicDetails;
	}

	public void setBasicDetails(MaximusBasicDetailsDto basicDetails) {
		this.basicDetails = basicDetails;
	}

	public MaximusDocumentsListDto getDocuments() {
		return documents;
	}

	public void setDocuments(MaximusDocumentsListDto documents) {
		this.documents = documents;
	}

	public MaximusPremiumBreakupDto getPremiumBreakup() {
		return premiumBreakup;
	}

	public void setPremiumBreakup(MaximusPremiumBreakupDto premiumBreakup) {
		this.premiumBreakup = premiumBreakup;
	}

	public MaximusAddressesListDto getAddresses() {
		return addresses;
	}

	public void setAddresses(MaximusAddressesListDto addresses) {
		this.addresses = addresses;
	}

	public MaximusPolicyPaymentInformationDto getPolicyPaymentInformations() {
		return policyPaymentInformations;
	}

	public void setPolicyPaymentInformations(MaximusPolicyPaymentInformationDto policyPaymentInformations) {
		this.policyPaymentInformations = policyPaymentInformations;
	}

	public MaximusEndorsementListDto getEndorsement() {
		return endorsement;
	}

	public void setEndorsement(MaximusEndorsementListDto endorsement) {
		this.endorsement = endorsement;
	}
	

}
