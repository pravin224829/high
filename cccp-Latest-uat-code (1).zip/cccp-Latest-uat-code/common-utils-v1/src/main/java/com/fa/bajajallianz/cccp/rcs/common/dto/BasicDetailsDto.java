package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.Date;

public class BasicDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Boolean isSalvageStatus;
	private String declarationStatus;
	private String claimNumber;
	private String declarationDate;
	private String declaredBy;
	private String diaRefNumber;
	private String diaRefCreatedDate;
	private String diaStatus;
	private String estimatedDamageValue;
	private String estimatedLossAmount;
	private String lossReserveAmt;
	private String diDetailDescription;
	private String declarationRemarks;
	private DiaRequestDetailsDto DiaRequestDetails;
	private String diaApprovalAuthority;
	private String docId;

	public Boolean getIsSalvageStatus() {
		return isSalvageStatus;
	}
	public void setIsSalvageStatus(Boolean isSalvageStatus) {
		this.isSalvageStatus = isSalvageStatus;
	}
	public String getDeclarationStatus() {
		return declarationStatus;
	}
	public void setDeclarationStatus(String declarationStatus) {
		this.declarationStatus = declarationStatus;
	}
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public String getDeclarationDate() {
		return declarationDate;
	}
	public void setDeclarationDate(String declarationDate) {
		this.declarationDate = declarationDate;
	}
	public String getDeclaredBy() {
		return declaredBy;
	}
	public void setDeclaredBy(String declaredBy) {
		this.declaredBy = declaredBy;
	}
	public String getDiaRefNumber() {
		return diaRefNumber;
	}
	public void setDiaRefNumber(String diaRefNumber) {
		this.diaRefNumber = diaRefNumber;
	}
	public String getDiaRefCreatedDate() {
		return diaRefCreatedDate;
	}
	public void setDiaRefCreatedDate(String diaRefCreatedDate) {
		this.diaRefCreatedDate = diaRefCreatedDate;
	}
	public String getDiaStatus() {
		return diaStatus;
	}
	public void setDiaStatus(String diaStatus) {
		this.diaStatus = diaStatus;
	}
	public String getEstimatedDamageValue() {
		return estimatedDamageValue;
	}
	public void setEstimatedDamageValue(String estimatedDamageValue) {
		this.estimatedDamageValue = estimatedDamageValue;
	}
	public String getEstimatedLossAmount() {
		return estimatedLossAmount;
	}
	public void setEstimatedLossAmount(String estimatedLossAmount) {
		this.estimatedLossAmount = estimatedLossAmount;
	}
	public String getLossReserveAmt() {
		return lossReserveAmt;
	}
	public void setLossReserveAmt(String lossReserveAmt) {
		this.lossReserveAmt = lossReserveAmt;
	}
	public String getDiDetailDescription() {
		return diDetailDescription;
	}
	public void setDiDetailDescription(String diDetailDescription) {
		this.diDetailDescription = diDetailDescription;
	}
	public String getDeclarationRemarks() {
		return declarationRemarks;
	}
	public void setDeclarationRemarks(String declarationRemarks) {
		this.declarationRemarks = declarationRemarks;
	}
	public DiaRequestDetailsDto getDiaRequestDetails() {
		return DiaRequestDetails;
	}
	public void setDiaRequestDetails(DiaRequestDetailsDto diaRequestDetails) {
		DiaRequestDetails = diaRequestDetails;
	}
	public String getDiaApprovalAuthority() {
		return diaApprovalAuthority;
	}
	public void setDiaApprovalAuthority(String diaApprovalAuthority) {
		this.diaApprovalAuthority = diaApprovalAuthority;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}

}
