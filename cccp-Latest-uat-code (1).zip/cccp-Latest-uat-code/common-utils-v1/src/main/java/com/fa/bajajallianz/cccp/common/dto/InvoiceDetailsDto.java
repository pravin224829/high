package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class InvoiceDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String partyId;
	private String lossAssessedAmount;
	private String billNumber;
	private String transType;
	private String billDate;
	private String grossBillAmount;
	private String remarks;
	private String sgstAmount;
	private String cgstAmount;
	private String ugstAmount;
	private String igstAmount;
	private String invoiceNumber;
	private String claimNumber;
	private String surveyNumber;
	private String aprroverRemarks;
	private String sgstPercentage;
	private String cgstPercentage;
	private String ugstPercentage;
	private String igstPercentage;
	private Boolean isPaymentPost;
	private Boolean isActive;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private String status;
	private String totalGstAmount;
	private String totalAmount;
	private String billAmount;
	private String gstAmount;
	private String surveyRefNo;
	private String invoiceStatus;
	private Boolean isGSTApplicable;
	private String totalBillAmount;
	private String taxApplicable;

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getLossAssessedAmount() {
		return lossAssessedAmount;
	}

	public void setLossAssessedAmount(String lossAssessedAmount) {
		this.lossAssessedAmount = lossAssessedAmount;
	}

	public String getBillNumber() {
		return billNumber;
	}

	public void setBillNumber(String billNumber) {
		this.billNumber = billNumber;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getBillDate() {
		return billDate;
	}

	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}

	public String getGrossBillAmount() {
		return grossBillAmount;
	}

	public void setGrossBillAmount(String grossBillAmount) {
		this.grossBillAmount = grossBillAmount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getSgstAmount() {
		return sgstAmount;
	}

	public void setSgstAmount(String sgstAmount) {
		this.sgstAmount = sgstAmount;
	}

	public String getCgstAmount() {
		return cgstAmount;
	}

	public void setCgstAmount(String cgstAmount) {
		this.cgstAmount = cgstAmount;
	}

	public String getUgstAmount() {
		return ugstAmount;
	}

	public void setUgstAmount(String ugstAmount) {
		this.ugstAmount = ugstAmount;
	}

	public String getIgstAmount() {
		return igstAmount;
	}

	public void setIgstAmount(String igstAmount) {
		this.igstAmount = igstAmount;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getSurveyNumber() {
		return surveyNumber;
	}

	public void setSurveyNumber(String surveyNumber) {
		this.surveyNumber = surveyNumber;
	}

	public String getAprroverRemarks() {
		return aprroverRemarks;
	}

	public void setAprroverRemarks(String aprroverRemarks) {
		this.aprroverRemarks = aprroverRemarks;
	}

	public Boolean getIsPaymentPost() {
		return isPaymentPost;
	}

	public void setIsPaymentPost(Boolean isPaymentPost) {
		this.isPaymentPost = isPaymentPost;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSgstPercentage() {
		return sgstPercentage;
	}

	public void setSgstPercentage(String sgstPercentage) {
		this.sgstPercentage = sgstPercentage;
	}

	public String getCgstPercentage() {
		return cgstPercentage;
	}

	public void setCgstPercentage(String cgstPercentage) {
		this.cgstPercentage = cgstPercentage;
	}

	public String getUgstPercentage() {
		return ugstPercentage;
	}

	public void setUgstPercentage(String ugstPercentage) {
		this.ugstPercentage = ugstPercentage;
	}

	public String getIgstPercentage() {
		return igstPercentage;
	}

	public void setIgstPercentage(String igstPercentage) {
		this.igstPercentage = igstPercentage;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getTotalGstAmount() {
		return totalGstAmount;
	}

	public void setTotalGstAmount(String totalGstAmount) {
		this.totalGstAmount = totalGstAmount;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(String billAmount) {
		this.billAmount = billAmount;
	}

	public String getGstAmount() {
		return gstAmount;
	}

	public void setGstAmount(String gstAmount) {
		this.gstAmount = gstAmount;
	}

	public String getSurveyRefNo() {
		return surveyRefNo;
	}

	public void setSurveyRefNo(String surveyRefNo) {
		this.surveyRefNo = surveyRefNo;
	}

	public String getInvoiceStatus() {
		return invoiceStatus;
	}

	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}

	public String getTotalBillAmount() {
		return totalBillAmount;
	}

	public void setTotalBillAmount(String totalBillAmount) {
		this.totalBillAmount = totalBillAmount;
	}

	public Boolean getIsGSTApplicable() {
		return isGSTApplicable;
	}

	public void setIsGSTApplicable(Boolean isGSTApplicable) {
		this.isGSTApplicable = isGSTApplicable;
	}

	public String getTaxApplicable() {
		return taxApplicable;
	}

	public void setTaxApplicable(String taxApplicable) {
		this.taxApplicable = taxApplicable;
	}

}
