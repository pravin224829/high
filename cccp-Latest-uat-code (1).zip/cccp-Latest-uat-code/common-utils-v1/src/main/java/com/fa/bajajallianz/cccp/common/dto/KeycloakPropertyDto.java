package com.fa.bajajallianz.cccp.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class KeycloakPropertyDto {

	private static final long serialVersionUID = 1L;
	private String serverUrl;
	private String realmId;
	private String clientId;
	private String clientSecret;
	private String sslRequired;
	private String confidentialPort;
	private String publicClient;
	private String roleMapping;
	
	public String getServerUrl() {
		return serverUrl;
	}
	public void setServerUrl(String serverUrl) {
		this.serverUrl = serverUrl;
	}
	public String getRealmId() {
		return realmId;
	}
	public void setRealmId(String realmId) {
		this.realmId = realmId;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getClientSecret() {
		return clientSecret;
	}
	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}
	public String getSslRequired() {
		return sslRequired;
	}
	public void setSslRequired(String sslRequired) {
		this.sslRequired = sslRequired;
	}
	public String getConfidentialPort() {
		return confidentialPort;
	}
	public void setConfidentialPort(String confidentialPort) {
		this.confidentialPort = confidentialPort;
	}
	public String getPublicClient() {
		return publicClient;
	}
	public void setPublicClient(String publicClient) {
		this.publicClient = publicClient;
	}
	public String getRoleMapping() {
		return roleMapping;
	}
	public void setRoleMapping(String roleMapping) {
		this.roleMapping = roleMapping;
	}
	
	
}
