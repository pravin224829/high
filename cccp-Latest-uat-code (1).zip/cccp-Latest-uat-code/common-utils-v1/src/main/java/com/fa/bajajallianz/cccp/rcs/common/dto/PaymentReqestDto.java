package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentReqestDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String userId;
	private String roleCode;
	private String claimNumber;
	private String partyId;
	private String partyCode;
	private String partnerId;
	private String documentName;
	private BenificiaryDetailsDto beneficiaryDetails;
	private IntermidiaryDetailsDto intermidiaryBankDetails;
	private RemittanceDetailsDto remittanceDetails;
	private PaymentApprovalDto approvalReq;
	private FdrPaymentDetailsDto fdrPaymentDetails;
	private DdPaymentDetailsDto ddPaymentDetails;
	private List<GstDetailsDto> gstpayable;
	private String delayReason;
	private String firstDocRecievedDate;
	private String lastDocRecievedDate;
	private String processType;
	private String finalSurveyDate;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public BenificiaryDetailsDto getBeneficiaryDetails() {
		return beneficiaryDetails;
	}

	public void setBeneficiaryDetails(BenificiaryDetailsDto beneficiaryDetails) {
		this.beneficiaryDetails = beneficiaryDetails;
	}

	public IntermidiaryDetailsDto getIntermidiaryBankDetails() {
		return intermidiaryBankDetails;
	}

	public void setIntermidiaryBankDetails(IntermidiaryDetailsDto intermidiaryBankDetails) {
		this.intermidiaryBankDetails = intermidiaryBankDetails;
	}

	public RemittanceDetailsDto getRemittanceDetails() {
		return remittanceDetails;
	}

	public void setRemittanceDetails(RemittanceDetailsDto remittanceDetails) {
		this.remittanceDetails = remittanceDetails;
	}

	public PaymentApprovalDto getApprovalReq() {
		return approvalReq;
	}

	public void setApprovalReq(PaymentApprovalDto approvalReq) {
		this.approvalReq = approvalReq;
	}

	public FdrPaymentDetailsDto getFdrPaymentDetails() {
		return fdrPaymentDetails;
	}

	public void setFdrPaymentDetails(FdrPaymentDetailsDto fdrPaymentDetails) {
		this.fdrPaymentDetails = fdrPaymentDetails;
	}

	public DdPaymentDetailsDto getDdPaymentDetails() {
		return ddPaymentDetails;
	}

	public void setDdPaymentDetails(DdPaymentDetailsDto ddPaymentDetails) {
		this.ddPaymentDetails = ddPaymentDetails;
	}

	public List<GstDetailsDto> getGstpayable() {
		return gstpayable;
	}

	public void setGstpayable(List<GstDetailsDto> gstpayable) {
		this.gstpayable = gstpayable;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDelayReason() {
		return delayReason;
	}

	public void setDelayReason(String delayReason) {
		this.delayReason = delayReason;
	}

	public String getFirstDocRecievedDate() {
		return firstDocRecievedDate;
	}

	public void setFirstDocRecievedDate(String firstDocRecievedDate) {
		this.firstDocRecievedDate = firstDocRecievedDate;
	}

	public String getLastDocRecievedDate() {
		return lastDocRecievedDate;
	}

	public void setLastDocRecievedDate(String lastDocRecievedDate) {
		this.lastDocRecievedDate = lastDocRecievedDate;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getFinalSurveyDate() {
		return finalSurveyDate;
	}

	public void setFinalSurveyDate(String finalSurveyDate) {
		this.finalSurveyDate = finalSurveyDate;
	}
	

}
