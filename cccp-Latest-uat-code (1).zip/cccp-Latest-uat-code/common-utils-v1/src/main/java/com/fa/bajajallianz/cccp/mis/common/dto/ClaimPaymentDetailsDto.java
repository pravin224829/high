package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;

public class ClaimPaymentDetailsDto implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	 public String fdrNumber;
	 private String claimNo;
	 private String referenceNo;
	 private String paymentBank;
	 private String chequeNo;
	 private String interestAmount;
	 private String certTdsPercentage;
	 private String ddNumber;
	 private String paymentAmount;
	 private String rejectedDate;
	 private String utrNumber;
	 private String voucherNo;
	 private String baseTdsPercentage;
	 private String sgstAmount;
	 private String cgstAmount;
	 private String igstAmount;
	 private String tdsAmount;
	 private String ugstAmount;
	 private String rejectionReason;
	 private String paymentDate;
	 private String uploadedBy;
	 private String paymentStatus;
	 private String claimStatus;
	 private String tdsPortalPaymentReferenceNo;
	 private String portalPaymentReferenceNo;
	 private String paymentPurpose;
	    private ApplicationErrorDto applicationErr;
		public String getFdrNumber() {
			return fdrNumber;
		}
		public void setFdrNumber(String fdrNumber) {
			this.fdrNumber = fdrNumber;
		}
		public String getClaimNo() {
			return claimNo;
		}
		public void setClaimNo(String claimNo) {
			this.claimNo = claimNo;
		}
		public String getReferenceNo() {
			return referenceNo;
		}
		public void setReferenceNo(String referenceNo) {
			this.referenceNo = referenceNo;
		}
		public String getPaymentBank() {
			return paymentBank;
		}
		public void setPaymentBank(String paymentBank) {
			this.paymentBank = paymentBank;
		}
		public String getChequeNo() {
			return chequeNo;
		}
		public void setChequeNo(String chequeNo) {
			this.chequeNo = chequeNo;
		}
		public String getInterestAmount() {
			return interestAmount;
		}
		public void setInterestAmount(String interestAmount) {
			this.interestAmount = interestAmount;
		}
		public String getCertTdsPercentage() {
			return certTdsPercentage;
		}
		public void setCertTdsPercentage(String certTdsPercentage) {
			this.certTdsPercentage = certTdsPercentage;
		}
		public String getDdNumber() {
			return ddNumber;
		}
		public void setDdNumber(String ddNumber) {
			this.ddNumber = ddNumber;
		}
		public String getPaymentAmount() {
			return paymentAmount;
		}
		public void setPaymentAmount(String paymentAmount) {
			this.paymentAmount = paymentAmount;
		}
		public String getRejectedDate() {
			return rejectedDate;
		}
		public void setRejectedDate(String rejectedDate) {
			this.rejectedDate = rejectedDate;
		}
		public String getUtrNumber() {
			return utrNumber;
		}
		public void setUtrNumber(String utrNumber) {
			this.utrNumber = utrNumber;
		}
		public String getVoucherNo() {
			return voucherNo;
		}
		public void setVoucherNo(String voucherNo) {
			this.voucherNo = voucherNo;
		}
		public String getBaseTdsPercentage() {
			return baseTdsPercentage;
		}
		public void setBaseTdsPercentage(String baseTdsPercentage) {
			this.baseTdsPercentage = baseTdsPercentage;
		}
		public String getSgstAmount() {
			return sgstAmount;
		}
		public void setSgstAmount(String sgstAmount) {
			this.sgstAmount = sgstAmount;
		}
		public String getCgstAmount() {
			return cgstAmount;
		}
		public void setCgstAmount(String cgstAmount) {
			this.cgstAmount = cgstAmount;
		}
		public String getIgstAmount() {
			return igstAmount;
		}
		public void setIgstAmount(String igstAmount) {
			this.igstAmount = igstAmount;
		}
		public String getTdsAmount() {
			return tdsAmount;
		}
		public void setTdsAmount(String tdsAmount) {
			this.tdsAmount = tdsAmount;
		}
		public String getUgstAmount() {
			return ugstAmount;
		}
		public void setUgstAmount(String ugstAmount) {
			this.ugstAmount = ugstAmount;
		}
		public String getRejectionReason() {
			return rejectionReason;
		}
		public void setRejectionReason(String rejectionReason) {
			this.rejectionReason = rejectionReason;
		}
		public String getPaymentDate() {
			return paymentDate;
		}
		public void setPaymentDate(String paymentDate) {
			this.paymentDate = paymentDate;
		}
		public String getUploadedBy() {
			return uploadedBy;
		}
		public void setUploadedBy(String uploadedBy) {
			this.uploadedBy = uploadedBy;
		}
		public String getPaymentStatus() {
			return paymentStatus;
		}
		public void setPaymentStatus(String paymentStatus) {
			this.paymentStatus = paymentStatus;
		}
		public String getClaimStatus() {
			return claimStatus;
		}
		public void setClaimStatus(String claimStatus) {
			this.claimStatus = claimStatus;
		}
		public String getTdsPortalPaymentReferenceNo() {
			return tdsPortalPaymentReferenceNo;
		}
		public void setTdsPortalPaymentReferenceNo(String tdsPortalPaymentReferenceNo) {
			this.tdsPortalPaymentReferenceNo = tdsPortalPaymentReferenceNo;
		}
		public String getPortalPaymentReferenceNo() {
			return portalPaymentReferenceNo;
		}
		public void setPortalPaymentReferenceNo(String portalPaymentReferenceNo) {
			this.portalPaymentReferenceNo = portalPaymentReferenceNo;
		}
		public String getPaymentPurpose() {
			return paymentPurpose;
		}
		public void setPaymentPurpose(String paymentPurpose) {
			this.paymentPurpose = paymentPurpose;
		}
		public ApplicationErrorDto getApplicationErr() {
			return applicationErr;
		}
		public void setApplicationErr(ApplicationErrorDto applicationErr) {
			this.applicationErr = applicationErr;
		}
	   
		
	    
	    

}
