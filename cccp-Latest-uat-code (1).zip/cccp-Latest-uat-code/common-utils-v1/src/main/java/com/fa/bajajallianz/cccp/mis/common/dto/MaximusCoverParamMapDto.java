package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MaximusCoverParamMapDto implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("Eq Premium")
	public String eqPremium;

	@JsonProperty("Cover Premium in Transaction Currency")
	public String coverPremiuminTransactionCurrency;

	@JsonProperty("Cover Premium in Base Currency")
	public String coverPremiuminBaseCurrency;

	@JsonProperty("Forex Rate at Cover Level")
	public String forexRateatCoverLevel;

	@JsonProperty("Pmm adj Factor for product remain")
	public String pmmadjFactorforproductremain;

	@JsonProperty("Content Premium")
	public String contentPremium;

	@JsonProperty("Plant and Machinery Premium")
	public String plantandMachineryPremium;

	@JsonProperty("Stock Premium")
	public String stockPremium;

	@JsonProperty("Electrical installation Premium")
	public String electricalinstallationPremium;

	@JsonProperty("Total Flexa Premium")
	public String totalFlexaPremium;

	@JsonProperty("Net Flexa Premium")
	public String netFlexaPremium;

	@JsonProperty("Base Amt on Current Pmm slab")
	public String baseAmtonCurrentPmmslab;

	@JsonProperty("Old Premium")
	public String oldPremium;

	@JsonProperty("Pmm adj factor for prd remain")
	public String pmmadjfactorforprdremain;

	@JsonProperty("Pmm adj factor for prd elapsed")
	public String pmmadjfactorforprdelapsed;

	@JsonProperty("Furnititure Fixture and  Fittings Prmium")
	public String furnititureFixtureandFittingsPrmium;

	@JsonProperty("Building premium")
	public String buildingpremium;

	@JsonProperty("Theft Premium")
	public String theftPremium;

	public String getEqPremium() {
		return eqPremium;
	}

	public void setEqPremium(String eqPremium) {
		this.eqPremium = eqPremium;
	}

	public String getCoverPremiuminTransactionCurrency() {
		return coverPremiuminTransactionCurrency;
	}

	public void setCoverPremiuminTransactionCurrency(String coverPremiuminTransactionCurrency) {
		this.coverPremiuminTransactionCurrency = coverPremiuminTransactionCurrency;
	}

	public String getCoverPremiuminBaseCurrency() {
		return coverPremiuminBaseCurrency;
	}

	public void setCoverPremiuminBaseCurrency(String coverPremiuminBaseCurrency) {
		this.coverPremiuminBaseCurrency = coverPremiuminBaseCurrency;
	}

	public String getForexRateatCoverLevel() {
		return forexRateatCoverLevel;
	}

	public void setForexRateatCoverLevel(String forexRateatCoverLevel) {
		this.forexRateatCoverLevel = forexRateatCoverLevel;
	}

	public String getPmmadjFactorforproductremain() {
		return pmmadjFactorforproductremain;
	}

	public void setPmmadjFactorforproductremain(String pmmadjFactorforproductremain) {
		this.pmmadjFactorforproductremain = pmmadjFactorforproductremain;
	}

	public String getContentPremium() {
		return contentPremium;
	}

	public void setContentPremium(String contentPremium) {
		this.contentPremium = contentPremium;
	}

	public String getPlantandMachineryPremium() {
		return plantandMachineryPremium;
	}

	public void setPlantandMachineryPremium(String plantandMachineryPremium) {
		this.plantandMachineryPremium = plantandMachineryPremium;
	}

	public String getStockPremium() {
		return stockPremium;
	}

	public void setStockPremium(String stockPremium) {
		this.stockPremium = stockPremium;
	}

	public String getElectricalinstallationPremium() {
		return electricalinstallationPremium;
	}

	public void setElectricalinstallationPremium(String electricalinstallationPremium) {
		this.electricalinstallationPremium = electricalinstallationPremium;
	}

	public String getTotalFlexaPremium() {
		return totalFlexaPremium;
	}

	public void setTotalFlexaPremium(String totalFlexaPremium) {
		this.totalFlexaPremium = totalFlexaPremium;
	}

	public String getNetFlexaPremium() {
		return netFlexaPremium;
	}

	public void setNetFlexaPremium(String netFlexaPremium) {
		this.netFlexaPremium = netFlexaPremium;
	}

	public String getBaseAmtonCurrentPmmslab() {
		return baseAmtonCurrentPmmslab;
	}

	public void setBaseAmtonCurrentPmmslab(String baseAmtonCurrentPmmslab) {
		this.baseAmtonCurrentPmmslab = baseAmtonCurrentPmmslab;
	}

	public String getOldPremium() {
		return oldPremium;
	}

	public void setOldPremium(String oldPremium) {
		this.oldPremium = oldPremium;
	}

	public String getPmmadjfactorforprdremain() {
		return pmmadjfactorforprdremain;
	}

	public void setPmmadjfactorforprdremain(String pmmadjfactorforprdremain) {
		this.pmmadjfactorforprdremain = pmmadjfactorforprdremain;
	}

	public String getPmmadjfactorforprdelapsed() {
		return pmmadjfactorforprdelapsed;
	}

	public void setPmmadjfactorforprdelapsed(String pmmadjfactorforprdelapsed) {
		this.pmmadjfactorforprdelapsed = pmmadjfactorforprdelapsed;
	}

	public String getFurnititureFixtureandFittingsPrmium() {
		return furnititureFixtureandFittingsPrmium;
	}

	public void setFurnititureFixtureandFittingsPrmium(String furnititureFixtureandFittingsPrmium) {
		this.furnititureFixtureandFittingsPrmium = furnititureFixtureandFittingsPrmium;
	}

	public String getBuildingpremium() {
		return buildingpremium;
	}

	public void setBuildingpremium(String buildingpremium) {
		this.buildingpremium = buildingpremium;
	}

	public String getTheftPremium() {
		return theftPremium;
	}

	public void setTheftPremium(String theftPremium) {
		this.theftPremium = theftPremium;
	}

}
