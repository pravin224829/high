package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

public class MaximusAdditionalPolicyDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String basePremium;
	private String branchCode;
	private String country;
	private String premiumCurrExchngRate;
	private String expiringPolicyNumber;
	private String forexRateAtPolicyLevel;
	private String geoCoverage;
	private String issuanceSource;
	private String loadedPremium;
	private String modeOfPayment;
	private String netPremiumInPremCurr;
	private String planCategory;
	private String polLevelBaseCurr;
	private String polLevelTransacCurr;
	private String polLevelTransacCurrForSI;
	private String insuranceCompanyName;
	private String policyPlan;
	private String policyPremInBaseCurr;
	private String polPremInTransacCurr;
	private String policyPremValue;
	private String policyPremWOLoading;
	private String policySumInsuredInBaseCurr;
	private String policySIInTransacCurr;
	private String policyType;
	private String premiumCurrency;
	private String renewalApplicable;
	private String srcOfBusiness;
	private String sumInsuredCurrency;
	private String sumInsuredCurrExchngRate;
	private String sumInsuredInSICurr;
	private String totalFees;
	private String totalFraudScore;
	private String totalTaxes;
	private String typeOfBusiness;
	private String underwritingRqrdFlag;
	private String policySubStatus;
	private String refType;
	private String referenceNumber;
	private String expiringPolicyExpiryDate;
	private String oldProductCode;
	private String excludedEventsRemarks;
	private String excludedCountriesRemarks;
	private String masterPolicyNumber;
	private String coInsuranceApplicable;
	private String costCenter;
	private String referenceNo;
	private String portalPaymentMode;
	private String netPremium;
	private String customized;
	private String typeOfTour;
	private String multipleCity;
	private String natureOfGroups;
	private String cruise;
	private String previousPolicyNumber;
	private String cbmReferenceId;
	private String gstinuin;
	private String panNumber;
	private String policyId;
	private String childPolicyPlan;
	private String createdBy;
	private String transitJourneyCover;
	private String coiNumber;
	private String transactionId;
	private String oldCoiNumber;
	private String gstType;
	private String travellingCompanionDiscount;
	private String baggageTrackingServiceApplicable;
	private String imdCode;
	private String subimdcode;
	private String igstamount;
	private String bagicrmecode;
	private String cgstamount;
	private String sgstamount;
	private String utgstamount;
	private String imdName;
	private String imdChannel;
	private String subImdChannel;
	private String subImdName;
	private String bondSumInsured;
	private String imdChannelName;
	private String subChannelName;

	public String getBasePremium() {
		return basePremium;
	}

	public void setBasePremium(String basePremium) {
		this.basePremium = basePremium;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPremiumCurrExchngRate() {
		return premiumCurrExchngRate;
	}

	public void setPremiumCurrExchngRate(String premiumCurrExchngRate) {
		this.premiumCurrExchngRate = premiumCurrExchngRate;
	}

	public String getExpiringPolicyNumber() {
		return expiringPolicyNumber;
	}

	public void setExpiringPolicyNumber(String expiringPolicyNumber) {
		this.expiringPolicyNumber = expiringPolicyNumber;
	}

	public String getForexRateAtPolicyLevel() {
		return forexRateAtPolicyLevel;
	}

	public void setForexRateAtPolicyLevel(String forexRateAtPolicyLevel) {
		this.forexRateAtPolicyLevel = forexRateAtPolicyLevel;
	}

	public String getGeoCoverage() {
		return geoCoverage;
	}

	public void setGeoCoverage(String geoCoverage) {
		this.geoCoverage = geoCoverage;
	}

	public String getIssuanceSource() {
		return issuanceSource;
	}

	public void setIssuanceSource(String issuanceSource) {
		this.issuanceSource = issuanceSource;
	}

	public String getLoadedPremium() {
		return loadedPremium;
	}

	public void setLoadedPremium(String loadedPremium) {
		this.loadedPremium = loadedPremium;
	}

	public String getModeOfPayment() {
		return modeOfPayment;
	}

	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

	public String getNetPremiumInPremCurr() {
		return netPremiumInPremCurr;
	}

	public void setNetPremiumInPremCurr(String netPremiumInPremCurr) {
		this.netPremiumInPremCurr = netPremiumInPremCurr;
	}

	public String getPlanCategory() {
		return planCategory;
	}

	public void setPlanCategory(String planCategory) {
		this.planCategory = planCategory;
	}

	public String getPolLevelBaseCurr() {
		return polLevelBaseCurr;
	}

	public void setPolLevelBaseCurr(String polLevelBaseCurr) {
		this.polLevelBaseCurr = polLevelBaseCurr;
	}

	public String getPolLevelTransacCurr() {
		return polLevelTransacCurr;
	}

	public void setPolLevelTransacCurr(String polLevelTransacCurr) {
		this.polLevelTransacCurr = polLevelTransacCurr;
	}

	public String getPolLevelTransacCurrForSI() {
		return polLevelTransacCurrForSI;
	}

	public void setPolLevelTransacCurrForSI(String polLevelTransacCurrForSI) {
		this.polLevelTransacCurrForSI = polLevelTransacCurrForSI;
	}

	public String getInsuranceCompanyName() {
		return insuranceCompanyName;
	}

	public void setInsuranceCompanyName(String insuranceCompanyName) {
		this.insuranceCompanyName = insuranceCompanyName;
	}

	public String getPolicyPlan() {
		return policyPlan;
	}

	public void setPolicyPlan(String policyPlan) {
		this.policyPlan = policyPlan;
	}

	public String getPolicyPremInBaseCurr() {
		return policyPremInBaseCurr;
	}

	public void setPolicyPremInBaseCurr(String policyPremInBaseCurr) {
		this.policyPremInBaseCurr = policyPremInBaseCurr;
	}

	public String getPolPremInTransacCurr() {
		return polPremInTransacCurr;
	}

	public void setPolPremInTransacCurr(String polPremInTransacCurr) {
		this.polPremInTransacCurr = polPremInTransacCurr;
	}

	public String getPolicyPremValue() {
		return policyPremValue;
	}

	public void setPolicyPremValue(String policyPremValue) {
		this.policyPremValue = policyPremValue;
	}

	public String getPolicyPremWOLoading() {
		return policyPremWOLoading;
	}

	public void setPolicyPremWOLoading(String policyPremWOLoading) {
		this.policyPremWOLoading = policyPremWOLoading;
	}

	public String getPolicySumInsuredInBaseCurr() {
		return policySumInsuredInBaseCurr;
	}

	public void setPolicySumInsuredInBaseCurr(String policySumInsuredInBaseCurr) {
		this.policySumInsuredInBaseCurr = policySumInsuredInBaseCurr;
	}

	public String getPolicySIInTransacCurr() {
		return policySIInTransacCurr;
	}

	public void setPolicySIInTransacCurr(String policySIInTransacCurr) {
		this.policySIInTransacCurr = policySIInTransacCurr;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public String getPremiumCurrency() {
		return premiumCurrency;
	}

	public void setPremiumCurrency(String premiumCurrency) {
		this.premiumCurrency = premiumCurrency;
	}

	public String getRenewalApplicable() {
		return renewalApplicable;
	}

	public void setRenewalApplicable(String renewalApplicable) {
		this.renewalApplicable = renewalApplicable;
	}

	public String getSrcOfBusiness() {
		return srcOfBusiness;
	}

	public void setSrcOfBusiness(String srcOfBusiness) {
		this.srcOfBusiness = srcOfBusiness;
	}

	public String getSumInsuredCurrency() {
		return sumInsuredCurrency;
	}

	public void setSumInsuredCurrency(String sumInsuredCurrency) {
		this.sumInsuredCurrency = sumInsuredCurrency;
	}

	public String getSumInsuredCurrExchngRate() {
		return sumInsuredCurrExchngRate;
	}

	public void setSumInsuredCurrExchngRate(String sumInsuredCurrExchngRate) {
		this.sumInsuredCurrExchngRate = sumInsuredCurrExchngRate;
	}

	public String getSumInsuredInSICurr() {
		return sumInsuredInSICurr;
	}

	public void setSumInsuredInSICurr(String sumInsuredInSICurr) {
		this.sumInsuredInSICurr = sumInsuredInSICurr;
	}

	public String getTotalFees() {
		return totalFees;
	}

	public void setTotalFees(String totalFees) {
		this.totalFees = totalFees;
	}

	public String getTotalFraudScore() {
		return totalFraudScore;
	}

	public void setTotalFraudScore(String totalFraudScore) {
		this.totalFraudScore = totalFraudScore;
	}

	public String getTotalTaxes() {
		return totalTaxes;
	}

	public void setTotalTaxes(String totalTaxes) {
		this.totalTaxes = totalTaxes;
	}

	public String getTypeOfBusiness() {
		return typeOfBusiness;
	}

	public void setTypeOfBusiness(String typeOfBusiness) {
		this.typeOfBusiness = typeOfBusiness;
	}

	public String getUnderwritingRqrdFlag() {
		return underwritingRqrdFlag;
	}

	public void setUnderwritingRqrdFlag(String underwritingRqrdFlag) {
		this.underwritingRqrdFlag = underwritingRqrdFlag;
	}

	public String getPolicySubStatus() {
		return policySubStatus;
	}

	public void setPolicySubStatus(String policySubStatus) {
		this.policySubStatus = policySubStatus;
	}

	public String getRefType() {
		return refType;
	}

	public void setRefType(String refType) {
		this.refType = refType;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getExpiringPolicyExpiryDate() {
		return expiringPolicyExpiryDate;
	}

	public void setExpiringPolicyExpiryDate(String expiringPolicyExpiryDate) {
		this.expiringPolicyExpiryDate = expiringPolicyExpiryDate;
	}

	public String getOldProductCode() {
		return oldProductCode;
	}

	public void setOldProductCode(String oldProductCode) {
		this.oldProductCode = oldProductCode;
	}

	public String getExcludedEventsRemarks() {
		return excludedEventsRemarks;
	}

	public void setExcludedEventsRemarks(String excludedEventsRemarks) {
		this.excludedEventsRemarks = excludedEventsRemarks;
	}

	public String getExcludedCountriesRemarks() {
		return excludedCountriesRemarks;
	}

	public void setExcludedCountriesRemarks(String excludedCountriesRemarks) {
		this.excludedCountriesRemarks = excludedCountriesRemarks;
	}

	public String getMasterPolicyNumber() {
		return masterPolicyNumber;
	}

	public void setMasterPolicyNumber(String masterPolicyNumber) {
		this.masterPolicyNumber = masterPolicyNumber;
	}

	public String getCoInsuranceApplicable() {
		return coInsuranceApplicable;
	}

	public void setCoInsuranceApplicable(String coInsuranceApplicable) {
		this.coInsuranceApplicable = coInsuranceApplicable;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getPortalPaymentMode() {
		return portalPaymentMode;
	}

	public void setPortalPaymentMode(String portalPaymentMode) {
		this.portalPaymentMode = portalPaymentMode;
	}

	public String getNetPremium() {
		return netPremium;
	}

	public void setNetPremium(String netPremium) {
		this.netPremium = netPremium;
	}

	public String getCustomized() {
		return customized;
	}

	public void setCustomized(String customized) {
		this.customized = customized;
	}

	public String getTypeOfTour() {
		return typeOfTour;
	}

	public void setTypeOfTour(String typeOfTour) {
		this.typeOfTour = typeOfTour;
	}

	public String getMultipleCity() {
		return multipleCity;
	}

	public void setMultipleCity(String multipleCity) {
		this.multipleCity = multipleCity;
	}

	public String getNatureOfGroups() {
		return natureOfGroups;
	}

	public void setNatureOfGroups(String natureOfGroups) {
		this.natureOfGroups = natureOfGroups;
	}

	public String getCruise() {
		return cruise;
	}

	public void setCruise(String cruise) {
		this.cruise = cruise;
	}

	public String getPreviousPolicyNumber() {
		return previousPolicyNumber;
	}

	public void setPreviousPolicyNumber(String previousPolicyNumber) {
		this.previousPolicyNumber = previousPolicyNumber;
	}

	public String getCbmReferenceId() {
		return cbmReferenceId;
	}

	public void setCbmReferenceId(String cbmReferenceId) {
		this.cbmReferenceId = cbmReferenceId;
	}

	public String getGstinuin() {
		return gstinuin;
	}

	public void setGstinuin(String gstinuin) {
		this.gstinuin = gstinuin;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getPolicyId() {
		return policyId;
	}

	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}

	public String getChildPolicyPlan() {
		return childPolicyPlan;
	}

	public void setChildPolicyPlan(String childPolicyPlan) {
		this.childPolicyPlan = childPolicyPlan;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getTransitJourneyCover() {
		return transitJourneyCover;
	}

	public void setTransitJourneyCover(String transitJourneyCover) {
		this.transitJourneyCover = transitJourneyCover;
	}

	public String getCoiNumber() {
		return coiNumber;
	}

	public void setCoiNumber(String coiNumber) {
		this.coiNumber = coiNumber;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getOldCoiNumber() {
		return oldCoiNumber;
	}

	public void setOldCoiNumber(String oldCoiNumber) {
		this.oldCoiNumber = oldCoiNumber;
	}

	public String getGstType() {
		return gstType;
	}

	public void setGstType(String gstType) {
		this.gstType = gstType;
	}

	public String getTravellingCompanionDiscount() {
		return travellingCompanionDiscount;
	}

	public void setTravellingCompanionDiscount(String travellingCompanionDiscount) {
		this.travellingCompanionDiscount = travellingCompanionDiscount;
	}

	public String getBaggageTrackingServiceApplicable() {
		return baggageTrackingServiceApplicable;
	}

	public void setBaggageTrackingServiceApplicable(String baggageTrackingServiceApplicable) {
		this.baggageTrackingServiceApplicable = baggageTrackingServiceApplicable;
	}

	public String getSubimdcode() {
		return subimdcode;
	}

	public void setSubimdcode(String subimdcode) {
		this.subimdcode = subimdcode;
	}

	public String getIgstamount() {
		return igstamount;
	}

	public void setIgstamount(String igstamount) {
		this.igstamount = igstamount;
	}

	public String getBagicrmecode() {
		return bagicrmecode;
	}

	public void setBagicrmecode(String bagicrmecode) {
		this.bagicrmecode = bagicrmecode;
	}

	public String getCgstamount() {
		return cgstamount;
	}

	public void setCgstamount(String cgstamount) {
		this.cgstamount = cgstamount;
	}

	public String getSgstamount() {
		return sgstamount;
	}

	public void setSgstamount(String sgstamount) {
		this.sgstamount = sgstamount;
	}

	public String getUtgstamount() {
		return utgstamount;
	}

	public void setUtgstamount(String utgstamount) {
		this.utgstamount = utgstamount;
	}

	public String getImdName() {
		return imdName;
	}

	public void setImdName(String imdName) {
		this.imdName = imdName;
	}

	public String getImdChannel() {
		return imdChannel;
	}

	public void setImdChannel(String imdChannel) {
		this.imdChannel = imdChannel;
	}

	public String getSubImdChannel() {
		return subImdChannel;
	}

	public void setSubImdChannel(String subImdChannel) {
		this.subImdChannel = subImdChannel;
	}

	public String getSubImdName() {
		return subImdName;
	}

	public void setSubImdName(String subImdName) {
		this.subImdName = subImdName;
	}

	public String getBondSumInsured() {
		return bondSumInsured;
	}

	public void setBondSumInsured(String bondSumInsured) {
		this.bondSumInsured = bondSumInsured;
	}

	public String getImdCode() {
		return imdCode;
	}

	public void setImdCode(String imdCode) {
		this.imdCode = imdCode;
	}

	public String getImdChannelName() {
		return imdChannelName;
	}

	public void setImdChannelName(String imdChannelName) {
		this.imdChannelName = imdChannelName;
	}

	public String getSubChannelName() {
		return subChannelName;
	}

	public void setSubChannelName(String subChannelName) {
		this.subChannelName = subChannelName;
	}
	
	

}
