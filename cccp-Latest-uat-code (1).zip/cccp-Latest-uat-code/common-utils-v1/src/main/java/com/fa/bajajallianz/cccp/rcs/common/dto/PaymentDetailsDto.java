package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private String partyId;
	private String claimNumber;
	private String partnerName;
	private String ipType;
	private String partyName;
	private String paymentType;
	private String paymentMode;
	private String paymentAmount;
	private String igstAmount;
	private String cgstAmount;
	private String sgstAmount;
	private String ugstAmount;
	private String gstAmount;
	private String totalAmount;
	private String referenceText;
	private String isForeignCurrency;
	private String exchangeRate;
	private String exchangeRateCurrency;
	private String invoiceNo;
	private String invoiceDate;
	private String paymentInitiatedBy;
	private String approvedBy;
	private String approvedDate;
	private String portalRefNo;
	private String paymentStatus;
	private String rejectReason;
	private String paymentRefNo;
	private String utrNumber;
	private String isActive;
	private String createdDate;
	private String reinstatementPremium;
	private String transactionType;
	private String transactionDate;
	private String name;
	private String neftStatus;
	private String status;
	private String outstandingReserveAmount;
	private String paidAmount;
	private String reserveAmount;
	private ForeignCurrencyDetailsDto currencyDetails;
	private FcBankDetailsDto bankDetails;
	private RecipientDetailsDto recipientDetails;
	private GstDetailsDto gstDetails;
	private FdrPaymentDetailsDto fdrPaymentDetails;
	private DdPaymentDetailsDto ddPaymentDetails;
	private String verifiedBy;
	private String netPaidAmount;
	private String approvalNumber;
	private String approvalStatus;
	private String rejectedAmount;
	private String transDate;
	private String transType;
	private String claimType;
	private String sendForApproval;
	private String approvedAmount;
	private String outstandingAmount;
	private String expensesOutstanding;
	private String lossOutstanding;
	private String expensesPaid;
	private String lossPaid;
	private String overallExpensesReserve;
	private String overallLossReserve;
	private String claimReferenceNo;
	private PaymentDto payments;
	private String verificationStatus;
	private String verificationDate;
	private String ipNo;
	private String taxAmount;
	private String invoiceType;
	private String payeeName;
	private String state;
	private String paybleAt;
	private String invReferenceText;
	private String reasonForChequePayment;
	private String typeOfRecovery;
	private String typeOfSalvage;
	private String interestPercentage;
	private String recoveryAmount;
	private String salvageAmount;
	private String interestAmount;
	private String exchangeAmount;
	private String coInsuranceRecoveryAmount;
	private String typeOfLoss;
	private String specialComments;
	private String claimClosingReason;
	private String chequeToBeDespatchedTo;
	private Boolean gstIsPayable;
	private String bagicGstIn;
	private String bagicState;
	private String supplierGstIn;
	private String supplierState;
	private String typeofTaxApplicable;
	private ApplicationErrorDto applicationError;
	private String sgst;
	private String igst;
	private String cgst;
	private String gstPercentage;
	private String lossEstmatedValue;
	private String ckycStatus;
	private String amlStatus;
	private String licenseExpiryDate;
	private BenificiaryDetailsDto beneficiaryDetails;
	private String lossSendForApproval;
	private String expenseSendForApproval;

	private String totalOutStandingAmount;

	private String totalLossReserve;
	private String totalSendForApproval;
	private String totalApprovedAmount;
	private String lossApprovedAmount;
	private String expenseApprovedAmount;
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOutstandingReserveAmount() {
		return outstandingReserveAmount;
	}

	public void setOutstandingReserveAmount(String outstandingReserveAmount) {
		this.outstandingReserveAmount = outstandingReserveAmount;
	}

	public String getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getReserveAmount() {
		return reserveAmount;
	}

	public void setReserveAmount(String reserveAmount) {
		this.reserveAmount = reserveAmount;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getIgstAmount() {
		return igstAmount;
	}

	public void setIgstAmount(String igstAmount) {
		this.igstAmount = igstAmount;
	}

	public String getCgstAmount() {
		return cgstAmount;
	}

	public void setCgstAmount(String cgstAmount) {
		this.cgstAmount = cgstAmount;
	}

	public String getSgstAmount() {
		return sgstAmount;
	}

	public void setSgstAmount(String sgstAmount) {
		this.sgstAmount = sgstAmount;
	}

	public String getUgstAmount() {
		return ugstAmount;
	}

	public void setUgstAmount(String ugstAmount) {
		this.ugstAmount = ugstAmount;
	}

	public String getGstAmount() {
		return gstAmount;
	}

	public void setGstAmount(String gstAmount) {
		this.gstAmount = gstAmount;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getPaymentInitiatedBy() {
		return paymentInitiatedBy;
	}

	public void setPaymentInitiatedBy(String paymentInitiatedBy) {
		this.paymentInitiatedBy = paymentInitiatedBy;
	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public String getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}

	public String getPortalRefNo() {
		return portalRefNo;
	}

	public void setPortalRefNo(String portalRefNo) {
		this.portalRefNo = portalRefNo;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getRejectReason() {
		return rejectReason;
	}

	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}

	public String getPaymentRefNo() {
		return paymentRefNo;
	}

	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}

	public String getUtrNumber() {
		return utrNumber;
	}

	public void setUtrNumber(String utrNumber) {
		this.utrNumber = utrNumber;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getReinstatementPremium() {
		return reinstatementPremium;
	}

	public void setReinstatementPremium(String reinstatementPremium) {
		this.reinstatementPremium = reinstatementPremium;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public FcBankDetailsDto getBankDetails() {
		return bankDetails;
	}

	public void setBankDetails(FcBankDetailsDto bankDetails) {
		this.bankDetails = bankDetails;
	}

	public RecipientDetailsDto getRecipientDetails() {
		return recipientDetails;
	}

	public void setRecipientDetails(RecipientDetailsDto recipientDetails) {
		this.recipientDetails = recipientDetails;
	}

	public FdrPaymentDetailsDto getFdrPaymentDetails() {
		return fdrPaymentDetails;
	}

	public void setFdrPaymentDetails(FdrPaymentDetailsDto fdrPaymentDetails) {
		this.fdrPaymentDetails = fdrPaymentDetails;
	}

	public DdPaymentDetailsDto getDdPaymentDetails() {
		return ddPaymentDetails;
	}

	public void setDdPaymentDetails(DdPaymentDetailsDto ddPaymentDetails) {
		this.ddPaymentDetails = ddPaymentDetails;
	}

	public ForeignCurrencyDetailsDto getCurrencyDetails() {
		return currencyDetails;
	}

	public void setCurrencyDetails(ForeignCurrencyDetailsDto currencyDetails) {
		this.currencyDetails = currencyDetails;
	}

	public String getVerifiedBy() {
		return verifiedBy;
	}

	public void setVerifiedBy(String verifiedBy) {
		this.verifiedBy = verifiedBy;
	}

	public String getApprovalNumber() {
		return approvalNumber;
	}

	public void setApprovalNumber(String approvalNumber) {
		this.approvalNumber = approvalNumber;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getSendForApproval() {
		return sendForApproval;
	}

	public void setSendForApproval(String sendForApproval) {
		this.sendForApproval = sendForApproval;
	}

	public String getRejectedAmount() {
		return rejectedAmount;
	}

	public void setRejectedAmount(String rejectedAmount) {
		this.rejectedAmount = rejectedAmount;
	}

	public String getApprovedAmount() {
		return approvedAmount;
	}

	public void setApprovedAmount(String approvedAmount) {
		this.approvedAmount = approvedAmount;
	}

	public String getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(String outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public String getExpensesOutstanding() {
		return expensesOutstanding;
	}

	public void setExpensesOutstanding(String expensesOutstanding) {
		this.expensesOutstanding = expensesOutstanding;
	}

	public String getLossOutstanding() {
		return lossOutstanding;
	}

	public void setLossOutstanding(String lossOutstanding) {
		this.lossOutstanding = lossOutstanding;
	}

	public String getExpensesPaid() {
		return expensesPaid;
	}

	public void setExpensesPaid(String expensesPaid) {
		this.expensesPaid = expensesPaid;
	}

	public String getLossPaid() {
		return lossPaid;
	}

	public void setLossPaid(String lossPaid) {
		this.lossPaid = lossPaid;
	}

	public String getOverallExpensesReserve() {
		return overallExpensesReserve;
	}

	public void setOverallExpensesReserve(String overallExpensesReserve) {
		this.overallExpensesReserve = overallExpensesReserve;
	}

	public String getOverallLossReserve() {
		return overallLossReserve;
	}

	public void setOverallLossReserve(String overallLossReserve) {
		this.overallLossReserve = overallLossReserve;
	}

	public String getClaimReferenceNo() {
		return claimReferenceNo;
	}

	public void setClaimReferenceNo(String claimReferenceNo) {
		this.claimReferenceNo = claimReferenceNo;
	}

	public PaymentDto getPayments() {
		return payments;
	}

	public void setPayments(PaymentDto payments) {
		this.payments = payments;
	}

	public String getVerificationStatus() {
		return verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

	public String getIpNo() {
		return ipNo;
	}

	public void setIpNo(String ipNo) {
		this.ipNo = ipNo;
	}

	public String getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(String taxAmount) {
		this.taxAmount = taxAmount;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getPayeeName() {
		return payeeName;
	}

	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPaybleAt() {
		return paybleAt;
	}

	public void setPaybleAt(String paybleAt) {
		this.paybleAt = paybleAt;
	}

	public String getInvReferenceText() {
		return invReferenceText;
	}

	public void setInvReferenceText(String invReferenceText) {
		this.invReferenceText = invReferenceText;
	}

	public String getReasonForChequePayment() {
		return reasonForChequePayment;
	}

	public void setReasonForChequePayment(String reasonForChequePayment) {
		this.reasonForChequePayment = reasonForChequePayment;
	}

	public String getTypeOfRecovery() {
		return typeOfRecovery;
	}

	public void setTypeOfRecovery(String typeOfRecovery) {
		this.typeOfRecovery = typeOfRecovery;
	}

	public String getTypeOfSalvage() {
		return typeOfSalvage;
	}

	public void setTypeOfSalvage(String typeOfSalvage) {
		this.typeOfSalvage = typeOfSalvage;
	}

	public String getInterestPercentage() {
		return interestPercentage;
	}

	public void setInterestPercentage(String interestPercentage) {
		this.interestPercentage = interestPercentage;
	}

	public String getRecoveryAmount() {
		return recoveryAmount;
	}

	public void setRecoveryAmount(String recoveryAmount) {
		this.recoveryAmount = recoveryAmount;
	}

	public String getSalvageAmount() {
		return salvageAmount;
	}

	public void setSalvageAmount(String salvageAmount) {
		this.salvageAmount = salvageAmount;
	}

	public String getInterestAmount() {
		return interestAmount;
	}

	public void setInterestAmount(String interestAmount) {
		this.interestAmount = interestAmount;
	}

	public String getExchangeAmount() {
		return exchangeAmount;
	}

	public void setExchangeAmount(String exchangeAmount) {
		this.exchangeAmount = exchangeAmount;
	}

	public String getCoInsuranceRecoveryAmount() {
		return coInsuranceRecoveryAmount;
	}

	public void setCoInsuranceRecoveryAmount(String coInsuranceRecoveryAmount) {
		this.coInsuranceRecoveryAmount = coInsuranceRecoveryAmount;
	}

	public String getTypeOfLoss() {
		return typeOfLoss;
	}

	public void setTypeOfLoss(String typeOfLoss) {
		this.typeOfLoss = typeOfLoss;
	}

	public String getSpecialComments() {
		return specialComments;
	}

	public void setSpecialComments(String specialComments) {
		this.specialComments = specialComments;
	}

	public String getClaimClosingReason() {
		return claimClosingReason;
	}

	public void setClaimClosingReason(String claimClosingReason) {
		this.claimClosingReason = claimClosingReason;
	}

	public String getChequeToBeDespatchedTo() {
		return chequeToBeDespatchedTo;
	}

	public void setChequeToBeDespatchedTo(String chequeToBeDespatchedTo) {
		this.chequeToBeDespatchedTo = chequeToBeDespatchedTo;
	}

	public Boolean getGstIsPayable() {
		return gstIsPayable;
	}

	public void setGstIsPayable(Boolean gstIsPayable) {
		this.gstIsPayable = gstIsPayable;
	}

	public String getNetPaidAmount() {
		return netPaidAmount;
	}

	public void setNetPaidAmount(String netPaidAmount) {
		this.netPaidAmount = netPaidAmount;
	}

	public String getVerificationDate() {
		return verificationDate;
	}

	public void setVerificationDate(String verificationDate) {
		this.verificationDate = verificationDate;
	}

	public String getBagicGstIn() {
		return bagicGstIn;
	}

	public void setBagicGstIn(String bagicGstIn) {
		this.bagicGstIn = bagicGstIn;
	}

	public String getBagicState() {
		return bagicState;
	}

	public void setBagicState(String bagicState) {
		this.bagicState = bagicState;
	}

	public String getSupplierGstIn() {
		return supplierGstIn;
	}

	public void setSupplierGstIn(String supplierGstIn) {
		this.supplierGstIn = supplierGstIn;
	}

	public String getSupplierState() {
		return supplierState;
	}

	public void setSupplierState(String supplierState) {
		this.supplierState = supplierState;
	}

	public String getTypeofTaxApplicable() {
		return typeofTaxApplicable;
	}

	public void setTypeofTaxApplicable(String typeofTaxApplicable) {
		this.typeofTaxApplicable = typeofTaxApplicable;
	}

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public GstDetailsDto getGstDetails() {
		return gstDetails;
	}

	public void setGstDetails(GstDetailsDto gstDetails) {
		this.gstDetails = gstDetails;
	}

	public String getReferenceText() {
		return referenceText;
	}

	public void setReferenceText(String referenceText) {
		this.referenceText = referenceText;
	}

	public String getIsForeignCurrency() {
		return isForeignCurrency;
	}

	public void setIsForeignCurrency(String isForeignCurrency) {
		this.isForeignCurrency = isForeignCurrency;
	}

	public String getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getExchangeRateCurrency() {
		return exchangeRateCurrency;
	}

	public void setExchangeRateCurrency(String exchangeRateCurrency) {
		this.exchangeRateCurrency = exchangeRateCurrency;
	}

	public String getSgst() {
		return sgst;
	}

	public void setSgst(String sgst) {
		this.sgst = sgst;
	}

	public String getIgst() {
		return igst;
	}

	public void setIgst(String igst) {
		this.igst = igst;
	}

	public String getCgst() {
		return cgst;
	}

	public void setCgst(String cgst) {
		this.cgst = cgst;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getIpType() {
		return ipType;
	}

	public void setIpType(String ipType) {
		this.ipType = ipType;
	}

	public String getGstPercentage() {
		return gstPercentage;
	}

	public void setGstPercentage(String gstPercentage) {
		this.gstPercentage = gstPercentage;
	}

	public String getLossEstmatedValue() {
		return lossEstmatedValue;
	}

	public void setLossEstmatedValue(String lossEstmatedValue) {
		this.lossEstmatedValue = lossEstmatedValue;
	}

	public String getCkycStatus() {
		return ckycStatus;
	}

	public void setCkycStatus(String ckycStatus) {
		this.ckycStatus = ckycStatus;
	}

	public String getLicenseExpiryDate() {
		return licenseExpiryDate;
	}

	public void setLicenseExpiryDate(String licenseExpiryDate) {
		this.licenseExpiryDate = licenseExpiryDate;
	}

	public BenificiaryDetailsDto getBeneficiaryDetails() {
		return beneficiaryDetails;
	}

	public void setBeneficiaryDetails(BenificiaryDetailsDto beneficiaryDetails) {
		this.beneficiaryDetails = beneficiaryDetails;
	}

	public String getAmlStatus() {
		return amlStatus;
	}

	public void setAmlStatus(String amlStatus) {
		this.amlStatus = amlStatus;
	}

	public String getLossSendForApproval() {
		return lossSendForApproval;
	}

	public void setLossSendForApproval(String lossSendForApproval) {
		this.lossSendForApproval = lossSendForApproval;
	}

	public String getExpenseSendForApproval() {
		return expenseSendForApproval;
	}

	public void setExpenseSendForApproval(String expenseSendForApproval) {
		this.expenseSendForApproval = expenseSendForApproval;
	}

	public String getTotalOutStandingAmount() {
		return totalOutStandingAmount;
	}

	public void setTotalOutStandingAmount(String totalOutStandingAmount) {
		this.totalOutStandingAmount = totalOutStandingAmount;
	}

	public String getTotalLossReserve() {
		return totalLossReserve;
	}

	public void setTotalLossReserve(String totalLossReserve) {
		this.totalLossReserve = totalLossReserve;
	}

	public String getTotalSendForApproval() {
		return totalSendForApproval;
	}

	public void setTotalSendForApproval(String totalSendForApproval) {
		this.totalSendForApproval = totalSendForApproval;
	}

	public String getTotalApprovedAmount() {
		return totalApprovedAmount;
	}

	public void setTotalApprovedAmount(String totalApprovedAmount) {
		this.totalApprovedAmount = totalApprovedAmount;
	}

	public String getLossApprovedAmount() {
		return lossApprovedAmount;
	}

	public void setLossApprovedAmount(String lossApprovedAmount) {
		this.lossApprovedAmount = lossApprovedAmount;
	}

	public String getExpenseApprovedAmount() {
		return expenseApprovedAmount;
	}

	public void setExpenseApprovedAmount(String expenseApprovedAmount) {
		this.expenseApprovedAmount = expenseApprovedAmount;
	}

	
}
