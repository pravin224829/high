/**
 * 
 */
package com.fa.bajajallianz.cccp.surveyor.common.dto;

import java.io.Serializable;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author santhosh
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class InsurerdBankDetailsDto implements Serializable{

	private static final long serialVersionUID = 1L;
	private String accountNo;
	private String neftStatus;
	private String payeeType;
	private String payeeCode;
	private String payeeEmailId;
	private String branchName;
	private String bankName;
	private String emailId;
	private ApplicationErrorDto applicationError;
	
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getNeftStatus() {
		return neftStatus;
	}
	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}
	public String getPayeeType() {
		return payeeType;
	}
	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}
	public String getPayeeCode() {
		return payeeCode;
	}
	public void setPayeeCode(String payeeCode) {
		this.payeeCode = payeeCode;
	}
	public String getPayeeEmailId() {
		return payeeEmailId;
	}
	public void setPayeeEmailId(String payeeEmailId) {
		this.payeeEmailId = payeeEmailId;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}
	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}
	
	

}