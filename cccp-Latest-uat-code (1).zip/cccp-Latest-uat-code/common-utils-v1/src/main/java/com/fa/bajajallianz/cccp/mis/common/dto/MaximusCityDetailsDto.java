package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusCityDetailsDto implements Serializable {

/**
 * 
 */
private static final long serialVersionUID = 1L;

private String locationCode;
private String locationName;
public String getLocationCode() {
	return locationCode;
}
public void setLocationCode(String locationCode) {
	this.locationCode = locationCode;
}
public String getLocationName() {
	return locationName;
}
public void setLocationName(String locationName) {
	this.locationName = locationName;
}


}
