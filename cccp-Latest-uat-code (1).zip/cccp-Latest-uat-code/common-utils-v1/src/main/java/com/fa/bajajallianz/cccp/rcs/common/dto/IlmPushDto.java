package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class IlmPushDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String investigationNo;
	private String claimNumber;
	private String productCode;
	private String ilmStatus;
	private String userId;
	private String processFlag;
	private String ilmRemarks;
	private String partyId;
	private String claimId;
	private String kindOfLoss;
	private List<IlmTaskDetailsDto> taskDetails;
	private List<IlmTriggerDetailsDto> triggerDetails;
	private ClaimDetailsRespDto claimDetailsRespDto;

	public String getInvestigationNo() {
		return investigationNo;
	}

	public void setInvestigationNo(String investigationNo) {
		this.investigationNo = investigationNo;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getIlmStatus() {
		return ilmStatus;
	}

	public void setIlmStatus(String ilmStatus) {
		this.ilmStatus = ilmStatus;
	}

	public List<IlmTaskDetailsDto> getTaskDetails() {
		return taskDetails;
	}

	public void setTaskDetails(List<IlmTaskDetailsDto> taskDetails) {
		this.taskDetails = taskDetails;
	}

	public List<IlmTriggerDetailsDto> getTriggerDetails() {
		return triggerDetails;
	}

	public void setTriggerDetails(List<IlmTriggerDetailsDto> triggerDetails) {
		this.triggerDetails = triggerDetails;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getProcessFlag() {
		return processFlag;
	}

	public void setProcessFlag(String processFlag) {
		this.processFlag = processFlag;
	}

	public String getIlmRemarks() {
		return ilmRemarks;
	}

	public void setIlmRemarks(String ilmRemarks) {
		this.ilmRemarks = ilmRemarks;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getClaimId() {
		return claimId;
	}

	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}

	public String getKindOfLoss() {
		return kindOfLoss;
	}

	public void setKindOfLoss(String kindOfLoss) {
		this.kindOfLoss = kindOfLoss;
	}

	public ClaimDetailsRespDto getClaimDetailsRespDto() {
		return claimDetailsRespDto;
	}

	public void setClaimDetailsRespDto(ClaimDetailsRespDto claimDetailsRespDto) {
		this.claimDetailsRespDto = claimDetailsRespDto;
	}

}
