
package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusKycTokenRespDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ApplicationErrorDto applicationError;
	private ValidationStatusDto validationStatus;
	private AccessTokenStatusDto accessTokenStatus;

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public ValidationStatusDto getValidationStatus() {
		return validationStatus;
	}

	public void setValidationStatus(ValidationStatusDto validationStatus) {
		this.validationStatus = validationStatus;
	}

	public AccessTokenStatusDto getAccessTokenStatus() {
		return accessTokenStatus;
	}

	public void setAccessTokenStatus(AccessTokenStatusDto accessTokenStatus) {
		this.accessTokenStatus = accessTokenStatus;
	}

}