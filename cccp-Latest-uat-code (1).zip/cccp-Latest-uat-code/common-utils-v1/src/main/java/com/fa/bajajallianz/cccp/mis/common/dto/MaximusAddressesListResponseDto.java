/**
 * 
 */
package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusAddressesListResponseDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<MaximusAddressResponseDto> address;

	public List<MaximusAddressResponseDto> getAddress() {
		return address;
	}

	public void setAddress(List<MaximusAddressResponseDto> address) {
		this.address = address;
	}
	
}
