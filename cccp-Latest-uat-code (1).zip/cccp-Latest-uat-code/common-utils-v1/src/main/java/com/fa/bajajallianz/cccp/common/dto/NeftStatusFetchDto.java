package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

public class NeftStatusFetchDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private String neftStatus;
	private String errCode;
	private String applicationError;

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public String getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(String applicationError) {
		this.applicationError = applicationError;
	}

}
