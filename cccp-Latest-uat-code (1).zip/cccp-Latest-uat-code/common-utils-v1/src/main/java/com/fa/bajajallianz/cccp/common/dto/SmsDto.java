/**
 * 
 */
package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SmsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String language;
	private List<MobileNoDto> mobileNo;
	private List<String> typeOfMsg;
	private String referenceId;
	private SmsTextDto smsText;
	private String templateId;
	private String partID;

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public List<MobileNoDto> getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(List<MobileNoDto> mobileNo) {
		this.mobileNo = mobileNo;
	}

	public List<String> getTypeOfMsg() {
		return typeOfMsg;
	}

	public void setTypeOfMsg(List<String> typeOfMsg) {
		this.typeOfMsg = typeOfMsg;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public SmsTextDto getSmsText() {
		return smsText;
	}

	public void setSmsText(SmsTextDto smsText) {
		this.smsText = smsText;
	}

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	public String getPartID() {
		return partID;
	}

	public void setPartID(String partID) {
		this.partID = partID;
	}

}
