/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentHistoryDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String payNeftStatus;
	private String payPartnerId;
	private String payType;
	private String payTransType;
	private String payTransDate;
	private String payReinstatementPremium;
	private String netPaidAmount;
	private String payApprovalNo;
	private String payApprovalStatus;
	private String payClaimType;
	private String payDocLabelName;
	private String approvedPaymentRefNo;
	private String payIpNo;
	private String payPartyType;
	private String payPartyName;
	private String claimNumber;
	private String policyNumber;
	private String payableAt;
	private String reasonForChequePayment;
	private String claimPaymentId;
	 private String paymentStatus;
	 private String rejectionReason;
	
	public String getPayNeftStatus() {
		return payNeftStatus;
	}
	public void setPayNeftStatus(String payNeftStatus) {
		this.payNeftStatus = payNeftStatus;
	}
	public String getPayPartnerId() {
		return payPartnerId;
	}
	public void setPayPartnerId(String payPartnerId) {
		this.payPartnerId = payPartnerId;
	}
	public String getPayType() {
		return payType;
	}
	public void setPayType(String payType) {
		this.payType = payType;
	}
	public String getPayTransType() {
		return payTransType;
	}
	public void setPayTransType(String payTransType) {
		this.payTransType = payTransType;
	}
	public String getPayTransDate() {
		return payTransDate;
	}
	public void setPayTransDate(String payTransDate) {
		this.payTransDate = payTransDate;
	}
	public String getPayReinstatementPremium() {
		return payReinstatementPremium;
	}
	public void setPayReinstatementPremium(String payReinstatementPremium) {
		this.payReinstatementPremium = payReinstatementPremium;
	}
	public String getNetPaidAmount() {
		return netPaidAmount;
	}
	public void setNetPaidAmount(String netPaidAmount) {
		this.netPaidAmount = netPaidAmount;
	}
	public String getPayApprovalNo() {
		return payApprovalNo;
	}
	public void setPayApprovalNo(String payApprovalNo) {
		this.payApprovalNo = payApprovalNo;
	}
	public String getPayApprovalStatus() {
		return payApprovalStatus;
	}
	public void setPayApprovalStatus(String payApprovalStatus) {
		this.payApprovalStatus = payApprovalStatus;
	}
	public String getPayClaimType() {
		return payClaimType;
	}
	public void setPayClaimType(String payClaimType) {
		this.payClaimType = payClaimType;
	}
	public String getPayDocLabelName() {
		return payDocLabelName;
	}
	public void setPayDocLabelName(String payDocLabelName) {
		this.payDocLabelName = payDocLabelName;
	}
	public String getApprovedPaymentRefNo() {
		return approvedPaymentRefNo;
	}
	public void setApprovedPaymentRefNo(String approvedPaymentRefNo) {
		this.approvedPaymentRefNo = approvedPaymentRefNo;
	}
	public String getPayIpNo() {
		return payIpNo;
	}
	public void setPayIpNo(String payIpNo) {
		this.payIpNo = payIpNo;
	}
	public String getPayPartyType() {
		return payPartyType;
	}
	public void setPayPartyType(String payPartyType) {
		this.payPartyType = payPartyType;
	}
	public String getPayPartyName() {
		return payPartyName;
	}
	public void setPayPartyName(String payPartyName) {
		this.payPartyName = payPartyName;
	}
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getPayableAt() {
		return payableAt;
	}
	public void setPayableAt(String payableAt) {
		this.payableAt = payableAt;
	}
	public String getReasonForChequePayment() {
		return reasonForChequePayment;
	}
	public void setReasonForChequePayment(String reasonForChequePayment) {
		this.reasonForChequePayment = reasonForChequePayment;
	}
	public String getClaimPaymentId() {
		return claimPaymentId;
	}
	public void setClaimPaymentId(String claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getRejectionReason() {
		return rejectionReason;
	}
	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}
	
	
	
}
