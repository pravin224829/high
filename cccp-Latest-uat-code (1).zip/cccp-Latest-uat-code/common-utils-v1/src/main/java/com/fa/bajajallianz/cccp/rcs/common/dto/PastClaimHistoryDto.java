package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PastClaimHistoryDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String policyNumber;
	private String pastClaimNumber;
	private String dateOfLoss;
	private String registrationDate;
	private String lossDiscription;
	private String causeOfLoss;
	private String claimStatus;
	private String claimRegistrationSource;
	private String claimHandler;
	private String lossReserveAmount;
	private String paidAmount;
	private String outStandingAmount;
	private String closingReason;
	private String fraudOrMisrepresentationFlag;
	private String ilmAppointment;

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getPastClaimNumber() {
		return pastClaimNumber;
	}

	public void setPastClaimNumber(String pastClaimNumber) {
		this.pastClaimNumber = pastClaimNumber;
	}

	public String getDateOfLoss() {
		return dateOfLoss;
	}

	public void setDateOfLoss(String dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}

	public String getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getLossDiscription() {
		return lossDiscription;
	}

	public void setLossDiscription(String lossDiscription) {
		this.lossDiscription = lossDiscription;
	}

	public String getCauseOfLoss() {
		return causeOfLoss;
	}

	public void setCauseOfLoss(String causeOfLoss) {
		this.causeOfLoss = causeOfLoss;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public String getClaimRegistrationSource() {
		return claimRegistrationSource;
	}

	public void setClaimRegistrationSource(String claimRegistrationSource) {
		this.claimRegistrationSource = claimRegistrationSource;
	}

	public String getClaimHandler() {
		return claimHandler;
	}

	public void setClaimHandler(String claimHandler) {
		this.claimHandler = claimHandler;
	}

	public String getLossReserveAmount() {
		return lossReserveAmount;
	}

	public void setLossReserveAmount(String lossReserveAmount) {
		this.lossReserveAmount = lossReserveAmount;
	}

	public String getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getOutStandingAmount() {
		return outStandingAmount;
	}

	public void setOutStandingAmount(String outStandingAmount) {
		this.outStandingAmount = outStandingAmount;
	}

	public String getClosingReason() {
		return closingReason;
	}

	public void setClosingReason(String closingReason) {
		this.closingReason = closingReason;
	}

	public String getFraudOrMisrepresentationFlag() {
		return fraudOrMisrepresentationFlag;
	}

	public void setFraudOrMisrepresentationFlag(String fraudOrMisrepresentationFlag) {
		this.fraudOrMisrepresentationFlag = fraudOrMisrepresentationFlag;
	}

	public String getIlmAppointment() {
		return ilmAppointment;
	}

	public void setIlmAppointment(String ilmAppointment) {
		this.ilmAppointment = ilmAppointment;
	}

}
