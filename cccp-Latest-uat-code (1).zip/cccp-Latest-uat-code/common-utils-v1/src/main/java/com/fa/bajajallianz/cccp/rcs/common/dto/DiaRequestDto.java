package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DiaRequestDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String userId;
	private String roleCode;
	private Boolean finalSubmit;
	private String claimNumber;
	private DiaDetailsDto diaDetails;
	private List<DiaQuotationDetailsDto> diQuotationDetails;
	private DiaRequestDetailsDto diaRequestDetails;
	private DiaCreationDto diaCreation;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public Boolean getFinalSubmit() {
		return finalSubmit;
	}
	public void setFinalSubmit(Boolean finalSubmit) {
		this.finalSubmit = finalSubmit;
	}
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public DiaDetailsDto getDiaDetails() {
		return diaDetails;
	}
	public void setDiaDetails(DiaDetailsDto diaDetails) {
		this.diaDetails = diaDetails;
	}
	public List<DiaQuotationDetailsDto> getDiQuotationDetails() {
		return diQuotationDetails;
	}
	public void setDiQuotationDetails(List<DiaQuotationDetailsDto> diQuotationDetails) {
		this.diQuotationDetails = diQuotationDetails;
	}
	public DiaRequestDetailsDto getDiaRequestDetails() {
		return diaRequestDetails;
	}
	public void setDiaRequestDetails(DiaRequestDetailsDto diaRequestDetails) {
		this.diaRequestDetails = diaRequestDetails;
	}
	public DiaCreationDto getDiaCreation() {
		return diaCreation;
	}
	public void setDiaCreation(DiaCreationDto diaCreation) {
		this.diaCreation = diaCreation;
	}

}
