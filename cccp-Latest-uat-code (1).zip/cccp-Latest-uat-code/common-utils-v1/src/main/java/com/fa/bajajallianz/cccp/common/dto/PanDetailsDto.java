/**
 * 
 */
package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author santhosh
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PanDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	private String partyId;
	private String claimantName;
	private String claimNumber;
	private String policyNumber;
	private String insuredName;
	private String surveyNo;
	private String ipType;
	private String panNumber;
	private String panDocId;
	private String nameAsPerPan;
	private Boolean isActive;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private ApplicationErrorDto applicationError;
	private List<PanDetailsDto> claimAntListDto;
	private String validFlag;
	private String fullname;
	private String lastDateUpdate;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPartyId() {
		return partyId;
	}
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}
	
	public String getClaimantName() {
		return claimantName;
	}
	public void setClaimantName(String claimantName) {
		this.claimantName = claimantName;
	}
	public String getSurveyNo() {
		return surveyNo;
	}
	public void setSurveyNo(String surveyNo) {
		this.surveyNo = surveyNo;
	}
	public String getIpType() {
		return ipType;
	}
	public void setIpType(String ipType) {
		this.ipType = ipType;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getNameAsPerPan() {
		return nameAsPerPan;
	}
	public void setNameAsPerPan(String nameAsPerPan) {
		this.nameAsPerPan = nameAsPerPan;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getPanDocId() {
		return panDocId;
	}
	public void setPanDocId(String panDocId) {
		this.panDocId = panDocId;
	}
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}
	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}
	public List<PanDetailsDto> getClaimAntListDto() {
		return claimAntListDto;
	}
	public void setClaimAntListDto(List<PanDetailsDto> claimAntListDto) {
		this.claimAntListDto = claimAntListDto;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getInsuredName() {
		return insuredName;
	}
	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}
	public String getValidFlag() {
		return validFlag;
	}
	public void setValidFlag(String validFlag) {
		this.validFlag = validFlag;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getLastDateUpdate() {
		return lastDateUpdate;
	}
	public void setLastDateUpdate(String lastDateUpdate) {
		this.lastDateUpdate = lastDateUpdate;
	}
	
}
