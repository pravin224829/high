package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class HomeLossDetailsDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String itemDescription;
	private String othersItemDescription;
	private String causeOfLoss;
	private String sectionAffected;
	private String contentsCategory;

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getOthersItemDescription() {
		return othersItemDescription;
	}

	public void setOthersItemDescription(String othersItemDescription) {
		this.othersItemDescription = othersItemDescription;
	}

	public String getCauseOfLoss() {
		return causeOfLoss;
	}

	public void setCauseOfLoss(String causeOfLoss) {
		this.causeOfLoss = causeOfLoss;
	}

	public String getSectionAffected() {
		return sectionAffected;
	}

	public void setSectionAffected(String sectionAffected) {
		this.sectionAffected = sectionAffected;
	}

	public String getContentsCategory() {
		return contentsCategory;
	}

	public void setContentsCategory(String contentsCategory) {
		this.contentsCategory = contentsCategory;
	}

}
