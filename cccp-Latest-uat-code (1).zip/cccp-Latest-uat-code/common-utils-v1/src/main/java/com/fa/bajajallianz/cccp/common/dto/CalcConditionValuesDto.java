package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

public class CalcConditionValuesDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3176916742729094215L;

	private Double minAmount;

	private Double maxAmount;

	private Double staticAmount;

	public Double getMinAmount() {
		return minAmount;
	}

	public void setMinAmount(Double minAmount) {
		this.minAmount = minAmount;
	}

	public Double getMaxAmount() {
		return maxAmount;
	}

	public void setMaxAmount(Double maxAmount) {
		this.maxAmount = maxAmount;
	}

	public Double getStaticAmount() {
		return staticAmount;
	}

	public void setStaticAmount(Double staticAmount) {
		this.staticAmount = staticAmount;
	}

}
