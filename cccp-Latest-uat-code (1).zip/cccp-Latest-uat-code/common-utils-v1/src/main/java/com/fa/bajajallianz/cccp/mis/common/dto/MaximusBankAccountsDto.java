package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.List;

public class MaximusBankAccountsDto implements Serializable{

private static final long serialVersionUID = 1L;


private List<MaximusBankingDetailsDto> bankingDetails;


public List<MaximusBankingDetailsDto> getBankingDetails() {
	return bankingDetails;
}


public void setBankingDetails(List<MaximusBankingDetailsDto> bankingDetails) {
	this.bankingDetails = bankingDetails;
}


}
