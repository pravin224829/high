package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fa.bajajallianz.cccp.common.dto.InvoiceDetailsDto;

public class CalcDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String referenceNo;
	private String surveyorCategory;
	private String calculationLob;
	private String lossReserveAmount;
	private String assessedLossAmount;
	private String selectedValue;
	private String calculatedValue;
	private String allowedValue;
	private CalcSummaryDetailsDto gstDetails;
	private List<CalcParamValuesDto> calcParamValues;
	public String getReferenceNo() {
		return referenceNo;
	}
	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}
	public String getSurveyorCategory() {
		return surveyorCategory;
	}
	public void setSurveyorCategory(String surveyorCategory) {
		this.surveyorCategory = surveyorCategory;
	}
	public String getCalculationLob() {
		return calculationLob;
	}
	public void setCalculationLob(String calculationLob) {
		this.calculationLob = calculationLob;
	}
	public String getLossReserveAmount() {
		return lossReserveAmount;
	}
	public void setLossReserveAmount(String lossReserveAmount) {
		this.lossReserveAmount = lossReserveAmount;
	}
	public String getAssessedLossAmount() {
		return assessedLossAmount;
	}
	public void setAssessedLossAmount(String assessedLossAmount) {
		this.assessedLossAmount = assessedLossAmount;
	}
	public String getSelectedValue() {
		return selectedValue;
	}
	public void setSelectedValue(String selectedValue) {
		this.selectedValue = selectedValue;
	}
	public String getCalculatedValue() {
		return calculatedValue;
	}
	public void setCalculatedValue(String calculatedValue) {
		this.calculatedValue = calculatedValue;
	}
	public String getAllowedValue() {
		return allowedValue;
	}
	public void setAllowedValue(String allowedValue) {
		this.allowedValue = allowedValue;
	}
	public CalcSummaryDetailsDto getGstDetails() {
		return gstDetails;
	}
	public void setGstDetails(CalcSummaryDetailsDto gstDetails) {
		this.gstDetails = gstDetails;
	}
	public List<CalcParamValuesDto> getCalcParamValues() {
		return calcParamValues;
	}
	public void setCalcParamValues(List<CalcParamValuesDto> calcParamValues) {
		this.calcParamValues = calcParamValues;
	}
	
}
