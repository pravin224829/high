package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

public class RptClaimSettlementRatioDto implements Serializable{

	private static final long serialVersionUID = 1L;

	private String lob;
	private String totalClaims;
	private String openClaims;
	private String onrPercentage;
	
	
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getTotalClaims() {
		return totalClaims;
	}
	public void setTotalClaims(String totalClaims) {
		this.totalClaims = totalClaims;
	}
	public String getOpenClaims() {
		return openClaims;
	}
	public void setOpenClaims(String openClaims) {
		this.openClaims = openClaims;
	}
	public String getOnrPercentage() {
		return onrPercentage;
	}
	public void setOnrPercentage(String onrPercentage) {
		this.onrPercentage = onrPercentage;
	}
	
	
	
}
