/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimStatusHistoryDto implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String modifiedDate;
	private String modifiedBy;
	private String message;
	private String status;
	private String subStatus;
	private String deficiencyReason;
	private String triggerSms;
	private String triggerEmail;
	private String delayReason;
	
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSubStatus() {
		return subStatus;
	}
	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}
	public String getDeficiencyReason() {
		return deficiencyReason;
	}
	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}
	public String getTriggerSms() {
		return triggerSms;
	}
	public void setTriggerSms(String triggerSms) {
		this.triggerSms = triggerSms;
	}
	public String getTriggerEmail() {
		return triggerEmail;
	}
	public void setTriggerEmail(String triggerEmail) {
		this.triggerEmail = triggerEmail;
	}
	public String getDelayReason() {
		return delayReason;
	}
	public void setDelayReason(String delayReason) {
		this.delayReason = delayReason;
	}
	
}
