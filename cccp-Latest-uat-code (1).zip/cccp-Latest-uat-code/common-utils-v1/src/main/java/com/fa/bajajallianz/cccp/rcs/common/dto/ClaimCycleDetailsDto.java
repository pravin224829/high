package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimCycleDetailsDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String claimNumber;
	private List<ClaimCycleDetailsResponseDto> claimCycleDetails;

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public List<ClaimCycleDetailsResponseDto> getClaimCycleDetails() {
		return claimCycleDetails;
	}

	public void setClaimCycleDetails(List<ClaimCycleDetailsResponseDto> claimCycleDetails) {
		this.claimCycleDetails = claimCycleDetails;
	}

}
