package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

public class MaximusInsuredInfoDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String strRiskSerialNumber;
	private String strRiskSumInsured;
	private String baseCurrency;
	private String strPartyCode;
	private String strEventCode;
	private String strRiskCode;
	private String strDiscount;
	private String strLoading;
	private String strRiskDesc;
	private String premCurrency;
	private String strRiskInceptionDate;
	private String strRiskExpiryDate;
	private String relationToInsured;
	private String riskPlan;
	private String polExpDate;
	private String leadingCover;
	private String isInsuredSameAsPolHolder;
	private String polInceptionDate;
	private String ped;
	private String smokeOrConsumeTobaco;
	private String drinkAlcohol;
	private String doUseRecreationalDrug;
	private String insuranceDetails;
	private String claimDetails;
	private String priorityMember;
	private String memberType;
	private String insuredName;
	private String categoryName;
	private String visaApplicationNumber;
	private String sponserName;
	private String sponserContact;
	private String medicalCheck;
	private String perTripLimitInDays;
	private String totalTripDurationInDays;
	private String policyRefNo;
	private String guidedTours;
	private String childPolicyMaxDuration;
	private String masterPlanName;
	private String masterPolicyType;
	private String riskLevelTransactionCurrencyForSumInsured;
	private String employeeNumber;
	private String dateOfBirth;
	private String firstName;
	private String middleName;
	private String lastName;
	private String totalStayOverseasinDays;
	private String totalSumInsured;
	private String riskSumInsuredinTransactionCurrency;
	private String bondSumInsured;
	private String riskSumInsuredinBaseCurrency;
	private String typeofTag;
	private String breedName;
	private String leftHorn;
	private String noOfLactation;
	private String animalPurposeofUse;
	private String tagNumber;
	private String animalSex;
	private String rightHorn;
	private String species;
	private String bodyColor;
	private String otherCompanyName;
	private String otherSpecies;
	private String tailSwitchColor;
	private String ageTermUnit;
	private String descriptionoftheAnimal;
	private String age;
	private String identification;

	public String getStrRiskSerialNumber() {
		return strRiskSerialNumber;
	}

	public void setStrRiskSerialNumber(String strRiskSerialNumber) {
		this.strRiskSerialNumber = strRiskSerialNumber;
	}

	public String getStrRiskSumInsured() {
		return strRiskSumInsured;
	}

	public void setStrRiskSumInsured(String strRiskSumInsured) {
		this.strRiskSumInsured = strRiskSumInsured;
	}

	public String getBaseCurrency() {
		return baseCurrency;
	}

	public void setBaseCurrency(String baseCurrency) {
		this.baseCurrency = baseCurrency;
	}

	public String getStrPartyCode() {
		return strPartyCode;
	}

	public void setStrPartyCode(String strPartyCode) {
		this.strPartyCode = strPartyCode;
	}

	public String getStrEventCode() {
		return strEventCode;
	}

	public void setStrEventCode(String strEventCode) {
		this.strEventCode = strEventCode;
	}

	public String getStrRiskCode() {
		return strRiskCode;
	}

	public void setStrRiskCode(String strRiskCode) {
		this.strRiskCode = strRiskCode;
	}

	public String getStrDiscount() {
		return strDiscount;
	}

	public void setStrDiscount(String strDiscount) {
		this.strDiscount = strDiscount;
	}

	public String getStrLoading() {
		return strLoading;
	}

	public void setStrLoading(String strLoading) {
		this.strLoading = strLoading;
	}

	public String getStrRiskDesc() {
		return strRiskDesc;
	}

	public void setStrRiskDesc(String strRiskDesc) {
		this.strRiskDesc = strRiskDesc;
	}

	public String getPremCurrency() {
		return premCurrency;
	}

	public void setPremCurrency(String premCurrency) {
		this.premCurrency = premCurrency;
	}

	public String getStrRiskInceptionDate() {
		return strRiskInceptionDate;
	}

	public void setStrRiskInceptionDate(String strRiskInceptionDate) {
		this.strRiskInceptionDate = strRiskInceptionDate;
	}

	public String getStrRiskExpiryDate() {
		return strRiskExpiryDate;
	}

	public void setStrRiskExpiryDate(String strRiskExpiryDate) {
		this.strRiskExpiryDate = strRiskExpiryDate;
	}

	public String getRelationToInsured() {
		return relationToInsured;
	}

	public void setRelationToInsured(String relationToInsured) {
		this.relationToInsured = relationToInsured;
	}

	public String getRiskPlan() {
		return riskPlan;
	}

	public void setRiskPlan(String riskPlan) {
		this.riskPlan = riskPlan;
	}

	public String getPolExpDate() {
		return polExpDate;
	}

	public void setPolExpDate(String polExpDate) {
		this.polExpDate = polExpDate;
	}

	public String getLeadingCover() {
		return leadingCover;
	}

	public void setLeadingCover(String leadingCover) {
		this.leadingCover = leadingCover;
	}

	public String getIsInsuredSameAsPolHolder() {
		return isInsuredSameAsPolHolder;
	}

	public void setIsInsuredSameAsPolHolder(String isInsuredSameAsPolHolder) {
		this.isInsuredSameAsPolHolder = isInsuredSameAsPolHolder;
	}

	public String getPolInceptionDate() {
		return polInceptionDate;
	}

	public void setPolInceptionDate(String polInceptionDate) {
		this.polInceptionDate = polInceptionDate;
	}

	public String getPed() {
		return ped;
	}

	public void setPed(String ped) {
		this.ped = ped;
	}

	public String getSmokeOrConsumeTobaco() {
		return smokeOrConsumeTobaco;
	}

	public void setSmokeOrConsumeTobaco(String smokeOrConsumeTobaco) {
		this.smokeOrConsumeTobaco = smokeOrConsumeTobaco;
	}

	public String getDrinkAlcohol() {
		return drinkAlcohol;
	}

	public void setDrinkAlcohol(String drinkAlcohol) {
		this.drinkAlcohol = drinkAlcohol;
	}

	public String getDoUseRecreationalDrug() {
		return doUseRecreationalDrug;
	}

	public void setDoUseRecreationalDrug(String doUseRecreationalDrug) {
		this.doUseRecreationalDrug = doUseRecreationalDrug;
	}

	public String getInsuranceDetails() {
		return insuranceDetails;
	}

	public void setInsuranceDetails(String insuranceDetails) {
		this.insuranceDetails = insuranceDetails;
	}

	public String getClaimDetails() {
		return claimDetails;
	}

	public void setClaimDetails(String claimDetails) {
		this.claimDetails = claimDetails;
	}

	public String getPriorityMember() {
		return priorityMember;
	}

	public void setPriorityMember(String priorityMember) {
		this.priorityMember = priorityMember;
	}

	public String getMemberType() {
		return memberType;
	}

	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getVisaApplicationNumber() {
		return visaApplicationNumber;
	}

	public void setVisaApplicationNumber(String visaApplicationNumber) {
		this.visaApplicationNumber = visaApplicationNumber;
	}

	public String getSponserName() {
		return sponserName;
	}

	public void setSponserName(String sponserName) {
		this.sponserName = sponserName;
	}

	public String getSponserContact() {
		return sponserContact;
	}

	public void setSponserContact(String sponserContact) {
		this.sponserContact = sponserContact;
	}

	public String getMedicalCheck() {
		return medicalCheck;
	}

	public void setMedicalCheck(String medicalCheck) {
		this.medicalCheck = medicalCheck;
	}

	public String getPerTripLimitInDays() {
		return perTripLimitInDays;
	}

	public void setPerTripLimitInDays(String perTripLimitInDays) {
		this.perTripLimitInDays = perTripLimitInDays;
	}

	public String getTotalTripDurationInDays() {
		return totalTripDurationInDays;
	}

	public void setTotalTripDurationInDays(String totalTripDurationInDays) {
		this.totalTripDurationInDays = totalTripDurationInDays;
	}

	public String getPolicyRefNo() {
		return policyRefNo;
	}

	public void setPolicyRefNo(String policyRefNo) {
		this.policyRefNo = policyRefNo;
	}

	public String getGuidedTours() {
		return guidedTours;
	}

	public void setGuidedTours(String guidedTours) {
		this.guidedTours = guidedTours;
	}

	public String getChildPolicyMaxDuration() {
		return childPolicyMaxDuration;
	}

	public void setChildPolicyMaxDuration(String childPolicyMaxDuration) {
		this.childPolicyMaxDuration = childPolicyMaxDuration;
	}

	public String getMasterPlanName() {
		return masterPlanName;
	}

	public void setMasterPlanName(String masterPlanName) {
		this.masterPlanName = masterPlanName;
	}

	public String getMasterPolicyType() {
		return masterPolicyType;
	}

	public void setMasterPolicyType(String masterPolicyType) {
		this.masterPolicyType = masterPolicyType;
	}

	public String getRiskLevelTransactionCurrencyForSumInsured() {
		return riskLevelTransactionCurrencyForSumInsured;
	}

	public void setRiskLevelTransactionCurrencyForSumInsured(String riskLevelTransactionCurrencyForSumInsured) {
		this.riskLevelTransactionCurrencyForSumInsured = riskLevelTransactionCurrencyForSumInsured;
	}

	public String getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(String employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getTotalStayOverseasinDays() {
		return totalStayOverseasinDays;
	}

	public void setTotalStayOverseasinDays(String totalStayOverseasinDays) {
		this.totalStayOverseasinDays = totalStayOverseasinDays;
	}

	public String getTotalSumInsured() {
		return totalSumInsured;
	}

	public void setTotalSumInsured(String totalSumInsured) {
		this.totalSumInsured = totalSumInsured;
	}

	public String getRiskSumInsuredinTransactionCurrency() {
		return riskSumInsuredinTransactionCurrency;
	}

	public void setRiskSumInsuredinTransactionCurrency(String riskSumInsuredinTransactionCurrency) {
		this.riskSumInsuredinTransactionCurrency = riskSumInsuredinTransactionCurrency;
	}

	public String getBondSumInsured() {
		return bondSumInsured;
	}

	public void setBondSumInsured(String bondSumInsured) {
		this.bondSumInsured = bondSumInsured;
	}

	public String getRiskSumInsuredinBaseCurrency() {
		return riskSumInsuredinBaseCurrency;
	}

	public void setRiskSumInsuredinBaseCurrency(String riskSumInsuredinBaseCurrency) {
		this.riskSumInsuredinBaseCurrency = riskSumInsuredinBaseCurrency;
	}

	public String getTypeofTag() {
		return typeofTag;
	}

	public void setTypeofTag(String typeofTag) {
		this.typeofTag = typeofTag;
	}

	public String getBreedName() {
		return breedName;
	}

	public void setBreedName(String breedName) {
		this.breedName = breedName;
	}

	public String getLeftHorn() {
		return leftHorn;
	}

	public void setLeftHorn(String leftHorn) {
		this.leftHorn = leftHorn;
	}

	public String getNoOfLactation() {
		return noOfLactation;
	}

	public void setNoOfLactation(String noOfLactation) {
		this.noOfLactation = noOfLactation;
	}

	public String getAnimalPurposeofUse() {
		return animalPurposeofUse;
	}

	public void setAnimalPurposeofUse(String animalPurposeofUse) {
		this.animalPurposeofUse = animalPurposeofUse;
	}

	public String getTagNumber() {
		return tagNumber;
	}

	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}

	public String getAnimalSex() {
		return animalSex;
	}

	public void setAnimalSex(String animalSex) {
		this.animalSex = animalSex;
	}

	public String getRightHorn() {
		return rightHorn;
	}

	public void setRightHorn(String rightHorn) {
		this.rightHorn = rightHorn;
	}

	public String getSpecies() {
		return species;
	}

	public void setSpecies(String species) {
		this.species = species;
	}

	public String getBodyColor() {
		return bodyColor;
	}

	public void setBodyColor(String bodyColor) {
		this.bodyColor = bodyColor;
	}

	public String getOtherCompanyName() {
		return otherCompanyName;
	}

	public void setOtherCompanyName(String otherCompanyName) {
		this.otherCompanyName = otherCompanyName;
	}

	public String getOtherSpecies() {
		return otherSpecies;
	}

	public void setOtherSpecies(String otherSpecies) {
		this.otherSpecies = otherSpecies;
	}

	public String getTailSwitchColor() {
		return tailSwitchColor;
	}

	public void setTailSwitchColor(String tailSwitchColor) {
		this.tailSwitchColor = tailSwitchColor;
	}

	public String getAgeTermUnit() {
		return ageTermUnit;
	}

	public void setAgeTermUnit(String ageTermUnit) {
		this.ageTermUnit = ageTermUnit;
	}

	public String getDescriptionoftheAnimal() {
		return descriptionoftheAnimal;
	}

	public void setDescriptionoftheAnimal(String descriptionoftheAnimal) {
		this.descriptionoftheAnimal = descriptionoftheAnimal;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getIdentification() {
		return identification;
	}

	public void setIdentification(String identification) {
		this.identification = identification;
	}
	
	
	
	
}
