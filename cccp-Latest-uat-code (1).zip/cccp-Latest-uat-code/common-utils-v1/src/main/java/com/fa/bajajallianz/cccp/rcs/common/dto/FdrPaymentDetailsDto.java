/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author santhosh
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FdrPaymentDetailsDto implements Serializable{

	private static final long serialVersionUID = 1L;
	private String fdrFavour;
	private String address;
	private String tenure;
	private String amount;
	
	public String getFdrFavour() {
		return fdrFavour;
	}
	public void setFdrFavour(String fdrFavour) {
		this.fdrFavour = fdrFavour;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTenure() {
		return tenure;
	}
	public void setTenure(String tenure) {
		this.tenure = tenure;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	  
}
