package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

public class GSTDetailsDto implements Serializable{

	private static final long serialVersionUID = 1L;
//	private String sgstPercentage;
//	private String cgstPercentage;
//	private String igstPercentage;
//	private String ugstPercentage;
	private String sgctRate;
	private String cgctRate;
	private String igctRate;
	private String utgctRate;
	private String nccRate;
	private String taxCode;
	private String errorMsg;
	
	public String getSgctRate() {
		return sgctRate;
	}
	public void setSgctRate(String sgctRate) {
		this.sgctRate = sgctRate;
	}
	public String getCgctRate() {
		return cgctRate;
	}
	public void setCgctRate(String cgctRate) {
		this.cgctRate = cgctRate;
	}
	public String getIgctRate() {
		return igctRate;
	}
	public void setIgctRate(String igctRate) {
		this.igctRate = igctRate;
	}
	public String getUtgctRate() {
		return utgctRate;
	}
	public void setUtgctRate(String utgctRate) {
		this.utgctRate = utgctRate;
	}
	public String getNccRate() {
		return nccRate;
	}
	public void setNccRate(String nccRate) {
		this.nccRate = nccRate;
	}
	public String getTaxCode() {
		return taxCode;
	}
	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

}
