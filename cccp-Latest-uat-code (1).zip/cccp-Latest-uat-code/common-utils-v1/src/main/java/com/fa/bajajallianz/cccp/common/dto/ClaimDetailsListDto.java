package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimDetailsListDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String policyNumber;
	private String insuredName;
	private String imdchannel;
	private String dateOfLoss;
	private String placeOfLoss;
	private String lossDescriptions;
	private String claimNumber;
	private String productCode;
	private String productName;
	private String sumInsured;
	private String status;
	private String agentCode;
	private String intimationDate;
	private String registrationDate;
	private String currentStepId;
	private String subStatus;
	private String claimRefNo;
	private String estimatedLossAmt;
	private String mobileNo;
	private String custEmailId;
	private String newPlaceOfLoss;

	
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getCustEmailId() {
		return custEmailId;
	}
	public void setCustEmailId(String custEmailId) {
		this.custEmailId = custEmailId;
	}
	public String getNewPlaceOfLoss() {
		return newPlaceOfLoss;
	}
	public void setNewPlaceOfLoss(String newPlaceOfLoss) {
		this.newPlaceOfLoss = newPlaceOfLoss;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getInsuredName() {
		return insuredName;
	}
	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}
	public String getImdchannel() {
		return imdchannel;
	}
	public void setImdchannel(String imdchannel) {
		this.imdchannel = imdchannel;
	}
	public String getDateOfLoss() {
		return dateOfLoss;
	}
	public void setDateOfLoss(String dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}
	public String getPlaceOfLoss() {
		return placeOfLoss;
	}
	public void setPlaceOfLoss(String placeOfLoss) {
		this.placeOfLoss = placeOfLoss;
	}
	public String getLossDescriptions() {
		return lossDescriptions;
	}
	public void setLossDescriptions(String lossDescriptions) {
		this.lossDescriptions = lossDescriptions;
	}
	public String getClaimNumber() {
		return claimNumber;
	}
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getSumInsured() {
		return sumInsured;
	}
	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public String getIntimationDate() {
		return intimationDate;
	}
	public void setIntimationDate(String intimationDate) {
		this.intimationDate = intimationDate;
	}
	public String getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}
	public String getCurrentStepId() {
		return currentStepId;
	}
	public void setCurrentStepId(String currentStepId) {
		this.currentStepId = currentStepId;
	}
	public String getSubStatus() {
		return subStatus;
	}
	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}
	public String getClaimRefNo() {
		return claimRefNo;
	}
	public void setClaimRefNo(String claimRefNo) {
		this.claimRefNo = claimRefNo;
	}
	public String getEstimatedLossAmt() {
		return estimatedLossAmt;
	}
	public void setEstimatedLossAmt(String estimatedLossAmt) {
		this.estimatedLossAmt = estimatedLossAmt;
	}
	
	
}
