/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Arul
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DiaDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String diaRefNumber;
	private String isSalvageStatus;
	private Boolean isSalvageDisabled;
	private String declarationStatus;
	private String declarationDate;
	private String declaredBy;
	private String diaRefCreatedDate;
	private String diaStatus;
	private String declarationsRemarks;
	private String diaApprovalAuthority;
	private String docId;
	private String docName;
	private String diaType;
	
	public String getDiaRefNumber() {
		return diaRefNumber;
	}
	public void setDiaRefNumber(String diaRefNumber) {
		this.diaRefNumber = diaRefNumber;
	}
	public String getIsSalvageStatus() {
		return isSalvageStatus;
	}
	public void setIsSalvageStatus(String isSalvageStatus) {
		this.isSalvageStatus = isSalvageStatus;
	}
	public Boolean getIsSalvageDisabled() {
		return isSalvageDisabled;
	}
	public void setIsSalvageDisabled(Boolean isSalvageDisabled) {
		this.isSalvageDisabled = isSalvageDisabled;
	}
	public String getDeclarationStatus() {
		return declarationStatus;
	}
	public void setDeclarationStatus(String declarationStatus) {
		this.declarationStatus = declarationStatus;
	}
	public String getDeclarationDate() {
		return declarationDate;
	}
	public void setDeclarationDate(String declarationDate) {
		this.declarationDate = declarationDate;
	}
	public String getDeclaredBy() {
		return declaredBy;
	}
	public void setDeclaredBy(String declaredBy) {
		this.declaredBy = declaredBy;
	}
	public String getDiaRefCreatedDate() {
		return diaRefCreatedDate;
	}
	public void setDiaRefCreatedDate(String diaRefCreatedDate) {
		this.diaRefCreatedDate = diaRefCreatedDate;
	}
	public String getDiaStatus() {
		return diaStatus;
	}
	public void setDiaStatus(String diaStatus) {
		this.diaStatus = diaStatus;
	}
	public String getDeclarationsRemarks() {
		return declarationsRemarks;
	}
	public void setDeclarationsRemarks(String declarationsRemarks) {
		this.declarationsRemarks = declarationsRemarks;
	}
	public String getDiaApprovalAuthority() {
		return diaApprovalAuthority;
	}
	public void setDiaApprovalAuthority(String diaApprovalAuthority) {
		this.diaApprovalAuthority = diaApprovalAuthority;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getDiaType() {
		return diaType;
	}
	public void setDiaType(String diaType) {
		this.diaType = diaType;
	}
	
}
