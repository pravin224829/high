package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

public class CkycSearchRespObjDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String age;

	private String ckyc_number;

	private String father_name;

	private String full_name;

	private String image;

	private String image_type;

	private String kyc_date;

	private String update_date;

	private String error_cd;

	private String message;

	private String gender;

	private String dob;

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getCkyc_number() {
		return ckyc_number;
	}

	public void setCkyc_number(String ckyc_number) {
		this.ckyc_number = ckyc_number;
	}

	public String getFather_name() {
		return father_name;
	}

	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}

	public String getFull_name() {
		return full_name;
	}

	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getImage_type() {
		return image_type;
	}

	public void setImage_type(String image_type) {
		this.image_type = image_type;
	}

	public String getKyc_date() {
		return kyc_date;
	}

	public void setKyc_date(String kyc_date) {
		this.kyc_date = kyc_date;
	}

	public String getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(String update_date) {
		this.update_date = update_date;
	}

	public String getError_cd() {
		return error_cd;
	}

	public void setError_cd(String error_cd) {
		this.error_cd = error_cd;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

}
