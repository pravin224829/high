package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fa.bajajallianz.cccp.common.dto.CalcConditionValuesDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CalcHeadsAttributesDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String code;
	private String attributes;
	private String name;
	private String objName;
	private String authorityCode;
	private String description;
	private String calcHeads;
//	private String calcHeadsFormula;
	private String orderNo;
	private String value;
	private String calculatedValue;
	private String allowedValue;
	private String boldString;
	private List<CalcConditionValuesDto> calcConditionValues;

	private List<CalcFormulaDto> calcHeadsFormula;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getAttributes() {
		return attributes;
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getAuthorityCode() {
		return authorityCode;
	}

	public void setAuthorityCode(String authorityCode) {
		this.authorityCode = authorityCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCalcHeads() {
		return calcHeads;
	}

	public void setCalcHeads(String calcHeads) {
		this.calcHeads = calcHeads;
	}

//	public String getCalcHeadsFormula() {
//		return calcHeadsFormula;
//	}
//
//	public void setCalcHeadsFormula(String calcHeadsFormula) {
//		this.calcHeadsFormula = calcHeadsFormula;
//	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public List<CalcFormulaDto> getCalcHeadsFormula() {
		return calcHeadsFormula;
	}

	public void setCalcHeadsFormula(List<CalcFormulaDto> calcHeadsFormula) {
		this.calcHeadsFormula = calcHeadsFormula;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCalculatedValue() {
		return calculatedValue;
	}

	public void setCalculatedValue(String calculatedValue) {
		this.calculatedValue = calculatedValue;
	}

	public String getAllowedValue() {
		return allowedValue;
	}

	public void setAllowedValue(String allowedValue) {
		this.allowedValue = allowedValue;
	}

	public String getBoldString() {
		return boldString;
	}

	public void setBoldString(String boldString) {
		this.boldString = boldString;
	}

	public List<CalcConditionValuesDto> getCalcConditionValues() {
		return calcConditionValues;
	}

	public void setCalcConditionValues(List<CalcConditionValuesDto> calcConditionValues) {
		this.calcConditionValues = calcConditionValues;
	}

}
