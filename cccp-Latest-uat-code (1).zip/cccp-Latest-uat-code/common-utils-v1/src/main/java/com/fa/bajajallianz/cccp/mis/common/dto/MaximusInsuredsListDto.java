package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.List;

public class MaximusInsuredsListDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<MaximusInsuredDetailsDto> insuredDetails;

	public List<MaximusInsuredDetailsDto> getInsuredDetails() {
		return insuredDetails;
	}

	public void setInsuredDetails(List<MaximusInsuredDetailsDto> insuredDetails) {
		this.insuredDetails = insuredDetails;
	}

}
