package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fa.bajajallianz.cccp.mis.common.dto.CreatePartyResponseDetailDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusIFSCDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusPincodeDetailDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcHeadsAttributesDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CkycSearchRespObjDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimantDetailsListDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CountryDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.EndorsementDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.LinkResponseDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.OpusRefObj;
import com.fa.bajajallianz.cccp.rcs.common.dto.PastClaimHistoryDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.PaymentDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.PaymentDtlsRespDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.RcsClaimantDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.RptClaimSettlementRatioDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.SectionDtlsResponseDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.SupplierDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.TaskDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.WorkFlowDto;
import com.fa.bajajallianz.cccp.surveyor.common.dto.ClaimReviewDetailsDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonResponseDto<T> implements Serializable {

	private static final long serialVersionUID = 1L;

	private T responseData;
	private String message;
	private String status;
	private String statusCode;
	private String error;
	private String errorDescription;
	private ApplicationErrorDto applicationError;
	private List<String> errorDescriptions;
	private List<String> remarks;
	private String responseStatus;
	private String responseMessage;
	private String description;
	private String errorCode;
	private String claimRefNo;
	private String claimNumber;
	private ClaimDetailsDto claimDetailsDto;
	private String messageId;
	private String encodeString;
	private String total;
	private String docId;
	private String messageCode;
	private String recordNo;
	private String claimNo;
	private String base64str;
	private String docIndex;
	private String docName;
	private String docType;
	private String successMessage;
	private String errorMessage;
	private String outstandingCnt;
	private String closedCount;
	private String isActive;
	private String accountNumber;
	private List<StatusCountDto> statusCount;
	private ClaimHeaderDetailsDto claimHeaderDetails;
	private List<LookUpValuesDto> lookupValues;
	private String count;
	private ClaimReviewDetailsDto claimReviewDetails;
	private List<WorkFlowDto> workflow;
	private List<SupplierDetailsDto> supplierDetails;
	private String unReadCount;
	private List<TaskDetailsDto> taskDetails;
	private CalcHeadsAttributesDto calcHeadsAttributes;
	private String insuredPartyId;
	private LinkResponseDto linkResponse;
	private String neftStatus;
	private MobileAppVersionDto mobileApp;
	private String diaRefNo;
	private String paymentRefNo;
	private PaymentDetailsDto paymentDetails;
	private String verificationStatus;
	private String roleCode;
	private String userId;
	private String supplierId;
	private RcsClaimantDetailsDto partyRespObjDto;
	private List<PastClaimHistoryDto> pastClaimHistoryResponseDto;
	private EndorsementDetailsDto endorsementDetailsDto;
	private CkycSearchRespObjDto ckycSearchRespObj;
	private List<SectionDtlsResponseDto> sectionDtlsResponseListDto;
	private String requestMethod;
	private String userName;
	private String partnerId;
	private List<ClaimantDetailsListDto> claimantDtlsList;
	private String currencyMode;
	private String paymentType;
	private String claimSynopsis;
	private List<PaymentDtlsRespDto> paymentDtlsRespDto;
	private String ipNo;
	private String lob;
	private List<CommonMasterDto> micrListDto;
	private RptClaimSettlementRatioDto rptClaimSettlementRatio;
//	private String opusRefNo;
	private List<CountryDto> countryListDto;
	private String encodingUrl;
	private ApplicationErrorDto applicationErr;
	private List<EndorsementDetailsDto> policyEndorsementDtls;
	private List<OpusRefObj> opusRefNo;
	private String documentId;
	private CreatePartyResponseDetailDto createPartyResponseDetail;
	private String paymentId;
	private List<MaximusIFSCDetailsDto> getIFSCDetails;
	private MaximusPincodeDetailDto pincodeDetail;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public CommonResponseDto() {
	}

	public CommonResponseDto(T responseData, String message, String status, String statusCode, String error,
			String errorCode) {
		super();
		this.responseData = responseData;
		this.message = message;
		this.status = status;
		this.statusCode = statusCode;
		this.error = error;

	}

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public T getResponseData() {
		return responseData;
	}

	public void setResponseData(T responseData) {
		this.responseData = responseData;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public List<String> getErrorDescriptions() {
		return errorDescriptions;
	}

	public void setErrorDescriptions(List<String> errorDescriptions) {
		this.errorDescriptions = errorDescriptions;
	}

	public List<String> getRemarks() {
		return remarks;
	}

	public void setRemarks(List<String> remarks) {
		this.remarks = remarks;
	}

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getClaimRefNo() {
		return claimRefNo;
	}

	public void setClaimRefNo(String claimRefNo) {
		this.claimRefNo = claimRefNo;
	}

	public ClaimDetailsDto getClaimDetailsDto() {
		return claimDetailsDto;
	}

	public void setClaimDetailsDto(ClaimDetailsDto claimDetailsDto) {
		this.claimDetailsDto = claimDetailsDto;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getEncodeString() {
		return encodeString;
	}

	public void setEncodeString(String encodeString) {
		this.encodeString = encodeString;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public String getMessageCode() {
		return messageCode;
	}

	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}

	public String getRecordNo() {
		return recordNo;
	}

	public void setRecordNo(String recordNo) {
		this.recordNo = recordNo;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getBase64str() {
		return base64str;
	}

	public void setBase64str(String base64str) {
		this.base64str = base64str;
	}

	public String getDocIndex() {
		return docIndex;
	}

	public void setDocIndex(String docIndex) {
		this.docIndex = docIndex;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getSuccessMessage() {
		return successMessage;
	}

	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getOutstandingCnt() {
		return outstandingCnt;
	}

	public void setOutstandingCnt(String outstandingCnt) {
		this.outstandingCnt = outstandingCnt;
	}

	public String getClosedCount() {
		return closedCount;
	}

	public void setClosedCount(String closedCount) {
		this.closedCount = closedCount;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public List<StatusCountDto> getStatusCount() {
		return statusCount;
	}

	public void setStatusCount(List<StatusCountDto> statusCount) {
		this.statusCount = statusCount;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public ClaimHeaderDetailsDto getClaimHeaderDetails() {
		return claimHeaderDetails;
	}

	public void setClaimHeaderDetails(ClaimHeaderDetailsDto claimHeaderDetailsDto) {
		this.claimHeaderDetails = claimHeaderDetailsDto;
	}

	public List<LookUpValuesDto> getLookupValues() {
		return lookupValues;
	}

	public void setLookupValues(List<LookUpValuesDto> lookupValues) {
		this.lookupValues = lookupValues;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public ClaimReviewDetailsDto getClaimReviewDetails() {
		return claimReviewDetails;
	}

	public void setClaimReviewDetails(ClaimReviewDetailsDto claimReviewDetails) {
		this.claimReviewDetails = claimReviewDetails;
	}

	public List<WorkFlowDto> getWorkflow() {
		return workflow;
	}

	public void setWorkflow(List<WorkFlowDto> workflow) {
		this.workflow = workflow;
	}

	public List<SupplierDetailsDto> getSupplierDetails() {
		return supplierDetails;
	}

	public void setSupplierDetails(List<SupplierDetailsDto> supplierDetails) {
		this.supplierDetails = supplierDetails;
	}

	public String getUnReadCount() {
		return unReadCount;
	}

	public void setUnReadCount(String unReadCount) {
		this.unReadCount = unReadCount;
	}

	public List<TaskDetailsDto> getTaskDetails() {
		return taskDetails;
	}

	public void setTaskDetails(List<TaskDetailsDto> taskDetails) {
		this.taskDetails = taskDetails;
	}

	public CalcHeadsAttributesDto getCalcHeadsAttributes() {
		return calcHeadsAttributes;
	}

	public void setCalcHeadsAttributes(CalcHeadsAttributesDto calcHeadsAttributes) {
		this.calcHeadsAttributes = calcHeadsAttributes;
	}

	public String getInsuredPartyId() {
		return insuredPartyId;
	}

	public void setInsuredPartyId(String insuredPartyId) {
		this.insuredPartyId = insuredPartyId;
	}

	public LinkResponseDto getLinkResponse() {
		return linkResponse;
	}

	public void setLinkResponse(LinkResponseDto linkResponse) {
		this.linkResponse = linkResponse;
	}

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public MobileAppVersionDto getMobileApp() {
		return mobileApp;
	}

	public void setMobileApp(MobileAppVersionDto mobileApp) {
		this.mobileApp = mobileApp;
	}

	public String getDiaRefNo() {
		return diaRefNo;
	}

	public void setDiaRefNo(String diaRefNo) {
		this.diaRefNo = diaRefNo;
	}

	public String getPaymentRefNo() {
		return paymentRefNo;
	}

	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}

	public PaymentDetailsDto getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(PaymentDetailsDto paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	public String getVerificationStatus() {
		return verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public RcsClaimantDetailsDto getPartyRespObjDto() {
		return partyRespObjDto;
	}

	public void setPartyRespObjDto(RcsClaimantDetailsDto partyRespObjDto) {
		this.partyRespObjDto = partyRespObjDto;
	}

	public List<PastClaimHistoryDto> getPastClaimHistoryResponseDto() {
		return pastClaimHistoryResponseDto;
	}

	public void setPastClaimHistoryResponseDto(List<PastClaimHistoryDto> pastClaimHistoryResponseDto) {
		this.pastClaimHistoryResponseDto = pastClaimHistoryResponseDto;
	}

	public EndorsementDetailsDto getEndorsementDetailsDto() {
		return endorsementDetailsDto;
	}

	public void setEndorsementDetailsDto(EndorsementDetailsDto endorsementDetailsDto) {
		this.endorsementDetailsDto = endorsementDetailsDto;
	}

	public CkycSearchRespObjDto getCkycSearchRespObj() {
		return ckycSearchRespObj;
	}

	public void setCkycSearchRespObj(CkycSearchRespObjDto ckycSearchRespObj) {
		this.ckycSearchRespObj = ckycSearchRespObj;
	}

	public List<SectionDtlsResponseDto> getSectionDtlsResponseListDto() {
		return sectionDtlsResponseListDto;
	}

	public void setSectionDtlsResponseListDto(List<SectionDtlsResponseDto> sectionDtlsResponseListDto) {
		this.sectionDtlsResponseListDto = sectionDtlsResponseListDto;
	}

	public String getRequestMethod() {
		return requestMethod;
	}

	public void setRequestMethod(String requestMethod) {
		this.requestMethod = requestMethod;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public List<ClaimantDetailsListDto> getClaimantDtlsList() {
		return claimantDtlsList;
	}

	public void setClaimantDtlsList(List<ClaimantDetailsListDto> claimantDtlsList) {
		this.claimantDtlsList = claimantDtlsList;
	}

	public String getCurrencyMode() {
		return currencyMode;
	}

	public void setCurrencyMode(String currencyMode) {
		this.currencyMode = currencyMode;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getClaimSynopsis() {
		return claimSynopsis;
	}

	public void setClaimSynopsis(String claimSynopsis) {
		this.claimSynopsis = claimSynopsis;
	}

	public List<PaymentDtlsRespDto> getPaymentDtlsRespDto() {
		return paymentDtlsRespDto;
	}

	public void setPaymentDtlsRespDto(List<PaymentDtlsRespDto> paymentDtlsRespDto) {
		this.paymentDtlsRespDto = paymentDtlsRespDto;
	}

	public String getIpNo() {
		return ipNo;
	}

	public void setIpNo(String ipNo) {
		this.ipNo = ipNo;
	}

	public List<CommonMasterDto> getMicrListDto() {
		return micrListDto;
	}

	public void setMicrListDto(List<CommonMasterDto> micrListDto) {
		this.micrListDto = micrListDto;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public RptClaimSettlementRatioDto getRptClaimSettlementRatio() {
		return rptClaimSettlementRatio;
	}

	public void setRptClaimSettlementRatio(RptClaimSettlementRatioDto rptClaimSettlementRatio) {
		this.rptClaimSettlementRatio = rptClaimSettlementRatio;
	}

	public List<CountryDto> getCountryListDto() {
		return countryListDto;
	}

	public void setCountryListDto(List<CountryDto> countryListDto) {
		this.countryListDto = countryListDto;
	}

	public String getEncodingUrl() {
		return encodingUrl;
	}

	public void setEncodingUrl(String encodingUrl) {
		this.encodingUrl = encodingUrl;
	}

	public ApplicationErrorDto getApplicationErr() {
		return applicationErr;
	}

	public void setApplicationErr(ApplicationErrorDto applicationErr) {
		this.applicationErr = applicationErr;
	}

	public List<EndorsementDetailsDto> getPolicyEndorsementDtls() {
		return policyEndorsementDtls;
	}

	public void setPolicyEndorsementDtls(List<EndorsementDetailsDto> policyEndorsementDtls) {
		this.policyEndorsementDtls = policyEndorsementDtls;
	}

	public List<OpusRefObj> getOpusRefNo() {
		return opusRefNo;
	}

	public void setOpusRefNo(List<OpusRefObj> opusRefNo) {
		this.opusRefNo = opusRefNo;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public CreatePartyResponseDetailDto getCreatePartyResponseDetail() {
		return createPartyResponseDetail;
	}

	public void setCreatePartyResponseDetail(CreatePartyResponseDetailDto createPartyResponseDetail) {
		this.createPartyResponseDetail = createPartyResponseDetail;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public List<MaximusIFSCDetailsDto> getGetIFSCDetails() {
		return getIFSCDetails;
	}

	public void setGetIFSCDetails(List<MaximusIFSCDetailsDto> getIFSCDetails) {
		this.getIFSCDetails = getIFSCDetails;
	}

	public MaximusPincodeDetailDto getPincodeDetail() {
		return pincodeDetail;
	}

	public void setPincodeDetail(MaximusPincodeDetailDto pincodeDetail) {
		this.pincodeDetail = pincodeDetail;
	}
	

}
