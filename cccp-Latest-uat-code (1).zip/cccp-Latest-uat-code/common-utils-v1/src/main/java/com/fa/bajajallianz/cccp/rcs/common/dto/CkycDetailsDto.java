package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fa.bajajallianz.cccp.common.dto.DocumentDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CkycDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;
	private String claimNumber;
	private String partyId;
	private String partyType;
	private String kycType;
	private String kycDocType;
	private String kycVerifyType;
	private String kycNumber;
	private String kycVerifyNumber;
	private String docHolderName;
	private Boolean isVerificationRequired;
	private String ipNo;
	private String subType;
	private String partnerID;
	private String nameOfInterestedParties;
	private String panNumber;
	private String status;
	private List<DocumentDto> docIdList;
	private String proofOfAddress;
	private String proofOfIdentity;
	private String pan;
	private String ckyc;
	private String poi;
	private String poa;
	private String docId;
	private String partnerId;
	private String partnerName;
	private String partnerType;
	private String taxId;
	private String email;
	private String telephone;
	private String ckycNo;
	private String ckycStatus;
	private String ckycUuid;
	private String aml;
	private String amlVerifiedName;
	private String neftStatus;
	private String nameAsPerCkyc;
	private String nameAsPerPanVerify;
	private String ipType;
	private List<DocumentDto> poiDocList;
	private List<DocumentDto> poaDocList;

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getPartnerType() {
		return partnerType;
	}

	public void setPartnerType(String partnerType) {
		this.partnerType = partnerType;
	}

	public String getTaxId() {
		return taxId;
	}

	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getCkycNo() {
		return ckycNo;
	}

	public void setCkycNo(String ckycNo) {
		this.ckycNo = ckycNo;
	}

	public String getCkycStatus() {
		return ckycStatus;
	}

	public void setCkycStatus(String ckycStatus) {
		this.ckycStatus = ckycStatus;
	}

	public String getCkycUuid() {
		return ckycUuid;
	}

	public void setCkycUuid(String ckycUuid) {
		this.ckycUuid = ckycUuid;
	}

	public String getAml() {
		return aml;
	}

	public void setAml(String aml) {
		this.aml = aml;
	}

	public String getAmlVerifiedName() {
		return amlVerifiedName;
	}

	public void setAmlVerifiedName(String amlVerifiedName) {
		this.amlVerifiedName = amlVerifiedName;
	}

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public String getNameAsPerCkyc() {
		return nameAsPerCkyc;
	}

	public void setNameAsPerCkyc(String nameAsPerCkyc) {
		this.nameAsPerCkyc = nameAsPerCkyc;
	}

	public String getNameAsPerPanVerify() {
		return nameAsPerPanVerify;
	}

	public void setNameAsPerPanVerify(String nameAsPerPanVerify) {
		this.nameAsPerPanVerify = nameAsPerPanVerify;
	}

	public String getIpType() {
		return ipType;
	}

	public void setIpType(String ipType) {
		this.ipType = ipType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getPartyType() {
		return partyType;
	}

	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}

	public String getKycType() {
		return kycType;
	}

	public void setKycType(String kycType) {
		this.kycType = kycType;
	}

	public String getKycDocType() {
		return kycDocType;
	}

	public void setKycDocType(String kycDocType) {
		this.kycDocType = kycDocType;
	}

	public String getKycNumber() {
		return kycNumber;
	}

	public void setKycNumber(String kycNumber) {
		this.kycNumber = kycNumber;
	}

	public String getDocHolderName() {
		return docHolderName;
	}

	public void setDocHolderName(String docHolderName) {
		this.docHolderName = docHolderName;
	}

	public Boolean getIsVerificationRequired() {
		return isVerificationRequired;
	}

	public void setIsVerificationRequired(Boolean isVerificationRequired) {
		this.isVerificationRequired = isVerificationRequired;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public List<DocumentDto> getDocIdList() {
		return docIdList;
	}

	public void setDocIdList(List<DocumentDto> docIdList) {
		this.docIdList = docIdList;
	}

	public String getIpNo() {
		return ipNo;
	}

	public void setIpNo(String ipNo) {
		this.ipNo = ipNo;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getPartnerID() {
		return partnerID;
	}

	public void setPartnerID(String partnerID) {
		this.partnerID = partnerID;
	}

	public String getNameOfInterestedParties() {
		return nameOfInterestedParties;
	}

	public void setNameOfInterestedParties(String nameOfInterestedParties) {
		this.nameOfInterestedParties = nameOfInterestedParties;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getProofOfAddress() {
		return proofOfAddress;
	}

	public void setProofOfAddress(String proofOfAddress) {
		this.proofOfAddress = proofOfAddress;
	}

	public String getProofOfIdentity() {
		return proofOfIdentity;
	}

	public void setProofOfIdentity(String proofOfIdentity) {
		this.proofOfIdentity = proofOfIdentity;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getCkyc() {
		return ckyc;
	}

	public void setCkyc(String ckyc) {
		this.ckyc = ckyc;
	}

	public String getPoi() {
		return poi;
	}

	public void setPoi(String poi) {
		this.poi = poi;
	}

	public String getPoa() {
		return poa;
	}

	public void setPoa(String poa) {
		this.poa = poa;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getKycVerifyType() {
		return kycVerifyType;
	}

	public void setKycVerifyType(String kycVerifyType) {
		this.kycVerifyType = kycVerifyType;
	}

	public String getKycVerifyNumber() {
		return kycVerifyNumber;
	}

	public void setKycVerifyNumber(String kycVerifyNumber) {
		this.kycVerifyNumber = kycVerifyNumber;
	}

	public List<DocumentDto> getPoiDocList() {
		return poiDocList;
	}

	public void setPoiDocList(List<DocumentDto> poiDocList) {
		this.poiDocList = poiDocList;
	}

	public List<DocumentDto> getPoaDocList() {
		return poaDocList;
	}

	public void setPoaDocList(List<DocumentDto> poaDocList) {
		this.poaDocList = poaDocList;
	}
	

}
