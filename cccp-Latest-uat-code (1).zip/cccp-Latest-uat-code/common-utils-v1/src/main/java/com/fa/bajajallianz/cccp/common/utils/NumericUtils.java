package com.fa.bajajallianz.cccp.common.utils;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.Format;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.math3.fraction.Fraction;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ibm.icu.text.RuleBasedNumberFormat;

/**
 * 
 * @author Karthik
 *
 */
public class NumericUtils implements Serializable {
	private static final long serialVersionUID = 1L;

	protected static final Logger logger = LoggerFactory.getLogger(NumericUtils.class);

	public static Integer convertStringToInteger(String value) {
		try {
			return value == null ? null : Integer.parseInt(value);
		} catch (NumberFormatException e) {
			logger.error("NumericUtils-------convertInteger----Started ");
			return null;
			// throw new ApplicationException("");
		}
	}

	public static Integer stringToInteger(String value) {
		try {
			return value == null ? 0 : Integer.parseInt(value);
		} catch (NumberFormatException e) {
			logger.error("NumericUtils-------convertInteger----Started ");
			return null;
			// throw new ApplicationException("");
		}
	}

	public static Long convertStringToLong(String value) {
		try {
			return value == null ? null : Long.valueOf(value);
		} catch (NumberFormatException e) {
			logger.error("NumericUtils-------convertInteger----error ", e.getMessage());
			return null;
			// throw new ApplicationException("");
		}
	}

	public static Long stringToLong(String value) {
		try {
			return value == null ? 0 : Long.valueOf(value);
		} catch (NumberFormatException e) {
			logger.error("NumericUtils-------convertInteger----Started ");
			return null;
			// throw new ApplicationException("");
		}
	}

	public static String convertLongToString(Long value) {
		try {
			return value == null ? "" : String.valueOf(value);
		} catch (NumberFormatException e) {
			logger.error("NumericUtils-------convertInteger----Started ");
			return null;
			// throw new ApplicationException("");
		}
	}

	public static Double stringToDouble(String value) {
		Double returnValue = 0d;
		try {
			if (StringUtils.isNotBlank(value) && value != "") {
				returnValue = Double.valueOf(value);
			}
		} catch (NumberFormatException e) {
			logger.error("NumericUtils-------convertStringToDouble----Started ");
		}
		return returnValue;
	}

	public static Double convertStringToDouble(String value) {
		try {
			if (value != null && StringUtils.isNotBlank(value) && value != "") {
				return Double.valueOf(value);
			}
		} catch (NumberFormatException e) {
			logger.error("NumericUtils-------convertStringToDouble----Started ");
		}
		return null;
	}

	public static String convertIntegerToString(Integer value) {
		String val = null;
		if (value != null) {
			val = String.valueOf(value);
		} else {
			val = "";
		}

		return val;
	}

	public static String convertDoubleToString(Double value) {
		String val = null;
		if (value != null) {
			val = String.valueOf(value);
		} else {
			val = "";
		}

		return val;
	}

	public static String convertBooleanToString(Boolean value) {
		String val = null;
		if (value != null) {
			val = String.valueOf(value);
		} else {
			val = "";
		}

		return val;
	}

	public static Boolean convertStringToBoolean(String value) {
		Boolean val = null;
		if (StringUtils.isNotBlank(value)) {
			val = Boolean.valueOf(value);
		} else {
			val = true;
		}
		return val;
	}

	public static String convertObjectToString(Object value) {
		String val = null;
		if (value != null) {
			val = String.valueOf(value);
		} else {
			val = "";
		}

		return val;
	}

	public static String convertJSONObjectToString(JSONObject value) {
		String val = null;
		if (value != null) {
			val = String.valueOf(value);
		} else {
			val = "";
		}

		return val;
	}

	public static <T> String convertPojoClassToString(T value) {
		String val = null;
		try {
			if (value != null) {
				JSONObject valuess = new JSONObject(value);
				if (valuess != null) {
					val = String.valueOf(valuess);
				}
			} else {
				val = null;
			}
		} catch (Exception e) {
			logger.error("Exception convertPojoClassToString- ", e);
		}

		return val;
	}

	public static <T> String convertPojoClassToJSONString(T value) {
		String val = null;
		try {
			if (value != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				val = objectMapper.writeValueAsString(value);
			}
		} catch (Exception e) {
			logger.error("Exception convertPojoClassToJSONString- ", e);
		}
		return val;
	}

	public static <T> String convertListObjectToJSONString(T value) {
		String val = null;
		try {
			if (value != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				val = objectMapper.writeValueAsString(value);
			}
		} catch (Exception e) {
			logger.error("Exception convertPojoClassToJSONString- ", e);
		}
		return val;
	}

	public static String doubleValuesToTwoDecimals(Double doubleValue) {
		logger.info("NumericUtils-------doubleValuesToTwoDecimals----Started ");
		try {
			if (doubleValue != null) {
				return String.format("%.2f", doubleValue);
			} else {
				logger.error("NumericUtils-------doubleValuesToTwoDecimals----ERROR ");
				return null;
			}
		} catch (NumberFormatException e) {
			logger.error("NumericUtils-------doubleValuesToTwoDecimals----Exception ", e);
			return null;
		}
	}

	public static void main(String[] args) {
//		System.out.println("stringToIndianAmountFormatWithoutSymbol "
//				+ NumericUtils.stringToIndianAmountFormatWithoutSymbol("12,32,23,400"));
//		System.out.println("stringToIndianAmountFormat " + stringToIndianAmountFormat("123223400.2343234233409"));
//		Format format = com.ibm.icu.text.NumberFormat.getCurrencyInstance(new Locale("en", "in"));
	}

	// reference
	// https://stackoverflow.com/questions/13249858/how-to-convert-from-fraction-formatted-string-to-decimal-or-float-in-java
	public static Double convertFractionToDouble(String value) {
		try {
			logger.info("NumericUtils-------convertFractionToDouble----Started - " + value);
			if (value != null && value.contains("/")) {
				String[] rat = value.split("/");
				if (rat.length >= 2) {
					Double valid = Double.parseDouble(rat[0]) / Double.parseDouble(rat[1]);
					return !valid.isNaN() ? valid : null;
				} else {
					return null;
				}
			} else {
				return null;
			}
		} catch (Exception e) {
			logger.error("NumericUtils-------convertFractionToDouble----Exception ", e);
			return null;
		}
	}

	// reference
	// https://stackoverflow.com/questions/40589798/convert-decimal-to-fraction-form-method-java
	public static String convertDoubleToFraction(Double decimal) {
		try {
			logger.info("NumericUtils-------convertDoubleToFraction----Started - " + decimal);
			if (decimal != null) {
				System.out.println(String.valueOf(decimal) + " String.valueOf(decimal).indexOf('.') "
						+ String.valueOf(decimal).indexOf('.'));
				int digitsAfterPoint = String.valueOf(decimal).length() - String.valueOf(decimal).indexOf('.') + 1;
				BigInteger numerator = BigInteger.valueOf((long) (decimal * Math.pow(10, digitsAfterPoint)));
				BigInteger denominator = BigInteger.valueOf((long) (Math.pow(10, digitsAfterPoint)));
				int gcd = numerator.gcd(denominator).intValue();
				if (gcd > 1) {
					return String.valueOf(numerator.intValue() / gcd) + "/"
							+ String.valueOf(denominator.intValue() / gcd);
				} else {
					return String.valueOf(numerator) + "/" + String.valueOf(denominator);
				}
			} else {
				return null;
			}
		} catch (Exception e) {
			logger.error("NumericUtils-------convertDoubleToFraction----Exception ", e);
			return null;
		}

	}

	public static String fractionMultiplication(Fraction fract1, Fraction fract2) {
		Fraction newFract = null;
		try {
			int newNumerator = (fract1.getNumerator() * fract2.getDenominator())
					- (fract2.getNumerator() * fract1.getDenominator());
			int newDenominator = fract1.getDenominator() * fract2.getDenominator();
			newFract = newFract.getReducedFraction(newNumerator, newDenominator);
			String string = (newFract.getNumerator() + "/" + newFract.getDenominator());
//			newFract = new Fraction(newNumerator, newDenominator);
			return string;
		} catch (Exception e) {
			logger.error("Exception-CalculatorServiceImplementation-fractionMultiplication-", e);
		}
		return null;
	}

	public static String stringToIndianAmountFormat(String value) {
		String returnValue = "";
		try {
			if (value != null) {
				Format format = com.ibm.icu.text.NumberFormat.getNumberInstance(new Locale("en", "IN"));
				returnValue = format.format(new BigDecimal(value));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return returnValue;
	}

	public static String stringToIndianAmountFormatWithoutSymbol(String value) {
		String returnValue = "";
		try {
			if (value != null) {
				String[] split = value.split(",");
				for (int i = 0; i < split.length; i++) {
					returnValue = returnValue + "" + split[i];
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return returnValue;
	}

	public static String roundOffvalues(Double value) {
		String returnValue = null;
		try {
			if (value != null) {
				Long long1 = Math.round(value);
				returnValue = NumericUtils.convertLongToString(long1);
			}
			System.out.println("values --" + returnValue);
			return returnValue;
		} catch (Exception e) {
			logger.error("Exception-NumericUtils-roundOffvalues-", e);
		}
		return null;
	}

	public static String stringToIndianAmountFormatToWords(String value) {
		String returnValue = "";
		try {
			if (value != null) {
				RuleBasedNumberFormat ruleBasedNumberFormat = new RuleBasedNumberFormat(new Locale("EN", "IN"),
						RuleBasedNumberFormat.SPELLOUT);
				// System.out.println(ruleBasedNumberFormat.format(value))
				returnValue = ruleBasedNumberFormat.format(new BigDecimal(value));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return returnValue;
	}

	public static String convertDoubleToStringWithoutDecimalAndSE(Double value) {
		String val = null;
		if (value != null) {
			val = String.format("%.0f", value);
		} else {
			val = "";
		}
		return val;
	}
	
	public static String checkNull(String value) {
		try {
			if (value != null) {
				return value;
			}
			return "";
		} catch (Exception e) {
			logger.error("Exception-NumericUtils-checkNull-", e);
		}
		return "";
	}
	
	public static <T> Map<String, String> convertPojoClassToMap(T value) {
		Map<String, String> map = null;
		try {
			if (value != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				// Convert POJO to Map<String, String>
				map = objectMapper.convertValue(value, new TypeReference<Map<String, String>>() {
				});
			}
		} catch (Exception e) {
			logger.error("Exception in convertPojoClassToMap - ", e);
		}
		return map;
	}
	public static <T> String convertPojoClassToStringWithoutNullKeys(T value) {
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode objectNode = (ObjectNode) mapper.valueToTree(value);
		try {
 
			cleanObjectNode(objectNode);
 
			return mapper.writeValueAsString(objectNode);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return null;
	}
 
	private static void cleanObjectNode(ObjectNode node) {
		List<String> keysToRemove = new ArrayList<>();
 
		node.fields().forEachRemaining(entry -> {
			JsonNode value = entry.getValue();
 
			if (value.isNull()) {
				keysToRemove.add(entry.getKey());
			} else if (value.isObject()) {
				cleanObjectNode((ObjectNode) value);
			} else if (value.isArray()) {
				ArrayNode arrayNode = (ArrayNode) value;
				arrayNode.forEach(item -> {
					if (item.isObject()) {
						cleanObjectNode((ObjectNode) item);
					}
				});
			}
		});
 
		keysToRemove.forEach(node::remove);
	}

}
