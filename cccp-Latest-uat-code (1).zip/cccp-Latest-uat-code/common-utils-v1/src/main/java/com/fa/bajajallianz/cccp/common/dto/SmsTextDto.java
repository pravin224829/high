/**
 * 
 */
package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SmsTextDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<SmsValuesDto> smsValues;

	public List<SmsValuesDto> getSmsValues() {
		return smsValues;
	}

	public void setSmsValues(List<SmsValuesDto> smsValues) {
		this.smsValues = smsValues;
	}

}
