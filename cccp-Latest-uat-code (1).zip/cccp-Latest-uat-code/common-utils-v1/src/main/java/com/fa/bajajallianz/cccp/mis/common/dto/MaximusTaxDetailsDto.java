package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

public class MaximusTaxDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String utgst;
	private String sgst;
	private String cgst;
	private String igst;
	private String cess;
	private String loadingPercentage;
	private String loadingAmount;
	private String remarks;

	public String getUtgst() {
		return utgst;
	}

	public void setUtgst(String utgst) {
		this.utgst = utgst;
	}

	public String getSgst() {
		return sgst;
	}

	public void setSgst(String sgst) {
		this.sgst = sgst;
	}

	public String getCgst() {
		return cgst;
	}

	public void setCgst(String cgst) {
		this.cgst = cgst;
	}

	public String getIgst() {
		return igst;
	}

	public void setIgst(String igst) {
		this.igst = igst;
	}

	public String getCess() {
		return cess;
	}

	public void setCess(String cess) {
		this.cess = cess;
	}

	public String getLoadingPercentage() {
		return loadingPercentage;
	}

	public void setLoadingPercentage(String loadingPercentage) {
		this.loadingPercentage = loadingPercentage;
	}

	public String getLoadingAmount() {
		return loadingAmount;
	}

	public void setLoadingAmount(String loadingAmount) {
		this.loadingAmount = loadingAmount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
