/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Santhosh
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class IntermidiaryDetailsDto implements Serializable{

	private static final long serialVersionUID = 1L;
	private String bankRoutingMethod;
	private String bankName;
	private String bankRoutingCode;
	private String intermediaryBankName;
	
	public String getBankRoutingMethod() {
		return bankRoutingMethod;
	}
	public void setBankRoutingMethod(String bankRoutingMethod) {
		this.bankRoutingMethod = bankRoutingMethod;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankRoutingCode() {
		return bankRoutingCode;
	}
	public void setBankRoutingCode(String bankRoutingCode) {
		this.bankRoutingCode = bankRoutingCode;
	}
	public String getIntermediaryBankName() {
		return intermediaryBankName;
	}
	public void setIntermediaryBankName(String intermediaryBankName) {
		this.intermediaryBankName = intermediaryBankName;
	}
	
	
	
	
	
	
	
}
