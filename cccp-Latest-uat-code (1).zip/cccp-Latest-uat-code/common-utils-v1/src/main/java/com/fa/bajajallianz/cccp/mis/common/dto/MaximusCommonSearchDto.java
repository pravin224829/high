package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

public class MaximusCommonSearchDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private String lastName;
	private String quoteCreatedTimestamp;
	private String outstandingAmount;
	private String endDate;
	private String mobileNumber;
	private String journeyEndDate;
	private String policyNumber;
	private String previousPolicyNumber;
	private String employeeID;
	private String premiumAmount;
	private String title;
	private String totalCount;
	private String policyBranch;
	private String emailAddress;
	private String dateCreated;
	private String policyPlan;
	private String journeyStartDate;
	private String policyIssuanceTimestamp;
	private String selected;
	private String product;
	private String address;
	private String subStatus;
	private String dateOfBirth;
	private String crossReferenceNumber;
	private String quoteDate;
	private String quoteNumber;
	private String firstName;
	private String proposerName;
	private String productCode;
	private String createdBy;
	private String passportNumber;
	private String policyType;
	private String partyCode;
	private String collectedAmount;
	private String cancellationNumber;
	private String middleName;
	private String category;
	private String lob;
	private String startDate;
	private String status;
	private String substatusCode;
	private String renewalQuoteNumber;
	private String vehicleRegistrationNumber;
	private String vehicleMake;
	private String vehicleType;
	private String expDate;

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getQuoteCreatedTimestamp() {
		return quoteCreatedTimestamp;
	}

	public void setQuoteCreatedTimestamp(String quoteCreatedTimestamp) {
		this.quoteCreatedTimestamp = quoteCreatedTimestamp;
	}

	public String getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(String outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getJourneyEndDate() {
		return journeyEndDate;
	}

	public void setJourneyEndDate(String journeyEndDate) {
		this.journeyEndDate = journeyEndDate;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getPreviousPolicyNumber() {
		return previousPolicyNumber;
	}

	public void setPreviousPolicyNumber(String previousPolicyNumber) {
		this.previousPolicyNumber = previousPolicyNumber;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public String getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}

	public String getPolicyBranch() {
		return policyBranch;
	}

	public void setPolicyBranch(String policyBranch) {
		this.policyBranch = policyBranch;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}

	public String getPolicyPlan() {
		return policyPlan;
	}

	public void setPolicyPlan(String policyPlan) {
		this.policyPlan = policyPlan;
	}

	public String getJourneyStartDate() {
		return journeyStartDate;
	}

	public void setJourneyStartDate(String journeyStartDate) {
		this.journeyStartDate = journeyStartDate;
	}

	public String getPolicyIssuanceTimestamp() {
		return policyIssuanceTimestamp;
	}

	public void setPolicyIssuanceTimestamp(String policyIssuanceTimestamp) {
		this.policyIssuanceTimestamp = policyIssuanceTimestamp;
	}

	public String getSelected() {
		return selected;
	}

	public void setSelected(String selected) {
		this.selected = selected;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getCrossReferenceNumber() {
		return crossReferenceNumber;
	}

	public void setCrossReferenceNumber(String crossReferenceNumber) {
		this.crossReferenceNumber = crossReferenceNumber;
	}

	public String getQuoteDate() {
		return quoteDate;
	}

	public void setQuoteDate(String quoteDate) {
		this.quoteDate = quoteDate;
	}

	public String getQuoteNumber() {
		return quoteNumber;
	}

	public void setQuoteNumber(String quoteNumber) {
		this.quoteNumber = quoteNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getProposerName() {
		return proposerName;
	}

	public void setProposerName(String proposerName) {
		this.proposerName = proposerName;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public String getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public String getCollectedAmount() {
		return collectedAmount;
	}

	public void setCollectedAmount(String collectedAmount) {
		this.collectedAmount = collectedAmount;
	}

	public String getCancellationNumber() {
		return cancellationNumber;
	}

	public void setCancellationNumber(String cancellationNumber) {
		this.cancellationNumber = cancellationNumber;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubstatusCode() {
		return substatusCode;
	}

	public void setSubstatusCode(String substatusCode) {
		this.substatusCode = substatusCode;
	}

	public String getRenewalQuoteNumber() {
		return renewalQuoteNumber;
	}

	public void setRenewalQuoteNumber(String renewalQuoteNumber) {
		this.renewalQuoteNumber = renewalQuoteNumber;
	}

	public String getVehicleRegistrationNumber() {
		return vehicleRegistrationNumber;
	}

	public void setVehicleRegistrationNumber(String vehicleRegistrationNumber) {
		this.vehicleRegistrationNumber = vehicleRegistrationNumber;
	}

	public String getVehicleMake() {
		return vehicleMake;
	}

	public void setVehicleMake(String vehicleMake) {
		this.vehicleMake = vehicleMake;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getExpDate() {
		return expDate;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

}
