package com.fa.bajajallianz.cccp.surveyor.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GradeQuestionDetailsDto implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String partyId;
	private String surveyorNumber;
	private String claimNumber;
	private String code;
	private String question;
	private String remarkCode;
	private String selectedAnswer;
	private String weightagePerQuestion;
	private String totalWeightage;
	private String averageWeightage;
	private String remarks;
	private Boolean isActive;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getSurveyorNumber() {
		return surveyorNumber;
	}

	public void setSurveyorNumber(String surveyorNumber) {
		this.surveyorNumber = surveyorNumber;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getSelectedAnswer() {
		return selectedAnswer;
	}

	public void setSelectedAnswer(String selectedAnswer) {
		this.selectedAnswer = selectedAnswer;
	}

	public String getWeightagePerQuestion() {
		return weightagePerQuestion;
	}

	public void setWeightagePerQuestion(String weightagePerQuestion) {
		this.weightagePerQuestion = weightagePerQuestion;
	}

	public String getTotalWeightage() {
		return totalWeightage;
	}

	public void setTotalWeightage(String totalWeightage) {
		this.totalWeightage = totalWeightage;
	}

	public String getAverageWeightage() {
		return averageWeightage;
	}

	public void setAverageWeightage(String averageWeightage) {
		this.averageWeightage = averageWeightage;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getRemarkCode() {
		return remarkCode;
	}

	public void setRemarkCode(String remarkCode) {
		this.remarkCode = remarkCode;
	}
	
	

}
