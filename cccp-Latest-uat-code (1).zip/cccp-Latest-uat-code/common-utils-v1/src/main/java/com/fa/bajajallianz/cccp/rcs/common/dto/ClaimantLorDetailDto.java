/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Arul
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimantLorDetailDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;
	private String firstDocReceivedDate;
	private String lastDocReceivedDate;
	private String delayReason;
	private String claimantPartyId;
	private String claimNumber;
	private String customerLink;
	private Boolean isActive;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private String resons;
	private String claimRegDate;
	private String processType;
	private String finalSurveyDate;

	public String getFirstDocReceivedDate() {
		return firstDocReceivedDate;
	}

	public void setFirstDocReceivedDate(String firstDocReceivedDate) {
		this.firstDocReceivedDate = firstDocReceivedDate;
	}

	public String getLastDocReceivedDate() {
		return lastDocReceivedDate;
	}

	public void setLastDocReceivedDate(String lastDocReceivedDate) {
		this.lastDocReceivedDate = lastDocReceivedDate;
	}

	public String getDelayReason() {
		return delayReason;
	}

	public void setDelayReason(String delayReason) {
		this.delayReason = delayReason;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCustomerLink() {
		return customerLink;
	}

	public void setCustomerLink(String customerLink) {
		this.customerLink = customerLink;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClaimantPartyId() {
		return claimantPartyId;
	}

	public void setClaimantPartyId(String claimantPartyId) {
		this.claimantPartyId = claimantPartyId;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getResons() {
		return resons;
	}

	public void setResons(String resons) {
		this.resons = resons;
	}

	public String getClaimRegDate() {
		return claimRegDate;
	}

	public void setClaimRegDate(String claimRegDate) {
		this.claimRegDate = claimRegDate;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getFinalSurveyDate() {
		return finalSurveyDate;
	}

	public void setFinalSurveyDate(String finalSurveyDate) {
		this.finalSurveyDate = finalSurveyDate;
	}
	

}
