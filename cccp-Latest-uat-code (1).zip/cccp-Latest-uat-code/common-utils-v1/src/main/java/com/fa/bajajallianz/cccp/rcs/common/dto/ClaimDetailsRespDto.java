package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimDetailsRespDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String claimId;
	private String claimNumber;
	private String insuredName;
	private String detailLossLocation;
	private String productCode;
	private String productName;
	private String kindOfLoss;
	private String causeOfLoss;
	private String extCol5;
	private String extCol1;
	private String extCol4;

	public String getClaimId() {
		return claimId;
	}

	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getDetailLossLocation() {
		return detailLossLocation;
	}

	public void setDetailLossLocation(String detailLossLocation) {
		this.detailLossLocation = detailLossLocation;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getKindOfLoss() {
		return kindOfLoss;
	}

	public void setKindOfLoss(String kindOfLoss) {
		this.kindOfLoss = kindOfLoss;
	}

	public String getCauseOfLoss() {
		return causeOfLoss;
	}

	public void setCauseOfLoss(String causeOfLoss) {
		this.causeOfLoss = causeOfLoss;
	}

	public String getExtCol5() {
		return extCol5;
	}

	public void setExtCol5(String extCol5) {
		this.extCol5 = extCol5;
	}

	public String getExtCol1() {
		return extCol1;
	}

	public void setExtCol1(String extCol1) {
		this.extCol1 = extCol1;
	}

	public String getExtCol4() {
		return extCol4;
	}

	public void setExtCol4(String extCol4) {
		this.extCol4 = extCol4;
	}

}
