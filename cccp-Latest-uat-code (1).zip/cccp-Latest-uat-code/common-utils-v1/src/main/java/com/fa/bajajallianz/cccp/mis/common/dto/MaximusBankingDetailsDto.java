package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

public class MaximusBankingDetailsDto implements Serializable {

/**

* 

*/

private static final long serialVersionUID = 1L;

private String operationCode;
private String accountHolder;
private String accountType;
private String bankAccountNumber;
private String bankName;
private String branchName;
private String confirmBankAccountNumber;
private String ifsc;
private String micr;
private String neftStatus;
private String isPrimary;
private String apprRejDt;
private String apprRejBy;
private String remark;

public String getAccountHolder() {
	return accountHolder;
}

public void setAccountHolder(String accountHolder) {
	this.accountHolder = accountHolder;
}

public String getAccountType() {
	return accountType;
}

public void setAccountType(String accountType) {
	this.accountType = accountType;
}

public String getBankAccountNumber() {
	return bankAccountNumber;
}

public void setBankAccountNumber(String bankAccountNumber) {
	this.bankAccountNumber = bankAccountNumber;
}

public String getBankName() {
	return bankName;
}

public void setBankName(String bankName) {
	this.bankName = bankName;
}

public String getConfirmBankAccountNumber() {
	return confirmBankAccountNumber;
}

public void setConfirmBankAccountNumber(String confirmBankAccountNumber) {
	this.confirmBankAccountNumber = confirmBankAccountNumber;
}

public String getIfsc() {
	return ifsc;
}

public void setIfsc(String ifsc) {
	this.ifsc = ifsc;
}

public String getMicr() {
	return micr;
}

public void setMicr(String micr) {
	this.micr = micr;
}

public String getNeftStatus() {
	return neftStatus;
}

public void setNeftStatus(String neftStatus) {
	this.neftStatus = neftStatus;
}

public String getOperationCode() {
	return operationCode;
}

public void setOperationCode(String operationCode) {
	this.operationCode = operationCode;
}

public String getBranchName() {
	return branchName;
}

public void setBranchName(String branchName) {
	this.branchName = branchName;
}

public String getIsPrimary() {
	return isPrimary;
}

public void setIsPrimary(String isPrimary) {
	this.isPrimary = isPrimary;
}

public String getApprRejDt() {
	return apprRejDt;
}

public void setApprRejDt(String apprRejDt) {
	this.apprRejDt = apprRejDt;
}

public String getApprRejBy() {
	return apprRejBy;
}

public void setApprRejBy(String apprRejBy) {
	this.apprRejBy = apprRejBy;
}

public String getRemark() {
	return remark;
}

public void setRemark(String remark) {
	this.remark = remark;
}




}
