package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AdditionalDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private String clientDivisionName;
	private String clientDistrictName;
	private String totalConsignmentValue;
	private String transportVehilceNo;
	private String transporterName;
	private String consignmentOrCargoType;
	private String k2k3;
	private String jirDate;
	private String claimNumber;
	private String claimStatus;
	private String policyNumber;
	private String claimHandler;
	private String insuredName;
	private Integer pendingAge;
	private String surveyorName;
	private String lossApprovedAmount;
	private String beneficiaryName;
	private String surveyorRefNumber;
	private String claimPaymentUTRNumber;
	private String utrDate;
	private List<RuntimeFields> runtime; 
	private String intimationDate;
	private String registrationDate;
	private String initialSurveyDate;
	private String psrIlaDate;
	private String fsrDate;
	private String surveyorAppointmentDate;
	private String partnerId;
	private String payeeType;
	private String neftBankStatus;
	
	public String getClientDivisionName() {
		return clientDivisionName;
	}

	public void setClientDivisionName(String clientDivisionName) {
		this.clientDivisionName = clientDivisionName;
	}

	public String getClientDistrictName() {
		return clientDistrictName;
	}

	public void setClientDistrictName(String clientDistrictName) {
		this.clientDistrictName = clientDistrictName;
	}

	public String getTotalConsignmentValue() {
		return totalConsignmentValue;
	}

	public void setTotalConsignmentValue(String totalConsignmentValue) {
		this.totalConsignmentValue = totalConsignmentValue;
	}

	public String getTransportVehilceNo() {
		return transportVehilceNo;
	}

	public void setTransportVehilceNo(String transportVehilceNo) {
		this.transportVehilceNo = transportVehilceNo;
	}

	public String getTransporterName() {
		return transporterName;
	}

	public void setTransporterName(String transporterName) {
		this.transporterName = transporterName;
	}

	public String getConsignmentOrCargoType() {
		return consignmentOrCargoType;
	}

	public void setConsignmentOrCargoType(String consignmentOrCargoType) {
		this.consignmentOrCargoType = consignmentOrCargoType;
	}

	public String getK2k3() {
		return k2k3;
	}

	public void setK2k3(String k2k3) {
		this.k2k3 = k2k3;
	}

	public String getJirDate() {
		return jirDate;
	}

	public void setJirDate(String jirDate) {
		this.jirDate = jirDate;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getClaimHandler() {
		return claimHandler;
	}

	public void setClaimHandler(String claimHandler) {
		this.claimHandler = claimHandler;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public Integer getPendingAge() {
		return pendingAge;
	}

	public void setPendingAge(Integer pendingAge) {
		this.pendingAge = pendingAge;
	}

	public String getSurveyorName() {
		return surveyorName;
	}

	public void setSurveyorName(String surveyorName) {
		this.surveyorName = surveyorName;
	}

	public String getLossApprovedAmount() {
		return lossApprovedAmount;
	}

	public void setLossApprovedAmount(String lossApprovedAmount) {
		this.lossApprovedAmount = lossApprovedAmount;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public String getSurveyorRefNumber() {
		return surveyorRefNumber;
	}

	public void setSurveyorRefNumber(String surveyorRefNumber) {
		this.surveyorRefNumber = surveyorRefNumber;
	}

	public String getClaimPaymentUTRNumber() {
		return claimPaymentUTRNumber;
	}

	public void setClaimPaymentUTRNumber(String claimPaymentUTRNumber) {
		this.claimPaymentUTRNumber = claimPaymentUTRNumber;
	}

	public String getUtrDate() {
		return utrDate;
	}

	public void setUtrDate(String utrDate) {
		this.utrDate = utrDate;
	}

	public List<RuntimeFields> getRuntime() {
		return runtime;
	}

	public void setRuntime(List<RuntimeFields> runtime) {
		this.runtime = runtime;
	}

	public String getIntimationDate() {
		return intimationDate;
	}

	public void setIntimationDate(String intimationDate) {
		this.intimationDate = intimationDate;
	}

	public String getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getInitialSurveyDate() {
		return initialSurveyDate;
	}

	public void setInitialSurveyDate(String initialSurveyDate) {
		this.initialSurveyDate = initialSurveyDate;
	}

	public String getPsrIlaDate() {
		return psrIlaDate;
	}

	public void setPsrIlaDate(String psrIlaDate) {
		this.psrIlaDate = psrIlaDate;
	}

	public String getFsrDate() {
		return fsrDate;
	}

	public void setFsrDate(String fsrDate) {
		this.fsrDate = fsrDate;
	}

	public String getSurveyorAppointmentDate() {
		return surveyorAppointmentDate;
	}

	public void setSurveyorAppointmentDate(String surveyorAppointmentDate) {
		this.surveyorAppointmentDate = surveyorAppointmentDate;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getPayeeType() {
		return payeeType;
	}

	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	public String getNeftBankStatus() {
		return neftBankStatus;
	}

	public void setNeftBankStatus(String neftBankStatus) {
		this.neftBankStatus = neftBankStatus;
	}	

}
