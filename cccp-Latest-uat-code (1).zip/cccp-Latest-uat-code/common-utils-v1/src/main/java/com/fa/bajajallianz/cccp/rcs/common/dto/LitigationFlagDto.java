package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LitigationFlagDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String generalAverage;
	private String ombudsmanComplaints;
	private String civilLitigation;
	private String otherLitigations;
	private String indemnityRecoveryBondCase;
	private String consumerForun;
	private String wcLitigation;
	private String criminalLitigation;
	private String suitFiledMarineRecovery;
	private String longTailDisputedCase;

	public String getGeneralAverage() {
		return generalAverage;
	}

	public void setGeneralAverage(String generalAverage) {
		this.generalAverage = generalAverage;
	}

	public String getOmbudsmanComplaints() {
		return ombudsmanComplaints;
	}

	public void setOmbudsmanComplaints(String ombudsmanComplaints) {
		this.ombudsmanComplaints = ombudsmanComplaints;
	}

	public String getCivilLitigation() {
		return civilLitigation;
	}

	public void setCivilLitigation(String civilLitigation) {
		this.civilLitigation = civilLitigation;
	}

	public String getOtherLitigations() {
		return otherLitigations;
	}

	public void setOtherLitigations(String otherLitigations) {
		this.otherLitigations = otherLitigations;
	}

	public String getIndemnityRecoveryBondCase() {
		return indemnityRecoveryBondCase;
	}

	public void setIndemnityRecoveryBondCase(String indemnityRecoveryBondCase) {
		this.indemnityRecoveryBondCase = indemnityRecoveryBondCase;
	}

	public String getConsumerForun() {
		return consumerForun;
	}

	public void setConsumerForun(String consumerForun) {
		this.consumerForun = consumerForun;
	}

	public String getWcLitigation() {
		return wcLitigation;
	}

	public void setWcLitigation(String wcLitigation) {
		this.wcLitigation = wcLitigation;
	}

	public String getCriminalLitigation() {
		return criminalLitigation;
	}

	public void setCriminalLitigation(String criminalLitigation) {
		this.criminalLitigation = criminalLitigation;
	}

	public String getSuitFiledMarineRecovery() {
		return suitFiledMarineRecovery;
	}

	public void setSuitFiledMarineRecovery(String suitFiledMarineRecovery) {
		this.suitFiledMarineRecovery = suitFiledMarineRecovery;
	}

	public String getLongTailDisputedCase() {
		return longTailDisputedCase;
	}

	public void setLongTailDisputedCase(String longTailDisputedCase) {
		this.longTailDisputedCase = longTailDisputedCase;
	}
}
