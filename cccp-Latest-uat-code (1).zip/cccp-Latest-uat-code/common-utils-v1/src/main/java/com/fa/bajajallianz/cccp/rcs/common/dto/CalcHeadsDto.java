package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CalcHeadsDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String code;
	private String name;
	private Boolean isActive;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private Integer orderNo;
	private String attributes;
	private List<CalcSubHeadsDto> calcSubHeads;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Integer getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}
	public String getAttributes() {
		return attributes;
	}
	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}
	public List<CalcSubHeadsDto> getCalcSubHeads() {
		return calcSubHeads;
	}
	public void setCalcSubHeads(List<CalcSubHeadsDto> calcSubHeads) {
		this.calcSubHeads = calcSubHeads;
	}

}
