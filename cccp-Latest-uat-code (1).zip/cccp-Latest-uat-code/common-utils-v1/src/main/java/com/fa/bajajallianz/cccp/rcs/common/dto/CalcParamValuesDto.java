package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CalcParamValuesDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String paramCode;
	private String paramId;
	private String paramValue;
	private String noOfVisit;
	private String selectedValue;
	private String attributeCode;
	private String attributeValue;
	private String enteredValue;
	private String calculatedValue;
	private String allowedValue;

	public String getAttributeCode() {
		return attributeCode;
	}

	public void setAttributeCode(String attributeCode) {
		this.attributeCode = attributeCode;
	}

	public String getAttributeValue() {
		return attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	public String getEnteredValue() {
		return enteredValue;
	}

	public void setEnteredValue(String enteredValue) {
		this.enteredValue = enteredValue;
	}

	public String getCalculatedValue() {
		return calculatedValue;
	}

	public void setCalculatedValue(String calculatedValue) {
		this.calculatedValue = calculatedValue;
	}

	public String getAllowedValue() {
		return allowedValue;
	}

	public void setAllowedValue(String allowedValue) {
		this.allowedValue = allowedValue;
	}

	public String getParamCode() {
		return paramCode;
	}

	public void setParamCode(String paramCode) {
		this.paramCode = paramCode;
	}

	public String getParamId() {
		return paramId;
	}

	public void setParamId(String paramId) {
		this.paramId = paramId;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	public String getNoOfVisit() {
		return noOfVisit;
	}

	public void setNoOfVisit(String noOfVisit) {
		this.noOfVisit = noOfVisit;
	}

	public String getSelectedValue() {
		return selectedValue;
	}

	public void setSelectedValue(String selectedValue) {
		this.selectedValue = selectedValue;
	}

}
