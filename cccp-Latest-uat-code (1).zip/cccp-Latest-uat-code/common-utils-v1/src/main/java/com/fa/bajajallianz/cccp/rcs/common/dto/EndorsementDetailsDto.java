package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.ArrayList;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fa.bajajallianz.cccp.mis.common.dto.PolicyEndorsementDetailDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EndorsementDetailsDto implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	private String policyNumber;
	private String contractID;
	private String versionNo;
	private String issueDate;
	private String effectiveDate;
	private String endorsementNo;
	private String userName;
	private String webUser;
	private String subMovementType;
	private String endorseReason;
	private String endorseWording;
	private String movementReasonText;
	private String prevPolicyNo;
	private String contractStatus;
	private ApplicationErrorDto applicationErr;

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getContractID() {
		return contractID;
	}

	public void setContractID(String contractID) {
		this.contractID = contractID;
	}

	public String getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getEndorsementNo() {
		return endorsementNo;
	}

	public void setEndorsementNo(String endorsementNo) {
		this.endorsementNo = endorsementNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getWebUser() {
		return webUser;
	}

	public void setWebUser(String webUser) {
		this.webUser = webUser;
	}

	public String getSubMovementType() {
		return subMovementType;
	}

	public void setSubMovementType(String subMovementType) {
		this.subMovementType = subMovementType;
	}

	public String getEndorseReason() {
		return endorseReason;
	}

	public void setEndorseReason(String endorseReason) {
		this.endorseReason = endorseReason;
	}

	public String getEndorseWording() {
		return endorseWording;
	}

	public void setEndorseWording(String endorseWording) {
		this.endorseWording = endorseWording;
	}

	public String getMovementReasonText() {
		return movementReasonText;
	}

	public void setMovementReasonText(String movementReasonText) {
		this.movementReasonText = movementReasonText;
	}

	public String getPrevPolicyNo() {
		return prevPolicyNo;
	}

	public void setPrevPolicyNo(String prevPolicyNo) {
		this.prevPolicyNo = prevPolicyNo;
	}

	public String getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

	public ApplicationErrorDto getApplicationErr() {
		return applicationErr;
	}

	public void setApplicationErr(ApplicationErrorDto applicationErr) {
		this.applicationErr = applicationErr;
	}

	@Override
	public String toString() {
		return "EndorsementDetailsDto [policyNumber=" + policyNumber + ", contractID=" + contractID + ", versionNo="
				+ versionNo + ", issueDate=" + issueDate + ", effectiveDate=" + effectiveDate + ", endorsementNo="
				+ endorsementNo + ", userName=" + userName + ", webUser=" + webUser + ", subMovementType="
				+ subMovementType + ", endorseReason=" + endorseReason + ", endorseWording=" + endorseWording
				+ ", movementReasonText=" + movementReasonText + ", prevPolicyNo=" + prevPolicyNo + ", contractStatus="
				+ contractStatus + ", applicationErr=" + applicationErr + "]";
	}

}
