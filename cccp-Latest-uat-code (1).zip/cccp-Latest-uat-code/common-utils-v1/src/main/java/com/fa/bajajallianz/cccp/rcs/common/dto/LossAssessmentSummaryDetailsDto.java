/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

/**
 * @author Arul
 *
 */
public class LossAssessmentSummaryDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;
	private String claimNumber;
	private String calcRefId;
	private String netAmount;
	private String claimSynopsis;
	private Boolean isActive;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private List<LossAssesmentDetailsDto> assesmentValueDetails;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getCalcRefId() {
		return calcRefId;
	}

	public void setCalcRefId(String calcRefId) {
		this.calcRefId = calcRefId;
	}

	public List<LossAssesmentDetailsDto> getAssesmentValueDetails() {
		return assesmentValueDetails;
	}

	public void setAssesmentValueDetails(List<LossAssesmentDetailsDto> assesmentValueDetails) {
		this.assesmentValueDetails = assesmentValueDetails;
	}

	public String getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}

	public String getClaimSynopsis() {
		return claimSynopsis;
	}

	public void setClaimSynopsis(String claimSynopsis) {
		this.claimSynopsis = claimSynopsis;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
