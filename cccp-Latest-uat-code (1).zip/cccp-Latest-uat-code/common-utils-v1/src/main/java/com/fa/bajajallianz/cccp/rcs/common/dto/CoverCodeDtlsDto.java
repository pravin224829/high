package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

public class CoverCodeDtlsDto implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String clauseNo;
	private String clauseType;
	private String clauseDesc;
	private Boolean isSelect;
	public Boolean getIsSelect() {
		return isSelect;
	}
	public void setIsSelect(Boolean isSelect) {
		this.isSelect = isSelect;
	}
	public String getClauseNo() {
		return clauseNo;
	}
	public void setClauseNo(String clauseNo) {
		this.clauseNo = clauseNo;
	}
	public String getClauseType() {
		return clauseType;
	}
	public void setClauseType(String clauseType) {
		this.clauseType = clauseType;
	}
	public String getClauseDesc() {
		return clauseDesc;
	}
	public void setClauseDesc(String clauseDesc) {
		this.clauseDesc = clauseDesc;
	}


}
