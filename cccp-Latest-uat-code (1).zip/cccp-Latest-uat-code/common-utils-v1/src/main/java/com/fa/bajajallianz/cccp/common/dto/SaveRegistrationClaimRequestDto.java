package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SaveRegistrationClaimRequestDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userId;
	private String roleCode;
	private String agentCode;
	private BankDetailsDto bankDetailsDto;
	private ClaimIntimatedDto claimIntimatedDto;
	private InsuredDetails insuredDetails;
	private LossDetailsDto lossDetailsDto;

	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getAgentCode() {
		return agentCode;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public BankDetailsDto getBankDetailsDto() {
		return bankDetailsDto;
	}

	public void setBankDetailsDto(BankDetailsDto bankDetailsDto) {
		this.bankDetailsDto = bankDetailsDto;
	}

	public ClaimIntimatedDto getClaimIntimatedDto() {
		return claimIntimatedDto;
	}

	public void setClaimIntimatedDto(ClaimIntimatedDto claimIntimatedDto) {
		this.claimIntimatedDto = claimIntimatedDto;
	}

	public InsuredDetails getInsuredDetails() {
		return insuredDetails;
	}

	public void setInsuredDetails(InsuredDetails insuredDetails) {
		this.insuredDetails = insuredDetails;
	}

	public LossDetailsDto getLossDetailsDto() {
		return lossDetailsDto;
	}

	public void setLossDetailsDto(LossDetailsDto lossDetailsDto) {
		this.lossDetailsDto = lossDetailsDto;
	}

}
