package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

public class CalcHeadsAttributesResponseDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String code;
	private String attributes;
	private String name;
	private String objName;
	private String authorityCode;
	private String calcHeads;
	private String orderNo;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getAttributes() {
		return attributes;
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getAuthorityCode() {
		return authorityCode;
	}

	public void setAuthorityCode(String authorityCode) {
		this.authorityCode = authorityCode;
	}

	public String getCalcHeads() {
		return calcHeads;
	}

	public void setCalcHeads(String calcHeads) {
		this.calcHeads = calcHeads;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

}
