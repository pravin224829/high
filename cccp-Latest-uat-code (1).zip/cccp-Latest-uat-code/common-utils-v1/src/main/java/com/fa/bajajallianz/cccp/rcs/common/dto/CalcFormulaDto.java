package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CalcFormulaDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private String code;
	private String calcHeadsAttributeId;
	private String operand;
	private String calcHeadsAttributesId1;
	private String calcHeadsAttributesId2;
	private String resultParam;
	private String isFinal;
	private String orderNo;
	private String createdDate;
	private String createdBy;
	private String modifiedDate;
	private String modifiedBy;
	private Boolean isAttributeId1;
	private Boolean isAttributeId2;
	private Boolean isRoundOff;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCalcHeadsAttributeId() {
		return calcHeadsAttributeId;
	}

	public void setCalcHeadsAttributeId(String calcHeadsAttributeId) {
		this.calcHeadsAttributeId = calcHeadsAttributeId;
	}

	public String getOperand() {
		return operand;
	}

	public void setOperand(String operand) {
		this.operand = operand;
	}

	public String getCalcHeadsAttributesId1() {
		return calcHeadsAttributesId1;
	}

	public void setCalcHeadsAttributesId1(String calcHeadsAttributesId1) {
		this.calcHeadsAttributesId1 = calcHeadsAttributesId1;
	}

	public String getCalcHeadsAttributesId2() {
		return calcHeadsAttributesId2;
	}

	public void setCalcHeadsAttributesId2(String calcHeadsAttributesId2) {
		this.calcHeadsAttributesId2 = calcHeadsAttributesId2;
	}

	public String getResultParam() {
		return resultParam;
	}

	public void setResultParam(String resultParam) {
		this.resultParam = resultParam;
	}

	public String getIsFinal() {
		return isFinal;
	}

	public void setIsFinal(String isFinal) {
		this.isFinal = isFinal;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Boolean getIsAttributeId1() {
		return isAttributeId1;
	}

	public void setIsAttributeId1(Boolean isAttributeId1) {
		this.isAttributeId1 = isAttributeId1;
	}

	public Boolean getIsAttributeId2() {
		return isAttributeId2;
	}

	public void setIsAttributeId2(Boolean isAttributeId2) {
		this.isAttributeId2 = isAttributeId2;
	}

	public Boolean getIsRoundOff() {
		return isRoundOff;
	}

	public void setIsRoundOff(Boolean isRoundOff) {
		this.isRoundOff = isRoundOff;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

}
