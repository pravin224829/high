package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.fa.bajajallianz.cccp.rcs.common.dto.CalcDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcHeadsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcSubHeadsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcTypeDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CkycDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CkycRequestObjDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimDataDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimHandlerDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimPartiesDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimantLorDetailDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimantLorDocDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.DdPaymentDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.DiaDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.FdrPaymentDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ForeignCurrencyDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.GstDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.InsuredCommunicationDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.IntermidiaryDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.LitigationFlagDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.LossAssessmentSummaryDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.PartyDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.PaymentDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.PaymentHistoryDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.RcsClaimDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.RcsClaimantDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.RcsDocumentDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.RemittanceDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ReserveDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.RiskCoverDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.StakeDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.SubCalcTypeDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.SupplierDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.TaskDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.TransporterDetailsDto;
import com.fa.bajajallianz.cccp.surveyor.common.dto.ClaimReviewDetailsDto;
import com.fa.bajajallianz.cccp.surveyor.common.dto.NeftDetails;
import com.fa.bajajallianz.cccp.surveyor.common.dto.NotifyUserDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonRequestDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	private String userId;
	private String email;
	private String mobileNo;
	private String designation;
	private String roleCode;
	private String pageName;
	private String pageCode;
	private String searchType;
	private String sectionCode;
	private String subSectionCode;
	private String code;
	private String source;
	private String type;
	private String pageType;
	private String referenceNo;
	private String docStatus;
	private String referenceType;
	private String fieldCode;
	private String claimNumber;
	private String policyNumber;
	private String productCode;
	private String lobCode;
	private String claimStatus;
	private String policyStartDate;
	private String policyEndDate;
	private String fromLimit;
	private String toLimit;
	private String orderBy;
	private String claimRegFromDate;
	private String claimRegToDate;
	private String claimHandler;
	private String insuredMobileNumber;
	private String insuredEmailId;
	private String claimRefNo;
	private String pincode;
	private String docId;
	private String templateType;
	private String userName;
	private String partnerId;
	private String corporateUserId;
	private String insuredName;
	private String inspectionDate;
	private String expiryDate;
	private String productDescription;
	private String imdChannel;
	private String sumInsured;
	private String policyStatus;
	private String lovType;
	private String createdDate;
	private String corporateId;
	private String fromDate;
	private String toDate;
	private String searchUserId;
	private List<HierarchyPrefDetailsDto> hierarchyDetails;
	private String fromUserId;
	private String replicateUserId;
	private String claimNo;
	private String fieldType;
	private String transactionDateFrom;
	private String transactionDateTo;
	private String reportType;
	private String claimRegDateFrom;
	private String claimRegDateTo;
	private String startRownum;
	private String endRownum;
	private String total;
	private String position;
	private String teamName;
	private String lineOfBusiness;
	private String userSearchId;
	private String menuSearchId;
	private String agentCode;
	private String isActive;
	private String imdCode;
	private String newPassword;
	private DeviceDetailsDto deviceDetails;
	private String version;
	private String locationCode;
	private String supplierId;
	private String surveyorNo;
	private String surveyorId;
	private String panNumber;
	private String invoiceNumber;
	private String partyId;
	private String claimantName;
	private String panDocId;
	private String claimHandlerUserId;
	private String claimUserId;
	private String statusCount;
	private NotifyUserDto notifyUser;
	private PanDetailsDto panDetails;
	private SurveyDetailsDto surveyDetails;
	private NeftDetails neftDetails;
	private String surveyNo;
	private String limit;
	private String invoiceDate;
	private String partId;
	private String policyNo;
	private String startDate;
	private String endDate;
	private String accountNo;
	private Boolean isLocked;
	private ClaimCycleDetailsDto claimCycleDetails;
	private String claimInsurerHistory;
	private String name;
	private String claimLocationCode;
	private String docType;
	private DocumentDto documentDto;
	private String actionId;
	private String subStatusCode;
	private ClaimReviewDetailsDto claimReviewDetails;
	private InsuredCommunicationDetailsDto insuredCommunicationDetails;
	private RcsClaimDetailsDto rcsClaimDetails;
	private PolicyDetailsDto policyDetails;
	private ClaimHandlerDetailsDto claimHandlerDetails;
	private String subType;
	private String action;
	private String taskNumber;
	private Long taskId;
	private TaskDetailsDto taskDetails;
	private ClaimDetailsDto claimDetails;
	private String wfStatusName;
	private String assignToName;
	private String assignToId;
	private String assignFromName;
	private String assignFromId;
	private String wfStatusCode;
	private SubCalcTypeDto calcSubType;
	private List<String> userList;
	private List<String> locationCodeList;
	private ReserveDetailsDto reserveDetails;
	private RcsDocumentDetailsDto documentDetails;
	private Boolean flag;
	private String statusMasterId;
	private Long eventCodeListDto;
	private ClaimDetailsDto claimDetailsDto;
	private RcsClaimDetailsDto rcsClaimDetailsDto;
	private PolicyDetailsDto policyDetailsDto;
	private Boolean defaultLoad;
	private String status;
	private String subStatus;
	private ClaimAllocationDetailsDto claimAllocationDetails;
	private String assignToUserId;
	private String assignFromUserName;
	private String assignToUserName;
	private String reserveType;
	private String partyType;
	private String partyName;
	private String currencyCode;
	private String currencyRate;
	private String foreignCurrencyRate;
	private String inrRate;
	private String paidAmount;
	private String outstandingAmount;
	private String remarks;
	private String approvalNo;
	private String insuredPartyId;
	private String productCategory;
	private ClaimantLorDocDetailsDto lorDocumentDetails;
	private ClaimantLorDetailDto otherDetails;
	private String deficiencyReason;
	private String lob;
	private String zoneCode;
	private String supplierCode;
	private String eventCode;
	private List<ClaimantLorDocDetailsDto> claimantLorDocDetails;
	private ClaimPartiesDetailsDto claimPartiesDetails;
	private RcsClaimantDetailsDto rcsClaimantDetails;
	private PartyDetailsDto partyDetails;
	private PartiesDto partyDetail;
	private Boolean isSelect;
	private String paymentType;
	private CkycDetailsDto ckycDetails;
	private ClaimDataDetailsDto claimDataDetails;
	private String panNo;
	private String sourceType;
	private String uniqueId;
	private String uniqueIndetifer;
	private String uniqueKey;
	private String moduleName;
	private String calcRefId;
	private LossAssessmentSummaryDetailsDto lossAssesmentDetails;
	private String diaRefNumber;
	private String diaStatus;
	private String attributeCode;
	private CalcDetailsDto calcDetails;
	private DiaDetailsDto diaDetails;
	private PaymentDetailsDto paymentDetails;
	private ForeignCurrencyDetailsDto foreignCurrencyDetails;
	private GstDetailsDto gstDetails;
	private IntermidiaryDetailsDto intermidiaryDetails;
	private FdrPaymentDetailsDto fdrPaymentDetails;
	private DdPaymentDetailsDto ddPaymentDetails;
	private RemittanceDetailsDto remittanceDetails;
	private String paymentRefNo;
	private String reportName;
	private SupplierDetailsDto supplierDetails;
	private String verifiedBy;
	private String verificationDate;
	private String verificationStatus;
	private String neftStatus;
	private CalcSubHeadsDto calcSubHead;
	private String calcHead;
	private String calcType;
	private String subCalcType;
	private String amount;
	private String processType;
	private List<DocumentDto> documentList;
	private String pendingAgeBand;
	private StakeDetailsDto stakeDetailsDto;
	private CalcTypeDto calcTypeDto;
	private String category;
	private String mainStatus;
	private String requestMethod;
	private CkycRequestObjDto ckycObj;
	private String currentStepId;
	private Boolean finalSubmit;
	private String foreignCurrencyAmount;
	private List<CalcHeadsDto> calcHeads;
	private String supplierName;
	private String inrAmount;
	private String reasonForChange;
	private String eReqNumber;
	private String claimantPartnerId;
	private List<String> emailTo;
	private String userTo;
	private String dateOfVisit;
	private String timeofVisit;
	private String surveyorMobileNo;
	private String surveyorEmailId;
	private String surveyorName;
	private String currencyMode;
	private Integer extraRows;
	private CkycDetailsDto ckycVerifyDetails;
	private Integer claimantPartID;
	private String ipType;
	private RemoveClaimantObj removeClaimantObj;
	private String claimNnmber;
	private String password;
	private String causeOfLoss;
	private String transactionMessage;
	private String reserveAmount;
	private String isSalvageStatus;
	private String ifscCode;
	private String pendingAge;
	private String selectZone;
	private Boolean isGSTPayable;
	private TransporterDetailsDto transporterDetails;
	private Boolean isSurveyUploaded;
	private List<String> disallowStatuses;
	private String firstDocReceiveDate;
	private String lastDocReceiveDate;
	private String delayReason;
	private String assessmentId;
	private String fileId;
	private String fileType;
	private String filePath;
	private LitigationFlagDto litigationFlag;
	private String documentId;
	private String fraudFlag;
	private String fraudDetails;
	private String activationStatus;
	private String deviceId;
	private String pin;
	private String clmRef;
	private String firstRevDocDate;
	private String lastDocDate;
	private String closingReason;
	private String colCode;
	private String userCode;
	private String partyCode;
	private String stakeCode;
	private String coverCode;
	private Map<String, String> emailBodyMap;
	private Map<String, String> smsBodyMap;
	private Boolean isMaximusClaim;
	private List<MobileNoDto> smsTo;
	private List<PaymentHistoryDto> paymentApprovalList;
	private String menuName;
	private String claimPaymentId;
	private List<CommonDetailsDto> coverages;
	private String businessUnit;
	private String searchCategory;
	private String searchInput;
	private String fileNumber;
	private String customerType;
	private String fullName;
	private String dob;
	private String gender;
	private String fieldValue;
	private String kycType;
	private String accessToken;
	private String udf1;
	private String udf2;
	private String udf3;
	private String udf4;
	private String udf5;
	private String checksum;
	private String domainType;
	private String ckycNumber;
	private String paramName;
	private String paramValue;
	private List<RiskCoverDetailsDto> opusCoverDetails;

	public List<CommonDetailsDto> getCoverages() {
		return coverages;
	}

	public void setCoverages(List<CommonDetailsDto> coverages) {
		this.coverages = coverages;
	}

	public List<RiskCoverDetailsDto> getOpusCoverDetails() {
		return opusCoverDetails;
	}

	public void setOpusCoverDetails(List<RiskCoverDetailsDto> opusCoverDetails) {
		this.opusCoverDetails = opusCoverDetails;
	}

	public String getReasonForChange() {
		return reasonForChange;
	}

	public void setReasonForChange(String reasonForChange) {
		this.reasonForChange = reasonForChange;
	}

	public String geteReqNumber() {
		return eReqNumber;
	}

	public void seteReqNumber(String eReqNumber) {
		this.eReqNumber = eReqNumber;
	}

	public Boolean getFinalSubmit() {
		return finalSubmit;
	}

	public void setFinalSubmit(Boolean finalSubmit) {
		this.finalSubmit = finalSubmit;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getPageCode() {
		return pageCode;
	}

	public void setPageCode(String pageCode) {
		this.pageCode = pageCode;
	}

	public String getSearchType() {
		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	public String getSectionCode() {
		return sectionCode;
	}

	public void setSectionCode(String sectionCode) {
		this.sectionCode = sectionCode;
	}

	public String getSubSectionCode() {
		return subSectionCode;
	}

	public void setSubSectionCode(String subSectionCode) {
		this.subSectionCode = subSectionCode;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPageType() {
		return pageType;
	}

	public void setPageType(String pageType) {
		this.pageType = pageType;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getFieldCode() {
		return fieldCode;
	}

	public void setFieldCode(String fieldCode) {
		this.fieldCode = fieldCode;
	}

	public String getReferenceType() {
		return referenceType;
	}

	public void setReferenceType(String referenceType) {
		this.referenceType = referenceType;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getLobCode() {
		return lobCode;
	}

	public void setLobCode(String lobCode) {
		this.lobCode = lobCode;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public String getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(String policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public String getPolicyEndDate() {
		return policyEndDate;
	}

	public void setPolicyEndDate(String policyEndDate) {
		this.policyEndDate = policyEndDate;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getClaimHandler() {
		return claimHandler;
	}

	public void setClaimHandler(String claimHandler) {
		this.claimHandler = claimHandler;
	}

	public String getClaimRefNo() {
		return claimRefNo;
	}

	public void setClaimRefNo(String claimRefNo) {
		this.claimRefNo = claimRefNo;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getFromLimit() {
		return fromLimit;
	}

	public void setFromLimit(String fromLimit) {
		this.fromLimit = fromLimit;
	}

	public String getToLimit() {
		return toLimit;
	}

	public void setToLimit(String toLimit) {
		this.toLimit = toLimit;
	}

	public String getClaimRegFromDate() {
		return claimRegFromDate;
	}

	public void setClaimRegFromDate(String claimRegFromDate) {
		this.claimRegFromDate = claimRegFromDate;
	}

	public String getClaimRegToDate() {
		return claimRegToDate;
	}

	public void setClaimRegToDate(String claimRegToDate) {
		this.claimRegToDate = claimRegToDate;
	}

	public String getInsuredMobileNumber() {
		return insuredMobileNumber;
	}

	public void setInsuredMobileNumber(String insuredMobileNumber) {
		this.insuredMobileNumber = insuredMobileNumber;
	}

	public String getInsuredEmailId() {
		return insuredEmailId;
	}

	public void setInsuredEmailId(String insuredEmailId) {
		this.insuredEmailId = insuredEmailId;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getCorporateUserId() {
		return corporateUserId;
	}

	public void setCorporateUserId(String corporateUserId) {
		this.corporateUserId = corporateUserId;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getInspectionDate() {
		return inspectionDate;
	}

	public void setInspectionDate(String inspectionDate) {
		this.inspectionDate = inspectionDate;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getImdChannel() {
		return imdChannel;
	}

	public void setImdChannel(String imdChannel) {
		this.imdChannel = imdChannel;
	}

	public String getSumInsured() {
		return sumInsured;
	}

	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}

	public String getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	public String getLovType() {
		return lovType;
	}

	public void setLovType(String lovType) {
		this.lovType = lovType;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCorporateId() {
		return corporateId;
	}

	public void setCorporateId(String corporateId) {
		this.corporateId = corporateId;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getSearchUserId() {
		return searchUserId;
	}

	public void setSearchUserId(String searchUserId) {
		this.searchUserId = searchUserId;
	}

	public List<HierarchyPrefDetailsDto> getHierarchyDetails() {
		return hierarchyDetails;
	}

	public void setHierarchyDetails(List<HierarchyPrefDetailsDto> hierarchyDetails) {
		this.hierarchyDetails = hierarchyDetails;
	}

	public String getFromUserId() {
		return fromUserId;
	}

	public void setFromUserId(String fromUserId) {
		this.fromUserId = fromUserId;
	}

	public String getReplicateUserId() {
		return replicateUserId;
	}

	public void setReplicateUserId(String replicateUserId) {
		this.replicateUserId = replicateUserId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getFieldType() {
		return fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	public String getTransactionDateFrom() {
		return transactionDateFrom;
	}

	public void setTransactionDateFrom(String transactionDateFrom) {
		this.transactionDateFrom = transactionDateFrom;
	}

	public String getTransactionDateTo() {
		return transactionDateTo;
	}

	public void setTransactionDateTo(String transactionDateTo) {
		this.transactionDateTo = transactionDateTo;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public String getClaimRegDateFrom() {
		return claimRegDateFrom;
	}

	public void setClaimRegDateFrom(String claimRegDateFrom) {
		this.claimRegDateFrom = claimRegDateFrom;
	}

	public String getClaimRegDateTo() {
		return claimRegDateTo;
	}

	public void setClaimRegDateTo(String claimRegDateTo) {
		this.claimRegDateTo = claimRegDateTo;
	}

	public String getStartRownum() {
		return startRownum;
	}

	public void setStartRownum(String startRownum) {
		this.startRownum = startRownum;
	}

	public String getEndRownum() {
		return endRownum;
	}

	public void setEndRownum(String endRownum) {
		this.endRownum = endRownum;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public String getUserSearchId() {
		return userSearchId;
	}

	public void setUserSearchId(String userSearchId) {
		this.userSearchId = userSearchId;
	}

	public String getMenuSearchId() {
		return menuSearchId;
	}

	public void setMenuSearchId(String menuSearchId) {
		this.menuSearchId = menuSearchId;
	}

	public String getAgentCode() {
		return agentCode;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public String getImdCode() {
		return imdCode;
	}

	public void setImdCode(String imdCode) {
		this.imdCode = imdCode;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public DeviceDetailsDto getDeviceDetails() {
		return deviceDetails;
	}

	public void setDeviceDetails(DeviceDetailsDto deviceDetails) {
		this.deviceDetails = deviceDetails;

	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getSurveyorNo() {
		return surveyorNo;
	}

	public void setSurveyorNo(String surveyorNo) {
		this.surveyorNo = surveyorNo;
	}

	public String getSurveyorId() {
		return surveyorId;
	}

	public void setSurveyorId(String surveyorId) {
		this.surveyorId = surveyorId;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getClaimantName() {
		return claimantName;
	}

	public void setClaimantName(String claimantName) {
		this.claimantName = claimantName;
	}

	public String getPanDocId() {
		return panDocId;
	}

	public void setPanDocId(String panDocId) {
		this.panDocId = panDocId;
	}

	public String getClaimHandlerUserId() {
		return claimHandlerUserId;
	}

	public void setClaimHandlerUserId(String claimHandlerUserId) {
		this.claimHandlerUserId = claimHandlerUserId;
	}

	public String getStatusCount() {
		return statusCount;
	}

	public void setStatusCount(String statusCount) {
		this.statusCount = statusCount;
	}

	public NotifyUserDto getNotifyUser() {
		return notifyUser;
	}

	public void setNotifyUser(NotifyUserDto notifyUser) {
		this.notifyUser = notifyUser;
	}

	public PanDetailsDto getPanDetails() {
		return panDetails;
	}

	public void setPanDetails(PanDetailsDto panDetails) {
		this.panDetails = panDetails;
	}

	public SurveyDetailsDto getSurveyDetails() {
		return surveyDetails;
	}

	public void setSurveyDetails(SurveyDetailsDto surveyDetails) {
		this.surveyDetails = surveyDetails;
	}

	public NeftDetails getNeftDetails() {
		return neftDetails;
	}

	public void setNeftDetails(NeftDetails neftDetails) {
		this.neftDetails = neftDetails;
	}

	public String getSurveyNo() {
		return surveyNo;
	}

	public void setSurveyNo(String surveyNo) {
		this.surveyNo = surveyNo;
	}

	public String getLimit() {
		return limit;
	}

	public void setLimit(String limit) {
		this.limit = limit;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getPartId() {
		return partId;
	}

	public void setPartId(String partId) {
		this.partId = partId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public Boolean getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(Boolean isLocked) {
		this.isLocked = isLocked;
	}

	public ClaimCycleDetailsDto getClaimCycleDetails() {
		return claimCycleDetails;
	}

	public void setClaimCycleDetails(ClaimCycleDetailsDto claimCycleDetails) {
		this.claimCycleDetails = claimCycleDetails;
	}

	public String getClaimInsurerHistory() {
		return claimInsurerHistory;
	}

	public void setClaimInsurerHistory(String claimInsurerHistory) {
		this.claimInsurerHistory = claimInsurerHistory;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getClaimLocationCode() {
		return claimLocationCode;
	}

	public void setClaimLocationCode(String claimLocationCode) {
		this.claimLocationCode = claimLocationCode;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public DocumentDto getDocumentDto() {
		return documentDto;
	}

	public void setDocumentDto(DocumentDto documentDto) {
		this.documentDto = documentDto;
	}

	public String getActionId() {
		return actionId;
	}

	public void setActionId(String actionId) {
		this.actionId = actionId;
	}

	public String getSubStatusCode() {
		return subStatusCode;
	}

	public void setSubStatusCode(String subStatusCode) {
		this.subStatusCode = subStatusCode;
	}

	public ClaimReviewDetailsDto getClaimReviewDetails() {
		return claimReviewDetails;
	}

	public void setClaimReviewDetails(ClaimReviewDetailsDto claimReviewDetails) {
		this.claimReviewDetails = claimReviewDetails;
	}

	public InsuredCommunicationDetailsDto getInsuredCommunicationDetails() {
		return insuredCommunicationDetails;
	}

	public void setInsuredCommunicationDetails(InsuredCommunicationDetailsDto insuredCommunicationDetails) {
		this.insuredCommunicationDetails = insuredCommunicationDetails;
	}

	public RcsClaimDetailsDto getRcsClaimDetails() {
		return rcsClaimDetails;
	}

	public void setRcsClaimDetails(RcsClaimDetailsDto rcsClaimDetails) {
		this.rcsClaimDetails = rcsClaimDetails;
	}

	public PolicyDetailsDto getPolicyDetails() {
		return policyDetails;
	}

	public void setPolicyDetails(PolicyDetailsDto policyDetails) {
		this.policyDetails = policyDetails;
	}

	public ClaimHandlerDetailsDto getClaimHandlerDetails() {
		return claimHandlerDetails;
	}

	public void setClaimHandlerDetails(ClaimHandlerDetailsDto claimHandlerDetails) {
		this.claimHandlerDetails = claimHandlerDetails;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getTaskNumber() {
		return taskNumber;
	}

	public void setTaskNumber(String taskNumber) {
		this.taskNumber = taskNumber;
	}

	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public TaskDetailsDto getTaskDetails() {
		return taskDetails;
	}

	public void setTaskDetails(TaskDetailsDto taskDetails) {
		this.taskDetails = taskDetails;
	}

	public ClaimDetailsDto getClaimDetails() {
		return claimDetails;
	}

	public void setClaimDetails(ClaimDetailsDto claimDetails) {
		this.claimDetails = claimDetails;
	}

	public String getWfStatusName() {
		return wfStatusName;
	}

	public void setWfStatusName(String wfStatusName) {
		this.wfStatusName = wfStatusName;
	}

	public String getAssignToName() {
		return assignToName;
	}

	public void setAssignToName(String assignToName) {
		this.assignToName = assignToName;
	}

	public String getAssignToId() {
		return assignToId;
	}

	public void setAssignToId(String assignToId) {
		this.assignToId = assignToId;
	}

	public String getAssignFromName() {
		return assignFromName;
	}

	public void setAssignFromName(String assignFromName) {
		this.assignFromName = assignFromName;
	}

	public String getAssignFromId() {
		return assignFromId;
	}

	public void setAssignFromId(String assignFromId) {
		this.assignFromId = assignFromId;
	}

	public String getWfStatusCode() {
		return wfStatusCode;
	}

	public void setWfStatusCode(String wfStatusCode) {
		this.wfStatusCode = wfStatusCode;
	}

	public SubCalcTypeDto getCalcSubType() {
		return calcSubType;
	}

	public void setCalcSubType(SubCalcTypeDto calcSubType) {
		this.calcSubType = calcSubType;
	}

	public List<String> getUserList() {
		return userList;
	}

	public void setUserList(List<String> userList) {
		this.userList = userList;
	}

	public ReserveDetailsDto getReserveDetails() {
		return reserveDetails;
	}

	public void setReserveDetails(ReserveDetailsDto reserveDetails) {
		this.reserveDetails = reserveDetails;
	}

	public RcsDocumentDetailsDto getDocumentDetails() {
		return documentDetails;
	}

	public void setDocumentDetails(RcsDocumentDetailsDto documentDetails) {
		this.documentDetails = documentDetails;
	}

	public Boolean getFlag() {
		return flag;
	}

	public void setFlag(Boolean flag) {
		this.flag = flag;
	}

	public String getStatusMasterId() {
		return statusMasterId;
	}

	public void setStatusMasterId(String statusMasterId) {
		this.statusMasterId = statusMasterId;
	}

	public Long getEventCodeListDto() {
		return eventCodeListDto;
	}

	public void setEventCodeListDto(Long eventCodeListDto) {
		this.eventCodeListDto = eventCodeListDto;
	}

	public ClaimDetailsDto getClaimDetailsDto() {
		return claimDetailsDto;
	}

	public void setClaimDetailsDto(ClaimDetailsDto claimDetailsDto) {
		this.claimDetailsDto = claimDetailsDto;
	}

	public RcsClaimDetailsDto getRcsClaimDetailsDto() {
		return rcsClaimDetailsDto;
	}

	public void setRcsClaimDetailsDto(RcsClaimDetailsDto rcsClaimDetailsDto) {
		this.rcsClaimDetailsDto = rcsClaimDetailsDto;
	}

	public PolicyDetailsDto getPolicyDetailsDto() {
		return policyDetailsDto;
	}

	public void setPolicyDetailsDto(PolicyDetailsDto policyDetailsDto) {
		this.policyDetailsDto = policyDetailsDto;
	}

	public Boolean getDefaultLoad() {
		return defaultLoad;
	}

	public void setDefaultLoad(Boolean defaultLoad) {
		this.defaultLoad = defaultLoad;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public ClaimAllocationDetailsDto getClaimAllocationDetails() {
		return claimAllocationDetails;
	}

	public void setClaimAllocationDetails(ClaimAllocationDetailsDto claimAllocationDetails) {
		this.claimAllocationDetails = claimAllocationDetails;
	}

	public String getAssignToUserId() {
		return assignToUserId;
	}

	public void setAssignToUserId(String assignToUserId) {
		this.assignToUserId = assignToUserId;
	}

	public String getAssignFromUserName() {
		return assignFromUserName;
	}

	public void setAssignFromUserName(String assignFromUserName) {
		this.assignFromUserName = assignFromUserName;
	}

	public String getAssignToUserName() {
		return assignToUserName;
	}

	public void setAssignToUserName(String assignToUserName) {
		this.assignToUserName = assignToUserName;
	}

	public String getReserveType() {
		return reserveType;
	}

	public void setReserveType(String reserveType) {
		this.reserveType = reserveType;
	}

	public String getPartyType() {
		return partyType;
	}

	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getCurrencyRate() {
		return currencyRate;
	}

	public void setCurrencyRate(String currencyRate) {
		this.currencyRate = currencyRate;
	}

	public String getForeignCurrencyRate() {
		return foreignCurrencyRate;
	}

	public void setForeignCurrencyRate(String foreignCurrencyRate) {
		this.foreignCurrencyRate = foreignCurrencyRate;
	}

	public String getInrRate() {
		return inrRate;
	}

	public void setInrRate(String inrRate) {
		this.inrRate = inrRate;
	}

	public String getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(String outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getApprovalNo() {
		return approvalNo;
	}

	public void setApprovalNo(String approvalNo) {
		this.approvalNo = approvalNo;
	}

	public String getInsuredPartyId() {
		return insuredPartyId;
	}

	public void setInsuredPartyId(String insuredPartyId) {
		this.insuredPartyId = insuredPartyId;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public ClaimantLorDocDetailsDto getLorDocumentDetails() {
		return lorDocumentDetails;
	}

	public void setLorDocumentDetails(ClaimantLorDocDetailsDto lorDocumentDetails) {
		this.lorDocumentDetails = lorDocumentDetails;
	}

	public ClaimantLorDetailDto getOtherDetails() {
		return otherDetails;
	}

	public void setOtherDetails(ClaimantLorDetailDto otherDetails) {
		this.otherDetails = otherDetails;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getZoneCode() {
		return zoneCode;
	}

	public void setZoneCode(String zoneCode) {
		this.zoneCode = zoneCode;
	}

	public String getSupplierCode() {
		return supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	public List<ClaimantLorDocDetailsDto> getClaimantLorDocDetails() {
		return claimantLorDocDetails;
	}

	public void setClaimantLorDocDetails(List<ClaimantLorDocDetailsDto> claimantLorDocDetails) {
		this.claimantLorDocDetails = claimantLorDocDetails;
	}

	public ClaimPartiesDetailsDto getClaimPartiesDetails() {
		return claimPartiesDetails;
	}

	public void setClaimPartiesDetails(ClaimPartiesDetailsDto claimPartiesDetails) {
		this.claimPartiesDetails = claimPartiesDetails;
	}

	public RcsClaimantDetailsDto getRcsClaimantDetails() {
		return rcsClaimantDetails;
	}

	public void setRcsClaimantDetails(RcsClaimantDetailsDto rcsClaimantDetails) {
		this.rcsClaimantDetails = rcsClaimantDetails;
	}

	public PartyDetailsDto getPartyDetails() {
		return partyDetails;
	}

	public void setPartyDetails(PartyDetailsDto partyDetails) {
		this.partyDetails = partyDetails;
	}

	public PartiesDto getPartyDetail() {
		return partyDetail;
	}

	public void setPartyDetail(PartiesDto partyDetail) {
		this.partyDetail = partyDetail;
	}

	public Boolean getIsSelect() {
		return isSelect;
	}

	public void setIsSelect(Boolean isSelect) {
		this.isSelect = isSelect;
	}

	public CkycDetailsDto getCkycDetails() {
		return ckycDetails;
	}

	public void setCkycDetails(CkycDetailsDto ckycDetails) {
		this.ckycDetails = ckycDetails;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public ClaimDataDetailsDto getClaimDataDetails() {
		return claimDataDetails;
	}

	public void setClaimDataDetails(ClaimDataDetailsDto claimDataDetails) {
		this.claimDataDetails = claimDataDetails;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getUniqueIndetifer() {
		return uniqueIndetifer;
	}

	public void setUniqueIndetifer(String uniqueIndetifer) {
		this.uniqueIndetifer = uniqueIndetifer;
	}

	public String getUniqueKey() {
		return uniqueKey;
	}

	public void setUniqueKey(String uniqueKey) {
		this.uniqueKey = uniqueKey;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getCalcRefId() {
		return calcRefId;
	}

	public void setCalcRefId(String calcRefId) {
		this.calcRefId = calcRefId;
	}

	public LossAssessmentSummaryDetailsDto getLossAssesmentDetails() {
		return lossAssesmentDetails;
	}

	public void setLossAssesmentDetails(LossAssessmentSummaryDetailsDto lossAssesmentDetails) {
		this.lossAssesmentDetails = lossAssesmentDetails;
	}

	public String getDiaRefNumber() {
		return diaRefNumber;
	}

	public void setDiaRefNumber(String diaRefNumber) {
		this.diaRefNumber = diaRefNumber;
	}

	public String getAttributeCode() {
		return attributeCode;
	}

	public void setAttributeCode(String attributeCode) {
		this.attributeCode = attributeCode;
	}

	public String getDiaStatus() {
		return diaStatus;
	}

	public void setDiaStatus(String diaStatus) {
		this.diaStatus = diaStatus;
	}

	public CalcDetailsDto getCalcDetails() {
		return calcDetails;
	}

	public void setCalcDetails(CalcDetailsDto calcDetails) {
		this.calcDetails = calcDetails;
	}

	public PaymentDetailsDto getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(PaymentDetailsDto paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	public ForeignCurrencyDetailsDto getForeignCurrencyDetails() {
		return foreignCurrencyDetails;
	}

	public void setForeignCurrencyDetails(ForeignCurrencyDetailsDto foreignCurrencyDetails) {
		this.foreignCurrencyDetails = foreignCurrencyDetails;
	}

	public GstDetailsDto getGstDetails() {
		return gstDetails;
	}

	public void setGstDetails(GstDetailsDto gstDetails) {
		this.gstDetails = gstDetails;
	}

	public IntermidiaryDetailsDto getIntermidiaryDetails() {
		return intermidiaryDetails;
	}

	public void setIntermidiaryDetails(IntermidiaryDetailsDto intermidiaryDetails) {
		this.intermidiaryDetails = intermidiaryDetails;
	}

	public FdrPaymentDetailsDto getFdrPaymentDetails() {
		return fdrPaymentDetails;
	}

	public void setFdrPaymentDetails(FdrPaymentDetailsDto fdrPaymentDetails) {
		this.fdrPaymentDetails = fdrPaymentDetails;
	}

	public DdPaymentDetailsDto getDdPaymentDetails() {
		return ddPaymentDetails;
	}

	public void setDdPaymentDetails(DdPaymentDetailsDto ddPaymentDetails) {
		this.ddPaymentDetails = ddPaymentDetails;
	}

	public RemittanceDetailsDto getRemittanceDetails() {
		return remittanceDetails;
	}

	public void setRemittanceDetails(RemittanceDetailsDto remittanceDetails) {
		this.remittanceDetails = remittanceDetails;
	}

	public String getPaymentRefNo() {
		return paymentRefNo;
	}

	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public SupplierDetailsDto getSupplierDetails() {
		return supplierDetails;
	}

	public void setSupplierDetails(SupplierDetailsDto supplierDetails) {
		this.supplierDetails = supplierDetails;
	}

	public String getVerifiedBy() {
		return verifiedBy;
	}

	public void setVerifiedBy(String verifiedBy) {
		this.verifiedBy = verifiedBy;
	}

	public String getVerificationDate() {
		return verificationDate;
	}

	public void setVerificationDate(String verificationDate) {
		this.verificationDate = verificationDate;
	}

	public String getVerificationStatus() {
		return verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public String getClaimUserId() {
		return claimUserId;
	}

	public void setClaimUserId(String claimUserId) {
		this.claimUserId = claimUserId;
	}

	public CalcSubHeadsDto getCalcSubHead() {
		return calcSubHead;
	}

	public void setCalcSubHead(CalcSubHeadsDto calcSubHead) {
		this.calcSubHead = calcSubHead;
	}

	public String getCalcHead() {
		return calcHead;
	}

	public void setCalcHead(String calcHead) {
		this.calcHead = calcHead;
	}

	public String getCalcType() {
		return calcType;
	}

	public void setCalcType(String calcType) {
		this.calcType = calcType;
	}

	public String getSubCalcType() {
		return subCalcType;
	}

	public void setSubCalcType(String subCalcType) {
		this.subCalcType = subCalcType;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public List<DocumentDto> getDocumentList() {
		return documentList;
	}

	public void setDocumentList(List<DocumentDto> documentList) {
		this.documentList = documentList;
	}

	public String getPendingAgeBand() {
		return pendingAgeBand;
	}

	public void setPendingAgeBand(String pendingAgeBand) {
		this.pendingAgeBand = pendingAgeBand;
	}

	public StakeDetailsDto getStakeDetailsDto() {
		return stakeDetailsDto;
	}

	public void setStakeDetailsDto(StakeDetailsDto stakeDetailsDto) {
		this.stakeDetailsDto = stakeDetailsDto;
	}

	public CalcTypeDto getCalcTypeDto() {
		return calcTypeDto;
	}

	public void setCalcTypeDto(CalcTypeDto calcTypeDto) {
		this.calcTypeDto = calcTypeDto;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getMainStatus() {
		return mainStatus;
	}

	public void setMainStatus(String mainStatus) {
		this.mainStatus = mainStatus;
	}

	public String getRequestMethod() {
		return requestMethod;
	}

	public void setRequestMethod(String requestMethod) {
		this.requestMethod = requestMethod;
	}

	public CkycRequestObjDto getCkycObj() {
		return ckycObj;
	}

	public void setCkycObj(CkycRequestObjDto ckycObj) {
		this.ckycObj = ckycObj;
	}

	public String getCurrentStepId() {
		return currentStepId;
	}

	public void setCurrentStepId(String currentStepId) {
		this.currentStepId = currentStepId;
	}

	public DiaDetailsDto getDiaDetails() {
		return diaDetails;
	}

	public void setDiaDetails(DiaDetailsDto diaDetails) {
		this.diaDetails = diaDetails;
	}

	public String getForeignCurrencyAmount() {
		return foreignCurrencyAmount;
	}

	public void setForeignCurrencyAmount(String foreignCurrencyAmount) {
		this.foreignCurrencyAmount = foreignCurrencyAmount;
	}

	public List<CalcHeadsDto> getCalcHeads() {
		return calcHeads;
	}

	public void setCalcHeads(List<CalcHeadsDto> calcHeads) {
		this.calcHeads = calcHeads;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getInrAmount() {
		return inrAmount;
	}

	public void setInrAmount(String inrAmount) {
		this.inrAmount = inrAmount;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public List<String> getLocationCodeList() {
		return locationCodeList;
	}

	public void setLocationCodeList(List<String> locationCodeList) {
		this.locationCodeList = locationCodeList;
	}

	public String getClaimantPartnerId() {
		return claimantPartnerId;
	}

	public void setClaimantPartnerId(String claimantPartnerId) {
		this.claimantPartnerId = claimantPartnerId;
	}

	public List<String> getEmailTo() {
		return emailTo;
	}

	public void setEmailTo(List<String> emailTo) {
		this.emailTo = emailTo;
	}

	public String getUserTo() {
		return userTo;
	}

	public void setUserTo(String userTo) {
		this.userTo = userTo;
	}

	public String getDateOfVisit() {
		return dateOfVisit;
	}

	public void setDateOfVisit(String dateOfVisit) {
		this.dateOfVisit = dateOfVisit;
	}

	public String getTimeofVisit() {
		return timeofVisit;
	}

	public void setTimeofVisit(String timeofVisit) {
		this.timeofVisit = timeofVisit;
	}

	public String getSurveyorMobileNo() {
		return surveyorMobileNo;
	}

	public void setSurveyorMobileNo(String surveyorMobileNo) {
		this.surveyorMobileNo = surveyorMobileNo;
	}

	public String getSurveyorEmailId() {
		return surveyorEmailId;
	}

	public void setSurveyorEmailId(String surveyorEmailId) {
		this.surveyorEmailId = surveyorEmailId;
	}

	public String getSurveyorName() {
		return surveyorName;
	}

	public void setSurveyorName(String surveyorName) {
		this.surveyorName = surveyorName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getCurrencyMode() {
		return currencyMode;
	}

	public void setCurrencyMode(String currencyMode) {
		this.currencyMode = currencyMode;
	}

	public CkycDetailsDto getCkycVerifyDetails() {
		return ckycVerifyDetails;
	}

	public void setCkycVerifyDetails(CkycDetailsDto ckycVerifyDetails) {
		this.ckycVerifyDetails = ckycVerifyDetails;
	}

	public Integer getExtraRows() {
		return extraRows;
	}

	public void setExtraRows(Integer extraRows) {
		this.extraRows = extraRows;
	}

	public String getIpType() {
		return ipType;
	}

	public void setIpType(String ipType) {
		this.ipType = ipType;
	}

	public RemoveClaimantObj getRemoveClaimantObj() {
		return removeClaimantObj;
	}

	public void setRemoveClaimantObj(RemoveClaimantObj removeClaimantObj) {
		this.removeClaimantObj = removeClaimantObj;
	}

	public String getClaimNnmber() {
		return claimNnmber;
	}

	public void setClaimNnmber(String claimNnmber) {
		this.claimNnmber = claimNnmber;
	}

	public Integer getClaimantPartID() {
		return claimantPartID;
	}

	public void setClaimantPartID(Integer claimantPartID) {
		this.claimantPartID = claimantPartID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCauseOfLoss() {
		return causeOfLoss;
	}

	public void setCauseOfLoss(String causeOfLoss) {
		this.causeOfLoss = causeOfLoss;
	}

	public TransporterDetailsDto getTransporterDetails() {
		return transporterDetails;
	}

	public void setTransporterDetails(TransporterDetailsDto transporterDetails) {
		this.transporterDetails = transporterDetails;
	}

	public String getTransactionMessage() {
		return transactionMessage;
	}

	public void setTransactionMessage(String transactionMessage) {
		this.transactionMessage = transactionMessage;
	}

	public String getReserveAmount() {
		return reserveAmount;
	}

	public void setReserveAmount(String reserveAmount) {
		this.reserveAmount = reserveAmount;
	}

	public String getIsSalvageStatus() {
		return isSalvageStatus;
	}

	public void setIsSalvageStatus(String isSalvageStatus) {
		this.isSalvageStatus = isSalvageStatus;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getPendingAge() {
		return pendingAge;
	}

	public void setPendingAge(String pendingAge) {
		this.pendingAge = pendingAge;
	}

	public String getSelectZone() {
		return selectZone;
	}

	public void setSelectZone(String selectZone) {
		this.selectZone = selectZone;
	}

	public Boolean getIsGSTPayable() {
		return isGSTPayable;
	}

	public void setIsGSTPayable(Boolean isGSTPayable) {
		this.isGSTPayable = isGSTPayable;
	}

	public Boolean getIsSurveyUploaded() {
		return isSurveyUploaded;
	}

	public void setIsSurveyUploaded(Boolean isSurveyUploaded) {
		this.isSurveyUploaded = isSurveyUploaded;
	}

	public List<String> getDisallowStatuses() {
		return disallowStatuses;
	}

	public void setDisallowStatuses(List<String> disallowStatuses) {
		this.disallowStatuses = disallowStatuses;
	}

	public String getFirstDocReceiveDate() {
		return firstDocReceiveDate;
	}

	public void setFirstDocReceiveDate(String firstDocReceiveDate) {
		this.firstDocReceiveDate = firstDocReceiveDate;
	}

	public String getLastDocReceiveDate() {
		return lastDocReceiveDate;
	}

	public void setLastDocReceiveDate(String lastDocReceiveDate) {
		this.lastDocReceiveDate = lastDocReceiveDate;
	}

	public String getDelayReason() {
		return delayReason;
	}

	public void setDelayReason(String delayReason) {
		this.delayReason = delayReason;
	}

	public String getAssessmentId() {
		return assessmentId;
	}

	public void setAssessmentId(String assessmentId) {
		this.assessmentId = assessmentId;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public LitigationFlagDto getLitigationFlag() {
		return litigationFlag;
	}

	public void setLitigationFlag(LitigationFlagDto litigationFlag) {
		this.litigationFlag = litigationFlag;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getFraudFlag() {
		return fraudFlag;
	}

	public void setFraudFlag(String fraudFlag) {
		this.fraudFlag = fraudFlag;
	}

	public String getFraudDetails() {
		return fraudDetails;
	}

	public void setFraudDetails(String fraudDetails) {
		this.fraudDetails = fraudDetails;
	}

	public String getActivationStatus() {
		return activationStatus;
	}

	public void setActivationStatus(String activationStatus) {
		this.activationStatus = activationStatus;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getClmRef() {
		return clmRef;
	}

	public void setClmRef(String clmRef) {
		this.clmRef = clmRef;
	}

	public String getFirstRevDocDate() {
		return firstRevDocDate;
	}

	public void setFirstRevDocDate(String firstRevDocDate) {
		this.firstRevDocDate = firstRevDocDate;
	}

	public String getLastDocDate() {
		return lastDocDate;
	}

	public void setLastDocDate(String lastDocDate) {
		this.lastDocDate = lastDocDate;
	}

	public String getClosingReason() {
		return closingReason;
	}

	public void setClosingReason(String closingReason) {
		this.closingReason = closingReason;
	}

	public String getColCode() {
		return colCode;
	}

	public void setColCode(String colCode) {
		this.colCode = colCode;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public String getStakeCode() {
		return stakeCode;
	}

	public void setStakeCode(String stakeCode) {
		this.stakeCode = stakeCode;
	}

	public String getCoverCode() {
		return coverCode;
	}

	public void setCoverCode(String coverCode) {
		this.coverCode = coverCode;
	}

	public Map<String, String> getEmailBodyMap() {
		return emailBodyMap;
	}

	public void setEmailBodyMap(Map<String, String> emailBodyMap) {
		this.emailBodyMap = emailBodyMap;
	}

	public Boolean getIsMaximusClaim() {
		return isMaximusClaim;
	}

	public void setIsMaximusClaim(Boolean isMaximusClaim) {
		this.isMaximusClaim = isMaximusClaim;
	}

	public Map<String, String> getSmsBodyMap() {
		return smsBodyMap;
	}

	public void setSmsBodyMap(Map<String, String> smsBodyMap) {
		this.smsBodyMap = smsBodyMap;
	}

	public List<MobileNoDto> getSmsTo() {
		return smsTo;
	}

	public void setSmsTo(List<MobileNoDto> smsTo) {
		this.smsTo = smsTo;
	}

	public String getDocStatus() {
		return docStatus;
	}

	public void setDocStatus(String docStatus) {
		this.docStatus = docStatus;
	}

	public List<PaymentHistoryDto> getPaymentApprovalList() {
		return paymentApprovalList;
	}

	public void setPaymentApprovalList(List<PaymentHistoryDto> paymentApprovalList) {
		this.paymentApprovalList = paymentApprovalList;
	}

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public String getClaimPaymentId() {
		return claimPaymentId;
	}

	public void setClaimPaymentId(String claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getSearchCategory() {
		return searchCategory;
	}

	public void setSearchCategory(String searchCategory) {
		this.searchCategory = searchCategory;
	}

	public String getSearchInput() {
		return searchInput;
	}

	public void setSearchInput(String searchInput) {
		this.searchInput = searchInput;
	}

	public String getFileNumber() {
		return fileNumber;
	}

	public void setFileNumber(String fileNumber) {
		this.fileNumber = fileNumber;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public String getKycType() {
		return kycType;
	}

	public void setKycType(String kycType) {
		this.kycType = kycType;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getUdf1() {
		return udf1;
	}

	public void setUdf1(String udf1) {
		this.udf1 = udf1;
	}

	public String getUdf2() {
		return udf2;
	}

	public void setUdf2(String udf2) {
		this.udf2 = udf2;
	}

	public String getUdf3() {
		return udf3;
	}

	public void setUdf3(String udf3) {
		this.udf3 = udf3;
	}

	public String getUdf4() {
		return udf4;
	}

	public void setUdf4(String udf4) {
		this.udf4 = udf4;
	}

	public String getUdf5() {
		return udf5;
	}

	public void setUdf5(String udf5) {
		this.udf5 = udf5;
	}

	public String getChecksum() {
		return checksum;
	}

	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	public String getDomainType() {
		return domainType;
	}

	public void setDomainType(String domainType) {
		this.domainType = domainType;
	}

	public String getCkycNumber() {
		return ckycNumber;
	}

	public void setCkycNumber(String ckycNumber) {
		this.ckycNumber = ckycNumber;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	
	
	
	
}