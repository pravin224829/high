package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusDocumentDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private String docId;
	private String roleCode;
	private String userCode;
	private String policyNumber;

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public MaximusDocumentDto(String docId, String roleCode, String userCode, String policyNumber) {
		super();
		this.docId = docId;
		this.roleCode = roleCode;
		this.userCode = userCode;
		this.policyNumber = policyNumber;
	}

	public MaximusDocumentDto() {
		super();
		// TODO Auto-generated constructor stub
	}

}
