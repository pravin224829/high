package com.fa.bajajallianz.cccp.mis.common.dto;

import java.util.ArrayList;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;

public class MaximusClaimPaymentDetails {

	public ApplicationErrorDto applicationError;

	public ArrayList<ClaimPaymentDetailsDto> claimPaymentDetails;

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public ArrayList<ClaimPaymentDetailsDto> getClaimPaymentDetails() {
		return claimPaymentDetails;
	}

	public void setClaimPaymentDetails(ArrayList<ClaimPaymentDetailsDto> claimPaymentDetails) {
		this.claimPaymentDetails = claimPaymentDetails;
	}

}
