package com.fa.bajajallianz.cccp.common.dto;

/**
 * @author Karthik
 */
import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class APIResponseDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long id;
	private String message;
	private String responseStatus;
	private String responseMessage;
	private List<?> responseData;

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public List<?> getResponseData() {
		return responseData;
	}

	public void setResponseData(List<?> responseData) {
		this.responseData = responseData;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
