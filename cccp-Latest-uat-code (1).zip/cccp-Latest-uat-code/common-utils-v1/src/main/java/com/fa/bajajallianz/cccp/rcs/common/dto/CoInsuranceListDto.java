package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CoInsuranceListDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String coInsuranceType;
	private String nameOfCompany;
	private String sharingPercentage;
	private String policyNumber;
	private String claimNumber;
	private String expensesAmount;
	private String lossAmount;
	private String branchName;
	private String branchCode;
	private String branchAddress;

	public String getCoInsuranceType() {
		return coInsuranceType;
	}

	public void setCoInsuranceType(String coInsuranceType) {
		this.coInsuranceType = coInsuranceType;
	}

	public String getNameOfCompany() {
		return nameOfCompany;
	}

	public void setNameOfCompany(String nameOfCompany) {
		this.nameOfCompany = nameOfCompany;
	}

	public String getSharingPercentage() {
		return sharingPercentage;
	}

	public void setSharingPercentage(String sharingPercentage) {
		this.sharingPercentage = sharingPercentage;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getExpensesAmount() {
		return expensesAmount;
	}

	public void setExpensesAmount(String expensesAmount) {
		this.expensesAmount = expensesAmount;
	}

	public String getLossAmount() {
		return lossAmount;
	}

	public void setLossAmount(String lossAmount) {
		this.lossAmount = lossAmount;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getBranchAddress() {
		return branchAddress;
	}

	public void setBranchAddress(String branchAddress) {
		this.branchAddress = branchAddress;
	}

}
