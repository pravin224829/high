package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

public class AgeBandDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private String locationCode;
	private String zoneCode;
	private String fromDays;
	private String toDays;
	private String count;
	private String dayDifference;

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getZoneCode() {
		return zoneCode;
	}

	public void setZoneCode(String zoneCode) {
		this.zoneCode = zoneCode;
	}

	public String getFromDays() {
		return fromDays;
	}

	public void setFromDays(String fromDays) {
		this.fromDays = fromDays;
	}

	public String getToDays() {
		return toDays;
	}

	public void setToDays(String toDays) {
		this.toDays = toDays;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public String getDayDifference() {
		return dayDifference;
	}

	public void setDayDifference(String dayDifference) {
		this.dayDifference = dayDifference;
	}

}
