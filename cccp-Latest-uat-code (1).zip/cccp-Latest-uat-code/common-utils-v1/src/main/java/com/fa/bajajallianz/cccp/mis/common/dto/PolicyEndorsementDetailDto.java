package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

public class PolicyEndorsementDetailDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String endorsementApprovedBy;
	private String endorsementIssueTime;
	private String contractStatus;
	private String previousPolicyNumber;
	private String endorsementRequestBy;
	private String endorsementIssueDate;
	private String endorsementWording;
	private String endorsementPremium;
	private String endorsementEffectiveDate;
	private String sourceOfPremium;
	private String endorsementType;
	private String endorsement64VBStatus;
	private String contractId;
	private String endorsementEffectiveTime;
	private String endorsementVersion;
	private String endorsementNumber;

	public String getEndorsementApprovedBy() {
		return endorsementApprovedBy;
	}

	public void setEndorsementApprovedBy(String endorsementApprovedBy) {
		this.endorsementApprovedBy = endorsementApprovedBy;
	}

	public String getEndorsementIssueTime() {
		return endorsementIssueTime;
	}

	public void setEndorsementIssueTime(String endorsementIssueTime) {
		this.endorsementIssueTime = endorsementIssueTime;
	}

	public String getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

	public String getPreviousPolicyNumber() {
		return previousPolicyNumber;
	}

	public void setPreviousPolicyNumber(String previousPolicyNumber) {
		this.previousPolicyNumber = previousPolicyNumber;
	}

	public String getEndorsementRequestBy() {
		return endorsementRequestBy;
	}

	public void setEndorsementRequestBy(String endorsementRequestBy) {
		this.endorsementRequestBy = endorsementRequestBy;
	}

	public String getEndorsementIssueDate() {
		return endorsementIssueDate;
	}

	public void setEndorsementIssueDate(String endorsementIssueDate) {
		this.endorsementIssueDate = endorsementIssueDate;
	}

	public String getEndorsementWording() {
		return endorsementWording;
	}

	public void setEndorsementWording(String endorsementWording) {
		this.endorsementWording = endorsementWording;
	}

	public String getEndorsementPremium() {
		return endorsementPremium;
	}

	public void setEndorsementPremium(String endorsementPremium) {
		this.endorsementPremium = endorsementPremium;
	}

	public String getEndorsementEffectiveDate() {
		return endorsementEffectiveDate;
	}

	public void setEndorsementEffectiveDate(String endorsementEffectiveDate) {
		this.endorsementEffectiveDate = endorsementEffectiveDate;
	}

	public String getSourceOfPremium() {
		return sourceOfPremium;
	}

	public void setSourceOfPremium(String sourceOfPremium) {
		this.sourceOfPremium = sourceOfPremium;
	}

	public String getEndorsementType() {
		return endorsementType;
	}

	public void setEndorsementType(String endorsementType) {
		this.endorsementType = endorsementType;
	}

	public String getEndorsement64VBStatus() {
		return endorsement64VBStatus;
	}

	public void setEndorsement64VBStatus(String endorsement64vbStatus) {
		endorsement64VBStatus = endorsement64vbStatus;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public String getEndorsementEffectiveTime() {
		return endorsementEffectiveTime;
	}

	public void setEndorsementEffectiveTime(String endorsementEffectiveTime) {
		this.endorsementEffectiveTime = endorsementEffectiveTime;
	}

	public String getEndorsementVersion() {
		return endorsementVersion;
	}

	public void setEndorsementVersion(String endorsementVersion) {
		this.endorsementVersion = endorsementVersion;
	}

	public String getEndorsementNumber() {
		return endorsementNumber;
	}

	public void setEndorsementNumber(String endorsementNumber) {
		this.endorsementNumber = endorsementNumber;
	}

}
