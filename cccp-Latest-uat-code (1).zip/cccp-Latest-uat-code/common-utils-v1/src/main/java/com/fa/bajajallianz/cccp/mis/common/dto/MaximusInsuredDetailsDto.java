package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

public class MaximusInsuredDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private MaximusInsuredInfoDto insuredInfo;
//	private Nominees nominees;
//	private Trips trips;
//	private Flights flights;
//	private Peds peds;
	private MaximusCoversDto covers;
	

//	private Passports passports;
//	private Slabs slabs;
//	private Premiums premiums;
	public MaximusInsuredInfoDto getInsuredInfo() {
		return insuredInfo;
	}

	public void setInsuredInfo(MaximusInsuredInfoDto insuredInfo) {
		this.insuredInfo = insuredInfo;
	}

	public MaximusCoversDto getCovers() {
		return covers;
	}

	public void setCovers(MaximusCoversDto covers) {
		this.covers = covers;
	}

	
	

}
