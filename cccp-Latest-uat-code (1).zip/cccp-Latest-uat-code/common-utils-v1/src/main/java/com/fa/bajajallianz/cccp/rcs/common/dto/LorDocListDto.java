package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LorDocListDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<DocName> docsName;
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<DocName> getDocsName() {
		return docsName;
	}

	public void setDocsName(List<DocName> docsName) {
		this.docsName = docsName;
	}

}
