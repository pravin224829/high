/**
 * 
 */
package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author santhosh
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class BenificiaryDetailsDto implements Serializable{

	private static final long serialVersionUID = 1L;

	private String name;
	private String address1;
	private String address2;
	private String city;
	private String country;
	private String bankName;
	private String bankAddress1;
	private String bankAddress2;
	private String bankAddressCity;
	private String bankAddressCountry;
	private String accountNo;
	private String bankSwiftCode;
	private String bankIbano;
	private String panOfRecipientRemittance;
	private String status;
	private String emailRecipient;
	private String mobileNoRecipient;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankAddress1() {
		return bankAddress1;
	}
	public void setBankAddress1(String bankAddress1) {
		this.bankAddress1 = bankAddress1;
	}
	public String getBankAddress2() {
		return bankAddress2;
	}
	public void setBankAddress2(String bankAddress2) {
		this.bankAddress2 = bankAddress2;
	}
	public String getBankAddressCity() {
		return bankAddressCity;
	}
	public void setBankAddressCity(String bankAddressCity) {
		this.bankAddressCity = bankAddressCity;
	}
	public String getBankAddressCountry() {
		return bankAddressCountry;
	}
	public void setBankAddressCountry(String bankAddressCountry) {
		this.bankAddressCountry = bankAddressCountry;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getBankSwiftCode() {
		return bankSwiftCode;
	}
	public void setBankSwiftCode(String bankSwiftCode) {
		this.bankSwiftCode = bankSwiftCode;
	}
	public String getBankIbano() {
		return bankIbano;
	}
	public void setBankIbano(String bankIbano) {
		this.bankIbano = bankIbano;
	}
	public String getPanOfRecipientRemittance() {
		return panOfRecipientRemittance;
	}
	public void setPanOfRecipientRemittance(String panOfRecipientRemittance) {
		this.panOfRecipientRemittance = panOfRecipientRemittance;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEmailRecipient() {
		return emailRecipient;
	}
	public void setEmailRecipient(String emailRecipient) {
		this.emailRecipient = emailRecipient;
	}
	public String getMobileNoRecipient() {
		return mobileNoRecipient;
	}
	public void setMobileNoRecipient(String mobileNoRecipient) {
		this.mobileNoRecipient = mobileNoRecipient;
	}
	
	
}


