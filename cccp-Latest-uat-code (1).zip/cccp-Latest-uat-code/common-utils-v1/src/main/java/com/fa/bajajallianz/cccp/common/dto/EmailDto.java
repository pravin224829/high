/**
 * 
 */
package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmailDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<String> emailAttachement;
	private String emailBcc;
	private String emailCc;
	private String emailSubject;
	private List<String> emailTo;
	private String partId;
	private String referenceId;
	private String templateId;
	private List<EmailBodyDto> emailBody;
	
	public List<String> getEmailAttachement() {
		return emailAttachement;
	}
	public void setEmailAttachement(List<String> emailAttachement) {
		this.emailAttachement = emailAttachement;
	}
	public String getEmailBcc() {
		return emailBcc;
	}
	public void setEmailBcc(String emailBcc) {
		this.emailBcc = emailBcc;
	}
	public String getEmailCc() {
		return emailCc;
	}
	public void setEmailCc(String emailCc) {
		this.emailCc = emailCc;
	}
	public String getEmailSubject() {
		return emailSubject;
	}
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}
	public List<String> getEmailTo() {
		return emailTo;
	}
	public void setEmailTo(List<String> emailTo) {
		this.emailTo = emailTo;
	}
	public String getPartId() {
		return partId;
	}
	public void setPartId(String partId) {
		this.partId = partId;
	}
	public String getReferenceId() {
		return referenceId;
	}
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	public List<EmailBodyDto> getEmailBody() {
		return emailBody;
	}
	public void setEmailBody(List<EmailBodyDto> emailBody) {
		this.emailBody = emailBody;
	}
	
	
}
