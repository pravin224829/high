package com.fa.bajajallianz.cccp.surveyor.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SurveyorDetailsDto implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String supplierName;
	private String supplierParternId;
	private String supplierPANNumber;
	private String emiailId;
	private String mobileNumber;
	private String licenceLOB;
	private String licenceNumber;
	private String supplierGSTNumber;
	private String alternateNumber;
	private String supplierCity;
	private String supplierStatus;
	private String supplierType;
	private String supplierCode;
	private String mappedLocationCode;
	private String pinCode;
	private String area;
	private String state;
	private String country;
	private String licenceValidFrom;
	private String licenceValidUpto;
	private String iIISLAMembership;
	
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getSupplierParternId() {
		return supplierParternId;
	}
	public void setSupplierParternId(String supplierParternId) {
		this.supplierParternId = supplierParternId;
	}
	public String getSupplierPANNumber() {
		return supplierPANNumber;
	}
	public void setSupplierPANNumber(String supplierPANNumber) {
		this.supplierPANNumber = supplierPANNumber;
	}
	public String getEmiailId() {
		return emiailId;
	}
	public void setEmiailId(String emiailId) {
		this.emiailId = emiailId;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getLicenceLOB() {
		return licenceLOB;
	}
	public void setLicenceLOB(String licenceLOB) {
		this.licenceLOB = licenceLOB;
	}
	public String getLicenceNumber() {
		return licenceNumber;
	}
	public void setLicenceNumber(String licenceNumber) {
		this.licenceNumber = licenceNumber;
	}
	public String getSupplierGSTNumber() {
		return supplierGSTNumber;
	}
	public void setSupplierGSTNumber(String supplierGSTNumber) {
		this.supplierGSTNumber = supplierGSTNumber;
	}
	public String getAlternateNumber() {
		return alternateNumber;
	}
	public void setAlternateNumber(String alternateNumber) {
		this.alternateNumber = alternateNumber;
	}
	public String getSupplierCity() {
		return supplierCity;
	}
	public void setSupplierCity(String supplierCity) {
		this.supplierCity = supplierCity;
	}
	public String getSupplierStatus() {
		return supplierStatus;
	}
	public void setSupplierStatus(String supplierStatus) {
		this.supplierStatus = supplierStatus;
	}
	public String getSupplierType() {
		return supplierType;
	}
	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}
	public String getSupplierCode() {
		return supplierCode;
	}
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}
	public String getMappedLocationCode() {
		return mappedLocationCode;
	}
	public void setMappedLocationCode(String mappedLocationCode) {
		this.mappedLocationCode = mappedLocationCode;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getLicenceValidFrom() {
		return licenceValidFrom;
	}
	public void setLicenceValidFrom(String licenceValidFrom) {
		this.licenceValidFrom = licenceValidFrom;
	}
	public String getLicenceValidUpto() {
		return licenceValidUpto;
	}
	public void setLicenceValidUpto(String licenceValidUpto) {
		this.licenceValidUpto = licenceValidUpto;
	}
	public String getiIISLAMembership() {
		return iIISLAMembership;
	}
	public void setiIISLAMembership(String iIISLAMembership) {
		this.iIISLAMembership = iIISLAMembership;
	}
	
}
