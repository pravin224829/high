package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonMisResponseDto<T> implements Serializable { 
	
	private static final long serialVersionUID = 1L;
	
	private T responseData;
	private ApplicationErrorDto applicationError;
	private ClaimMisDetailsDto claimDetails;
	private String message;
	private String status;
	private String errorMessage;
	private String statusCode;
	private List<ClaimReserveDetailsDto> claimReserveDetails;
	
	public T getResponseData() {
		return responseData;
	}
	public void setResponseData(T responseData) {
		this.responseData = responseData;
	}
	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}
	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public ClaimMisDetailsDto getClaimDetails() {
		return claimDetails;
	}
	public void setClaimDetails(ClaimMisDetailsDto claimDetails) {
		this.claimDetails = claimDetails;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public List<ClaimReserveDetailsDto> getClaimReserveDetails() {
		return claimReserveDetails;
	}
	public void setClaimReserveDetails(List<ClaimReserveDetailsDto> claimReserveDetails) {
		this.claimReserveDetails = claimReserveDetails;
	}
	
}