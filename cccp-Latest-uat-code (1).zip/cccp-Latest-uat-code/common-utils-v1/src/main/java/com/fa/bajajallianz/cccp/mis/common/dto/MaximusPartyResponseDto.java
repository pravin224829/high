package com.fa.bajajallianz.cccp.mis.common.dto;
 
import java.io.Serializable;
 
import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
 
@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusPartyResponseDto implements Serializable {
 
	private static final long serialVersionUID = 1L;
 
	private MaximusAddressesListResponseDto addresses;
	private ApplicationErrorDto applicationError;
	private MaximusBasicDetailsDto basicDetails;
	private MaximusPartyDetailsDto partyDetails;
	private MaximusBankAccountsDto bankAccounts;
 
	public MaximusAddressesListResponseDto getAddresses() {
		return addresses;
	}
 
	public void setAddresses(MaximusAddressesListResponseDto addresses) {
		this.addresses = addresses;
	}
 
	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}
 
	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}
 
	public MaximusBasicDetailsDto getBasicDetails() {
		return basicDetails;
	}
 
	public void setBasicDetails(MaximusBasicDetailsDto basicDetails) {
		this.basicDetails = basicDetails;
	}

	public MaximusPartyDetailsDto getPartyDetails() {
		return partyDetails;
	}

	public void setPartyDetails(MaximusPartyDetailsDto partyDetails) {
		this.partyDetails = partyDetails;
	}

	public MaximusBankAccountsDto getBankAccounts() {
		return bankAccounts;
	}

	public void setBankAccounts(MaximusBankAccountsDto bankAccounts) {
		this.bankAccounts = bankAccounts;
	}
 
}
