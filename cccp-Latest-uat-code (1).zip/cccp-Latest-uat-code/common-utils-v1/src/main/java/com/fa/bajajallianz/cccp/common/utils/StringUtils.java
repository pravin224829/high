package com.fa.bajajallianz.cccp.common.utils;

import java.io.Serializable;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * 
 * @author Karthik
 *
 */
public class StringUtils implements Serializable {

	private static final long serialVersionUID = 1L;

	// Request List of String Values Responce is List of Long Values
	public static List<Long> convertListOfStringToLong(List<String> listOfString) {
		List<Long> responceList = new ArrayList<Long>();
		try {
			listOfString.forEach((string -> {
				responceList.add(NumericUtils.convertStringToLong(string));
			}));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return responceList;
	}

	// Request List of Long Values Responce is List of String Values
	public static List<String> convertListOfLongToString(List<Long> listOfLong) {
		List<String> responceList = new ArrayList<String>();
		try {
			listOfLong.forEach((string -> {
				responceList.add(NumericUtils.convertLongToString(string));
			}));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return responceList;
	}

	public static String emptyOrNullWithHypen(String request) {
		try {
			request = (org.apache.commons.lang3.StringUtils.isNotBlank(request) && !"null".equalsIgnoreCase(request))
					? request
					: "-";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return request;
	}

	public static String checkNull(String request) {
		try {
			request = (org.apache.commons.lang3.StringUtils.isNotBlank(request) && !"null".equalsIgnoreCase(request))
					? request
					: CommonConstants.EMPTY_STRING;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return request;
	}

	public static String appendWithPipe(List<String> strings) {
		String result = strings.stream().map(s -> s == null ? "" : s).collect(Collectors.joining("|"));
		return result;
	}

	public static String createChecksum(String message, String algorithmName, String secret) {
		try {
			Mac sha512_HMAC = Mac.getInstance(algorithmName);
			SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(), algorithmName);
			sha512_HMAC.init(secret_key);
			byte raw[] = sha512_HMAC.doFinal(message.getBytes());
			StringBuffer ls_sb = new StringBuffer();
			ls_sb.append(toHex(raw));
			return ls_sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	private static String toHex(byte[] array) throws NoSuchAlgorithmException {
		BigInteger bi = new BigInteger(1, array);
		String hex = bi.toString(16);
		int paddingLength = (array.length * 2) - hex.length();
		if (paddingLength > 0) {
			return String.format("%0" + paddingLength + "d", 0) + hex;
		} else {
			return hex;
		}
	}

}
