package com.fa.bajajallianz.cccp.rcs.common.dto;

public class ClaimantDetailsListDto {

	private String neftStatus;
	private String subType;
	private String partyId;
	private String firstName;
	private String stakeCode;
	private String paymentType;
	private String transactionType;
	private String transactionDate;
	private String reinstatementPremium;
	private String paidAmount;
	private String approvalNo;
	private String paymentStatus;
	private String verificationStatus;
	private String verifiedBy;
	private String verificationRemark;
	private String verificationDateAndTime;
	private String enabledDate;
	private String approvalStatus;
	private String ipNo;
	private String customerType;
	private String nameOfInterestedParties;
	private String claimantRemark;
	private String partyCode;
	private String id;

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getStakeCode() {
		return stakeCode;
	}

	public void setStakeCode(String stakeCode) {
		this.stakeCode = stakeCode;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getReinstatementPremium() {
		return reinstatementPremium;
	}

	public void setReinstatementPremium(String reinstatementPremium) {
		this.reinstatementPremium = reinstatementPremium;
	}

	public String getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(String paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getApprovalNo() {
		return approvalNo;
	}

	public void setApprovalNo(String approvalNo) {
		this.approvalNo = approvalNo;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getVerificationStatus() {
		return verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

	public String getVerifiedBy() {
		return verifiedBy;
	}

	public void setVerifiedBy(String verifiedBy) {
		this.verifiedBy = verifiedBy;
	}

	public String getVerificationRemark() {
		return verificationRemark;
	}

	public void setVerificationRemark(String verificationRemark) {
		this.verificationRemark = verificationRemark;
	}

	public String getEnabledDate() {
		return enabledDate;
	}

	public void setEnabledDate(String enabledDate) {
		this.enabledDate = enabledDate;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public String getIpNo() {
		return ipNo;
	}

	public void setIpNo(String ipNo) {
		this.ipNo = ipNo;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getNameOfInterestedParties() {
		return nameOfInterestedParties;
	}

	public void setNameOfInterestedParties(String nameOfInterestedParties) {
		this.nameOfInterestedParties = nameOfInterestedParties;
	}

	public String getVerificationDateAndTime() {
		return verificationDateAndTime;
	}

	public void setVerificationDateAndTime(String verificationDateAndTime) {
		this.verificationDateAndTime = verificationDateAndTime;
	}

	public String getClaimantRemark() {
		return claimantRemark;
	}

	public void setClaimantRemark(String claimantRemark) {
		this.claimantRemark = claimantRemark;
	}

	public String getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
