package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimantLorDocDetailsDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private String claimantLorDetailsId;
	private String claimantPartyId;
	private String claimNumber;
	private String documentCode;
	private String docLabelName;
	private String docVerifyStatus;
	private String addDocument;
	private String chRemarks;
	private String firstReminderDate;
	private String secondReminderDate;
	private String thirdReminderDate;
	private Boolean isMandatory;
	private Boolean isSelect;
	private String docId;
	private Boolean isActive;
	private String uploadStatus;
	private String docName;
	private String documentName;
	private String displayName;
	private String docVisibleRoles;
	private Boolean isDisabled;
	

	public String getClaimantLorDetailsId() {
		return claimantLorDetailsId;
	}

	public void setClaimantLorDetailsId(String claimantLorDetailsId) {
		this.claimantLorDetailsId = claimantLorDetailsId;
	}

	public String getClaimantPartyId() {
		return claimantPartyId;
	}

	public void setClaimantPartyId(String claimantPartyId) {
		this.claimantPartyId = claimantPartyId;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}

	public String getDocLabelName() {
		return docLabelName;
	}

	public void setDocLabelName(String docLabelName) {
		this.docLabelName = docLabelName;
	}

	public String getDocVerifyStatus() {
		return docVerifyStatus;
	}

	public void setDocVerifyStatus(String docVerifyStatus) {
		this.docVerifyStatus = docVerifyStatus;
	}

	public String getChRemarks() {
		return chRemarks;
	}

	public void setChRemarks(String chRemarks) {
		this.chRemarks = chRemarks;
	}

	public String getFirstReminderDate() {
		return firstReminderDate;
	}

	public void setFirstReminderDate(String firstReminderDate) {
		this.firstReminderDate = firstReminderDate;
	}

	public String getSecondReminderDate() {
		return secondReminderDate;
	}

	public void setSecondReminderDate(String secondReminderDate) {
		this.secondReminderDate = secondReminderDate;
	}

	public String getThirdReminderDate() {
		return thirdReminderDate;
	}

	public void setThirdReminderDate(String thirdReminderDate) {
		this.thirdReminderDate = thirdReminderDate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Boolean getIsMandatory() {
		return isMandatory;
	}

	public void setIsMandatory(Boolean isMandatory) {
		this.isMandatory = isMandatory;
	}

	public String getAddDocument() {
		return addDocument;
	}

	public void setAddDocument(String addDocument) {
		this.addDocument = addDocument;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public Boolean getIsSelect() {
		return isSelect;
	}

	public void setIsSelect(Boolean isSelect) {
		this.isSelect = isSelect;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getUploadStatus() {
		return uploadStatus;
	}

	public void setUploadStatus(String uploadStatus) {
		this.uploadStatus = uploadStatus;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getDocVisibleRoles() {
		return docVisibleRoles;
	}

	public void setDocVisibleRoles(String docVisibleRoles) {
		this.docVisibleRoles = docVisibleRoles;
	}

	public Boolean getIsDisabled() {
		return isDisabled;
	}

	public void setIsDisabled(Boolean isDisabled) {
		this.isDisabled = isDisabled;
	}

}