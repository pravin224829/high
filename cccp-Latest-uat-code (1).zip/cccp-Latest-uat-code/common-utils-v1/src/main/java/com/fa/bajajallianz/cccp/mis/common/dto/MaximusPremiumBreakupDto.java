package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

public class MaximusPremiumBreakupDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private MaximusPremCalcDetailsDto premCalcDetail;
	private MaximusTaxDetailsDto taxDetail;
	private String outstandingPremium;
	private String collectedPremium;

	public MaximusPremCalcDetailsDto getPremCalcDetail() {
		return premCalcDetail;
	}

	public void setPremCalcDetail(MaximusPremCalcDetailsDto premCalcDetail) {
		this.premCalcDetail = premCalcDetail;
	}

	public MaximusTaxDetailsDto getTaxDetail() {
		return taxDetail;
	}

	public void setTaxDetail(MaximusTaxDetailsDto taxDetail) {
		this.taxDetail = taxDetail;
	}

	public String getOutstandingPremium() {
		return outstandingPremium;
	}

	public void setOutstandingPremium(String outstandingPremium) {
		this.outstandingPremium = outstandingPremium;
	}

	public String getCollectedPremium() {
		return collectedPremium;
	}

	public void setCollectedPremium(String collectedPremium) {
		this.collectedPremium = collectedPremium;
	}

}
