package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

import com.fa.bajajallianz.cccp.rcs.common.dto.ReserveDetailsDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimHeaderDetailsDto implements Serializable {
	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;
	private String claimNumber;
	private String policyNumber;
	private String claimHandlerUserId;
	private String deficiencyReason;
	private String pendingAge;
	private String insuredName;
	private String status;
	private String subStatus;
	private String sumInsured;
	private ReserveDetailsDto reserveDetails;
	private String lossReserveAmount;
	private String lossReserveBand;
	private String customerLoyalityCategory;
	private String insuredProfileRating;
	private String productCode;
	private String phiPartnerId;
	private String currentStepId;
	private String claimProcessId;
	private String registrationDate;
	private String causeOfLoss;
	private String dateOfLoss;
	private String policyStartDate;
	private String claimMainStatus;
	private String claimSubStatus;
	private String sourceFlag;
	private String policyEndDate;

	public String getPolicyEndDate() {
		return policyEndDate;
	}

	public void setPolicyEndDate(String policyEndDate) {
		this.policyEndDate = policyEndDate;
	}

	public String getLossReserveAmount() {
		return lossReserveAmount;
	}

	public void setLossReserveAmount(String lossReserveAmount) {
		this.lossReserveAmount = lossReserveAmount;
	}

	public String getLossReserveBand() {
		return lossReserveBand;
	}

	public void setLossReserveBand(String lossReserveBand) {
		this.lossReserveBand = lossReserveBand;
	}

	public String getCustomerLoyalityCategory() {
		return customerLoyalityCategory;
	}

	public void setCustomerLoyalityCategory(String customerLoyalityCategory) {
		this.customerLoyalityCategory = customerLoyalityCategory;
	}

	public String getInsuredProfileRating() {
		return insuredProfileRating;
	}

	public void setInsuredProfileRating(String insuredProfileRating) {
		this.insuredProfileRating = insuredProfileRating;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getClaimHandlerUserId() {
		return claimHandlerUserId;
	}

	public void setClaimHandlerUserId(String claimHandlerUserId) {
		this.claimHandlerUserId = claimHandlerUserId;
	}

	public String getDeficiencyReason() {
		return deficiencyReason;
	}

	public void setDeficiencyReason(String deficiencyReason) {
		this.deficiencyReason = deficiencyReason;
	}

	public String getPendingAge() {
		return pendingAge;
	}

	public void setPendingAge(String pendingAge) {
		this.pendingAge = pendingAge;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public ReserveDetailsDto getReserveDetails() {
		return reserveDetails;
	}

	public void setReserveDetails(ReserveDetailsDto reserveDetails) {
		this.reserveDetails = reserveDetails;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getCurrentStepId() {
		return currentStepId;
	}

	public void setCurrentStepId(String currentStepId) {
		this.currentStepId = currentStepId;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getPhiPartnerId() {
		return phiPartnerId;
	}

	public void setPhiPartnerId(String phiPartnerId) {
		this.phiPartnerId = phiPartnerId;
	}

	public String getClaimProcessId() {
		return claimProcessId;
	}

	public void setClaimProcessId(String claimProcessId) {
		this.claimProcessId = claimProcessId;
	}

	public String getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getSumInsured() {
		return sumInsured;
	}

	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}

	public String getCauseOfLoss() {
		return causeOfLoss;
	}

	public void setCauseOfLoss(String causeOfLoss) {
		this.causeOfLoss = causeOfLoss;
	}

	public String getDateOfLoss() {
		return dateOfLoss;
	}

	public void setDateOfLoss(String dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}

	public String getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(String policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public String getClaimMainStatus() {
		return claimMainStatus;
	}

	public void setClaimMainStatus(String claimMainStatus) {
		this.claimMainStatus = claimMainStatus;
	}

	public String getClaimSubStatus() {
		return claimSubStatus;
	}

	public void setClaimSubStatus(String claimSubStatus) {
		this.claimSubStatus = claimSubStatus;
	}

	public String getSourceFlag() {
		return sourceFlag;
	}

	public void setSourceFlag(String sourceFlag) {
		this.sourceFlag = sourceFlag;
	}
	

}