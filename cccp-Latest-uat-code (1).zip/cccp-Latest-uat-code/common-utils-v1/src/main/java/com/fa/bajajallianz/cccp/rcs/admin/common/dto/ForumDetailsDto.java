package com.fa.bajajallianz.cccp.rcs.admin.common.dto;

import java.io.Serializable;

public class ForumDetailsDto implements Serializable{

	
	
}
