package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OpusRefObj implements Serializable {

	private static final long serialVersionUID = 1L;
	private String claimNumber;
	private String opusRefNo;
	private String transAmount;
	private String ipNo;

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getOpusRefNo() {
		return opusRefNo;
	}

	public void setOpusRefNo(String opusRefNo) {
		this.opusRefNo = opusRefNo;
	}

	public String getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(String transAmount) {
		this.transAmount = transAmount;
	}

	public String getIpNo() {
		return ipNo;
	}

	public void setIpNo(String ipNo) {
		this.ipNo = ipNo;
	}
}
