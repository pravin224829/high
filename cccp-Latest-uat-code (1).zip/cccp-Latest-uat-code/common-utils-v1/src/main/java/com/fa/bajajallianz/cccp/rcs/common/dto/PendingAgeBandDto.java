package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

public class PendingAgeBandDto implements Serializable {
	/**
		 * 
		 */

	private static final long serialVersionUID = 1L;

	private String code;
	private String name;
	private String lowerLimit;
	private String upperLimit;
	private Integer count;
	private String band;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(String lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	public String getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(String upperLimit) {
		this.upperLimit = upperLimit;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public String getBand() {
		return band;
	}

	public void setBand(String band) {
		this.band = band;
	}

}
