/**
 * 
 */
package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimAttributeDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<ClaimAttributeDetailsDto> claimAttributeDetails;

	public List<ClaimAttributeDetailsDto> getClaimAttributeDetails() {
		return claimAttributeDetails;
	}

	public void setClaimAttributeDetails(List<ClaimAttributeDetailsDto> claimAttributeDetails) {
		this.claimAttributeDetails = claimAttributeDetails;
	}
	
	
}
