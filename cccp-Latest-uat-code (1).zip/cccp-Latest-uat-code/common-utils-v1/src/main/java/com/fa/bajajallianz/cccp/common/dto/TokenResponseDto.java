package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TokenResponseDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String messageCode;
	private String successMessage;
	private String errorMessage;
	private PreAuthTokenDto tokenBeanObj;

	public String getMessageCode() {
		return messageCode;
	}

	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}

	public String getSuccessMessage() {
		return successMessage;
	}

	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public PreAuthTokenDto getTokenBeanObj() {
		return tokenBeanObj;
	}

	public void setTokenBeanObj(PreAuthTokenDto tokenBeanObj) {
		this.tokenBeanObj = tokenBeanObj;
	}

}
