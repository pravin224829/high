package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusMiscellaneousDto implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String roleCode;
	private String typeOfEndorsement;
	private String userCode;
	
	public String getRoleCode() {
		return roleCode;
	}
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}
	public String getTypeOfEndorsement() {
		return typeOfEndorsement;
	}
	public void setTypeOfEndorsement(String typeOfEndorsement) {
		this.typeOfEndorsement = typeOfEndorsement;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}	

}
