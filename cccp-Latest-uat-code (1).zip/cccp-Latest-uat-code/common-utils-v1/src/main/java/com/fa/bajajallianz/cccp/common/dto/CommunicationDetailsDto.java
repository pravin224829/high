/**
 * 
 */
package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommunicationDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String surveyNo;
	private String surveyorNo;
	private String surveyRefNo;
	private String claimNumber;
	private String surveyorId;
	private String initialSurveyDate;
	private String psrIlaDate;
	private String fsrDate;
	private String reasonForInitialDate;
	private String reasonForPsrDate;
	private String reasonForFsrDate;
	private String message;
	private String roleCode;
	private String userId;
	private String supplierId;
	private String appointmentDate;
	private String delayReason;
	private Boolean isrChange;
	private Boolean psrChange;
	private Boolean fsrChange;
	private String createdDate;
	private String emailId;
	private String mobileNumber;
	private String createdBy;
	private String source;
	private String visitDate;
	private String visitTime;
	private String acceptedDate;
	private String acceptedBy;

	private List<SurveyCommunicationMsgDto> messageList;

	public String getSurveyNo() {
		return surveyNo;
	}

	public void setSurveyNo(String surveyNo) {
		this.surveyNo = surveyNo;
	}

	public String getSurveyRefNo() {
		return surveyRefNo;
	}

	public void setSurveyRefNo(String surveyRefNo) {
		this.surveyRefNo = surveyRefNo;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getSurveyorId() {
		return surveyorId;
	}

	public void setSurveyorId(String surveyorId) {
		this.surveyorId = surveyorId;
	}

	public String getInitialSurveyDate() {
		return initialSurveyDate;
	}

	public void setInitialSurveyDate(String initialSurveyDate) {
		this.initialSurveyDate = initialSurveyDate;
	}

	public String getPsrIlaDate() {
		return psrIlaDate;
	}

	public void setPsrIlaDate(String psrIlaDate) {
		this.psrIlaDate = psrIlaDate;
	}

	public String getFsrDate() {
		return fsrDate;
	}

	public void setFsrDate(String fsrDate) {
		this.fsrDate = fsrDate;
	}

	public String getReasonForInitialDate() {
		return reasonForInitialDate;
	}

	public void setReasonForInitialDate(String reasonForInitialDate) {
		this.reasonForInitialDate = reasonForInitialDate;
	}

	public String getReasonForPsrDate() {
		return reasonForPsrDate;
	}

	public void setReasonForPsrDate(String reasonForPsrDate) {
		this.reasonForPsrDate = reasonForPsrDate;
	}

	public String getReasonForFsrDate() {
		return reasonForFsrDate;
	}

	public void setReasonForFsrDate(String reasonForFsrDate) {
		this.reasonForFsrDate = reasonForFsrDate;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<SurveyCommunicationMsgDto> getMessageList() {
		return messageList;
	}

	public void setMessageList(List<SurveyCommunicationMsgDto> messageList) {
		this.messageList = messageList;
	}

	public String getSurveyorNo() {
		return surveyorNo;
	}

	public void setSurveyorNo(String surveyorNo) {
		this.surveyorNo = surveyorNo;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getDelayReason() {
		return delayReason;
	}

	public void setDelayReason(String delayReason) {
		this.delayReason = delayReason;
	}

	public Boolean getIsrChange() {
		return isrChange;
	}

	public void setIsrChange(Boolean isrChange) {
		this.isrChange = isrChange;
	}

	public Boolean getPsrChange() {
		return psrChange;
	}

	public void setPsrChange(Boolean psrChange) {
		this.psrChange = psrChange;
	}

	public Boolean getFsrChange() {
		return fsrChange;
	}

	public void setFsrChange(Boolean fsrChange) {
		this.fsrChange = fsrChange;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}

	public String getVisitTime() {
		return visitTime;
	}

	public void setVisitTime(String visitTime) {
		this.visitTime = visitTime;
	}

	public String getAcceptedDate() {
		return acceptedDate;
	}

	public void setAcceptedDate(String acceptedDate) {
		this.acceptedDate = acceptedDate;
	}

	public String getAcceptedBy() {
		return acceptedBy;
	}

	public void setAcceptedBy(String acceptedBy) {
		this.acceptedBy = acceptedBy;
	}

}
