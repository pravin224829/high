package com.fa.bajajallianz.cccp.mis.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaximusPoiSearchDetailsDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private MaximusPanDetailsDto panDetails;

	public MaximusPanDetailsDto getPanDetails() {
		return panDetails;
	}

	public void setPanDetails(MaximusPanDetailsDto panDetails) {
		this.panDetails = panDetails;
	}
}
