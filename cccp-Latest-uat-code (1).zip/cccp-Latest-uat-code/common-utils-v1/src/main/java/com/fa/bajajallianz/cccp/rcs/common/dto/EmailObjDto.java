package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmailObjDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String stringVal1;
	private String stringVal2;
	private String stringVal3;
	private String stringVal4;
	private String stringVal5;
	private String stringVal6;
	private String stringVal7;
	private String stringVal8;
	private String stringVal9;
	private String stringVal10;
	private String stringVal11;
	private String stringVal12;
	private String stringVal13;
	private String stringVal14;
	private String stringVal15;
	private String stringVal16;
	private String stringVal17;
	private String stringVal18;
	private String stringVal19;
	private String stringVal20;
	
	public String getStringVal1() {
		return stringVal1;
	}
	public void setStringVal1(String stringVal1) {
		this.stringVal1 = stringVal1;
	}
	public String getStringVal2() {
		return stringVal2;
	}
	public void setStringVal2(String stringVal2) {
		this.stringVal2 = stringVal2;
	}
	public String getStringVal3() {
		return stringVal3;
	}
	public void setStringVal3(String stringVal3) {
		this.stringVal3 = stringVal3;
	}
	public String getStringVal4() {
		return stringVal4;
	}
	public void setStringVal4(String stringVal4) {
		this.stringVal4 = stringVal4;
	}
	public String getStringVal5() {
		return stringVal5;
	}
	public void setStringVal5(String stringVal5) {
		this.stringVal5 = stringVal5;
	}
	public String getStringVal6() {
		return stringVal6;
	}
	public void setStringVal6(String stringVal6) {
		this.stringVal6 = stringVal6;
	}
	public String getStringVal7() {
		return stringVal7;
	}
	public void setStringVal7(String stringVal7) {
		this.stringVal7 = stringVal7;
	}
	public String getStringVal8() {
		return stringVal8;
	}
	public void setStringVal8(String stringVal8) {
		this.stringVal8 = stringVal8;
	}
	public String getStringVal9() {
		return stringVal9;
	}
	public void setStringVal9(String stringVal9) {
		this.stringVal9 = stringVal9;
	}
	public String getStringVal10() {
		return stringVal10;
	}
	public void setStringVal10(String stringVal10) {
		this.stringVal10 = stringVal10;
	}
	public String getStringVal11() {
		return stringVal11;
	}
	public void setStringVal11(String stringVal11) {
		this.stringVal11 = stringVal11;
	}
	public String getStringVal12() {
		return stringVal12;
	}
	public void setStringVal12(String stringVal12) {
		this.stringVal12 = stringVal12;
	}
	public String getStringVal13() {
		return stringVal13;
	}
	public void setStringVal13(String stringVal13) {
		this.stringVal13 = stringVal13;
	}
	public String getStringVal14() {
		return stringVal14;
	}
	public void setStringVal14(String stringVal14) {
		this.stringVal14 = stringVal14;
	}
	public String getStringVal15() {
		return stringVal15;
	}
	public void setStringVal15(String stringVal15) {
		this.stringVal15 = stringVal15;
	}
	public String getStringVal16() {
		return stringVal16;
	}
	public void setStringVal16(String stringVal16) {
		this.stringVal16 = stringVal16;
	}
	public String getStringVal17() {
		return stringVal17;
	}
	public void setStringVal17(String stringVal17) {
		this.stringVal17 = stringVal17;
	}
	public String getStringVal18() {
		return stringVal18;
	}
	public void setStringVal18(String stringVal18) {
		this.stringVal18 = stringVal18;
	}
	public String getStringVal19() {
		return stringVal19;
	}
	public void setStringVal19(String stringVal19) {
		this.stringVal19 = stringVal19;
	}
	public String getStringVal20() {
		return stringVal20;
	}
	public void setStringVal20(String stringVal20) {
		this.stringVal20 = stringVal20;
	}
	
	
}
