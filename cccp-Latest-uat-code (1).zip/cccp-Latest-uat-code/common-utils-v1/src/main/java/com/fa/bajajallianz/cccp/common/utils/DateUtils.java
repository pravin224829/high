package com.fa.bajajallianz.cccp.common.utils;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 
 * @author Karthik
 *
 */

public class DateUtils {

	static {
		TimeZone.setDefault(TimeZone.getTimeZone("Asia/Kolkata"));
	}

	private static String formatMMDDYYYHHMM = "yyyy-MM-dd hh:mm:ss aa";
	private static DecimalFormat decimalFormatHHHMMM = new DecimalFormat("######");

	public static Date sysDate() {
		return new Date();
	}

	public static void main(String[] args) {
//		System.err.println(convertDateTimeToStringHyphen("2023-11-10 15:11:06.0"));
//		System.err.println(isExpire(dateToStringDDMMYYYY(convertStringToDateddMMMyy("07-DEC-23"))));
//		System.err.println(convertStringToDateTimeWithPeriod("10/12/2023 15:11:06 am"));
//		String detectedType = tika.detect(file.getBytes());
	}

	public static Date convertStringToDate(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd/MM/yyyy");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static Date convertStringToDateWithHypen(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("yyyy-MM-dd");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static Date convertStringToDateddMMMyy(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd-MMM-yy");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static String convertStringToStringddMMMyyyy(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd/MM/yyyy");
			try {
				Date date = dfFormat.parse(dateValue);
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
				String val = sdf.format(date);
				return val;
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static Date convertStringToDateMMDDYYYY(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("MM/dd/yyyy");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static Date convertStringToDateDDMMMYYYY(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd/MMM/yyyy");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static String dateToStringDDMMYYYY(Date value) {
		String val = "";
		if (value != null) {
			String DATE_FORMAT_NOW = "dd/MM/yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
			val = sdf.format(value);
		}
		return val;
	}

	public static String dateToStringMMDDYYYY(Date value) {
		String val = "";
		if (value != null) {
			String DATE_FORMAT_NOW = "MM/dd/yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
			val = sdf.format(value);
		}
		return val;
	}

	public static String dateToStringFormatYyyyMmDdHhMmSsHyphen(Date value) {
		String val = "";
		if (value != null) {
			String DATE_FORMAT_NOW = "yyyy-MM-dd HH:mm:ss";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
			val = sdf.format(value);
		}
		return val;
	}

	public static String dateToStringFormatYyyyMmDdHhMmSsSlash(Date value) {
		String val = "";
		if (value != null) {
			String DATE_FORMAT_NOW = "dd/MM/yyyy HH:mm:ss";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
			val = sdf.format(value);
		}
		return val;
	}

	public static String dateToStringFormatddMmYyyy(Date value) {
		String val = "";
		if (value != null) {
			String DATE_FORMAT_NOW = "dd/MM/yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
			val = sdf.format(value);
		}
		return val;
	}

	public static String dateToStringFormatHhMmSs(Date value) {
		String val = "";
		if (value != null) {
			String DATE_FORMAT_NOW = "HH:mm:ss";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
			val = sdf.format(value);
		}
		return val;
	}

	public static String dateToStringFormatHhMmSsWithA(Date value) {
		String val = "";
		if (value != null) {
			String DATE_FORMAT_NOW = "HH:mm:ss a";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
			val = sdf.format(value);
		}
		return val;
	}

	// request is 03/04/2022 01:02:03 AM
	public static Date convertStringToDateTimeWithPeriod(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

	public static Date convertStringToDateTime(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

	public static Date convertStringToDateTimeWithPeriodMMDDYYYY(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

	public static String convertDateTimeToStringWithPeriod(Date dateValue) {
		if (dateValue != null) {
			try {
				String DATE_FORMAT_NOW = "dd/MM/yyyy hh:mm:ss a";
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
				return sdf.format(dateValue);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static String convertDateTimeDDMMMYyyyToStringWithPeriod(Date dateValue) {
		if (dateValue != null) {
			try {
				String DATE_FORMAT_NOW = "dd-MMM-yyyy hh:mm:ss a";
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
				return sdf.format(dateValue);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static String convertDateTimeToStringWithPeriodMMM(Date dateValue) {
		if (dateValue != null) {
			try {
				String DATE_FORMAT_NOW = "dd-MMM-yyyy hh:mm:ss a";
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
				return sdf.format(dateValue);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static String convertDateTimeToString(Date dateValue) {
		if (dateValue != null) {
			try {
				String DATE_FORMAT_NOW = "dd/MM/yyyy hh:mm:ss";
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
				return sdf.format(dateValue);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static String convertDateTimeToStringYYYYDDMM(Date dateValue) {
		if (dateValue != null) {
			try {
				String DATE_FORMAT_NOW = "yyyy/dd/MM";
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
				return sdf.format(dateValue);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static Date convertDateTimeToString(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

	public static Date convertDateTimeToStringHyphen(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

	public static Map<String, String> findTwoDaysDiffHourMinitsSecendsMilliseconds(Date fromDate, Date toDate) {
		Map<String, String> map = null;
		if (fromDate != null && toDate != null) {
			try {
				map = new HashMap<String, String>();
				long diff = fromDate.getTime() - toDate.getTime();
				int years = (int) (diff / (24 * 60 * 60 * 1000)) / 365;
				map.put("Age", String.valueOf(years));
				int diffDays = (int) (diff / (24 * 60 * 60 * 1000));
				map.put("Days", String.valueOf(diffDays));
				int diffhours = (int) (diff / (60 * 60 * 1000));
				map.put("hours", decimalFormatHHHMMM.format(diffhours));
				int diffmin = (int) (diff / (60 * 1000));
				map.put("Minitues", decimalFormatHHHMMM.format(diffmin));
				int diffsec = (int) (diff / (1000));
				map.put("Secends", decimalFormatHHHMMM.format(diffsec));
				map.put("Milliseconds", decimalFormatHHHMMM.format(diff));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return map;
	}

	public static Boolean validateIsDateFormatInHHMM(String dateValue) {
		boolean isValue = false;
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm");
			try {
				System.out.println(dfFormat.parse(dateValue));
				isValue = true;
			} catch (ParseException e) {
				isValue = false;
				e.printStackTrace();
			}
		}
		return isValue;
	}

	public static Boolean validateIsDateFormat(String dateValue) {
		boolean isValue = false;
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd/MM/yyyy");
			try {
				System.out.println("validateIsDateFormat " + dfFormat.parse(dateValue));
				isValue = true;
			} catch (ParseException e) {
				isValue = false;
				e.printStackTrace();
			}
		}
		return isValue;
	}

	public static String uniqueNoYYYMMYDDMilli() {
		SimpleDateFormat dfFormat = new SimpleDateFormat("yyyMMyddkkmmssSS");
		return dfFormat.format(new Date());
	}

	public static String uniqueNoMilli() {
		SimpleDateFormat dfFormat = new SimpleDateFormat("ddMMyyyykkmm");
		return dfFormat.format(new Date());
	}

	public static String uniqueNoYYYY() {
		SimpleDateFormat dfFormat = new SimpleDateFormat("yyyy");
		return dfFormat.format(new Date());
	}

	public static String uniqueNoYYYYMMDD() {
		SimpleDateFormat dfFormat = new SimpleDateFormat("yyyyMMdd");
		return dfFormat.format(new Date());
	}

	public static long dateDifferenceInHour(Date fromDate, Date toDate) {
		LocalDateTime fromDateTime = DateToLocalDateTime(fromDate);
		LocalDateTime toDateTime = DateToLocalDateTime(toDate);
		long diffInDays = ChronoUnit.DAYS.between(fromDateTime, toDateTime);
		long diffInHours = ChronoUnit.HOURS.between(fromDateTime, toDateTime);
		long diffInMin = ChronoUnit.MINUTES.between(fromDateTime, toDateTime);
		long diffInSec = ChronoUnit.SECONDS.between(fromDateTime, toDateTime);
		String result = diffInDays + ":" + diffInHours + ":" + diffInMin + ":" + diffInSec;
		System.out.println(result);
		return diffInHours;
	}

	public static LocalDateTime DateToLocalDateTime(Date date) {
		return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
	}

	public static boolean isDatebetweenTwoDates(Date fromDate, Date toDate, Date currentDate) {
		return currentDate.after(fromDate) && currentDate.before(toDate);
	}

	public static List<LocalDate> getDatesBetweenUsingJava8(LocalDate startDate, LocalDate endDate) {
		long numOfDaysBetween = ChronoUnit.DAYS.between(startDate, endDate);
		return IntStream.iterate(0, i -> i + 1).limit(numOfDaysBetween).mapToObj(i -> startDate.plusDays(i))
				.collect(Collectors.toList());
	}

	public static List<LocalDate> getDatesBetweenUsingJava9(LocalDate startDate, LocalDate endDate) {
		return startDate.datesUntil(endDate).collect(Collectors.toList());
	}

	public static String convertLdtToString(LocalDate localDate) {
		// Get current date time
		String DATE_FORMAT_NOW = "dd/MM/yyyy";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT_NOW);
		String formatDateTime = localDate.format(formatter);
		return formatDateTime;
	}

	public static Date convertStringToDBDateWithHHMMSSA(String date) {
		try {
			if (StringUtils.isNotBlank(date) && !"null".equalsIgnoreCase(date)) {
				return new Date(formatMMDDYYYHHMM.format(date));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static Date convertStringToDBDateWithHHMMSS(String date) {
		String formatMMDDYYYHHMM = "dd/mm/yyyy";
		try {
			if (StringUtils.isNotBlank(date) && !"null".equalsIgnoreCase(date)) {
				return new Date(formatMMDDYYYHHMM.format(date));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String uniqueNoYYYYMM() {
		SimpleDateFormat dfFormat = new SimpleDateFormat("yyyyMM");
		return dfFormat.format(new Date());
	}

	public static Date convertStringYYYYMMDDTHHMMSSZ(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static Date convertStringDDMMYYYYYHHMMSS(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static Date convertStringYYYYMMDDTHHMMSSSSZ(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static Date getDateOnly() {
		Date today = sysDate();
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		try {
			return formatter.parse(formatter.format(today));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return null;
	}

	public static boolean validateCaseCreationDateFormat(String dateValue) {
		boolean isValue = false;

		String[] permissFormats = new String[] { "d/m/yyyy h:mm:ss tt", "d/m/yyyy h:mm tt", "dd/MM/yyyy hh:mm:ss",
				"d/M/yyyy h:mm:ss", "d/M/yyyy hh:mm tt", "d/M/yyyy hh tt", "d/M/yyyy h:mm", "d/M/yyyy h:mm",
				"dd/MM/yyyy hh:mm", "dd/M/yyyy hh:mm", "dd/MM/yyyy", "dd/M/yyyy HH:mm" };
		for (int i = 0; i < permissFormats.length; i++) {
			try {
				SimpleDateFormat sdfObj = new SimpleDateFormat(permissFormats[i]);
				sdfObj.setLenient(false);
				sdfObj.parse(dateValue);
				isValue = true;

				break;
			} catch (Exception e) {
				isValue = false;
			}
		}
		if (!isValue) {
			isValue = isValidDate1(dateValue);
		} else {
			isValue = isValue;
		}
		return isValue;
	}

	public static boolean isValidDate1(String d) {
		String regex = "^([1-9])/([1-9])/[0-9]{4} [0-9]{2} [A-Z][A-Z]$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher((CharSequence) d);
		return matcher.matches();
	}

	public static Date convertStringToTime(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("hh:mm:ss");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static String timeToStringHHMMSS(Date value) {
		String val = "";
		if (value != null) {
			String TIME_FORMAT_NOW = "hh:mm:ss";
			SimpleDateFormat sdf = new SimpleDateFormat(TIME_FORMAT_NOW);
			val = sdf.format(value);
		}
		return val;
	}

	public static String dateDeferenceBetween2date(String inputStringDate1, String inputStringDate2) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
//		inputStringDate1 = "01/01/2022";
//		inputStringDate2 = "40/01/2022";
		try {
			if (StringUtils.isNotBlank(inputStringDate1) && StringUtils.isNotBlank(inputStringDate2)) {
				LocalDate firstDate = LocalDate.parse(inputStringDate1, dtf);
				LocalDate secondDate = LocalDate.parse(inputStringDate2, dtf);
				long days = ChronoUnit.DAYS.between(firstDate, secondDate);
				System.out.println("Days between: " + days);
				return String.valueOf(days);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "0";
	}

	public static String stringToTimeTwelveHours(String time) {
		try {
			String pattern = "hh:mm:ss a";
			ZonedDateTime zdt = ZonedDateTime.parse(time);
			LocalDateTime ldt = zdt.toLocalDateTime();
			DateTimeFormatter.ofPattern(pattern);
			String format = ldt.format(DateTimeFormatter.ofPattern(pattern));
			if (StringUtils.isNotBlank(format)) {
				return format;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	public static String dateToStringDDMMYYYYWith(Date value) {
		String val = "";
		if (value != null) {
			String DATE_FORMAT_NOW = "dd-MMM-yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
			val = sdf.format(value);
		}
		return val;
	}

	public static String stringToDateDDMMYYYYWith(String value) {
		if (StringUtils.isNotEmpty(value)) {
			SimpleDateFormat dfFormat = new SimpleDateFormat("yyyy-MM-dd");
			try {
				SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");
				Date date = dfFormat.parse(value);
				return outputFormat.format(date);
			} catch (ParseException e) {
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

	public static String stringToDateYYYYDDMMWith(String value) {
		if (StringUtils.isNotEmpty(value)) {
			SimpleDateFormat dfFormat = new SimpleDateFormat("yyyy-MM-dd");
			try {
				SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy/dd/MM");
				Date date = dfFormat.parse(value);
				return outputFormat.format(date);
			} catch (ParseException e) {
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

	public static Date convertStringToDateDDMMMYYHYPHEN(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd-MMM-yy");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

//	2023-10-03T00:00:00.000+05:30
	public static Date stringToDateSplitT(String value) {
		String[] sub = value.split("T");
		if (StringUtils.isNotEmpty(value)) {
			DateFormat dfFormat = new SimpleDateFormat("yyyy-MM-dd");
			try {
				return dfFormat.parse(sub[0]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	// 2023-12-23 11:43:17.777
	public static Date stringToDatefromDbObject(String value) {
		if (StringUtils.isNotEmpty(value)) {
			DateFormat dfFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			try {
				return dfFormat.parse(value);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static String convertStringMMddyyyytoddMMyyyy(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("MM/dd/yyyy");
			DateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");
			try {
				Date date = dfFormat.parse(dateValue);
				return outputFormat.format(date);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static long dateDifferenceInDays(Date fromDate, Date toDate) {
		LocalDateTime fromDateTime = DateToLocalDateTime(fromDate);
		LocalDateTime toDateTime = DateToLocalDateTime(toDate);
		long diffInDays = ChronoUnit.DAYS.between(fromDateTime, toDateTime);
		long diffInHours = ChronoUnit.HOURS.between(fromDateTime, toDateTime);
		long diffInMin = ChronoUnit.MINUTES.between(fromDateTime, toDateTime);
		long diffInSec = ChronoUnit.SECONDS.between(fromDateTime, toDateTime);
		String result = diffInDays + ":" + diffInHours + ":" + diffInMin + ":" + diffInSec;
		System.out.println(result);
		return diffInDays;
	}

	public static boolean isExpire(String date) {
		if (date.isEmpty() || date.trim().equals("")) {
			return false;
		} else {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date d = null;
			Date d1 = null;
			try {
				d = sdf.parse(date);
				d1 = sysDate();
				if (d1.compareTo(d) < 0) {
					return false;
				} else if (d.compareTo(d1) == 0) {
					return false;
				} else {
					return true;
				}
			} catch (ParseException e) {
				e.printStackTrace();
				return false;
			}
		}
	}

	public static String convertDateTimeToStringWithTimeZone(Date dateValue) {
		if (dateValue != null) {
			try {
				String DATE_FORMAT_NOW = "yyyy-MM-dd'T'HH:mm:ss'Z'";
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
				return sdf.format(dateValue);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static String convertStringddMMMyyyyToStringddMMyyyy(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd-MMM-yyyy");
			try {
				Date date = dfFormat.parse(dateValue);
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				String val = sdf.format(date);
				return val;
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static String convertStringddMMMyyToStringddMMyyyy(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd-MMM-yy");
			try {
				Date date = dfFormat.parse(dateValue);
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				String val = sdf.format(date);
				return val;
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public static Date stringToDateFormatddMMMyyyyHhMmSsWithA(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss a");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	public static Date stringToDateFormatddMMyyyyHhMmSsWithA(String dateValue) {
		if (StringUtils.isNotEmpty(dateValue)) {
			DateFormat dfFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss a");
			try {
				return dfFormat.parse(dateValue);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;

}
	public static Date convertStringToDateddMMyyyy(String dateValue) {
        if (StringUtils.isNotEmpty(dateValue)) {
            DateFormat dfFormat = new SimpleDateFormat("dd-MM-yyyy");
            try {
                return dfFormat.parse(dateValue);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
	
	public static Date maximusDateConvert(String dateValue) {
        if (StringUtils.isNotEmpty(dateValue)) {
            DateFormat dfFormat = new SimpleDateFormat("dd/MM/yyyy");
            try {
                return dfFormat.parse(dateValue);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
