package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LorDtlListDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<DocumentName> doclist;
	private String status;

	public List<DocumentName> getDoclist() {
		return doclist;
	}

	public void setDoclist(List<DocumentName> doclist) {
		this.doclist = doclist;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
