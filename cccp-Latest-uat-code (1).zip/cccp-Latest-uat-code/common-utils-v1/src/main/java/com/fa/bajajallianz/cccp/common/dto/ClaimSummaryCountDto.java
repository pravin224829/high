package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties
public class ClaimSummaryCountDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5789332422841964060L;

	private Integer noOfClaimRegsitered;

	private Integer noOfClaimUploaded;

	private Integer noOfClaimUpdated;

	private Date createdDate;

	public Integer getNoOfClaimRegsitered() {
		return noOfClaimRegsitered;
	}

	public void setNoOfClaimRegsitered(Integer noOfClaimRegsitered) {
		this.noOfClaimRegsitered = noOfClaimRegsitered;
	}

	public Integer getNoOfClaimUploaded() {
		return noOfClaimUploaded;
	}

	public void setNoOfClaimUploaded(Integer noOfClaimUploaded) {
		this.noOfClaimUploaded = noOfClaimUploaded;
	}

	public Integer getNoOfClaimUpdated() {
		return noOfClaimUpdated;
	}

	public void setNoOfClaimUpdated(Integer noOfClaimUpdated) {
		this.noOfClaimUpdated = noOfClaimUpdated;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
