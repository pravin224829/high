package com.fa.bajajallianz.cccp.surveyor.common.dto;

import java.io.Serializable;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NeftDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 821842970266597209L;
	private String mobileNumber;
	private String payeeAddress;
	private String state;
	private String city;
	private String area;
	private String pinCode;
	private String ifscCode;
	private String micrCode;
	private String bankName;
	private String bankAddress;
	private String bankContactNo;
	private String accountNo;
	private String accountType;
	private String accountHolderName;
	private String email;
	private String panNumber;
	private String reason;
	private String requestStatus;
	private String partyId;
	private String payeeType;
	private String neftRefNo;
	private String surveyNumber;
	private String claimNumber;
	private String status;
	private String insurerdBankDetails;
	private String payeeCode;
	private String payeeEmailId;
	private String branchName;
	private String neftStatus;
	private String modifiedDate;
	private String verificationStatus;
	private String confirmAccountNo;
	private String referenceNo;
	private String verifiedBy;
	private String verificationDateAndTime;
	private String claimantRemark;
	private String createdDate;
	private String partyCode;
	private String verificationDate;
	private String ckycStatus;
	private ApplicationErrorDto applicationError;
	private String messageCode;
	private String remarks;
	private String neftEnableDate;
	private String neftModifiedDate;
	private String lastModifiedBy;

	public String getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(String partyCode) {
		this.partyCode = partyCode;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPayeeAddress() {
		return payeeAddress;
	}

	public void setPayeeAddress(String payeeAddress) {
		this.payeeAddress = payeeAddress;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getMicrCode() {
		return micrCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankAddress() {
		return bankAddress;
	}

	public void setBankAddress(String bankAddress) {
		this.bankAddress = bankAddress;
	}

	public String getBankContactNo() {
		return bankContactNo;
	}

	public void setBankContactNo(String bankContactNo) {
		this.bankContactNo = bankContactNo;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getPayeeType() {
		return payeeType;
	}

	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	public String getNeftRefNo() {
		return neftRefNo;
	}

	public void setNeftRefNo(String neftRefNo) {
		this.neftRefNo = neftRefNo;
	}

	public String getSurveyNumber() {
		return surveyNumber;
	}

	public void setSurveyNumber(String surveyNumber) {
		this.surveyNumber = surveyNumber;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getInsurerdBankDetails() {
		return insurerdBankDetails;
	}

	public void setInsurerdBankDetails(String insurerdBankDetails) {
		this.insurerdBankDetails = insurerdBankDetails;
	}

	public String getPayeeCode() {
		return payeeCode;
	}

	public void setPayeeCode(String payeeCode) {
		this.payeeCode = payeeCode;
	}

	public String getPayeeEmailId() {
		return payeeEmailId;
	}

	public void setPayeeEmailId(String payeeEmailId) {
		this.payeeEmailId = payeeEmailId;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getNeftStatus() {
		return neftStatus;
	}

	public void setNeftStatus(String neftStatus) {
		this.neftStatus = neftStatus;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getVerificationStatus() {
		return verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getConfirmAccountNo() {
		return confirmAccountNo;
	}

	public void setConfirmAccountNo(String confirmAccountNo) {
		this.confirmAccountNo = confirmAccountNo;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getVerifiedBy() {
		return verifiedBy;
	}

	public void setVerifiedBy(String verifiedBy) {
		this.verifiedBy = verifiedBy;
	}

	public String getClaimantRemark() {
		return claimantRemark;
	}

	public void setClaimantRemark(String claimantRemark) {
		this.claimantRemark = claimantRemark;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getVerificationDateAndTime() {
		return verificationDateAndTime;
	}

	public void setVerificationDateAndTime(String verificationDateAndTime) {
		this.verificationDateAndTime = verificationDateAndTime;
	}

	public String getVerificationDate() {
		return verificationDate;
	}

	public void setVerificationDate(String verificationDate) {
		this.verificationDate = verificationDate;
	}

	public String getCkycStatus() {
		return ckycStatus;
	}

	public void setCkycStatus(String ckycStatus) {
		this.ckycStatus = ckycStatus;
	}

	public ApplicationErrorDto getApplicationError() {
		return applicationError;
	}

	public void setApplicationError(ApplicationErrorDto applicationError) {
		this.applicationError = applicationError;
	}

	public String getMessageCode() {
		return messageCode;
	}

	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getNeftEnableDate() {
		return neftEnableDate;
	}

	public void setNeftEnableDate(String neftEnableDate) {
		this.neftEnableDate = neftEnableDate;
	}

	public String getNeftModifiedDate() {
		return neftModifiedDate;
	}

	public void setNeftModifiedDate(String neftModifiedDate) {
		this.neftModifiedDate = neftModifiedDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

}
