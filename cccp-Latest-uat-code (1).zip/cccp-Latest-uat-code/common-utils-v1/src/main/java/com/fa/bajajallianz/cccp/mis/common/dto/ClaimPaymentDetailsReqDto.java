package com.fa.bajajallianz.cccp.mis.common.dto;

public class ClaimPaymentDetailsReqDto {

	private String claimNumber;
	private String voucherNumber;

	public ClaimPaymentDetailsReqDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getVoucherNumber() {
		return voucherNumber;
	}

	public void setVoucherNumber(String voucherNumber) {
		this.voucherNumber = voucherNumber;
	}

	public ClaimPaymentDetailsReqDto(String claimNumber, String voucherNumber) {
		super();
		this.claimNumber = claimNumber;
		this.voucherNumber = voucherNumber;
	}

}
