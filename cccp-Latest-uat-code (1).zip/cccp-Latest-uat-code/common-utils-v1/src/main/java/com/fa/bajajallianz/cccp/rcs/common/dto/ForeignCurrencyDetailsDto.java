package com.fa.bajajallianz.cccp.rcs.common.dto;

import java.io.Serializable;


public class ForeignCurrencyDetailsDto implements Serializable{

	private static final long serialVersionUID = 1L;
	private BenificiaryDetailsDto benificiaryDetails;
		private IntermidiaryDetailsDto intermidiaryDetails;
		private RemittanceDetailsDto remittanceDetails;
	
	public BenificiaryDetailsDto getBenificiaryDetails() {
		return benificiaryDetails;
	}
	public void setBenificiaryDetails(BenificiaryDetailsDto benificiaryDetails) {
		this.benificiaryDetails = benificiaryDetails;
	}
	public IntermidiaryDetailsDto getIntermidiaryDetails() {
		return intermidiaryDetails;
	}
	public void setIntermidiaryDetails(IntermidiaryDetailsDto intermidiaryDetails) {
		this.intermidiaryDetails = intermidiaryDetails;
	}
	public RemittanceDetailsDto getRemittanceDetails() {
		return remittanceDetails;
	}
	public void setRemittanceDetails(RemittanceDetailsDto remittanceDetails) {
		this.remittanceDetails = remittanceDetails;
	}

	
}
