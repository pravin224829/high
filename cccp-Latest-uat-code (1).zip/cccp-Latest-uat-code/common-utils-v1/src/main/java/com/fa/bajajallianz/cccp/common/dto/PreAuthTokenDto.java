package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PreAuthTokenDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String preAuthToken;

	public String getPreAuthToken() {
		return preAuthToken;
	}

	public void setPreAuthToken(String preAuthToken) {
		this.preAuthToken = preAuthToken;
	}

}
