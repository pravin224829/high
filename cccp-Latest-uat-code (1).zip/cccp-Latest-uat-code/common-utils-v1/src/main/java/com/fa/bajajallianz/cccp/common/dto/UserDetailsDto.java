/**
 * 
 */
package com.fa.bajajallianz.cccp.common.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author arunkumar
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserDetailsDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String userName;
	private String userId;
	private String status;
	private List<AccessDetailsDto> accessDetails;
	private List<UserDetailsDto> userDetails;
	private String dashboard;
	private String newClaimRegistration;
	private String claimDocumentUpload;
	private String claimstatus;
	private String reports;
	private String updateClaimDetails;
	private String configuration;
	private PartiesDto partiesDto;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<AccessDetailsDto> getAccessDetails() {
		return accessDetails;
	}

	public void setAccessDetails(List<AccessDetailsDto> accessDetails) {
		this.accessDetails = accessDetails;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<UserDetailsDto> getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(List<UserDetailsDto> userDetails) {
		this.userDetails = userDetails;
	}

	public String getDashboard() {
		return dashboard;
	}

	public void setDashboard(String dashboard) {
		this.dashboard = dashboard;
	}

	public String getNewClaimRegistration() {
		return newClaimRegistration;
	}

	public void setNewClaimRegistration(String newClaimRegistration) {
		this.newClaimRegistration = newClaimRegistration;
	}

	public String getClaimDocumentUpload() {
		return claimDocumentUpload;
	}

	public void setClaimDocumentUpload(String claimDocumentUpload) {
		this.claimDocumentUpload = claimDocumentUpload;
	}
	
	public String getClaimstatus() {
		return claimstatus;
	}

	public void setClaimstatus(String claimstatus) {
		this.claimstatus = claimstatus;
	}

	public String getUpdateClaimDetails() {
		return updateClaimDetails;
	}

	public void setUpdateClaimDetails(String updateClaimDetails) {
		this.updateClaimDetails = updateClaimDetails;
	}

	public String getReports() {
		return reports;
	}

	public void setReports(String reports) {
		this.reports = reports;
	}

	public String getConfiguration() {
		return configuration;
	}

	public void setConfiguration(String configuration) {
		this.configuration = configuration;
	}

	public PartiesDto getPartiesDto() {
		return partiesDto;
	}

	public void setPartiesDto(PartiesDto partiesDto) {
		this.partiesDto = partiesDto;
	}
	
	
	
}
