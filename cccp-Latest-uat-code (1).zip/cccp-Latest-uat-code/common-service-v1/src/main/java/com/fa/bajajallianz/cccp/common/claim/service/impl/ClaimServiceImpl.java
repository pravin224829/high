package com.fa.bajajallianz.cccp.common.claim.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fa.bajajallianz.cccp.common.claim.service.ClaimService;
import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsListDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsListResponseDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDocListResponseDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.dto.PolicyDetails;
import com.fa.bajajallianz.cccp.common.dto.PolicyDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.PolicyResponseDto;
import com.fa.bajajallianz.cccp.common.notify.repository.NotifyRepository;
import com.fa.bajajallianz.cccp.common.report.repository.UserCountRepo;
import com.fa.bajajallianz.cccp.common.restapi.service.CommonRestTemplateService;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.DateUtils;
import com.fa.bajajallianz.cccp.common.utils.ErrorCodeConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.common.utils.NumericUtils;
import com.fa.bajajallianz.cccp.config.utils.CommonErrorMsg;
import com.fa.bajajallianz.cccp.config.utils.CommonRequestUtil;
import com.fa.bajajallianz.cccp.mis.common.dto.CommonMisResponseDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusBasicDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusBasicPolicyDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusCityDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusCityDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClaimSaveDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClmIntimationRespDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusInsuredDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusInsuredInfoDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusPincodeDetailDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusSinglePolicySearchDto;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ClaimServiceImpl implements ClaimService {

	private static final Logger logger = LoggerFactory.getLogger(ClaimServiceImpl.class);

	@Autowired
	CommonErrorMsg commonErrorMsg;

	@Autowired
	CommonRestTemplateService commonRestTemplateService;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private Environment env;

	@Autowired
	NotifyRepository notifyRepository;

	@Autowired
	UserCountRepo userCountRepo;

	public String getProperty() {
		return env.getProperty("CONFIG_API_URL");
	}

	@Override
	public CommonResponseDto<List<ClaimDetailsListDto>> getClaimList(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonResponseDto<List<ClaimDetailsListDto>> commonResponseDto = new CommonResponseDto<>();
		List<ClaimDetailsListDto> dtos = new ArrayList<>();
		logger.info("ClaimServiceImpl--getClaimList--Start");
		try {
			ClaimDetailsListResponseDto claimDetailsListResponseDto = commonRestTemplateService
					.getClaimList(commonRequestDto, request);
			if (claimDetailsListResponseDto != null
					&& !claimDetailsListResponseDto.getClaimDetailsListResponseDto().isEmpty()) {
				commonResponseDto.setResponseData(claimDetailsListResponseDto.getClaimDetailsListResponseDto());
				commonResponseDto.setTotal(claimDetailsListResponseDto.getTotal());
			} else {
				commonResponseDto.setTotal(CommonConstants.ZERO_STRING);
				commonResponseDto.setResponseData(dtos);
			}
			commonResponseDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Exception--- ClaimServiceImpl--getClaimList---", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-getClaimList", "getClaimList", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		return commonResponseDto;
	}

	@Override
	public ClaimDetailsDto getClaimDetails(String claimNumber, HttpServletRequest request) {
		ClaimDetailsDto claimDetailsDto = new ClaimDetailsDto();
		logger.info("ClaimServiceImpl--fetchClaimDetails--Start");
		try {
			if (claimNumber != null && StringUtils.isNotBlank(claimNumber)) {
				claimDetailsDto = commonRestTemplateService.getClaimDetails(claimNumber, request);
			}
		} catch (Exception e) {
			logger.error("Exception--- ClaimServiceImpl--getClaimDetails---", e);
			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-getClaimDetails", "getClaimDetails", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		return claimDetailsDto;
	}

//	@Override
//	public DataTableDto<List<PolicyDetailsDto>> getPolicyDetails(String payload, String main_filter, String sort,
//			String page, String per_page, HttpServletRequest request) {
//		logger.info("Enter into ClaimServiceImpl getPolicyDetails Start...");
//		DataTableDto<List<PolicyDetailsDto>> dataTableDto = new DataTableDto<List<PolicyDetailsDto>>();
//		List<PolicyDetailsDto> dtos = new ArrayList<>();
//		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
//		try {
//			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
//			if ((commonRequestDto != null)) {
//				if (commonRequestDto.getPolicyStartDate() != null
//						&& StringUtils.isNotEmpty(commonRequestDto.getPolicyStartDate())) {
//					commonRequestDto.setInspectionDate(DateUtils.dateToStringDDMMYYYYWith(
//							DateUtils.convertStringToDate(commonRequestDto.getPolicyStartDate())));
//				}
//				if (commonRequestDto.getPolicyEndDate() != null
//						&& StringUtils.isNotEmpty(commonRequestDto.getPolicyEndDate())) {
//					commonRequestDto.setExpiryDate(DateUtils.dateToStringDDMMYYYYWith(
//							DateUtils.convertStringToDate(commonRequestDto.getPolicyEndDate())));
//				}
//				if (commonRequestDto.getLineOfBusiness() != null
//						&& StringUtils.isNotEmpty(commonRequestDto.getLineOfBusiness())) {
//					commonRequestDto.setLovType(commonRequestDto.getLineOfBusiness());
//				}
//				if (commonRequestDto.getImdCode() != null && StringUtils.isNotEmpty(commonRequestDto.getImdCode())) {
//					commonRequestDto.setAgentCode(commonRequestDto.getImdCode());
//				}
//				String flag = null;
//				if(commonRequestDto.getPolicyNumber() != null) {
//					if(CommonConstants.ROLE_ADMIN.equals(commonRequestDto.getRoleCode())) {
//						flag = notifyRepository.getPolicyFlag(commonRequestDto.getPolicyNumber());
//					} else {
//						flag = notifyRepository.getPolicyFlagByUserId(commonRequestDto.getUserId(),
//								commonRequestDto.getPolicyNumber(), CommonConstants.TRUE);
//					}
//				}
//				
//				if (StringUtils.isNotBlank(page) && page != null) {
//					if (page.equals("1")) {
//						commonRequestDto.setStartRownum(NumericUtils.convertIntegerToString(1));
//						commonRequestDto.setEndRownum((NumericUtils.convertIntegerToString(
//								NumericUtils.convertStringToInteger(commonRequestDto.getStartRownum()) + 7)));
//					} else {
//						commonRequestDto.setEndRownum(
//								NumericUtils.convertIntegerToString(NumericUtils.convertStringToInteger(page) * 8));
//						commonRequestDto.setStartRownum(NumericUtils.convertIntegerToString(
//								((NumericUtils.convertStringToInteger(commonRequestDto.getEndRownum()) - 8) + 1)));
//					}
//				}
//				PolicyResponseDto policyDetailsList = null;
//				if (CommonConstants.MAXIMUSFLAG.equals(flag)) {
//					MaximusSinglePolicySearchDto response = commonRestTemplateService
//							.getSavedQuote(commonRequestDto.getPolicyNumber(), request);
//					if (response != null && response.getApplicationError() != null) {
//						if (CommonConstants.ZERO_STRING.equals(response.getApplicationError().getErrorCode())) {
//							policyDetailsList = new PolicyResponseDto();
//							List<PolicyDetailsDto> policyList = new ArrayList<>();
//							PolicyDetailsDto policyDetailsDto = new PolicyDetailsDto();
//							if(response.getBasicPolicyDetails() != null) {
//								MaximusBasicPolicyDetailsDto basicDetails = response.getBasicPolicyDetails();
//								policyDetailsDto.setPolicyNumber(basicDetails.getStrPolicyNumber());
//								policyDetailsDto.setInspectionDate(
//										DateUtils.convertStringToStringddMMMyyyy(basicDetails.getStrPolicyInceptionDate()));
//								policyDetailsDto.setExpiryDate(
//										DateUtils.convertStringToStringddMMMyyyy(basicDetails.getStrPolicyExpiryDate()));
//								policyDetailsDto.setProductCode(basicDetails.getStrProductCode());
//								policyDetailsDto.setProductDescription(basicDetails.getProductName());
//								
//								policyDetailsDto.setPolicyStatus(basicDetails.getStrPolicyStatusDesc());
//							}
//							if(response.getBasicDetails() != null) {
//								MaximusBasicDetailsDto basicDetails = response.getBasicDetails();
//								if("I".equals(basicDetails.getPartyType())) {
//									policyDetailsDto.setInsuredName(Stream
//											.of(basicDetails.getFirstName(), basicDetails.getMiddleName(),
//													basicDetails.getLastName())
//									.filter(name -> name != null && !name.isEmpty()).collect(Collectors.joining(" ")));
//								} else {
//									policyDetailsDto.setInsuredName(basicDetails.getBusinessName());
//								}
//							}
//							policyDetailsDto.setSumInsured(CommonConstants.NA);
//							if (response.getAdditionalPolicyDetails() != null) {
//								policyDetailsDto.setImdChannel(response.getAdditionalPolicyDetails().getImdCode());
//							}
//							if (response.getInsureds() != null) {
//								List<MaximusInsuredDetailsDto> maximusInsuredDetailsDtoList = response.getInsureds()
//										.getInsuredDetails();
//								if (maximusInsuredDetailsDtoList != null && !maximusInsuredDetailsDtoList.isEmpty()) {
//									for (MaximusInsuredDetailsDto maximusInsuredDetailsDto : maximusInsuredDetailsDtoList) {
//										if (maximusInsuredDetailsDto.getInsuredInfo() != null) {
//											MaximusInsuredInfoDto insuredInfo = maximusInsuredDetailsDto
//													.getInsuredInfo();
//											List<String> cattleCodes = Arrays.asList("5002", "6622");
//											List<String> suretyCodes = Arrays.asList("6621");
//											MaximusBasicPolicyDetailsDto basicDetails = response.getBasicPolicyDetails();
//											String[] splitted = basicDetails.getStrPolicyNumber().split("-");
//											if(splitted != null && splitted.length > 1 && cattleCodes.contains(splitted[1])) {
//												policyDetailsDto.setSumInsured(insuredInfo.getRiskSumInsuredinTransactionCurrency());
//											}else if(splitted != null && splitted.length > 1 && suretyCodes.contains(splitted[1])){
//												policyDetailsDto.setSumInsured(response.getAdditionalPolicyDetails().getBondSumInsured());
//											}
//											else{
//												policyDetailsDto.setSumInsured(insuredInfo.getTotalSumInsured());
//											}											
//										}
//									}
//								}
//							}
//							policyList.add(policyDetailsDto);
//							policyDetailsList.setPolicyDetailsList(policyList);
//							policyDetailsList.setTotal(NumericUtils.convertIntegerToString(dtos.size()));
//						}
//					}
//				} else {
//					policyDetailsList = commonRestTemplateService.getPolicyDetails(commonRequestDto, request);
//				}
//				Integer totalCount = 0;
//				if (policyDetailsList != null) {
//					totalCount = NumericUtils.convertStringToInteger(policyDetailsList.getTotal());
//					if (policyDetailsList.getPolicyDetailsList() != null && !policyDetailsList.getPolicyDetailsList().isEmpty()) {
//						 dtos.addAll(policyDetailsList.getPolicyDetailsList());
//					}
//				}
// 
//				Integer pageCount;
//				if (page != null) {
//					pageCount = NumericUtils.convertStringToInteger(page);
//				} else {
//					pageCount = 0;
//				}
//				Integer limit = NumericUtils.convertStringToInteger(per_page);
//				Integer from = (pageCount * limit) - limit + 1;
//				Integer to = pageCount * limit;
//				dataTableDto.setData(dtos);
//				dataTableDto.setPer_page(NumericUtils.convertIntegerToString(limit));
//				dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
//				dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
//				dataTableDto.setCurrent_page(NumericUtils.convertIntegerToString(pageCount));
//				dataTableDto.setTotal(NumericUtils.convertIntegerToString(totalCount));
//				Integer lastReminder = (Optional.ofNullable(totalCount).orElse(0) % limit);
//				Integer last = (Optional.ofNullable(totalCount).orElse(0) / limit);
//				if (lastReminder == 0) {
//					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
//				} else {
//					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
//				}
//				Integer nextPage = pageCount + 1;
//				Integer prevPage = pageCount - 1;
//				String rootUrl = CommonUtils.fetchApi("COMMONROOTURL", getProperty());
//				dataTableDto.setNext_page_url(
//						rootUrl + "/cccp/common/claim/api/searchPolicyList?payload=" + payload + "&main_filter="
//								+ main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
//				dataTableDto.setPrev_page_url(
//						rootUrl + "/cccp/common/claim/api/searchPolicyList?payload=" + payload + "&main_filter="
//								+ main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
//			}
//		} catch (Exception e) {
//			logger.error("Enter into ClaimServiceImpl getPolicyDetails Exception", e);
//			dataTableDto.setStatus(CommonConstants.ERROR);
//			dataTableDto.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
//			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-getPolicyDetails", "searchPolicyList", "",
//					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
//		}
//		logger.info("Enter into ClaimServiceImpl getPolicyDetails End...");
//		return dataTableDto;
//	}
	
		//	BackUp for Ayush code addition
//	@Override
//	public DataTableDto<List<PolicyDetailsDto>> getPolicyDetails(String payload, String main_filter, String sort,
//			String page, String per_page, HttpServletRequest request) {
//		logger.info("Enter into ClaimServiceImpl getPolicyDetails Start...");
//		DataTableDto<List<PolicyDetailsDto>> dataTableDto = new DataTableDto<List<PolicyDetailsDto>>();
//		List<PolicyDetailsDto> dtos = new ArrayList<>();
//		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
//		Integer totalCount = 0;
//		try {
//			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
//			if ((commonRequestDto != null)) {
//				if (commonRequestDto.getPolicyStartDate() != null
//						&& StringUtils.isNotEmpty(commonRequestDto.getPolicyStartDate())) {
//					commonRequestDto.setInspectionDate(DateUtils.dateToStringDDMMYYYYWith(
//							DateUtils.convertStringToDate(commonRequestDto.getPolicyStartDate())));
//				}
//				if (commonRequestDto.getPolicyEndDate() != null
//						&& StringUtils.isNotEmpty(commonRequestDto.getPolicyEndDate())) {
//					commonRequestDto.setExpiryDate(DateUtils.dateToStringDDMMYYYYWith(
//							DateUtils.convertStringToDate(commonRequestDto.getPolicyEndDate())));
//				}
//
//				if (commonRequestDto.getImdCode() != null && StringUtils.isNotEmpty(commonRequestDto.getImdCode())) {
//					commonRequestDto.setAgentCode(commonRequestDto.getImdCode());
//				}
//				if (commonRequestDto.getLineOfBusiness() != null
//						&& StringUtils.isNotEmpty(commonRequestDto.getLineOfBusiness())) {
//					commonRequestDto.setLovType(commonRequestDto.getLineOfBusiness());
//					// db operations
//					ObjectMapper mapper = new ObjectMapper();
//					List<PolicyDetails> details = new ArrayList<>();
//					List<Object[]> fetchPolicyDetailsByLob = userCountRepo
//							.fetchPolicyDetailsByLob(commonRequestDto.getLineOfBusiness());
//					System.out.println("fetch policyDetail" + fetchPolicyDetailsByLob);
//					if (!CollectionUtils.isEmpty(fetchPolicyDetailsByLob)) {
//						for (Object[] obj : fetchPolicyDetailsByLob) {
//							PolicyDetails detail = new PolicyDetails();
//							detail.setInsuredName(obj[0] != null ? obj[0].toString() : null);
//							detail.setPolicyNumber(obj[1] != null ? obj[1].toString() : null);
//							detail.setSumInsured(obj[2] != null ? obj[2].toString() : null);
//							detail.setProductCode(obj[3] != null ? obj[3].toString() : null);
//							detail.setStartDate(obj[4] != null ? obj[4].toString() : null);
//							detail.setPolicyEndDate(obj[5] != null ? obj[5].toString() : null);
//							detail.setLovType(obj[6] != null ? obj[6].toString() : null);
//							detail.setPolicyStatus(obj[7] != null ? obj[7].toString() : null);
//							detail.setProductDescription(obj[8] != null ? obj[8].toString() : null);
//							details.add(detail);
//						}
//						List<PolicyDetailsDto> collect = details.stream()
//								.map(dto -> mapper.convertValue(dto, PolicyDetailsDto.class))
//								.collect(Collectors.toList());
//						dtos.addAll(collect);
//						return mapResponse(payload, main_filter, sort, page, per_page, dataTableDto, dtos, totalCount);
//					}
//				}
//
//				String flag = null;
//				if (commonRequestDto.getPolicyNumber() != null) {
//					if (CommonConstants.ROLE_ADMIN.equals(commonRequestDto.getRoleCode())) {
//						flag = notifyRepository.getPolicyFlag(commonRequestDto.getPolicyNumber());
//					} else {
//						flag = notifyRepository.getPolicyFlagByUserId(commonRequestDto.getUserId(),
//								commonRequestDto.getPolicyNumber(), CommonConstants.TRUE);
//					}
//				}
//
//				if (StringUtils.isNotBlank(page) && page != null) {
//					if (page.equals("1")) {
//						commonRequestDto.setStartRownum(NumericUtils.convertIntegerToString(1));
//						commonRequestDto.setEndRownum((NumericUtils.convertIntegerToString(
//								NumericUtils.convertStringToInteger(commonRequestDto.getStartRownum()) + 7)));
//					} else {
//						commonRequestDto.setEndRownum(
//								NumericUtils.convertIntegerToString(NumericUtils.convertStringToInteger(page) * 8));
//						commonRequestDto.setStartRownum(NumericUtils.convertIntegerToString(
//								((NumericUtils.convertStringToInteger(commonRequestDto.getEndRownum()) - 8) + 1)));
//					}
//				}
//				PolicyResponseDto policyDetailsList = null;
//				//System.out.println("flag======" + flag);
//				if (flag != null && !CommonConstants.MAXIMUSFLAG.equals(flag)) {
//					policyDetailsList = commonRestTemplateService.getPolicyDetails(commonRequestDto, request);
//
//				} else {
//					// List<String> arrayList = notifyRepository.findActiveProductCode();
//					MaximusSinglePolicySearchDto response = commonRestTemplateService
//							.getSavedQuote(commonRequestDto.getPolicyNumber(), request);
//					if (response != null && response.getApplicationError() != null) {
//						if (CommonConstants.ZERO_STRING.equals(response.getApplicationError().getErrorCode())) {
//							policyDetailsList = new PolicyResponseDto();
//							List<PolicyDetailsDto> policyList = new ArrayList<>();
//							PolicyDetailsDto policyDetailsDto = new PolicyDetailsDto();
//							if (response.getBasicPolicyDetails() != null) {
//								MaximusBasicPolicyDetailsDto basicDetails = response.getBasicPolicyDetails();
//								policyDetailsDto.setPolicyNumber(basicDetails.getStrPolicyNumber());
//								policyDetailsDto.setInspectionDate(DateUtils
//										.convertStringToStringddMMMyyyy(basicDetails.getStrPolicyInceptionDate()));
//								policyDetailsDto.setExpiryDate(DateUtils
//										.convertStringToStringddMMMyyyy(basicDetails.getStrPolicyExpiryDate()));
//								policyDetailsDto.setProductCode(basicDetails.getStrProductCode());
//								policyDetailsDto.setProductDescription(basicDetails.getProductName());
//								policyDetailsDto.setPolicyStatus(basicDetails.getStrPolicyStatusDesc());
//							}
//							if (response.getBasicDetails() != null) {
//								MaximusBasicDetailsDto basicDetails = response.getBasicDetails();
//								if ("I".equals(basicDetails.getPartyType())) {
//									policyDetailsDto.setInsuredName(Stream
//											.of(basicDetails.getFirstName(), basicDetails.getMiddleName(),
//													basicDetails.getLastName())
//											.filter(name -> name != null && !name.isEmpty())
//											.collect(Collectors.joining(" ")));
//								} else {
//									policyDetailsDto.setInsuredName(basicDetails.getBusinessName());
//								}
//							}
//							policyDetailsDto.setSumInsured(CommonConstants.NA);
//							if (response.getAdditionalPolicyDetails() != null) {
//								policyDetailsDto.setImdChannel(response.getAdditionalPolicyDetails().getImdCode());
//							}
//							if (response.getInsureds() != null) {
//								List<MaximusInsuredDetailsDto> maximusInsuredDetailsDtoList = response.getInsureds()
//										.getInsuredDetails();
//								if (maximusInsuredDetailsDtoList != null && !maximusInsuredDetailsDtoList.isEmpty()) {
//									for (MaximusInsuredDetailsDto maximusInsuredDetailsDto : maximusInsuredDetailsDtoList) {
//										if (maximusInsuredDetailsDto.getInsuredInfo() != null) {
//											MaximusInsuredInfoDto insuredInfo = maximusInsuredDetailsDto
//													.getInsuredInfo();
//											// List<String> cattleCodes = Arrays.asList("5002", "5003", "5004","5007",
//											// "5008", "5009", "6623","6622");
//											List<String> cattleCodes = notifyRepository.findByActiveProductCode();
//											// List<String> suretyCodes = Arrays.asList("6621");
//											List<String> suretyCodes = notifyRepository.findByActiveProductCode();
//											MaximusBasicPolicyDetailsDto basicDetails = response
//													.getBasicPolicyDetails();
//											String[] splitted = basicDetails.getStrPolicyNumber().split("-");
//											if (splitted != null && splitted.length > 1
//													&& cattleCodes.contains(splitted[1])) {
//												policyDetailsDto.setSumInsured(
//														insuredInfo.getRiskSumInsuredinTransactionCurrency());
//											} else if (splitted != null && splitted.length > 1
//													&& suretyCodes.contains(splitted[1])) {
//												policyDetailsDto.setSumInsured(
//														response.getAdditionalPolicyDetails().getBondSumInsured());
//											} else {
//												policyDetailsDto.setSumInsured(insuredInfo.getTotalSumInsured());
//											}
//										}
//									}
//								}
//							}
//							policyList.add(policyDetailsDto);
//							policyDetailsList.setPolicyDetailsList(policyList);
//							policyDetailsList.setTotal(NumericUtils.convertIntegerToString(dtos.size()));
//							
//
//							}
//						}
//					}
//				if (dtos.size() == 0) {
//					dataTableDto.setError("INVALID");
//					dataTableDto.setMessage("Invalid Policy Number");
//					
//
//				}
//				if (policyDetailsList != null) {
//					totalCount = NumericUtils.convertStringToInteger(policyDetailsList.getTotal());
//					if (policyDetailsList.getPolicyDetailsList() != null
//							&& !policyDetailsList.getPolicyDetailsList().isEmpty()) {
//						dtos.addAll(policyDetailsList.getPolicyDetailsList());
//					}
//				}
//
//				return mapResponse(payload, main_filter, sort, page, per_page, dataTableDto, dtos, totalCount);
//			}
//		} catch (Exception e) {
//			logger.error("Enter into ClaimServiceImpl getPolicyDetails Exception", e);
//			dataTableDto.setStatus(CommonConstants.ERROR);
//			dataTableDto.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
//			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-getPolicyDetails", "searchPolicyList", "",
//					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
//		}
//		logger.info("Enter into ClaimServiceImpl getPolicyDetails End...");
//		return dataTableDto;
//	}
	
	@Override
	public DataTableDto<List<PolicyDetailsDto>> getPolicyDetails(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request) {
		logger.info("Enter into ClaimServiceImpl getPolicyDetails Start...");
			

		DataTableDto<List<PolicyDetailsDto>> dataTableDto = new DataTableDto<List<PolicyDetailsDto>>();
		List<PolicyDetailsDto> dtos = new ArrayList<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		Integer totalCount = 0;
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			
			if ((commonRequestDto != null)) {
				if (commonRequestDto.getPolicyStartDate() != null
						&& StringUtils.isNotEmpty(commonRequestDto.getPolicyStartDate())) {
					commonRequestDto.setInspectionDate(DateUtils.dateToStringDDMMYYYYWith(
							DateUtils.convertStringToDate(commonRequestDto.getPolicyStartDate())));
				}
				if (commonRequestDto.getPolicyEndDate() != null
						&& StringUtils.isNotEmpty(commonRequestDto.getPolicyEndDate())) {
					commonRequestDto.setExpiryDate(DateUtils.dateToStringDDMMYYYYWith(
							DateUtils.convertStringToDate(commonRequestDto.getPolicyEndDate())));
				}

				if (commonRequestDto.getImdCode() != null && StringUtils.isNotEmpty(commonRequestDto.getImdCode())) {
					commonRequestDto.setAgentCode(commonRequestDto.getImdCode());
				}
				if (commonRequestDto.getLineOfBusiness() != null
						&& StringUtils.isNotEmpty(commonRequestDto.getLineOfBusiness())) {
					commonRequestDto.setLovType(commonRequestDto.getLineOfBusiness());
					// db operations
					ObjectMapper mapper = new ObjectMapper();
					List<PolicyDetails> details = new ArrayList<>();
					List<Object[]> fetchPolicyDetailsByLob = userCountRepo
							.fetchPolicyDetailsByLob(commonRequestDto.getLineOfBusiness());
					System.out.println("fetch policyDetail" + fetchPolicyDetailsByLob);
					if (!CollectionUtils.isEmpty(fetchPolicyDetailsByLob)) {
						for (Object[] obj : fetchPolicyDetailsByLob) {
							PolicyDetails detail = new PolicyDetails();
							detail.setInsuredName(obj[0] != null ? obj[0].toString() : null);
							detail.setPolicyNumber(obj[1] != null ? obj[1].toString() : null);
							detail.setSumInsured(obj[2] != null ? obj[2].toString() : null);
							detail.setProductCode(obj[3] != null ? obj[3].toString() : null);
							detail.setStartDate(obj[4] != null ? obj[4].toString() : null);
							detail.setPolicyEndDate(obj[5] != null ? obj[5].toString() : null);
							detail.setLovType(obj[6] != null ? obj[6].toString() : null);
							detail.setPolicyStatus(obj[7] != null ? obj[7].toString() : null);
							detail.setProductDescription(obj[8] != null ? obj[8].toString() : null);
							details.add(detail);
						}
						List<PolicyDetailsDto> collect = details.stream()
								.map(dto -> mapper.convertValue(dto, PolicyDetailsDto.class))
								.collect(Collectors.toList());
						dtos.addAll(collect);
						return mapResponse(payload, main_filter, sort, page, per_page, dataTableDto, dtos, totalCount);
					}
				}

				String flag = null;
				if (commonRequestDto.getPolicyNumber() != null) {
					if (CommonConstants.ROLE_ADMIN.equals(commonRequestDto.getRoleCode())) {
						flag = notifyRepository.getPolicyFlag(commonRequestDto.getPolicyNumber());
					} else {
						flag = notifyRepository.getPolicyFlagByUserId(commonRequestDto.getUserId(),
								commonRequestDto.getPolicyNumber(), CommonConstants.TRUE);
					}
				}

				if (StringUtils.isNotBlank(page) && page != null) {
					if (page.equals("1")) {
						commonRequestDto.setStartRownum(NumericUtils.convertIntegerToString(1));
						commonRequestDto.setEndRownum((NumericUtils.convertIntegerToString(
								NumericUtils.convertStringToInteger(commonRequestDto.getStartRownum()) + 7)));
					} else {
						commonRequestDto.setEndRownum(
								NumericUtils.convertIntegerToString(NumericUtils.convertStringToInteger(page) * 8));
						commonRequestDto.setStartRownum(NumericUtils.convertIntegerToString(
								((NumericUtils.convertStringToInteger(commonRequestDto.getEndRownum()) - 8) + 1)));
					}
				}
				PolicyResponseDto policyDetailsList = null;
				if (CommonConstants.MAXIMUSFLAG.equals(flag)) {
					MaximusSinglePolicySearchDto response = commonRestTemplateService
							.getSavedQuote(commonRequestDto.getPolicyNumber(), request);
					if (response != null && response.getApplicationError() != null) {
						if (CommonConstants.ZERO_STRING.equals(response.getApplicationError().getErrorCode())) {
							policyDetailsList = new PolicyResponseDto();
							List<PolicyDetailsDto> policyList = new ArrayList<>();
							PolicyDetailsDto policyDetailsDto = new PolicyDetailsDto();
							if (response.getBasicPolicyDetails() != null) {
								MaximusBasicPolicyDetailsDto basicDetails = response.getBasicPolicyDetails();
								policyDetailsDto.setPolicyNumber(basicDetails.getStrPolicyNumber());
								policyDetailsDto.setInspectionDate(DateUtils
										.convertStringToStringddMMMyyyy(basicDetails.getStrPolicyInceptionDate()));
								policyDetailsDto.setExpiryDate(DateUtils
										.convertStringToStringddMMMyyyy(basicDetails.getStrPolicyExpiryDate()));
								policyDetailsDto.setProductCode(basicDetails.getStrProductCode());
								policyDetailsDto.setProductDescription(basicDetails.getProductName());
								policyDetailsDto.setPolicyStatus(basicDetails.getStrPolicyStatusDesc());
							}
							if (response.getBasicDetails() != null) {
								MaximusBasicDetailsDto basicDetails = response.getBasicDetails();
								if ("I".equals(basicDetails.getPartyType())) {
									policyDetailsDto.setInsuredName(Stream
											.of(basicDetails.getFirstName(), basicDetails.getMiddleName(),
													basicDetails.getLastName())
											.filter(name -> name != null && !name.isEmpty())
											.collect(Collectors.joining(" ")));
								} else {
									policyDetailsDto.setInsuredName(basicDetails.getBusinessName());
								}
							}
							policyDetailsDto.setSumInsured(CommonConstants.NA);
							if (response.getAdditionalPolicyDetails() != null) {
								policyDetailsDto.setImdChannel(response.getAdditionalPolicyDetails().getImdCode());
							}
							if (response.getInsureds() != null) {
								List<MaximusInsuredDetailsDto> maximusInsuredDetailsDtoList = response.getInsureds()
										.getInsuredDetails();
								if (maximusInsuredDetailsDtoList != null && !maximusInsuredDetailsDtoList.isEmpty()) {
									for (MaximusInsuredDetailsDto maximusInsuredDetailsDto : maximusInsuredDetailsDtoList) {
										if (maximusInsuredDetailsDto.getInsuredInfo() != null) {
											MaximusInsuredInfoDto insuredInfo = maximusInsuredDetailsDto
													.getInsuredInfo();
											List<String> cattleCodes = Arrays.asList("5002", "6622");
											List<String> suretyCodes = Arrays.asList("6621");
											MaximusBasicPolicyDetailsDto basicDetails = response
													.getBasicPolicyDetails();
											String[] splitted = basicDetails.getStrPolicyNumber().split("-");
											if (splitted != null && splitted.length > 1
													&& cattleCodes.contains(splitted[1])) {
												policyDetailsDto.setSumInsured(
														insuredInfo.getRiskSumInsuredinTransactionCurrency());
											} else if (splitted != null && splitted.length > 1
													&& suretyCodes.contains(splitted[1])) {
												policyDetailsDto.setSumInsured(
														response.getAdditionalPolicyDetails().getBondSumInsured());
											} else {
												policyDetailsDto.setSumInsured(insuredInfo.getTotalSumInsured());
											}
										}
									}
								}
							}
							policyList.add(policyDetailsDto);
							policyDetailsList.setPolicyDetailsList(policyList);
							policyDetailsList.setTotal(NumericUtils.convertIntegerToString(dtos.size()));
						}
					}
				} else {
					policyDetailsList = commonRestTemplateService.getPolicyDetails(commonRequestDto, request);
				}
				if (policyDetailsList != null) {
					totalCount = NumericUtils.convertStringToInteger(policyDetailsList.getTotal());
					if (policyDetailsList.getPolicyDetailsList() != null
							&& !policyDetailsList.getPolicyDetailsList().isEmpty()) {
						dtos.addAll(policyDetailsList.getPolicyDetailsList());
					}
				}

				return mapResponse(payload, main_filter, sort, page, per_page, dataTableDto, dtos, totalCount);
			}
		} catch (Exception e) {
			logger.error("Enter into ClaimServiceImpl getPolicyDetails Exception", e);
			dataTableDto.setStatus(CommonConstants.ERROR);
			dataTableDto.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-getPolicyDetails", "searchPolicyList", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("Enter into ClaimServiceImpl getPolicyDetails End...");
		return dataTableDto;
	}

	private DataTableDto<List<PolicyDetailsDto>> mapResponse(String payload, String main_filter, String sort,
			String page, String per_page, DataTableDto<List<PolicyDetailsDto>> dataTableDto,
			List<PolicyDetailsDto> dtos, Integer totalCount) {
		Integer pageCount;
		if (page != null) {
			pageCount = NumericUtils.convertStringToInteger(page);
		} else {
			pageCount = 0;
		}
		Integer limit = NumericUtils.convertStringToInteger(per_page);
		Integer from = (pageCount * limit) - limit + 1;
		Integer to = pageCount * limit;
		dataTableDto.setData(dtos);
		dataTableDto.setPer_page(NumericUtils.convertIntegerToString(limit));
		dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
		dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
		dataTableDto.setCurrent_page(NumericUtils.convertIntegerToString(pageCount));
		dataTableDto.setTotal(NumericUtils.convertIntegerToString(totalCount));
		Integer lastReminder = (totalCount.intValue() % limit);
		Integer last = (totalCount.intValue() / limit);
		if (lastReminder == 0) {
			dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
		} else {
			dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
		}
		Integer nextPage = pageCount + 1;
		Integer prevPage = pageCount - 1;
		String rootUrl = CommonUtils.fetchApi("COMMONROOTURL", getProperty());

		dataTableDto.setNext_page_url(rootUrl + "/cccp/common/claim/api/searchPolicyList?payload=" + payload
				+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
		dataTableDto.setPrev_page_url(rootUrl + "/cccp/common/claim/api/searchPolicyList?payload=" + payload
				+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
		return dataTableDto;
	}

	@Override
	public ClaimDocListResponseDto getClaimDocList(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		ClaimDocListResponseDto claimDocListResponseDto = new ClaimDocListResponseDto();
		logger.info("Enter into ClaimServiceImpl getClaimDocList Start");
		try {
			claimDocListResponseDto = commonRestTemplateService.getClaimDocList(commonRequestDto, request);
		} catch (Exception e) {
			logger.error("Exception--- ClaimServiceImpl--getClaimDocList---", e);
		}
		logger.info("Enter into ClaimServiceImpl getClaimDocList End");
		return claimDocListResponseDto;
	}

	@Override
	public CommonMisResponseDto<String> getMisClaimDetails(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonMisResponseDto<String> claimMisResponseDto = new CommonMisResponseDto<>();
		logger.info("ClaimServiceImpl--getMisClaimDetails--Start");
		try {
			if (commonRequestDto != null && commonRequestDto.getClaimNumber() != null
					&& StringUtils.isNotBlank(commonRequestDto.getClaimNumber())) {
				claimMisResponseDto = commonRestTemplateService.getMisClaimDetails(commonRequestDto, request);
			}
		} catch (Exception e) {
			logger.error("Exception--- ClaimServiceImpl--getMisClaimDetails---", e);
			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-getMisClaimDetails", "getMisClaimDetails", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		return claimMisResponseDto;
	}

	@Override
	public MaximusClmIntimationRespDto claimIntimation(MaximusClaimSaveDto maximusClaimSaveDto,
			HttpServletRequest request) {
		logger.info("Enter into ClaimServiceImpl claimIntimation Start...");
		MaximusClmIntimationRespDto maximusClmIntimationRespDto = new MaximusClmIntimationRespDto();
		try {
			maximusClmIntimationRespDto = commonRestTemplateService.claimIntimation(maximusClaimSaveDto, request);
		} catch (Exception e) {
			logger.error("Enter into ClaimServiceImpl claimIntimation Exception", e);
			e.printStackTrace();
		}
		logger.info("Enter into ClaimServiceImpl claimIntimation End...");
		return maximusClmIntimationRespDto;
	}

	@Override
	public CommonResponseDto<String> getStateCityAreaByPincode(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("Enter into ClaimServiceImpl getBankDetailsByIFSC Start...");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			ApplicationErrorDto applicationErrorDto = new ApplicationErrorDto();
			MaximusPincodeDetailDto pincodeDetail = new MaximusPincodeDetailDto();
			MaximusCityDto cityDto = new MaximusCityDto();
			List<MaximusCityDetailsDto> cityDetails = new ArrayList<MaximusCityDetailsDto>();
			String status = commonRestTemplateService.getStateCityAreaByPincode(commonRequestDto, request);
			logger.info("status: " + status);
			if (status != null && StringUtils.isNotBlank(status)) {
				JSONObject jsonObject = new JSONObject(status);

				if (jsonObject.has("applicationError")) {
					JSONObject jsonObject2 = new JSONObject(jsonObject.get("applicationError").toString());
					applicationErrorDto.setErrorCode(jsonObject2.optString("errorCode", null));
					applicationErrorDto.setErrorDescription(jsonObject2.optString("errorDescription", null));
				}

				if (jsonObject.has("pincodeDetail")) {
					JSONObject jsonObject3 = new JSONObject(jsonObject.get("pincodeDetail").toString());
					pincodeDetail.setCountryCode(jsonObject3.optString("countryCode", null));
					pincodeDetail.setCountryName(jsonObject3.optString("countryName", null));
					pincodeDetail.setStateCode(jsonObject3.optString("stateCode", null));
					pincodeDetail.setStateName(jsonObject3.optString("stateName", null));
					pincodeDetail.setCityCode(jsonObject3.optString("cityCode", null));
					pincodeDetail.setCityName(jsonObject3.optString("cityName", null));

					if (jsonObject3.has("city")) {
						JSONObject jsonObject4 = new JSONObject(jsonObject3.get("city").toString());
						if (jsonObject4.has("cityDetails")) {
							JSONArray jsonArray = new JSONArray(jsonObject4.get("cityDetails").toString());
							IntStream.range(0, jsonArray.length()).mapToObj(jsonArray::getJSONObject)
									.forEach(cityDetailsJson -> {
										MaximusCityDetailsDto dto = new MaximusCityDetailsDto();
										dto.setLocationCode(cityDetailsJson.optString("locationCode", null));
										dto.setLocationName(cityDetailsJson.optString("locationName", null));
										cityDetails.add(dto);
									});
						}
					}
				}
				cityDto.setCityDetails(cityDetails);
				pincodeDetail.setCity(cityDto);
				commonResponseDto.setPincodeDetail(pincodeDetail);
				commonResponseDto.setApplicationError(applicationErrorDto);
			}
		} catch (Exception e) {
			logger.error("Enter into ClaimServiceImpl getBankDetailsByIFSC Exception", e);
			e.printStackTrace();
		}
		logger.info("Enter into ClaimServiceImpl getBankDetailsByIFSC End...");
		return commonResponseDto;
	}

}
