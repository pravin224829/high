package com.fa.bajajallianz.cccp.common.payment.controller;


import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.common.dto.CommonDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.payment.service.PaymentService;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/common/payment/api/" })
public class PaymentController {

    protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	PaymentService paymentService;
	
	@PostMapping("saveinvoicedtls")
	public ResponseEntity<?> saveinvoicedtls(@RequestBody CommonDetailsDto commonDetailsDto, HttpServletRequest request) {
		logger.info("PaymentController-saveinvoicedtls-start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = paymentService.saveinvoicedtls(commonDetailsDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("PaymentController - saveinvoicedtls" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<String>>(commonResponseDto, HttpStatus.OK);
	}
	
	@PostMapping("saveNeftDtls")
	public ResponseEntity<?> saveNeftDtls(@RequestBody CommonDetailsDto commonDetailsDto, HttpServletRequest request) {
		logger.info("PaymentController-saveinvoicedtls-start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = paymentService.saveNeftDtls(commonDetailsDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("PaymentController - saveNeftDtls" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<String>>(commonResponseDto, HttpStatus.OK);
	}
	
	@PostMapping("updateClaimantPanDetail")
	public ResponseEntity<?> updateClaimantPanDetail(@RequestBody CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("PaymentController-updateClaimantPanDetail-start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = paymentService.updateClaimantPanDetail(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("PaymentController - updateClaimantPanDetail" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<String>>(commonResponseDto, HttpStatus.OK);
	}
	
}
