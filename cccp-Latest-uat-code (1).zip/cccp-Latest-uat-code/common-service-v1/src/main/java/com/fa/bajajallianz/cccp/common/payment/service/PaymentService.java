package com.fa.bajajallianz.cccp.common.payment.service;


import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.common.dto.CommonDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;

public interface PaymentService {

	CommonResponseDto<String> saveinvoicedtls(CommonDetailsDto commonDetailsDto,
			HttpServletRequest request);

	CommonResponseDto<String> saveNeftDtls(CommonDetailsDto commonDetailsDto, HttpServletRequest request);

	CommonResponseDto<String> updateClaimantPanDetail(CommonRequestDto commonRequestDto, HttpServletRequest request);


}
