package com.fa.bajajallianz.cccp.config.utils;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CommonErrorMsg {
	@Autowired
	private EntityManagerFactory factory;
	protected static final org.slf4j.Logger logger = LoggerFactory.getLogger(CommonErrorMsg.class);

	public String fetchErrorMsg(String errorCode, Boolean isActive) {
		return getSequence(errorCode, isActive);
	}

	// @SuppressWarnings("unchecked")
	public synchronized String getSequence(String errorCode, Boolean isActive) {
		logger.info("CommonErrorMsg-getSequence-start - errorCode -> " + errorCode);
		String response = null;
		EntityManager entityManager = factory.createEntityManager();
		try {
			StoredProcedureQuery storedProcedureQuery = entityManager
					.createStoredProcedureQuery("cccp_bagic.geterrorcode");
			storedProcedureQuery.registerStoredProcedureParameter("ecode", String.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("isactive", Boolean.class, ParameterMode.IN);
			storedProcedureQuery.setParameter("ecode", errorCode);
			storedProcedureQuery.setParameter("isactive", isActive);
			List<String> invAssignResults = storedProcedureQuery.execute() ? storedProcedureQuery.getResultList()
					: null;
			if (invAssignResults != null && invAssignResults.size() > 0) {
				response = invAssignResults.get(0);
			}

		} catch (Exception e) {
			logger.error("Exception-CommonErrorMsg-geterrorcode-", e);
			entityManager.close();
		} finally {
			entityManager.close();
		}
		logger.info("CommonErrorMsg-geterrorcode-end");
		return response;
	}
}
