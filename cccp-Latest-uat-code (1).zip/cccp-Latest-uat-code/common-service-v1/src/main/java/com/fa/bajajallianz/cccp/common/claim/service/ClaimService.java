package com.fa.bajajallianz.cccp.common.claim.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsListDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDocListResponseDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.dto.PolicyDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.CommonMisResponseDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClaimSaveDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClmIntimationRespDto;

public interface ClaimService {
	
	CommonResponseDto<List<ClaimDetailsListDto>> getClaimList(CommonRequestDto commonRequestDto, HttpServletRequest request);
	
	ClaimDetailsDto getClaimDetails(String claimNumber, HttpServletRequest request);

	DataTableDto<List<PolicyDetailsDto>> getPolicyDetails(String payload, String main_filter,
			String sort, String page, String per_page, HttpServletRequest request);

	ClaimDocListResponseDto getClaimDocList(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonMisResponseDto<String> getMisClaimDetails(CommonRequestDto commonRequestDto, HttpServletRequest request);

	MaximusClmIntimationRespDto claimIntimation(MaximusClaimSaveDto maximusClaimSaveDto, HttpServletRequest request);
	
	CommonResponseDto<String> getStateCityAreaByPincode(CommonRequestDto commonRequestDto, HttpServletRequest request);

}
