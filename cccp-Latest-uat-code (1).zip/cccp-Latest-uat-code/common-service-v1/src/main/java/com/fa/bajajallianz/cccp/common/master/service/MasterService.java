package com.fa.bajajallianz.cccp.common.master.service;

import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.common.dto.AreaResponseDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.UserDto;

public interface MasterService {

	CommonResponseDto<AreaResponseDto> fetchLocationByPincode(CommonRequestDto commonRequestDto,
			HttpServletRequest request);

	UserDto getSurveyorprofileDtls(CommonRequestDto commonRequestDto,
			HttpServletRequest request);


}
