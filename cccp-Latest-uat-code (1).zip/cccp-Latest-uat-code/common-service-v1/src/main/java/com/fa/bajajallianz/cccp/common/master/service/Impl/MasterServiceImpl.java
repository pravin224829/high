package com.fa.bajajallianz.cccp.common.master.service.Impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fa.bajajallianz.cccp.common.claim.service.ClaimService;
import com.fa.bajajallianz.cccp.common.dto.AreaListDto;
import com.fa.bajajallianz.cccp.common.dto.AreaResponseDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.UserDto;
import com.fa.bajajallianz.cccp.common.master.service.MasterService;
import com.fa.bajajallianz.cccp.common.notify.repository.NotifyRepository;
import com.fa.bajajallianz.cccp.common.restapi.service.CommonRestTemplateService;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.config.utils.CommonErrorMsg;
import com.fa.bajajallianz.cccp.config.utils.CommonRequestUtil;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusCityDetailsDto;


@Service
public class MasterServiceImpl implements MasterService{
	
	private static final Logger logger = LoggerFactory.getLogger(MasterServiceImpl.class);

	@Autowired
	CommonErrorMsg commonErrorMsg;
	
	@Autowired
	CommonRestTemplateService commonRestTemplateService;
	
	@Autowired
	ClaimService claimService;
	
	@Autowired
	NotifyRepository notifyRepository;
	
	
	@Override
	public CommonResponseDto<AreaResponseDto> fetchLocationByPincode(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonResponseDto<AreaResponseDto> commonResponseDto = new CommonResponseDto<>();
		logger.info("MasterServiceImpl--fetchLocationByPincode--Start");
		try {
			if(commonRequestDto.getPolicyNumber() != null && StringUtils.isNotBlank(commonRequestDto.getPolicyNumber())) {
				String flag = notifyRepository.getPolicyFlag(commonRequestDto.getPolicyNumber());
				if(CommonConstants.MAXIMUSFLAG.equals(flag)) {
					AreaResponseDto areaResponse = new AreaResponseDto();
					areaResponse.setPincode(commonRequestDto.getPincode());
					CommonResponseDto<String> response = claimService.getStateCityAreaByPincode(commonRequestDto, request);
					if (response != null && response.getApplicationError() != null
							&& CommonConstants.ZERO_STRING.equals(response.getApplicationError().getErrorCode())) {
						
						if (response.getPincodeDetail() != null) {
							areaResponse.setCity(response.getPincodeDetail().getCityCode());
							areaResponse.setCountry(response.getPincodeDetail().getCountryCode());
							areaResponse.setState(response.getPincodeDetail().getStateCode());
							List<AreaListDto> areaDtos = new ArrayList<>();
							if (response.getPincodeDetail().getCity() != null && response.getPincodeDetail().getCity().getCityDetails() != null
									&& !response.getPincodeDetail().getCity().getCityDetails().isEmpty()) {
								
								for (MaximusCityDetailsDto cityDetails : response.getPincodeDetail().getCity()
										.getCityDetails()) {
									AreaListDto area = new AreaListDto();
									area.setArea(cityDetails.getLocationCode());
									areaDtos.add(area);
								}
							}
							areaResponse.setArea(areaDtos);
						}
					}
					commonResponseDto.setResponseData(areaResponse);
					commonResponseDto.setStatus(CommonConstants.SUCCESS);
					return commonResponseDto;
				}
			}
			AreaResponseDto areaResponseDto = commonRestTemplateService.fetchLocationByPincode(commonRequestDto, request);
			if (areaResponseDto != null && areaResponseDto.getApplicationError() != null
					&& CommonConstants.SUCCESS.equals(areaResponseDto.getApplicationError().getErrorDescription())) {
				commonResponseDto.setResponseData(areaResponseDto);
			}
			commonResponseDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Exception-MasterServiceImpl-fetchLocationByPincode", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			CommonRequestUtil.errorInfo(request, "", "MasterServiceImpl-fetchLocationByPincode",
					"fetchLocationByPincode", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
			commonResponseDto.setError(e.getMessage());
		}
		logger.info("MasterServiceImpl--fetchLocationByPincode--End");
		return commonResponseDto;
	}


	@Override
	public UserDto getSurveyorprofileDtls(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("MasterServiceImpl--getSurveyorprofileDtls--Start");
		UserDto userDto = new UserDto();
		try {
			userDto = commonRestTemplateService.getSurveyorprofileDtls(commonRequestDto, request);
		} catch (Exception e) {
			logger.error("Enter into MasterServiceImpl-getSurveyorprofileDtls Exception", e);
			CommonRequestUtil.errorInfo(request, "", "MasterServiceImpl", "getSurveyorprofileDtls", "", e.getMessage(),
					CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("MasterServiceImpl--getSurveyorprofileDtls--End");
		return userDto;
	}

}
