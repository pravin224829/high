package com.fa.bajajallianz.cccp.common.report.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "rpt_user_count")
public class UserCount {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", length = 20, nullable = false)
	private Long id;

	@Column(name = "corporate_code", length = 100)
	private String corporateCode;

	@Column(name = "active_user", length = 5, nullable = false)
	private Integer activeUser;

	@Column(name = "in_active_user", length = 5, nullable = false)
	private Integer inActiveUser;

	@Column(name = "total_user", length = 5, nullable = false)
	private Integer totalUser;

	@Column(name = "created_date", nullable = false)
	private Date createdDate;

	@Column(name = "is_active")
	private Boolean isActive;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCorporateCode() {
		return corporateCode;
	}

	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}

	public Integer getActiveUser() {
		return activeUser;
	}

	public void setActiveUser(Integer activeUser) {
		this.activeUser = activeUser;
	}

	public Integer getInActiveUser() {
		return inActiveUser;
	}

	public void setInActiveUser(Integer inActiveUser) {
		this.inActiveUser = inActiveUser;
	}

	public Integer getTotalUser() {
		return totalUser;
	}

	public void setTotalUser(Integer totalUser) {
		this.totalUser = totalUser;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

}
