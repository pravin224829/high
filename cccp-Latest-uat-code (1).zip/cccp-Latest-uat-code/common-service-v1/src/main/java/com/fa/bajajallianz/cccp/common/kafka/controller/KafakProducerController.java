package com.fa.bajajallianz.cccp.common.kafka.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.common.kafka.service.KafkaProducerService;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/common/kafka/api/" })
public class KafakProducerController {
	
	private static final Logger logger = LoggerFactory.getLogger(KafakProducerController.class);

//    @Autowired
//    private KafkaProducerService kafkaProducerService;
    
    private final KafkaProducerService kafkaMessageProducer;
    
    @Autowired
    public KafakProducerController(KafkaProducerService kafkaMessageProducer) {
        this.kafkaMessageProducer = kafkaMessageProducer;
    }

//    @PostMapping("send")
//    public String sendMessage(@RequestParam String message) {
//    	logger.info("Enter into KafakProducerController sendMessage start...");
//    	try {
//    		kafkaProducerService.sendMessage(message);
//		} catch (Exception e) {
//			logger.error("Enter into KafakProducerController sendMessage Exception", e);
//			e.getStackTrace();
//		}
//    	logger.info("Enter into KafakProducerController sendMessage end...");
//        return "Message sent to Kafka topic!";
//    }
    
//	@PostMapping("publish")
//	public String publishMessage(@RequestBody Object obj) {
//		logger.info("Enter into KafakProducerController publishMessage start...");
//		try {
//			kafkaProducerService.send(obj);
//		} catch (Exception e) {
//			logger.error("Enter into KafakProducerController publishMessage Exception", e);
//			e.getStackTrace();
//		}
//		// Sending the message
//		// kafkaTemplate.send(TOPIC, Object);
//		logger.info("Enter into KafakProducerController publishMessage end...");
//		return "Published Successfully";
//	}
	
	@PostMapping("send")
    public ResponseEntity<String> send(@RequestParam String topic,
                                        @RequestParam String key,
                                        @RequestParam String message) {
		logger.info("Enter into KafakProducerController send start...");
		try {
			kafkaMessageProducer.sendMessage(topic, key, message);
		} catch (Exception e) {
			logger.error("Enter into KafakProducerController send Exception", e);
			e.getStackTrace();
		}
		logger.info("Enter into KafakProducerController send end...");
        return ResponseEntity.ok("Message sent successfully");
    }
}
