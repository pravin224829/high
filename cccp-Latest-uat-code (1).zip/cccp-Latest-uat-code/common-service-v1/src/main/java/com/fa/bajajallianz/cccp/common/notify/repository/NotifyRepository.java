/**
 * 
 */
package com.fa.bajajallianz.cccp.common.notify.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.common.notify.entity.NotifyEntity;

/**
 * @author praveen
 *
 */
@Repository
public interface NotifyRepository extends JpaRepository<NotifyEntity, Long> {

	NotifyEntity findByUserIdAndClaimNumberAndSurveyNumber(String userId, String claimNumber, String surveyorNo);

	List<NotifyEntity> findByUserIdAndIsReadOrderByIdDesc(String userId, Boolean false1);

	List<NotifyEntity> findTop5ByUserIdAndIsReadOrderByIdDesc(String userId, Boolean false1);

	List<NotifyEntity> findByUserIdAndIsRead(String userId, Boolean false1);

	List<NotifyEntity> findByUserIdOrderByIdDesc(String userId);

	@Query(value = "select pd.source_flag from cccp_bagic.policy_details pd where pd.policy_number = ?1 and pd.is_active = true limit 1", nativeQuery = true)
	String getPolicyFlag(String policyNumber);

	@Query(value = "select pd.source_flag from cccp_bagic.user_policy_details upd inner join cccp_bagic.users u on u.id = upd.user_id "
			+ "inner join cccp_bagic.policy_details pd on pd.id = upd.policy_id where u.is_active = ?3 and upd.is_active = ?3 and pd.is_active = ?3 "
			+ "and u.user_id = ?1 and pd.policy_number = ?2 ;", nativeQuery = true)
	String getPolicyFlagByUserId(String userId, String policyNumber, Boolean true1);

//	@Query("select p.product_code from cccp_bagic.maximus_product_master where is_active = 'true'")
//	List<String> findByActiveProductCode();

	@Query(value = "select product_code from cccp_bagic.maximus_product_master where is_active =true", nativeQuery = true)
	List<String> findByActiveProductCode();

}
