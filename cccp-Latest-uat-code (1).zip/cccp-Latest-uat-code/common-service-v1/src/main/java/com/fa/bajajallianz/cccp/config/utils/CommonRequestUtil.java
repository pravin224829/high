package com.fa.bajajallianz.cccp.config.utils;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.fa.bajajallianz.cccp.common.dto.APIRequestDto;
import com.fa.bajajallianz.cccp.common.logger.service.LoggerRestAPI;
import com.fa.bajajallianz.cccp.common.utils.DateUtils;

@Component
public class CommonRequestUtil {

	private static LoggerRestAPI stloggerAPI;

	@Autowired
	private LoggerRestAPI loggerAPI;

	@PostConstruct
	private void initStaticLogger() {
		stloggerAPI = this.loggerAPI;
	}

	public static void errorInfo(HttpServletRequest request, String payload, String methodName, String apiName,
			String action, String message, String errorMessage, String claimNumber, String taskId, String response,
			String userId) {
		APIRequestDto apiRequestDto = new APIRequestDto();
		apiRequestDto.setApiName(apiName);
		// apiRequestDto.setApiUrl(env.getProperty("ERRORLOGGER"));
		if (request != null) {
			apiRequestDto.setBusinessCorrelationId(request.getHeader("businesscorelationid"));
			apiRequestDto.setCorrelationId(request.getHeader("corelationid"));
			apiRequestDto.setToken(request.getHeader("Authorization"));
		}
		apiRequestDto.setCreatedDate(DateUtils.sysDate().toString());
		apiRequestDto.setMethodName(methodName);
		apiRequestDto.setRequest(payload);
		apiRequestDto.setResponse(response);
		apiRequestDto.setType("Error");
		apiRequestDto.setUserId(userId);
		apiRequestDto.setMessage(message);
		apiRequestDto.setAction(action);
		apiRequestDto.setErrorMessage(errorMessage);
		stloggerAPI.callErrorLogger(apiRequestDto);
	}
	
	public static void saveApiLog(HttpServletRequest request, String payload, String methodName, String apiName,
			String action, String message, String errorMessage, String claimNumber, String taskId, String response,
			String userId, String url, HttpHeaders headers) {
		APIRequestDto apiRequestDto = new APIRequestDto();
		apiRequestDto.setApiName(apiName);
		if (headers != null) {
			apiRequestDto.setBusinessCorrelationId(headers.getFirst("businesscorelationid"));
			apiRequestDto.setCorrelationId(headers.getFirst("corelationid"));
			apiRequestDto.setToken(headers.getFirst("Authorization"));
		}
		apiRequestDto.setCreatedDate(DateUtils.sysDate().toString());
//		apiRequestDto.setClaimNumber(claimNumber);
		apiRequestDto.setMethodName(methodName);
		apiRequestDto.setRequest(payload);
		apiRequestDto.setResponse(response);
//		apiRequestDto.setTaskId(taskId);
		apiRequestDto.setType("APILOG");
		apiRequestDto.setUserId(userId);
		apiRequestDto.setMessage(message);
		apiRequestDto.setAction(action);
		apiRequestDto.setApiUrl(url);
//		apiRequestDto.setUrl(url);
		apiRequestDto.setErrorMessage(errorMessage);
		stloggerAPI.callSaveApiLog(apiRequestDto);
	}
}
