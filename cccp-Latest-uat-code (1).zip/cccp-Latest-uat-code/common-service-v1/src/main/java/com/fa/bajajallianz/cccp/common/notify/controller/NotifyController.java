/**
 * 
 */
package com.fa.bajajallianz.cccp.common.notify.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.notify.service.NotifyService;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.surveyor.common.dto.NotifyUserDto;

/**
 * @author praveen
 *
 */

@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/common/notify/api/" })
public class NotifyController {
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	NotifyService notifyService;

	@GetMapping(value = { "healthCheck" })
	public String healthCheck() {
		logger.info("CommonController-healthCheck-started 26-09-2022");
		return CommonConstants.COMMONHEALTHCHECK;
	}

	@PostMapping("saveUserNotifcation")
	public ResponseEntity<?> saveUserNotifcation(@RequestBody CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("NotifyController-saveUserNotifcation-start");
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = notifyService.saveUserNotifcation(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("NotifyController - saveUserNotifcation" + commonResponseDto.getStatus());
		return new ResponseEntity<>(commonResponseDto, HttpStatus.OK);
	}

	@PostMapping("saveNotificationStatus")
	public ResponseEntity<?> saveNotificationStatus(@RequestBody CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("NotifyController-saveNotificationStatus-start");
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = notifyService.saveNotificationStatus(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("NotifyController - saveNotificationStatus" + commonResponseDto.getStatus());
		return new ResponseEntity<>(commonResponseDto, HttpStatus.OK);
	}
	
	@GetMapping("fetchRecentNotifications")
	public ResponseEntity<?> fetchRecentNotifications(@RequestParam String payload, HttpServletRequest request) {
		logger.info("NotifyController-fetchRecentNotifications-start");
		CommonResponseDto<List<NotifyUserDto>> commonResponseDto = new CommonResponseDto<List<NotifyUserDto>>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = notifyService.fetchRecentNotifications(commonRequestDto, request);
		} catch (Exception e) {
			logger.error("Exception-NotifyController-fetchRecentNotifications", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("NotifyController-fetchRecentNotifications-end");
		return new ResponseEntity<>(commonResponseDto, HttpStatus.OK);
	}
	
	@PostMapping("notificationProcessor")
	public ResponseEntity<?> notificationProcessor(@RequestBody CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("NotifyController-notificationProcessor-start");
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = notifyService.notificationProcessor(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("NotifyController - notificationProcessor" + commonResponseDto.getStatus());
		return new ResponseEntity<>(commonResponseDto, HttpStatus.OK);
	}
	
	@PostMapping("maximusNotificationProcessor")
	public ResponseEntity<?> maximusNotificationProcessor(@RequestBody CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("Enter into NotifyController maximusNotificationProcessor start");
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = notifyService.maximusNotificationProcessor(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("Enter into NotifyController maximusNotificationProcessor end");
		return new ResponseEntity<>(commonResponseDto, HttpStatus.OK);
	}
	
	@PostMapping("sendNotification")
	public ResponseEntity<?> sendNotification(@RequestBody CommonRequestDto commonRequestDto, HttpServletRequest request){
		logger.info("NotifyController-sendNotification-start");
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = notifyService.sendNotification(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("NotifyController-sendNotification-end");
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}
	
}
