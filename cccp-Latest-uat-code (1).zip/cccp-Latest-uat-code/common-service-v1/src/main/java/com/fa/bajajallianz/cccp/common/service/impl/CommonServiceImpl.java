package com.fa.bajajallianz.cccp.common.service.impl;

import org.springframework.stereotype.Service;


import com.fa.bajajallianz.cccp.common.service.CommonService;


@Service
public class CommonServiceImpl implements CommonService {

}
