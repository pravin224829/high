package com.fa.bajajallianz.cccp.common.kafka.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;


@Service
public class KafkaProducerService {
	
	private static final Logger logger = LoggerFactory.getLogger(KafkaProducerService.class);
    
	private final KafkaTemplate<String, String> kafkaTemplate;
	 
    @Autowired
    public KafkaProducerService(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }
    
    private static final String TOPIC = "rcsdevtopic";
    
//    public void send(Object obj) {
//    	logger.info("Enter into KafkaProducerService send start...");
//    	try {
//    		kafkaTemplate.send(TOPIC, obj);
//		} catch (Exception e) {
//			logger.error("Enter into KafkaProducerService send Exception", e);
//			e.getStackTrace();
//		}
//    	logger.info("Enter into KafkaProducerService send end...");  
//    }

	public void sendMessage(String topic2, String key, String message) {
		logger.info("Enter into KafkaProducerService sendMessage start...");  
		try {
			kafkaTemplate.send(topic2, key, message);
		} catch (Exception e) {
			logger.error("Enter into KafkaProducerService sendMessage Exception", e);
			e.getStackTrace();
		}
		logger.info("Enter into KafkaProducerService sendMessage end...");  
	}
    
//    public void sendMessage(String message) {
//    	logger.info("Enter into KafkaProducerService sendMessage start...");
//    	try {
//    		 kafkaTemplate.send(TOPIC, message);
//		} catch (Exception e) {
//			logger.error("Enter into KafkaProducerService sendMessage Exception", e);
//			e.getStackTrace();
//		}
//    	logger.info("Enter into KafkaProducerService sendMessage end...");
//    }
}
