/**
 * 
 */
package com.fa.bajajallianz.cccp.nonmotor.keycloak.security;

/**
 * @author Muruganandam
 *
 *         Version 1.0, Created Date:21-06-2020, Updated Date:21-06-2020
 */
public interface SecurityConstants {

	static String STATUS_ACTIVE = "ACTIVE";
	static String STATUS_INACTIVE = "INACTIVE";
	String[] PATHTOSKIP = {
			"/cccp/common/claim/api/healthCheck",
			"/cccp/config/master/api/fetchAPIUrlByCode",
			"/cccp/common/claim/api/getClaimList",
			"/cccp/common/claim/api/getClaimDetails",
			"/cccp/common/report/api/refreshClaimCount",
			"/cccp/common/report/api/refreshUserCount",
			"/cccp/common/notify/api/saveUserNotifcation",
			"/cccp/common/notify/api/saveNotificationStatus",
			"/cccp/common/notify/api/fetchRecentNotifications",
			"/cccp/common/notify/api/sendNotification",
			"/cccp/common/payment/api/getPanDetails",
			"/cccp/common/payment/api/saveinvoicedtls",
			"/cccp/common/payment/api/saveNeftDtls",
			"/cccp/common/payment/api/updateClaimantPanDetail",
			"/cccp/common/report/api/getMISReport",
			"/cccp/common/master/api/getSurveyorprofileDtls",
			"/cccp/common/claim/api/getMisClaimDetails",
			"/cccp/common/claim/api/searchPolicyList",
			"/cccp/common/claim/api/claimIntimation",
			"/cccp/common/kafka/api/send",
			"/cccp/common/claim/api/getStateCityAreaByPincode"
			};
	String[] SWAGGERPATHTOSKIP = {
//			"/v2/api-docs", "/swagger-resources/**", "/swagger-ui.html**", "/swagger-ui.html/**",
//			"/css/**", "/js/**", "/doc**", "/webjars/**", "/favicon.ico", "/api/doc/**", "/csrf/**" 
	};

}
