/**
 * 
 */
package com.fa.bajajallianz.cccp.common.notify.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;


import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.surveyor.common.dto.NotifyUserDto;

/**
 * @author praveen
 *
 */

public interface NotifyService {

	CommonResponseDto<?> saveUserNotifcation(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonResponseDto<?> saveNotificationStatus(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonResponseDto<List<NotifyUserDto>> fetchRecentNotifications(CommonRequestDto commonRequestDto,
			HttpServletRequest request);
	
	CommonResponseDto<?> notificationProcessor(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonResponseDto<?> sendNotification(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonResponseDto<?> maximusNotificationProcessor(CommonRequestDto commonRequestDto, HttpServletRequest request);

}
