package com.fa.bajajallianz.cccp.common.report.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "rpt_claim_count")
public class ClaimCount implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 642449112418823526L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", length = 20, nullable = false)
	private Long id;

	@Column(name = "corporate_code", length = 100)
	private String corporateCode;

	@Column(name = "user_id", length = 100)
	private String userId;

	@Column(name = "no_of_claim_registered", length = 5, nullable = false)
	private Integer noOfClaimRegsitered;

	@Column(name = "no_of_claim_uploaded", length = 5, nullable = false)
	private Integer noOfClaimUploaded;

	@Column(name = "no_of_claim_updated", length = 5, nullable = false)
	private Integer noOfClaimUpdated;

	@Column(name = "created_date", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date date;

	@Column(name = "claim_category", length = 150)
	private String claimCategory;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCorporateCode() {
		return corporateCode;
	}

	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getNoOfClaimRegsitered() {
		return noOfClaimRegsitered;
	}

	public void setNoOfClaimRegsitered(Integer noOfClaimRegsitered) {
		this.noOfClaimRegsitered = noOfClaimRegsitered;
	}

	public Integer getNoOfClaimUploaded() {
		return noOfClaimUploaded;
	}

	public void setNoOfClaimUploaded(Integer noOfClaimUploaded) {
		this.noOfClaimUploaded = noOfClaimUploaded;
	}

	public Integer getNoOfClaimUpdated() {
		return noOfClaimUpdated;
	}

	public void setNoOfClaimUpdated(Integer noOfClaimUpdated) {
		this.noOfClaimUpdated = noOfClaimUpdated;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getClaimCategory() {
		return claimCategory;
	}

	public void setClaimCategory(String claimCategory) {
		this.claimCategory = claimCategory;
	}

}
