package com.fa.bajajallianz.cccp.common.report.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.fa.bajajallianz.cccp.common.report.entity.UserCount;

@Repository
public interface UserCountRepo extends JpaRepository<UserCount, Long> {

	@Query(value = "SELECT sum(u.active_user) as active_user,sum(u.in_active_user) as"
			+ " in_active_user,sum(u.total_user) as total_user  FROM cccp_bagic.rpt_user_count u where "
			+ "u.is_active=?1", nativeQuery = true)
	List<Object[]> getUserCount(Boolean isActive);
	
	@Query(value="select pd.insured_name,pd.policy_number,pd.sum_insured,pd.product_code,pd.policy_start_date as inception_date,pd.policy_end_date,pd.lob,pd.is_active as policy_status,pm.description from rcs_claims.policy_details pd,cccp_bagic.product_master pm where pd.product_code=pm.code and pd.lob=:lob",
			 nativeQuery = true)
	List<Object[]> fetchPolicyDetailsByLob(String lob);

}
