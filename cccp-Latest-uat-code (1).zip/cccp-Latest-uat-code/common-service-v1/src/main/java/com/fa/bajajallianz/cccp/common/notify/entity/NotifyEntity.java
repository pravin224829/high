/**
 * 
 */
package com.fa.bajajallianz.cccp.common.notify.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author praveen
 *
 */
@Entity
@Table(name = "notify_user_notification")
public class NotifyEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", length = 20)
	private Long id;

	@Column(name = "notify_config_id", length = 20)
	private Long notifyConfigId;

	@Column(name = "claim_number", length = 50)
	private String claimNumber;

	@Column(name = "survey_number", length = 50)
	private String surveyNumber;

	@Column(name = "task_id", length = 20)
	private Long taskId;

	@Column(name = "subject", length = 1000)
	private String subject;

	@Column(name = "content", length = 3000)
	private String content;

	@Column(name = "type")
	private String type;

	@Column(name = "is_read")
	private Boolean isRead;

	@Column(name = "user_id", length = 100)
	private String userId;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_date")
	private Date modifiedDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getNotifyConfigId() {
		return notifyConfigId;
	}

	public void setNotifyConfigId(Long notifyConfigId) {
		this.notifyConfigId = notifyConfigId;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getSurveyNumber() {
		return surveyNumber;
	}

	public void setSurveyNumber(String surveyNumber) {
		this.surveyNumber = surveyNumber;
	}

	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Boolean getIsRead() {
		return isRead;
	}

	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

}
