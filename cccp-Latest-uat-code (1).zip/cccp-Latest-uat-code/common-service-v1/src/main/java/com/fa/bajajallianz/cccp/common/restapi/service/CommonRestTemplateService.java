/**
 * 
 */
package com.fa.bajajallianz.cccp.common.restapi.service;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.common.dto.APIRequestDto;
import com.fa.bajajallianz.cccp.common.dto.AreaResponseDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsListResponseDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDocListResponseDto;
import com.fa.bajajallianz.cccp.common.dto.CommonDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.CommonMasterDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.EmailDto;
import com.fa.bajajallianz.cccp.common.dto.PolicyResponseDto;
import com.fa.bajajallianz.cccp.common.dto.SmsDto;
import com.fa.bajajallianz.cccp.common.dto.UserDto;
import com.fa.bajajallianz.cccp.mis.common.dto.CommonMisResponseDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClaimSaveDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClmIntimationRespDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusSinglePolicySearchDto;
import com.fa.bajajallianz.cccp.surveyor.common.dto.NotifyConfigDto;

/**
 * @author arunkumar
 *
 */
public interface CommonRestTemplateService {

	ClaimDetailsListResponseDto getClaimList(CommonRequestDto commonRequestDto, HttpServletRequest request);

	AreaResponseDto fetchLocationByPincode(CommonRequestDto commonRequestDto, HttpServletRequest request);

	ClaimDetailsDto getClaimDetails(String claimNumber, HttpServletRequest request);

	PolicyResponseDto getPolicyDetails(CommonRequestDto commonRequestDto, HttpServletRequest request);

	ClaimDocListResponseDto getClaimDocList(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonResponseDto<String> getOutStandingReport(CommonRequestDto dto, HttpServletRequest request);
	
	CommonResponseDto<String> getDtlClmInfoReport(CommonRequestDto dto, HttpServletRequest request);
	
	CommonResponseDto<String> getClmPaymentReport(CommonRequestDto dto, HttpServletRequest request);
	
	CommonResponseDto<String> getClmSettlementReport(CommonRequestDto dto, HttpServletRequest request);

	CommonResponseDto<List<APIRequestDto>> getRetryDetails();

	CommonResponseDto<String> getClaimCount(CommonRequestDto requestDto);

	CommonResponseDto<NotifyConfigDto> getNotifyConfig(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonMasterDto sendEmailRequest(EmailDto dto, HttpServletRequest request);

	CommonResponseDto<String> saveinvoicedtls(CommonDetailsDto commonDetailsDto, HttpServletRequest request);

	CommonResponseDto<String> saveNeftDtls(CommonDetailsDto commonDetailsDto, HttpServletRequest request);

	CommonResponseDto<String> updateClaimantPanDetail(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonResponseDto<String> getOutstandingClmReport(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonResponseDto<String> getSurveyorPaymentClaimsReport(CommonRequestDto commonRequestDto,
			HttpServletRequest request);

	CommonResponseDto<String> getClmServingReport(CommonRequestDto commonRequestDto, HttpServletRequest request);

	UserDto getSurveyorprofileDtls(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonResponseDto<String> getUpdateClaimList(CommonRequestDto dto, HttpServletRequest request);

	CommonMisResponseDto<String> getMisClaimDetails(CommonRequestDto commonRequestDto, HttpServletRequest request);

	MaximusClmIntimationRespDto saveMaximusClaimIntimation(MaximusClaimSaveDto commonRequestDto,
			HttpServletRequest request);

	PolicyResponseDto getMaximusPolicyDetails(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonMasterDto sendSmsRequest(SmsDto smsDto, HttpServletRequest request);

	MaximusSinglePolicySearchDto getSavedQuote(String policyNumber, HttpServletRequest request);

	MaximusClmIntimationRespDto claimIntimation(MaximusClaimSaveDto maximusClaimSaveDto, HttpServletRequest request);
	
	String getStateCityAreaByPincode(CommonRequestDto commonRequestDto, HttpServletRequest request);

}
