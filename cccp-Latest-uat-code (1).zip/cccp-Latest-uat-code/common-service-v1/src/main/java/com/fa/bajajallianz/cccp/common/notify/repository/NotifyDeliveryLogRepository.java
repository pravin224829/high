package com.fa.bajajallianz.cccp.common.notify.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.common.notify.entity.NotifyDeliveryLogEntity;

@Repository
public interface NotifyDeliveryLogRepository extends JpaRepository<NotifyDeliveryLogEntity, Long> {

}
