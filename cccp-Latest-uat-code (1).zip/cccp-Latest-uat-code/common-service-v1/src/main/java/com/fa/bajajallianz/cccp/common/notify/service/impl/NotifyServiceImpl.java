/**
 * 
 */
package com.fa.bajajallianz.cccp.common.notify.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.CommonMasterDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.EmailBodyDto;
import com.fa.bajajallianz.cccp.common.dto.EmailDto;
import com.fa.bajajallianz.cccp.common.dto.SmsDto;
import com.fa.bajajallianz.cccp.common.dto.SmsTextDto;
import com.fa.bajajallianz.cccp.common.dto.SmsValuesDto;
import com.fa.bajajallianz.cccp.common.notify.entity.NotificationLogEntity;
import com.fa.bajajallianz.cccp.common.notify.entity.NotifyDeliveryLogEntity;
import com.fa.bajajallianz.cccp.common.notify.entity.NotifyEntity;
import com.fa.bajajallianz.cccp.common.notify.repository.NotificationLogRepository;
import com.fa.bajajallianz.cccp.common.notify.repository.NotifyDeliveryLogRepository;
import com.fa.bajajallianz.cccp.common.notify.repository.NotifyRepository;
import com.fa.bajajallianz.cccp.common.notify.service.NotifyService;
import com.fa.bajajallianz.cccp.common.restapi.service.CommonRestTemplateService;
import com.fa.bajajallianz.cccp.common.service.impl.CommonServiceImpl;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.DateUtils;
import com.fa.bajajallianz.cccp.common.utils.ErrorCodeConstants;
import com.fa.bajajallianz.cccp.common.utils.NumericUtils;
import com.fa.bajajallianz.cccp.config.utils.CommonErrorMsg;
import com.fa.bajajallianz.cccp.config.utils.CommonRequestUtil;
import com.fa.bajajallianz.cccp.surveyor.common.dto.NotifyConfigDto;
import com.fa.bajajallianz.cccp.surveyor.common.dto.NotifyUserDto;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author praveen
 *
 */
@Service
public class NotifyServiceImpl implements NotifyService {

	private static final Logger logger = LoggerFactory.getLogger(CommonServiceImpl.class);

	@Autowired
	NotifyRepository notifyRepository;

	@Autowired
	CommonErrorMsg commonErrorMsg;
	
	@Autowired
	private NotificationLogRepository notificationLogRepo;
	
	@Autowired
	private NotifyDeliveryLogRepository notifyDeliveryLogRepo;
	
	@Autowired
	private CommonRestTemplateService commonRestTemplateService;
	
	private ObjectMapper mapper = new ObjectMapper();

	@Override
	public CommonResponseDto<?> saveUserNotifcation(CommonRequestDto commonRequestDto, HttpServletRequest request) {

		NotifyUserDto dto = commonRequestDto.getNotifyUser();
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		logger.info("NotifyServiceImpl--saveUserNotifcation--Start");
		try {
			if(CommonConstants.ALLOCATE.equals(commonRequestDto.getAction())) {
				if(!commonRequestDto.getUserList().isEmpty()) {
					for (String userId : commonRequestDto.getUserList()) {
						NotifyEntity entity = new NotifyEntity();
						BeanUtils.copyProperties(dto, entity);
						entity.setClaimNumber(dto.getClaimNumber());
						entity.setSurveyNumber(dto.getSurveyNumber());
						entity.setTaskId(NumericUtils.convertStringToLong(dto.getTaskId()));
						entity.setSubject(dto.getSubject());
						entity.setContent(dto.getContent());
						entity.setType(dto.getType());
						entity.setIsRead(CommonConstants.FALSE);
						entity.setUserId(userId);
						entity.setNotifyConfigId(NumericUtils.convertStringToLong(dto.getNotifyConfigId()));
						entity.setCreatedDate(DateUtils.sysDate());
						entity.setModifiedDate(DateUtils.convertStringToDate(dto.getModifiedDate()));
						notifyRepository.save(entity);
						commonResponseDto.setStatus(CommonConstants.SUCCESS);
					}
				}
			}else {
				if (commonRequestDto.getNotifyUser() != null) {
					NotifyEntity entity = new NotifyEntity();
					BeanUtils.copyProperties(dto, entity);
					entity.setClaimNumber(dto.getClaimNumber());
					entity.setSurveyNumber(dto.getSurveyNumber());
					entity.setTaskId(NumericUtils.convertStringToLong(dto.getTaskId()));
					entity.setSubject(dto.getSubject());
					entity.setContent(dto.getContent());
					entity.setType(dto.getType());
					entity.setIsRead(CommonConstants.FALSE);
					entity.setUserId(dto.getUserId());
					entity.setNotifyConfigId(NumericUtils.convertStringToLong(dto.getNotifyConfigId()));
					entity.setCreatedDate(DateUtils.sysDate());
					entity.setModifiedDate(DateUtils.convertStringToDate(dto.getModifiedDate()));
					notifyRepository.save(entity);
					commonResponseDto.setStatus(CommonConstants.SUCCESS);
				}
			}

		} catch (Exception e) {
			logger.error("Exception-NotifyServiceImpl-saveUserNotifcation", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "NotifyServiceImpl-saveUserNotifcation", "fetchLOBList", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<?> saveNotificationStatus(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		logger.info("NotifyServiceImpl--saveNotificationStatus--Start");
		try {
			List<NotifyEntity> entities = notifyRepository.findByUserIdAndIsRead(commonRequestDto.getUserId(), CommonConstants.FALSE);
			if (!entities.isEmpty()) {
				for (NotifyEntity notifyEntity : entities) {
					notifyEntity.setIsRead(CommonConstants.TRUE);
					notifyEntity.setModifiedDate(DateUtils.sysDate());
					notifyRepository.save(notifyEntity);
				}
			}
			commonResponseDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.info("NotifyServiceImpl--saveNotificationStatus--Start", e);
		}
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<List<NotifyUserDto>> fetchRecentNotifications(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("NotifyServiceImpl--fetchRecentNotifications--Start");
		CommonResponseDto<List<NotifyUserDto>> commonResponseDto=new CommonResponseDto<List<NotifyUserDto>>();
		List<NotifyEntity> notifyEntity= new ArrayList<>();
		List<NotifyUserDto> notifyUserDtos=new ArrayList<>();
		try {
			if(!StringUtils.isNotBlank(commonRequestDto.getLimit())) {
			 notifyEntity=notifyRepository.findByUserIdAndIsReadOrderByIdDesc(commonRequestDto.getUserId(),CommonConstants.FALSE);
			}else {
			 notifyEntity=notifyRepository.findTop5ByUserIdAndIsReadOrderByIdDesc(commonRequestDto.getUserId(),CommonConstants.FALSE);	
			}
			List<NotifyEntity> notifyEntities = notifyRepository.findByUserIdOrderByIdDesc(commonRequestDto.getUserId());
			if(notifyEntities != null&& !notifyEntities.isEmpty()) {
				for(NotifyEntity entity: notifyEntities) {
					NotifyUserDto notifyUserDto=new NotifyUserDto();
					BeanUtils.copyProperties(entity, notifyUserDto);
					notifyUserDto.setIsRead(entity.getIsRead());
					notifyUserDto.setContent(entity.getContent());
					notifyUserDto.setSubject(entity.getSubject());
					notifyUserDto.setSurveyNumber(entity.getSurveyNumber());
					notifyUserDto.setType(entity.getType());
					notifyUserDto.setUserId(entity.getUserId());
					notifyUserDto.setCreatedDate(DateUtils.convertDateTimeToStringWithPeriodMMM(entity.getCreatedDate()));
					notifyUserDto.setModifiedDate(DateUtils.convertDateTimeToString(entity.getModifiedDate()));
					notifyUserDtos.add(notifyUserDto);
				}
				commonResponseDto.setResponseData(notifyUserDtos);
				commonResponseDto.setUnReadCount(NumericUtils.convertIntegerToString(notifyEntity.size()));
				commonResponseDto.setStatus(CommonConstants.SUCCESS);
			}else {
				commonResponseDto.setMessage("No records found");
				commonResponseDto.setStatus(CommonConstants.ERROR);
			}
		}catch (Exception e) {
			e.printStackTrace();			
			logger.error("NotifyServiceImpl-fetchRecentNotifications ", e);
			CommonRequestUtil.errorInfo(request, "", "NotifyServiceImpl-fetchRecentNotifications",
					"fetchRecentNotifications", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");		
		}
		logger.info("NotifyServiceImpl-fetchRecentNotifications-end");
		return commonResponseDto;
	}
	
	
	@Override
	public CommonResponseDto<?> notificationProcessor(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		logger.info("NotifyServiceImpl-notificationProcessor-start");
		try {
			NotifyDeliveryLogEntity notifyDeliveryLog = new NotifyDeliveryLogEntity();
			List<NotifyDeliveryLogEntity> notifyDeliveryLogs = new ArrayList<>();
			List<NotificationLogEntity> notificationLogEntities = notificationLogRepo.findByIsLocked(CommonConstants.FALSE);
			if (!notificationLogEntities.isEmpty()) {
				for (NotificationLogEntity notificationLog : notificationLogEntities) {
					notificationLog.setIsLocked(CommonConstants.TRUE);
					notificationLog.setModifiedDate(DateUtils.sysDate());
					notificationLogRepo.save(notificationLog);
				}
			} else {
				commonResponseDto
						.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
				commonResponseDto.setStatus(CommonConstants.ERROR);
			}
			for (NotificationLogEntity notificationLogEntity : notificationLogEntities) {
				if(CommonConstants.EMAIL.equals(notificationLogEntity.getNotifyType())) {
					EmailDto emailDto = new EmailDto();
					List<EmailBodyDto> emailBodyDtos = new ArrayList<>();
					emailBodyDtos.add(new EmailBodyDto("$CLAIM_NUMBER", notificationLogEntity.getClaimNumber()));
					ClaimDetailsDto claimDetailsDto = commonRestTemplateService.getClaimDetails(notificationLogEntity.getClaimNumber(), request);
					if(claimDetailsDto.getApplicationErr() != null) {
						if(CommonConstants.ZERO_STRING.equals(claimDetailsDto.getApplicationErr().getErrorCode())) {
							emailBodyDtos.add(new EmailBodyDto("$POLICY_NUMBER", claimDetailsDto.getPolicyNumber()));
							emailBodyDtos.add(new EmailBodyDto("$INSURED_NAME", claimDetailsDto.getInsuredName()));
							if(claimDetailsDto.getClaimHandler() != null) {
								emailBodyDtos.add(new EmailBodyDto("$CLAIM_HANDLER", claimDetailsDto.getClaimHandler()));
							}
							if(claimDetailsDto.getCustomerEmailId() != null) {
								emailBodyDtos.add(new EmailBodyDto("$INSURED_MAIL", claimDetailsDto.getCustomerEmailId()));
							}
							if(commonRequestDto.getSurveyorMobileNo() != null) {
								emailBodyDtos.add(new EmailBodyDto("$SURVEYOR_MOBILE", commonRequestDto.getSurveyorMobileNo()));
							}
							if(commonRequestDto.getSurveyorEmailId() != null) {
								emailBodyDtos.add(new EmailBodyDto("$SURVEYOR_MAIL", commonRequestDto.getSurveyorEmailId()));
							}
							if(commonRequestDto.getRemarks() != null) {
								emailBodyDtos.add(new EmailBodyDto("$REMARK", commonRequestDto.getRemarks()));
							}
							if(commonRequestDto.getDateOfVisit() != null) {
								emailBodyDtos.add(new EmailBodyDto("$DATE_OF_VISIT", commonRequestDto.getDateOfVisit()));
							}
							if(commonRequestDto.getTimeofVisit() != null) {
								emailBodyDtos.add(new EmailBodyDto("$TIME_OF_VISIT", commonRequestDto.getTimeofVisit()));
							}
							if(commonRequestDto.getSurveyorName() != null) {
								emailBodyDtos.add(new EmailBodyDto("$SURVEYOR_NAME", commonRequestDto.getSurveyorName()));
							}
							if(claimDetailsDto.getLossDetails() != null) {
								if(claimDetailsDto.getLossDetails().getLossDate() != null) {
									emailBodyDtos.add(new EmailBodyDto("$DATE_OF_LOSS", claimDetailsDto.getLossDetails().getLossDate()));
								}
								if(claimDetailsDto.getLossDetails().getLossDetails() != null) {
									emailBodyDtos.add(new EmailBodyDto("$LOSS_DESCRIPTION", claimDetailsDto.getLossDetails().getLossDetails()));
								}
							}
							if(claimDetailsDto.getIntimatedDetails() != null) {
								if(claimDetailsDto.getIntimatedDetails().getEmail() != null) {
									emailBodyDtos.add(new EmailBodyDto("$INSURED_CONTACT_NUM", claimDetailsDto.getIntimatedDetails().getEmail()));
								}
								
							}
						}else {
							notifyDeliveryLog.setIsSuccess(CommonConstants.FALSE);
							notifyDeliveryLog.setIsSent(CommonConstants.FALSE);
							notifyDeliveryLog.setErrorMsg(claimDetailsDto.getApplicationErr().getErrorDescription());
						}
					}
					List<String> emailTo = new ArrayList<>();
					emailTo.addAll(commonRequestDto.getEmailTo());
					emailDto.setEmailAttachement(Arrays.asList(""));
					emailDto.setEmailBcc(CommonConstants.EMPTY_STRING);
					emailDto.setEmailBody(emailBodyDtos);
					emailDto.setEmailCc(null);
					emailDto.setEmailBcc(null);
					Long emailTempId = notificationLogRepo.getEmailTemplateId(notificationLogEntity.getNotifyConfigId());
					emailDto.setEmailSubject(notificationLogRepo.getSubjectByConfigId(emailTempId, CommonConstants.TRUE));
					emailDto.setEmailTo(emailTo);
					emailDto.setPartId(CommonConstants.EMPTY_STRING);
					emailDto.setReferenceId(DateUtils.uniqueNoYYYMMYDDMilli());
//					emailDto.setTemplateId(CommonConstants.TEMPLATE_ID);
					emailDto.setTemplateId(notificationLogEntity.getTemplateId());
					String writeValueAsString = mapper.writeValueAsString(emailDto);
					logger.info("Email Request:" + writeValueAsString);
					CommonMasterDto sendEmailRequest = sendEmailRequest(emailDto, request);
					String mailResponse = mapper.writeValueAsString(sendEmailRequest);
					logger.info("Email Response:" + mailResponse);
					notifyDeliveryLog.setCreatedDate(DateUtils.sysDate());
					notifyDeliveryLog.setDeliveryType(notificationLogEntity.getNotifyType());
					if (sendEmailRequest != null && StringUtils.isNotBlank(sendEmailRequest.getStatus())
							&& sendEmailRequest.getStatus().equalsIgnoreCase(CommonConstants.SUCCESS)) {
						sendEmailRequest.setName(writeValueAsString);
						sendEmailRequest.setStatus(sendEmailRequest.getStatus());
						commonResponseDto.setMessage(
								"Mail has been sent successfully to your email.");
						notifyDeliveryLog.setIsSuccess(CommonConstants.TRUE);
						notifyDeliveryLog.setIsSent(CommonConstants.FALSE);
					} else {
						commonResponseDto.setStatus(CommonConstants.ERROR);
						commonResponseDto
								.setMessage("Try again. Error in sending mail to your email.");
						sendEmailRequest.setName(writeValueAsString);
						sendEmailRequest.setStatus(sendEmailRequest.getStatus());
						notifyDeliveryLog.setIsSuccess(CommonConstants.FALSE);
						notifyDeliveryLog.setIsSent(CommonConstants.FALSE);
//						notifyDeliveryLog.setErrorMsg(sendEmailRequest.getMessage());
					}
					notifyDeliveryLog.setNotifyLogEntity(notificationLogEntity);
					notifyDeliveryLogs.add(notifyDeliveryLog);
					notificationLogEntity.setNotifyDeliveryLogs(notifyDeliveryLogs);
					notificationLogRepo.save(notificationLogEntity);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();			
			logger.error("NotifyServiceImpl-notificationProcessor ", e);
			CommonRequestUtil.errorInfo(request, "", "NotifyServiceImpl-notificationProcessor",
					"notificationProcessor", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("NotifyServiceImpl-notificationProcessor-end");
		return commonResponseDto;
	}
	
	private CommonMasterDto sendEmailRequest(EmailDto dto, HttpServletRequest request) {
		CommonMasterDto resDto = new CommonMasterDto();
		resDto.setStatus(CommonConstants.ERROR);
		logger.info("userServiceImpl-sendEmailRequest-Start");
		try {
			resDto = commonRestTemplateService.sendEmailRequest(dto, request);
		} catch (Exception e) {
			resDto.setMessage(e.getMessage());
			logger.error("Excpetion in MasterServiceImpl-sendEmailRequest", e);
		}
		logger.info("userServiceImple-sendEmailRequest-End");
		return resDto;
	}
	
	private CommonMasterDto sendSmsRequest(SmsDto smsDto, HttpServletRequest request) {
		CommonMasterDto commonMasterDto = new CommonMasterDto();
		commonMasterDto.setStatus(CommonConstants.ERROR);
		logger.info("userServiceImpl-sendSmsRequest-Start");
		try {
			commonMasterDto = commonRestTemplateService.sendSmsRequest(smsDto, request);
		} catch (Exception e) {
			commonMasterDto.setMessage(e.getMessage());
			logger.error("Excpetion in MasterServiceImpl-sendSmsRequest", e);
		}
		logger.info("userServiceImple-sendSmsRequest-End");
		return commonMasterDto;
	}
	
	
	@Override
	public CommonResponseDto<?> maximusNotificationProcessor(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		logger.info("Enter into NotifyServiceImpl maximusNotificationProcessor Start...");
		try {
			NotifyDeliveryLogEntity notifyDeliveryLog = new NotifyDeliveryLogEntity();
			List<NotifyDeliveryLogEntity> notifyDeliveryLogs = new ArrayList<>();
			List<NotificationLogEntity> notificationLogEntities = notificationLogRepo.findByIsLocked(CommonConstants.FALSE);
			if (!notificationLogEntities.isEmpty()) {
				for (NotificationLogEntity notificationLog : notificationLogEntities) {
					notificationLog.setIsLocked(CommonConstants.TRUE);
					notificationLog.setModifiedDate(DateUtils.sysDate());
					notificationLogRepo.save(notificationLog);
				}
			} else {
				commonResponseDto
						.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
				commonResponseDto.setStatus(CommonConstants.ERROR);
			}
			for (NotificationLogEntity notificationLogEntity : notificationLogEntities) {
				if(CommonConstants.EMAIL.equals(notificationLogEntity.getNotifyType())) {
					EmailDto emailDto = new EmailDto();
					List<EmailBodyDto> emailBodyDtos = new ArrayList<>();
					if(commonRequestDto.getEmailBodyMap() != null) {
						emailBodyDtos = commonRequestDto.getEmailBodyMap().entrySet().stream()
				                .filter(entry -> entry.getValue() != null)
				                .map(entry -> new EmailBodyDto(entry.getKey(), entry.getValue()))
				                .collect(Collectors.toList());
					}
					List<String> emailTo = new ArrayList<>();
					emailTo.addAll(commonRequestDto.getEmailTo());
					emailDto.setEmailAttachement(Arrays.asList(""));
					emailDto.setEmailBcc(CommonConstants.EMPTY_STRING);
					emailDto.setEmailBody(emailBodyDtos);
					emailDto.setEmailCc(null);
					emailDto.setEmailBcc(null);
					Long emailTempId = notificationLogRepo.getEmailTemplateId(notificationLogEntity.getNotifyConfigId());
					emailDto.setEmailSubject(notificationLogRepo.getSubjectByConfigId(emailTempId, CommonConstants.TRUE));
					emailDto.setEmailTo(emailTo);
					emailDto.setPartId(CommonConstants.EMPTY_STRING);
					emailDto.setReferenceId(DateUtils.uniqueNoYYYMMYDDMilli());
					emailDto.setTemplateId(notificationLogEntity.getTemplateId());
					String writeValueAsString = mapper.writeValueAsString(emailDto);
					logger.info("Email Request:" + writeValueAsString);
					CommonMasterDto sendEmailRequest = sendEmailRequest(emailDto, request);
					String mailResponse = mapper.writeValueAsString(sendEmailRequest);
					logger.info("Email Response:" + mailResponse);
					notifyDeliveryLog.setCreatedDate(DateUtils.sysDate());
					notifyDeliveryLog.setDeliveryType(notificationLogEntity.getNotifyType());
					if (sendEmailRequest != null && StringUtils.isNotBlank(sendEmailRequest.getStatus())
							&& sendEmailRequest.getStatus().equalsIgnoreCase(CommonConstants.SUCCESS)) {
						sendEmailRequest.setName(writeValueAsString);
						sendEmailRequest.setStatus(sendEmailRequest.getStatus());
						commonResponseDto.setMessage(
								"Mail has been sent successfully to your email.");
						notifyDeliveryLog.setIsSuccess(CommonConstants.TRUE);
						notifyDeliveryLog.setIsSent(CommonConstants.FALSE);
					} else {
						commonResponseDto.setStatus(CommonConstants.ERROR);
						commonResponseDto
								.setMessage("Try again. Error in sending mail to your email.");
						notifyDeliveryLog.setIsSuccess(CommonConstants.FALSE);
						notifyDeliveryLog.setIsSent(CommonConstants.FALSE);
//						notifyDeliveryLog.setErrorMsg(sendEmailRequest.getMessage());
					}
					notifyDeliveryLog.setNotifyLogEntity(notificationLogEntity);
					notifyDeliveryLogs.add(notifyDeliveryLog);
					notificationLogEntity.setNotifyDeliveryLogs(notifyDeliveryLogs);
					notificationLogRepo.save(notificationLogEntity);
				} else if(CommonConstants.SMS.equals(notificationLogEntity.getNotifyType())) {
					SmsDto smsDto = new SmsDto();
					smsDto.setLanguage(CommonConstants.ENGLISH);
					if(commonRequestDto.getSmsTo() != null && !commonRequestDto.getSmsTo().isEmpty()) {
						smsDto.setMobileNo(commonRequestDto.getSmsTo());
					}
					smsDto.setTypeOfMsg(List.of(CommonConstants.SMS));
					smsDto.setPartID(CommonConstants.EMPTY_STRING);
					smsDto.setReferenceId(DateUtils.uniqueNoYYYMMYDDMilli());
					smsDto.setTemplateId(notificationLogEntity.getTemplateId());
					SmsTextDto smsText = new SmsTextDto();
					List<SmsValuesDto> smsValues = new ArrayList<>();
					if(commonRequestDto.getSmsBodyMap() != null) {
						smsValues = commonRequestDto.getSmsBodyMap().entrySet().stream()
				                .filter(entry -> entry.getValue() != null)
				                .map(entry -> new SmsValuesDto(entry.getKey(), entry.getValue()))
				                .collect(Collectors.toList());
					}
					smsText.setSmsValues(smsValues);
					smsDto.setSmsText(smsText);
					String writeValueAsString = mapper.writeValueAsString(smsDto);
					logger.info("SMS Request:" + writeValueAsString);
					CommonMasterDto sendSmsRequest = sendSmsRequest(smsDto, request);
					String smsResponse = mapper.writeValueAsString(sendSmsRequest);
					logger.info("SMS Response:" + smsResponse);
					notifyDeliveryLog.setCreatedDate(DateUtils.sysDate());
					notifyDeliveryLog.setDeliveryType(notificationLogEntity.getNotifyType());
					if (sendSmsRequest != null && StringUtils.isNotBlank(sendSmsRequest.getStatus())
							&& sendSmsRequest.getStatus().equalsIgnoreCase(CommonConstants.SUCCESS)) {
						sendSmsRequest.setName(writeValueAsString);
						sendSmsRequest.setStatus(sendSmsRequest.getStatus());
						commonResponseDto.setMessage(
								"SMS has been sent successfully to your email.");
						notifyDeliveryLog.setIsSuccess(CommonConstants.TRUE);
						notifyDeliveryLog.setIsSent(CommonConstants.FALSE);
					} else {
						commonResponseDto.setStatus(CommonConstants.ERROR);
						commonResponseDto
								.setMessage("Try again. Error in sending mail to your email.");
						notifyDeliveryLog.setIsSuccess(CommonConstants.FALSE);
						notifyDeliveryLog.setIsSent(CommonConstants.FALSE);
//						notifyDeliveryLog.setErrorMsg(sendEmailRequest.getMessage());
					}
					notifyDeliveryLog.setNotifyLogEntity(notificationLogEntity);
					notifyDeliveryLogs.add(notifyDeliveryLog);
					notificationLogEntity.setNotifyDeliveryLogs(notifyDeliveryLogs);
					notificationLogRepo.save(notificationLogEntity);
				}
			}
		} catch (Exception e) {			
			logger.error("Enter into NotifyServiceImpl maximusNotificationProcessor Exception ", e);
			e.printStackTrace();
			CommonRequestUtil.errorInfo(request, "", "NotifyServiceImpl-maximusNotificationProcessor",
					"maximusNotificationProcessor", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("Enter into NotifyServiceImpl maximusNotificationProcessor End...");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<?> sendNotification(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("NotifyServiceImpl-sendNotification-start");
		CommonResponseDto<NotifyConfigDto> commonResponseDto = new CommonResponseDto<>();
		try {
			if(commonRequestDto.getAction() != null && StringUtils.isNotEmpty(commonRequestDto.getAction())) {
				CommonResponseDto<NotifyConfigDto> response= commonRestTemplateService.getNotifyConfig(commonRequestDto, request);
				if(response != null) {
					if(CommonConstants.SUCCESS.equals(response.getStatus())) {
						if(response.getResponseData() != null) {
							NotifyConfigDto notifyConfig = response.getResponseData();
							if(notifyConfig.getNotifyEmailTemplate() != null) {
								NotificationLogEntity notificationLog = new NotificationLogEntity();
								notificationLog.setCreatedDate(DateUtils.sysDate());
								notificationLog.setIsLocked(CommonConstants.FALSE);
								notificationLog.setNotifyConfigId(NumericUtils.convertStringToLong(notifyConfig.getId()));
								notificationLog.setClaimNumber(commonRequestDto.getClaimNumber());
								notificationLog.setSurveyNumber(commonRequestDto.getSurveyorNo());
								notificationLog.setUserId(commonRequestDto.getUserId());
								notificationLog.setNotifyType(CommonConstants.EMAIL);
								notificationLog.setTemplateId(notifyConfig.getNotifyEmailTemplate().getTemplateId());
								notificationLogRepo.save(notificationLog);
								NotifyUserDto dto = new NotifyUserDto();
								dto.setClaimNumber(commonRequestDto.getClaimNumber());
								dto.setSurveyNumber(commonRequestDto.getSurveyorNo());
								dto.setContent(notifyConfig.getNotifyEmailTemplate().getContent());
								dto.setSubject(notifyConfig.getNotifyEmailTemplate().getSubject());
								dto.setUserId(commonRequestDto.getUserId());
								dto.setType(notificationLog.getNotifyType());
								dto.setNotifyConfigId(notifyConfig.getId());
								commonRequestDto.setNotifyUser(dto);
							    saveUserNotifcation(commonRequestDto, request);
							}
							if(notifyConfig.getNotifyMsgTemplate() != null) {
								NotificationLogEntity notificationLog = new NotificationLogEntity();
								notificationLog.setCreatedDate(DateUtils.sysDate());
								notificationLog.setIsLocked(CommonConstants.FALSE);
								notificationLog.setNotifyConfigId(NumericUtils.convertStringToLong(notifyConfig.getId()));
								notificationLog.setClaimNumber(commonRequestDto.getClaimNumber());
								notificationLog.setSurveyNumber(commonRequestDto.getSurveyorNo());
								notificationLog.setUserId(commonRequestDto.getUserId());
								notificationLog.setNotifyType(CommonConstants.MSG);
								notificationLogRepo.save(notificationLog);
								NotifyUserDto dto = new NotifyUserDto();
								dto.setClaimNumber(commonRequestDto.getClaimNumber());
								dto.setSurveyNumber(commonRequestDto.getSurveyorNo());
								dto.setContent(notifyConfig.getNotifyMsgTemplate().getContent());
								dto.setSubject(notifyConfig.getNotifyMsgTemplate().getSubject());
								dto.setUserId(commonRequestDto.getUserId());
								dto.setType(notificationLog.getNotifyType());
								dto.setNotifyConfigId(notifyConfig.getId());
								commonRequestDto.setNotifyUser(dto);
							    saveUserNotifcation(commonRequestDto, request);
							}
							if(notifyConfig.getNotifySmsTemplate() != null) {
								NotificationLogEntity notificationLog = new NotificationLogEntity();
								notificationLog.setCreatedDate(DateUtils.sysDate());
								notificationLog.setIsLocked(CommonConstants.FALSE);
								notificationLog.setNotifyConfigId(NumericUtils.convertStringToLong(notifyConfig.getId()));
								notificationLog.setClaimNumber(commonRequestDto.getClaimNumber());
								notificationLog.setSurveyNumber(commonRequestDto.getSurveyorNo());
								notificationLog.setUserId(commonRequestDto.getUserId());
								notificationLog.setNotifyType(CommonConstants.SMS);
								notificationLog.setTemplateId(notifyConfig.getNotifySmsTemplate().getTemplateId());
								notificationLogRepo.save(notificationLog);
								NotifyUserDto dto = new NotifyUserDto();
								dto.setClaimNumber(commonRequestDto.getClaimNumber());
								dto.setSurveyNumber(commonRequestDto.getSurveyorNo());
								dto.setContent(notifyConfig.getNotifySmsTemplate().getContent());
								dto.setSubject(notifyConfig.getNotifySmsTemplate().getSubject());
								dto.setUserId(commonRequestDto.getUserId());
								dto.setType(notificationLog.getNotifyType());
								dto.setNotifyConfigId(notifyConfig.getId());
								commonRequestDto.setNotifyUser(dto);
							    saveUserNotifcation(commonRequestDto, request);
							}
							commonResponseDto.setResponseData(commonResponseDto.getResponseData());
							commonResponseDto.setStatus(CommonConstants.SUCCESS);
							if(CommonConstants.TRUE.equals(commonRequestDto.getIsMaximusClaim())) {
								maximusNotificationProcessor(commonRequestDto, request);
							} else {
								notificationProcessor(commonRequestDto, request);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();			
			logger.error("NotifyServiceImpl-sendNotification ", e);
			CommonRequestUtil.errorInfo(request, "", "NotifyServiceImpl-sendNotification",
					"sendNotification", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("NotifyServiceImpl-sendNotification-end");
		return commonResponseDto;
	}

}
