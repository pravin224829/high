package com.fa.bajajallianz.cccp.common.report.service.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fa.bajajallianz.cccp.common.dto.APIRequestDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimAnalysisDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimSummaryCountDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.dto.ReportResponseDto;
import com.fa.bajajallianz.cccp.common.dto.UserCountDto;
import com.fa.bajajallianz.cccp.common.report.repository.ClaimSummaryCountRepo;
import com.fa.bajajallianz.cccp.common.report.repository.UserCountRepo;
import com.fa.bajajallianz.cccp.common.report.service.ReportService;
import com.fa.bajajallianz.cccp.common.restapi.service.CommonRestTemplateService;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.DateUtils;
import com.fa.bajajallianz.cccp.common.utils.ErrorCodeConstants;
import com.fa.bajajallianz.cccp.common.utils.NumericUtils;
import com.fa.bajajallianz.cccp.config.utils.CommonErrorMsg;
import com.fa.bajajallianz.cccp.config.utils.CommonRequestUtil;

@Service
public class ReportServiceImpl implements ReportService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	ClaimSummaryCountRepo claimSummaryCountRepo;

	@Autowired
	UserCountRepo userCountRepo;

	@Autowired
	CommonRestTemplateService commonRestTemplateService;

	@Autowired
	CommonErrorMsg commonErrorMsg;

	@Override
	public CommonResponseDto<ClaimSummaryCountDto> fetchClaimSummaryCount(CommonRequestDto requestDto,
			HttpServletRequest request) {
		CommonResponseDto<ClaimSummaryCountDto> commonResponseDto = new CommonResponseDto<>();
		logger.info("ReportServiceImpl-fetchClaimSummaryCount-start");
		try {
			ClaimSummaryCountDto claimSummaryCountDto = new ClaimSummaryCountDto();
//			List<Object[]> resultObj = null;
//			if (requestDto.getRoleCode().equalsIgnoreCase(CommonConstants.ROLE_ADMIN)) {
//				resultObj = claimSummaryCountRepo.fetchSummaryCountForAdmin(CommonConstants.TRUE);
//			} else if(requestDto.getRoleCode().equalsIgnoreCase(CommonConstants.ROLE_CORPADMIN)){
//				resultObj = claimSummaryCountRepo.fetchSummaryCount(CommonConstants.TRUE, requestDto.getCorporateId());
//			}else {
//				resultObj = claimSummaryCountRepo.fetchSummaryCountForUser(CommonConstants.TRUE, requestDto.getUserId());
//			}

//			if (resultObj != null) {
//				for (Object[] row : resultObj) {
//					if(row[0] != null) {
//						claimSummaryCountDto.setNoOfClaimRegsitered(((BigInteger) row[0]).intValue());
//					}
			CommonResponseDto<String> response = commonRestTemplateService.getClaimCount(requestDto);
			if (response.getStatus().equals(CommonConstants.SUCCESS)) {
				claimSummaryCountDto
						.setNoOfClaimRegsitered(NumericUtils.convertStringToInteger(response.getClosedCount())
								+ NumericUtils.convertStringToInteger(response.getOutstandingCnt()));
				claimSummaryCountDto
						.setNoOfClaimUploaded(NumericUtils.convertStringToInteger(response.getClosedCount()));
				claimSummaryCountDto
						.setNoOfClaimUpdated(NumericUtils.convertStringToInteger(response.getOutstandingCnt()));

			}
			// 20230123
//					if(row[1] != null) {
//						claimSummaryCountDto.setNoOfClaimUpdated(((BigInteger) row[1]).intValue());
//					}
//					if(row[2] != null) {
//						claimSummaryCountDto.setNoOfClaimUploaded(((BigInteger) row[2]).intValue());
//					}
//					claimSummaryCountDto.setNoOfClaimUpdated(((BigInteger) row[1]).intValue());
//					claimSummaryCountDto.setNoOfClaimUploaded(((BigInteger) row[2]).intValue());
//				}
//			}
			commonResponseDto.setStatus(CommonConstants.SUCCESS);
			commonResponseDto.setResponseData(claimSummaryCountDto);
		} catch (Exception e) {
			logger.error("ReportServiceImpl-fetchClaimSummaryCount ", e);
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
			commonResponseDto.setStatus(CommonConstants.ERROR);
			CommonRequestUtil.errorInfo(request, "", "ReportServiceImpl-fetchClaimSummaryCount",
					"fetchClaimSummaryCount", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("ReportServiceImpl-fetchClaimSummaryCount-end");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<UserCountDto> fetchUserCount(CommonRequestDto requestDto, HttpServletRequest request) {
		CommonResponseDto<UserCountDto> commonResponseDto = new CommonResponseDto<>();
		logger.info("ReportServiceImpl-fetchUserCount-start");
		try {

			List<Object[]> resultObj = userCountRepo.getUserCount(CommonConstants.TRUE);
			UserCountDto userCountDto = new UserCountDto();
			if (resultObj != null) {
				for (Object[] row : resultObj) {

					userCountDto.setActiveUser(((BigInteger) row[0]).intValue());
					userCountDto.setInActiveUser(((BigInteger) row[1]).intValue());
					userCountDto.setTotalUser(((BigInteger) row[2]).intValue());
				}
			}

			commonResponseDto.setStatus(CommonConstants.SUCCESS);
			commonResponseDto.setResponseData(userCountDto);
		} catch (Exception e) {
			logger.error("ReportServiceImpl-fetchUserCount ", e);
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
			commonResponseDto.setStatus(CommonConstants.ERROR);
			CommonRequestUtil.errorInfo(request, "", "ReportServiceImpl-fetchUserCount", "fetchUserCount", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("ReportServiceImpl-fetchUserCount-end");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<List<ClaimAnalysisDto>> fetchClaimAnalysisCount(CommonRequestDto requestDto,
			HttpServletRequest request) {
		CommonResponseDto<List<ClaimAnalysisDto>> commonResponseDto = new CommonResponseDto<>();
		logger.info("ReportServiceImpl-fetchClaimAnalysisCount-start");
		try {
			List<Object[]> resultObj = null;
			Date fromDate = (requestDto.getFromDate() != null
					? (DateUtils.convertDateTimeToString(requestDto.getFromDate() + " 00:00:00"))
					: null);
			Date toDate = (requestDto.getFromDate() != null
					? (DateUtils.convertDateTimeToString(requestDto.getToDate() + " 23:59:59"))
					: null);
			if (CommonConstants.ROLE_CORPUSR.equals(requestDto.getRoleCode())) {
				resultObj = claimSummaryCountRepo.fetchClaimAnalysisCount(requestDto.getUserId(), fromDate, toDate);
			} else if (CommonConstants.ROLE_CORPADMIN.equals(requestDto.getRoleCode())) {
				resultObj = claimSummaryCountRepo
						.fetchClaimAnalysisCountByCorporateAdmin(requestDto.getCorporateUserId(), fromDate, toDate);
			} else {
				resultObj = claimSummaryCountRepo.fetchClaimAnalysisCountByAdmin(fromDate, toDate);
			}
//			List<Object[]> resultObj = claimSummaryCountRepo.fetchClaimAnalysisCount(fromDate, toDate);
			List<ClaimAnalysisDto> claimAnalysisDtolist = new ArrayList<>();
			if (resultObj != null) {
				for (Object[] row : resultObj) {
					ClaimAnalysisDto claimAnalysisDto = new ClaimAnalysisDto();
					claimAnalysisDto.setCount(((BigInteger) row[0]).intValue());
					claimAnalysisDto.setDate(DateUtils.dateToStringDDMMYYYY((Date) row[1]));
					claimAnalysisDtolist.add(claimAnalysisDto);
				}
			}

			commonResponseDto.setStatus(CommonConstants.SUCCESS);
			commonResponseDto.setResponseData(claimAnalysisDtolist);
		} catch (Exception e) {
			logger.error("ReportServiceImpl-fetchClaimAnalysisCount ", e);
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
			commonResponseDto.setStatus(CommonConstants.ERROR);
			CommonRequestUtil.errorInfo(request, "", "ReportServiceImpl-fetchClaimAnalysisCount",
					"fetchClaimAnalysisCount", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("ReportServiceImpl-fetchClaimAnalysisCount-end");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<ClaimAnalysisDto> refreshClaimCount(HttpServletRequest request) {
		CommonResponseDto<ClaimAnalysisDto> commonResponseDto = new CommonResponseDto<>();
		logger.info("ReportServiceImpl-refreshClaimCount-start");
		try {
			claimSummaryCountRepo.callClaimSummaryRefreshCount();
			commonResponseDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("ReportServiceImpl-refreshClaimCount ", e);
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
			commonResponseDto.setStatus(CommonConstants.ERROR);
			CommonRequestUtil.errorInfo(request, "", "ReportServiceImpl-refreshClaimCount", "refreshClaimCount", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("ReportServiceImpl-refreshClaimCount-end");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<UserCountDto> refreshUserCount(HttpServletRequest request) {
		CommonResponseDto<UserCountDto> commonResponseDto = new CommonResponseDto<>();
		logger.info("ReportServiceImpl-refreshUserCount-start");
		try {
			claimSummaryCountRepo.callUserRefreshCount();
			executeClaimCount(request);
			commonResponseDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("ReportServiceImpl-refreshUserCount ", e);
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
			commonResponseDto.setStatus(CommonConstants.ERROR);
			CommonRequestUtil.errorInfo(request, "", "ReportServiceImpl-refreshUserCount", "refreshUserCount", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("ReportServiceImpl-refreshUserCount-end");
		return commonResponseDto;
	}

	private String executeClaimCount(HttpServletRequest request) {
		logger.info("ReportServiceImpl-executeClaimCount-start");
		try {
			claimSummaryCountRepo.callClaimRefreshCount();
			logger.info("ReportServiceImpl-executeClaimCount-end");
			return CommonConstants.SUCCESS;
		} catch (Exception e) {
			logger.error("ReportServiceImpl-executeClaimCount ", e);
			CommonRequestUtil.errorInfo(request, "", "ReportServiceImpl-executeClaimCount", "executeClaimCount", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
			logger.info("ReportServiceImpl-executeClaimCount-end");
			return CommonConstants.ERROR;
		}

	}

	@Override
	public DataTableDto<List<ReportResponseDto>> getOutstandingReport(CommonRequestDto dto, String main_filter,
			String sort, String page, String per_page, HttpServletRequest request) {
		DataTableDto<List<ReportResponseDto>> response = new DataTableDto<List<ReportResponseDto>>();
		List<ReportResponseDto> dtos = new ArrayList<ReportResponseDto>();
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<String>();
		logger.info("Enter into ReportServiceImpl--getOutstandingReport---Start");
		try {
			if (dto != null) {
				if (dto.getFromDate() != null && StringUtils.isNotEmpty(dto.getFromDate())) {
					dto.setStartDate(dto.getFromDate());
					dto.setFromDate(
							DateUtils.dateToStringDDMMYYYYWith(DateUtils.convertStringToDate(dto.getFromDate())));
				}
				if (dto.getToDate() != null && StringUtils.isNotEmpty(dto.getToDate())) {
					dto.setEndDate(dto.getToDate());
					dto.setToDate(DateUtils.dateToStringDDMMYYYYWith(DateUtils.convertStringToDate(dto.getToDate())));
				}
				if (dto.getImdCode() != null && StringUtils.isNotEmpty(dto.getImdCode())) {
					dto.setAgentCode(dto.getImdCode());
				}
			}
			if(dto.getName() != null && StringUtils.isNotEmpty(dto.getName())) {
				switch (dto.getName()) {
				case CommonConstants.OUTSTANDCLAIM:
					commonResponseDto = commonRestTemplateService.getOutStandingReport(dto, request);
					if (commonResponseDto != null) {
						ReportResponseDto reportResponseDto = new ReportResponseDto();
						String bytes = commonResponseDto.getEncodeString();
						byte[] decodedString = Base64.getDecoder().decode(new String(bytes).getBytes("UTF-8"));
						String decode = new String(decodedString);
						reportResponseDto.setBase64String(decode);
						reportResponseDto.setName(CommonConstants.OUTSTANDCLAIM);
						reportResponseDto.setTotal(commonResponseDto.getTotal());
						reportResponseDto.setReportType(dto.getReportType());
						dtos.add(reportResponseDto);
					}
					break;
	            case CommonConstants.DETAILINFOREP:
	            	commonResponseDto = commonRestTemplateService.getDtlClmInfoReport(dto, request);
	    			if (commonResponseDto != null) {
	    				ReportResponseDto reportResponseDto = new ReportResponseDto();
	    				String bytes = commonResponseDto.getEncodeString();
	    				byte[] decodedString = Base64.getDecoder().decode(new String(bytes).getBytes("UTF-8"));
	    				String decode = new String(decodedString);
	    				reportResponseDto.setBase64String(decode);
	    				reportResponseDto.setName(CommonConstants.DETAILINFOREP);
	    				reportResponseDto.setTotal(commonResponseDto.getTotal());
	    				reportResponseDto.setReportType(dto.getReportType());
	    				dtos.add(reportResponseDto);
	    			}
					break;
	            case CommonConstants.CLAIMPAYREP:
	            	commonResponseDto = commonRestTemplateService.getClmPaymentReport(dto, request);
	    			if (commonResponseDto != null) {
	    				ReportResponseDto reportResponseDto = new ReportResponseDto();
	    				String bytes = commonResponseDto.getEncodeString();
	    				byte[] decodedString = Base64.getDecoder().decode(new String(bytes).getBytes("UTF-8"));
	    				String decode = new String(decodedString);
	    				reportResponseDto.setBase64String(decode);
	    				reportResponseDto.setName(CommonConstants.CLAIMPAYREP);
	    				reportResponseDto.setTotal(commonResponseDto.getTotal());
	    				reportResponseDto.setReportType(dto.getReportType());
	    				dtos.add(reportResponseDto);
	    			}
					break;
	            case CommonConstants.SETTLEDCLAIMS:
	            	commonResponseDto = commonRestTemplateService.getClmSettlementReport(dto, request);
	    			if (commonResponseDto != null) {
	    				ReportResponseDto reportResponseDto = new ReportResponseDto();
	    				String bytes = commonResponseDto.getEncodeString();
	    				byte[] decodedString = Base64.getDecoder().decode(new String(bytes).getBytes("UTF-8"));
	    				String decode = new String(decodedString);
	    				reportResponseDto.setBase64String(decode);
	    				reportResponseDto.setName(CommonConstants.SETTLEDCLAIMS);
	    				reportResponseDto.setTotal(commonResponseDto.getTotal());
	    				reportResponseDto.setReportType(dto.getReportType());
	    				dtos.add(reportResponseDto);
	    			}
					break;
	            case CommonConstants.UPDATEDCLAIMS:
	            	commonResponseDto = commonRestTemplateService.getUpdateClaimList(dto, request);
	    			if (commonResponseDto != null) {
	    				ReportResponseDto reportResponseDto = new ReportResponseDto();
	    				reportResponseDto.setBase64String(commonResponseDto.getResponseData());
	    				reportResponseDto.setName(CommonConstants.UPDATEDCLAIMS);
	    				reportResponseDto.setTotal(commonResponseDto.getTotal());
	    				reportResponseDto.setReportType(dto.getReportType());
	    				dtos.add(reportResponseDto);
	    			}
					break;
				}
			}
			response.setStatus("SUCCESS");
			response.setData(dtos);

			Integer pageCount = NumericUtils.convertStringToInteger(page);
			Integer limit = NumericUtils.convertStringToInteger(per_page);
			response.setLast_page("0");
			response.setTotal("0");
			if (dtos != null && !dtos.isEmpty()) {
				Integer lastReminder = (dtos.size() % limit);
				Integer last = (dtos.size() / limit);
				if (lastReminder == 0) {
					response.setLast_page(NumericUtils.convertIntegerToString(last));
				} else {
					response.setLast_page(NumericUtils.convertIntegerToString(last + 1));
				}
				response.setTotal(NumericUtils.convertIntegerToString(dtos.size()));
			}
			response.setCurrent_page(page);
			response.setPer_page(per_page);
			Integer from = (pageCount * limit) - limit + 1;
			Integer to = pageCount * limit;
			response.setFrom(NumericUtils.convertIntegerToString(from));
			response.setTo(NumericUtils.convertIntegerToString(to));
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("ReportServiceImpl-getOutstandingReport ", e);
			CommonRequestUtil.errorInfo(request, "", "ReportServiceImpl-getOutstandingReport", "getOutstandingReport",
					"", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		return response;
	}

	@Override
	public CommonResponseDto<String> retryfailure(HttpServletRequest request) {
		CommonResponseDto<String> responseDto = new CommonResponseDto<String>();
		logger.info("Enter into ReportServiceImpl retryfailure Start");
		try {
			CommonResponseDto<List<APIRequestDto>> response = commonRestTemplateService.getRetryDetails();
			if (response.getStatus().equals(CommonConstants.SUCCESS)) {

			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("ReportServiceImpl-retryfailure ", e);
			CommonRequestUtil.errorInfo(request, "", "ReportServiceImpl-retryfailure", "retryfailure", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("Enter into ReportServiceImpl retryfailure End");
		return responseDto;
	}

	@Override
	public CommonResponseDto<List<ReportResponseDto>> getMISReport(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("Enter into ReportServiceImpl getMISReport Start");
		CommonResponseDto<List<ReportResponseDto>> commonResponseDto = new CommonResponseDto<>();
		List<ReportResponseDto> dtos = new ArrayList<>();
		CommonResponseDto<String> response = new CommonResponseDto<String>();
		try {	
			if(commonRequestDto.getReportName() != null && StringUtils.isNotEmpty(commonRequestDto.getReportName())) {
				switch (commonRequestDto.getReportName()) {
				case CommonConstants.OUTSTANDCLAIMS:
					response = commonRestTemplateService.getOutstandingClmReport(commonRequestDto, request);
					if (response != null) {
						ReportResponseDto dto = new ReportResponseDto();
						String bytes = response.getEncodeString();
						byte[] decodedString = Base64.getDecoder().decode(new String(bytes).getBytes("UTF-8"));
						String decode = new String(decodedString);
						dto.setBase64String(decode);
						dto.setName(CommonConstants.OUTSTANDCLAIMS);
						dto.setTotal(response.getTotal());
						dtos.add(dto);
					}
					break;
               case CommonConstants.SURFEEPAIDREP:
            	   response = commonRestTemplateService.getSurveyorPaymentClaimsReport(commonRequestDto, request);
            	   if (response != null) {
       				ReportResponseDto dto = new ReportResponseDto();
       				String bytes = response.getEncodeString();
       				byte[] decodedString = Base64.getDecoder().decode(new String(bytes).getBytes("UTF-8"));
       				String decode = new String(decodedString);
       				dto.setBase64String(decode);
       				dto.setName(CommonConstants.SURFEEPAIDREP);
       				dto.setTotal(response.getTotal());
       				dtos.add(dto);
       			}
					break;
               case CommonConstants.CLAIMSERVREP:
            	   response = commonRestTemplateService.getClmServingReport(commonRequestDto, request);
            	   if (response != null) {
       				ReportResponseDto dto = new ReportResponseDto();
       				String bytes = response.getEncodeString();
       				byte[] decodedString = Base64.getDecoder().decode(new String(bytes).getBytes("UTF-8"));
       				String decode = new String(decodedString);
       				dto.setBase64String(decode);
       				dto.setName(CommonConstants.CLAIMSERVREP);
       				dto.setTotal(response.getTotal());
       				dtos.add(dto);
       			}
					break;
				}
			}
			commonResponseDto.setResponseData(dtos);
			commonResponseDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Enter into ReportServiceImpl-getMISReport Exception", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "PaymentServiceImpl", "getMISReport", "", e.getMessage(),
					CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("Enter into ReportServiceImpl getMISReport Start");
		return commonResponseDto;
	}

}
