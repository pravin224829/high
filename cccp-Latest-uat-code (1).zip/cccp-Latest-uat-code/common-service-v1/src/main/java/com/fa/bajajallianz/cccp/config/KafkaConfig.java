package com.fa.bajajallianz.cccp.config;

import java.util.HashMap;
import java.util.Map;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;



@Configuration
public class KafkaConfig {	
	
	private static final Logger logger = LoggerFactory.getLogger(KafkaConfig.class);

	@Bean
	public ProducerFactory<String, Object> producerFactory() {

		Map<String, Object> config = new HashMap<>();
	
		config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "b-1.bancsggmsk1.rrkt3n.c3.kafka.ap-south-1.amazonaws.com:9098");
		config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
		return new DefaultKafkaProducerFactory<>(config);
	}

	@Bean
	public KafkaTemplate kafkaTemplate() {
		logger.info("Enter into KafkaConfig kafkaTemplate start...");
		return new KafkaTemplate<>(producerFactory());
	}
}
