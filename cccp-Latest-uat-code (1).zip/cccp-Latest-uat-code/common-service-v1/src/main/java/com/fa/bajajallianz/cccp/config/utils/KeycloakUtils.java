/**
 * 
 */
package com.fa.bajajallianz.cccp.config.utils;

import java.net.URI;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fa.bajajallianz.cccp.common.utils.CommonUtils;

/**
 * @author arunkumar
 *
 */
@Service
public class KeycloakUtils {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	private Environment env;

	public static void main(String[] args) {

	}
	
	public String getKeycloakToken() {
		String accessToken = null;
		try {
			logger.info("KeycloakUtils-getKeycloakToken-start");
			RestTemplate restTemplate = new RestTemplate();
			String url = CommonUtils.fetchApi("KEYCLOAK_URL", env.getProperty("CONFIG_API_URL"));
			String clientId = CommonUtils.fetchApi("KEYCLOAK_CLIENT_ID", env.getProperty("CONFIG_API_URL"));
			String clientSecret = CommonUtils.fetchApi("KEYCLOAK_CLIENT_SECRET", env.getProperty("CONFIG_API_URL"));

			String body = "client_id=" + clientId + "&grant_type=client_credentials" + "&client_secret=" + clientSecret;
			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Type", "application/x-www-form-urlencoded");
			RequestEntity<String> requestEntity = new RequestEntity<>(body, headers, HttpMethod.POST, new URI(url));
			ResponseEntity<String> result = restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class,
					new Object[0]);
			if (result != null && StringUtils.isNotBlank(result.getBody())) {
				String response = result.getBody();
				JSONObject object = new JSONObject(response);
				accessToken = String.valueOf(object.get("access_token"));

			}
		} catch (Exception e) {
			logger.error("Exception-KeycloakUtils-getKeycloakToken-", e);
		}
		logger.info("KeycloakUtils-getKeycloakToken-end");
		return accessToken;
	}
	
}
