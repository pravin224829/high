package com.fa.bajajallianz.cccp.common.service;


public interface CommonService {

}
