package com.fa.bajajallianz.cccp.common.report.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.common.report.entity.ClaimSummaryCount;

@Repository
public interface ClaimSummaryCountRepo extends JpaRepository<ClaimSummaryCount, Long> {

	List<ClaimSummaryCount> findByIsActive(Boolean isActive);

	@Query(value = "SELECT sum(c.no_of_claim_registered) as no_of_claim_registered,sum(c.no_of_claim_uploaded) as"
			+ " no_of_claim_uploaded,sum(c.no_of_claim_updated) as  no_of_claim_updated  FROM cccp_bagic.rpt_claim_summary_count c where "
			+ "c.is_active=?1", nativeQuery = true)
	List<Object[]> fetchSummaryCountForAdmin(Boolean isActive);

	@Query(value = "SELECT sum(c.no_of_claim_registered) as no_of_claim_registered,sum(c.no_of_claim_uploaded) as"
			+ " no_of_claim_uploaded,sum(c.no_of_claim_updated) as  no_of_claim_updated  FROM cccp_bagic.rpt_claim_summary_count c where "
			+ "c.is_active=?1 and corporate_code=?2", nativeQuery = true)
	List<Object[]> fetchSummaryCount(Boolean isActive, String corpId);
	
	@Query(value = "SELECT sum(c.no_of_claim_registered) as no_of_claim_registered,sum(c.no_of_claim_uploaded) as"
			+ " no_of_claim_uploaded,sum(c.no_of_claim_updated) as  no_of_claim_updated  FROM cccp_bagic.rpt_claim_summary_count c where "
			+ "c.is_active=?1 and c.user_id=?2", nativeQuery = true)
	List<Object[]> fetchSummaryCountForUser(Boolean true1, String userId);

	@Query(value = "SELECT sum(c.no_of_claim_registered) as no_of_claim_registered,c.created_date"
			+ " FROM cccp_bagic.rpt_claim_count c where "
			+ "user_id = ?1 and c.created_date between ?2 and ?3 group by c.created_date order by c.created_date asc", nativeQuery = true)
	List<Object[]> fetchClaimAnalysisCount(String userId, Date fromDate, Date toDate);
	
	@Query(value = "SELECT sum(c.no_of_claim_registered) as no_of_claim_registered,c.created_date"
			+ " FROM cccp_bagic.rpt_claim_count c where "
			+ "c.created_date between ?1 and ?2 group by c.created_date order by c.created_date asc", nativeQuery = true)
	List<Object[]> fetchClaimAnalysisCountByAdmin(Date fromDate, Date toDate);
	
	@Query(value = "SELECT sum(c.no_of_claim_registered) as no_of_claim_registered,c.created_date"
			+ " FROM cccp_bagic.rpt_claim_count c where "
			+ "corporate_code = ?1 and c.created_date between ?2 and ?3 group by c.created_date order by c.created_date asc", nativeQuery = true)
	List<Object[]> fetchClaimAnalysisCountByCorporateAdmin(String corporateId, Date fromDate, Date toDate);

	@Query(value = "(select count(*) as count,created_by,'registerd_claim' as remarks,(select code from  cccp_bagic.corporate_details where id=(select corporate_id from  cccp_bagic.users where user_id=c.created_by)) from cccp_bagic.claim_details c group by c.created_by)"
			+ "union (select count(*) as count,created_by,'claim_updated' as remarks,(select code from  cccp_bagic.corporate_details where id=(select corporate_id from  cccp_bagic.users where user_id=c.created_by)) from  cccp_bagic.claim_details  c where c.is_claim_updated =true group by c.created_by)"
			+ "union (select count(*) as count,created_by,'doc_uploaded' as remarks,(select code from  cccp_bagic.corporate_details where id=(select corporate_id from  cccp_bagic.users where user_id=c.created_by)) from  cccp_bagic.claim_details c where c.is_doc_uploaded =true group by c.created_by)", nativeQuery = true)
	List<Object[]> getSummaryCount();

	@Query(value = "CALL cccp_bagic.refresh_claim_summary_count()", nativeQuery = true)
	@Modifying
	@Transactional
	void callClaimSummaryRefreshCount();

	@Query(value = "CALL cccp_bagic.refresh_user_count()", nativeQuery = true)
	@Modifying
	@Transactional
	void callUserRefreshCount();

	@Query(value = "CALL cccp_bagic.refresh_claim_count()", nativeQuery = true)
	@Modifying
	@Transactional
	void callClaimRefreshCount();

}
