/**
 * 
 */
package com.fa.bajajallianz.cccp.common.restapi.service.impl;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fa.bajajallianz.cccp.common.dto.APIRequestDto;
import com.fa.bajajallianz.cccp.common.dto.AreaResponseDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsListResponseDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDocListResponseDto;
import com.fa.bajajallianz.cccp.common.dto.CommonDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.CommonMasterDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.EmailDto;
import com.fa.bajajallianz.cccp.common.dto.PolicyDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.PolicyResponseDto;
import com.fa.bajajallianz.cccp.common.dto.SmsDto;
import com.fa.bajajallianz.cccp.common.dto.TokenResponseDto;
import com.fa.bajajallianz.cccp.common.dto.UserDto;
import com.fa.bajajallianz.cccp.common.notify.repository.NotifyRepository;
import com.fa.bajajallianz.cccp.common.restapi.service.CommonRestTemplateService;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.DateUtils;
import com.fa.bajajallianz.cccp.common.utils.ErrorCodeConstants;
import com.fa.bajajallianz.cccp.common.utils.NumericUtils;
import com.fa.bajajallianz.cccp.config.utils.CommonErrorMsg;
import com.fa.bajajallianz.cccp.config.utils.CommonRequestUtil;
import com.fa.bajajallianz.cccp.config.utils.KeycloakUtils;
import com.fa.bajajallianz.cccp.config.utils.PreAuthTokenUtils;
import com.fa.bajajallianz.cccp.mis.common.dto.CommonMisResponseDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClaimSaveDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClmIntimationRespDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusCommonSearchDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusPolicyReqDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusPolicyResDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusSinglePolicySearchDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusTokenDto;
import com.fa.bajajallianz.cccp.surveyor.common.dto.NotifyConfigDto;

/**
 * @author arunkumar
 *
 */
@Service
public class CommonRestTemplateServiceImpl implements CommonRestTemplateService {

	private static final Logger logger = LoggerFactory.getLogger(CommonRestTemplateServiceImpl.class);

	@Autowired
	private Environment environment;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	PreAuthTokenUtils preAuthTokenUtils;

	@Autowired
	private CommonErrorMsg commonErrorMsg;
	
	@Autowired
	NotifyRepository notifyRepository;

	public String getProperty() {
		return environment.getProperty("CONFIG_API_URL");
	}

	@Autowired
	private KeycloakUtils keycloakUtils;

	@Override
	public ClaimDetailsListResponseDto getClaimList(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("CommonRestTemplateServiceImpl-getClaimList-Start");
		ClaimDetailsListResponseDto claimDetailsListDtos = new ClaimDetailsListResponseDto();
		String baseUrl = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			baseUrl = CommonUtils.fetchApi("GETCLAIMLIST", getProperty());
//			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.add(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(commonRequestDto, headers);
			claimDetailsListDtos = restTemplate.exchange(baseUrl, HttpMethod.POST, entity,
					new ParameterizedTypeReference<ClaimDetailsListResponseDto>() {
					}, headers).getBody();
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("CommonRestTemplateServiceImpl-getClaimList-end", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.info("Exception-CommonRestTemplateServiceImpl-getClaimList-", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(commonRequestDto),
					"getClaimList", "getClaimList", "getClaimList", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(claimDetailsListDtos), "", baseUrl, headers);
		}
		logger.info("CommonRestTemplateServiceImpl-getClaimList-end");
		return claimDetailsListDtos;
	}

	@Override
	public AreaResponseDto fetchLocationByPincode(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		AreaResponseDto areaResponseDto = new AreaResponseDto();
		logger.info("CommonRestTemplateServiceImpl-fetchLocationByPincode-Start");
		String baseUrl = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			baseUrl = CommonUtils.fetchApi("GETAREABYPINCODE", getProperty());
//			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.add(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(commonRequestDto, headers);
			areaResponseDto = restTemplate
					.exchange(baseUrl, HttpMethod.POST, entity, new ParameterizedTypeReference<AreaResponseDto>() {
					}, headers).getBody();
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("CommonRestTemplateServiceImpl-fetchLocationByPincode-end", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.info("Exception-CommonRestTemplateServiceImpl-fetchLocationByPincode-", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(commonRequestDto),
					"fetchLocationByPincode", "fetchLocationByPincode", "fetchLocationByPincode", message, errorMessage,
					"", "", NumericUtils.convertPojoClassToString(areaResponseDto), "", baseUrl, headers);
		}
		logger.info("CommonRestTemplateServiceImpl-fetchLocationByPincode-end");
		return areaResponseDto;
	}

	@Override
	public ClaimDetailsDto getClaimDetails(String claimNumber, HttpServletRequest request) {
		ClaimDetailsDto claimDetailsDto = new ClaimDetailsDto();
		logger.info("CommonRestTemplateServiceImpl-getClaimDetails-Start");
		String url = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			url = CommonUtils.fetchApi("GETCLAIMDETAILS", getProperty());
//			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.add(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			HttpEntity<String> requestEntity = new HttpEntity<>(headers);
			UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url).queryParam("claimNumber",
					claimNumber);
			claimDetailsDto = restTemplate.exchange(uriBuilder.toUriString(), HttpMethod.POST, requestEntity,
					new ParameterizedTypeReference<ClaimDetailsDto>() {
					}, headers).getBody();
			logger.info("Response Body: " + NumericUtils.convertPojoClassToString(claimDetailsDto));
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("CommonRestTemplateServiceImpl-getClaimDetails-end", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.info("Exception-CommonRestTemplateServiceImpl-getClaimDetails-", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, claimNumber, "getClaimDetails", "getClaimDetails", "getClaimDetails",
					message, errorMessage, "", "", NumericUtils.convertPojoClassToString(claimDetailsDto), "", url,
					headers);
		}
		logger.info("CommonRestTemplateServiceImpl-getClaimDetails-end");
		return claimDetailsDto;
	}

	@Override
	public CommonMisResponseDto<String> getMisClaimDetails(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonMisResponseDto<String> commonResponseDto = new CommonMisResponseDto<String>();
		logger.info("Enter into CommonRestTemplateServiceImpl getMisClaimDetails Start...");
		String url = null;
		String code = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
//			MaximusTokenDto authResponse = preAuthTokenUtils.getMaximusToken();
//			url = CommonUtils.fetchApi("GETMISCLAIMDETAILS", getProperty());
			logger.info("MIS URL: " + url);
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
//			if(authResponse != null) {
//			 headers.add(CommonConstants.AUTHORIZATION, "Bearer " + authResponse.getAccess_token());
//			}
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			// UAT - Comment for PROD Start
//			List<String> arrayList = Arrays.asList("6621", "5002", "5003", "5004", "5007", "5008", "5009", "6623",
//					"4070", "6622");
			List<String> arrayList = notifyRepository.findByActiveProductCode();
			// List<String> arrayList = Arrays.asList("5002", "5003", "5004", "5007",
			// "5008", "5009", "6623", "6622");
			String[] splitted = commonRequestDto.getPolicyNumber().split("-");
			String[] splitted1 = commonRequestDto.getClaimNumber().split("-");
			if ((splitted != null && splitted.length > 1 && arrayList.contains(splitted[1]))
					|| (splitted1 != null && splitted1.length > 1 && arrayList.contains(splitted1[1]))) {
				MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getMaximusToken();
				if (maximusResponseToken != null && maximusResponseToken.getAccess_token() != null) {
					headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
				}
				url = CommonUtils.fetchApi("VALUES7", getProperty());
				code = "VALUES7";
			} /*
				 * else { MaximusTokenDto maximusResponseToken =
				 * preAuthTokenUtils.getSITMaximusToken(); if (maximusResponseToken != null &&
				 * maximusResponseToken.getAccess_token() != null) {
				 * headers.add(CommonConstants.AUTHORIZATION, "Bearer " +
				 * maximusResponseToken.getAccess_token()); } url =
				 * CommonUtils.fetchApi("GETMISCLAIMDETAILS", getProperty()); code =
				 * "GETMISCLAIMDETAILS"; }
				 */
			// UAT - Comment for PROD End
			HttpEntity<CommonRequestDto> entity = new HttpEntity<>(commonRequestDto, headers);
			commonResponseDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonMisResponseDto<String>>() {
					}, headers).getBody();
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("CommonRestTemplateServiceImpl-getMisClaimDetails- Exception", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.info("Exception-CommonRestTemplateServiceImpl-getMisClaimDetails- Exception", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(commonRequestDto), code,
					"getMisClaimDetails", "getMisClaimDetails", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(commonResponseDto), "", url, headers);
		}
		logger.info("Enter into CommonRestTemplateServiceImpl getMisClaimDetails End...");
		return commonResponseDto;
	}

	@Override
	public PolicyResponseDto getPolicyDetails(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		PolicyResponseDto policyResponseDto = new PolicyResponseDto();
		logger.info("CommonRestTemplateServiceImpl-getPolicyDetails-Start");
		String baseUrl = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			baseUrl = CommonUtils.fetchApi("GETPOLICYDETAILS", getProperty());
//			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.add(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(commonRequestDto, headers);
			policyResponseDto = restTemplate
					.exchange(baseUrl, HttpMethod.POST, entity, new ParameterizedTypeReference<PolicyResponseDto>() {
					}, headers).getBody();
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("CommonRestTemplateServiceImpl-getPolicyDetails-end", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.info("Exception-CommonRestTemplateServiceImpl-getPolicyDetails-", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(commonRequestDto),
					"getPolicyDetails", "searchPolicyList", "searchPolicyList", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(policyResponseDto), "", baseUrl, headers);
		}
		logger.info("CommonRestTemplateServiceImpl-getPolicyDetails-end");
		return policyResponseDto;
	}

	@Override
	public ClaimDocListResponseDto getClaimDocList(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("Enter into CommonRestTemplateServiceImpl - getClaimDocList Start");
		ClaimDocListResponseDto response = new ClaimDocListResponseDto();
		String baseUrl = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			baseUrl = CommonUtils.fetchApi("GETDOCCLAIMLIST", getProperty());
//			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				headers.set(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
			}
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(commonRequestDto, headers);
			response = restTemplate.exchange(baseUrl, HttpMethod.POST, entity,
					new ParameterizedTypeReference<ClaimDocListResponseDto>() {
					}).getBody();
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.info("Exception CommonRestTemplateServiceImpl -" + e.getMessage());
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(commonRequestDto),
					"getClaimDocList", "getClaimDocList", "getClaimDocList", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(response), "", baseUrl, headers);
		}
		logger.info("Enter into CommonRestTemplateServiceImpl - getClaimDocList End");
		return response;
	}

	@Override
	public CommonResponseDto<String> getOutStandingReport(CommonRequestDto dto, HttpServletRequest request) {
		logger.info("RestTemplateServiceImpl-getOutStandingReport-start");
		CommonResponseDto<String> responseDto = new CommonResponseDto<>();
		String url = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			url = CommonUtils.fetchApi("GETOUTSTANDINGREPORT", getProperty());
//			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.set(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("API => " + url);
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(dto, headers);
			responseDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<String>>() {
					}, headers).getBody();
			if (responseDto != null && CommonConstants.SUCCESS.equalsIgnoreCase(responseDto.getStatus())) {
				responseDto.getResponseData();
			} else {
				logger.error("Rest Template Response => ", responseDto);
			}
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("CommonRestTemplateServiceImpl-getOutStandingReport-end", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.info("Exception-CommonRestTemplateServiceImpl-getOutStandingReport-", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(dto), "getOutStandingReport",
					"getOutStandingReport", "getOutStandingReport", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(responseDto), "", url, headers);
		}
		logger.info("CommonRestTemplateServiceImpl-getOutStandingReport-end");
		return responseDto;
	}

	@Override
	public CommonResponseDto<String> getDtlClmInfoReport(CommonRequestDto dto, HttpServletRequest request) {
		logger.info("RestTemplateServiceImpl-getDtlClmInfoReport-start");
		CommonResponseDto<String> responseDto = new CommonResponseDto<>();
		String url = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			url = CommonUtils.fetchApi("GETDTLCLMINFOREPORT", getProperty());
//			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.set(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("API => " + url);
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(dto, headers);
			responseDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<String>>() {
					}, headers).getBody();
			if (responseDto != null && CommonConstants.SUCCESS.equalsIgnoreCase(responseDto.getStatus())) {
				responseDto.getResponseData();
			} else {
				logger.error("Rest Template Response => ", responseDto);
			}
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("CommonRestTemplateServiceImpl-getDtlClmInfoReport-end", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.info("Exception-CommonRestTemplateServiceImpl-getDtlClmInfoReport-", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(dto), "getDtlClmInfoReport",
					"getOutStandingReport", "getOutStandingReport", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(responseDto), "", url, headers);
		}
		logger.info("CommonRestTemplateServiceImpl-getDtlClmInfoReport-end");
		return responseDto;
	}

	@Override
	public CommonResponseDto<String> getClmPaymentReport(CommonRequestDto dto, HttpServletRequest request) {
		logger.info("RestTemplateServiceImpl-getClmPaymentReport-start");
		CommonResponseDto<String> responseDto = new CommonResponseDto<>();
		String url = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			url = CommonUtils.fetchApi("GETCLMPAYMENTREPORT", getProperty());
//			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.set(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("API => " + url);
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(dto, headers);
			responseDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<String>>() {
					}, headers).getBody();
			if (responseDto != null && CommonConstants.SUCCESS.equalsIgnoreCase(responseDto.getStatus())) {
				responseDto.getResponseData();
			} else {
				logger.error("Rest Template Response => ", responseDto);
			}
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("CommonRestTemplateServiceImpl-getClmPaymentReport-end", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.info("Exception-CommonRestTemplateServiceImpl-getClmPaymentReport-", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(dto), "getClmPaymentReport",
					"getOutStandingReport", "getOutStandingReport", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(responseDto), "", url, headers);
		}
		logger.info("CommonRestTemplateServiceImpl-getClmPaymentReport-end");
		return responseDto;
	}

	@Override
	public CommonResponseDto<String> getClmSettlementReport(CommonRequestDto dto, HttpServletRequest request) {
		logger.info("RestTemplateServiceImpl-getClmSettlementReport-start");
		CommonResponseDto<String> responseDto = new CommonResponseDto<>();
		String url = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			url = CommonUtils.fetchApi("GETCLMSETTLEMENTREPORT", getProperty());
//			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.set(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("API => " + url);
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(dto, headers);
			responseDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<String>>() {
					}, headers).getBody();
			if (responseDto != null && CommonConstants.SUCCESS.equalsIgnoreCase(responseDto.getStatus())) {
				responseDto.getResponseData();
			} else {
				logger.error("Rest Template Response => ", responseDto);
			}
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("CommonRestTemplateServiceImpl-getClmSettlementReport-end", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.info("Exception-CommonRestTemplateServiceImpl-getClmSettlementReport-", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(dto), "getClmSettlementReport",
					"getOutStandingReport", "getOutStandingReport", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(responseDto), "", url, headers);
		}
		logger.info("CommonRestTemplateServiceImpl-getClmSettlementReport-end");
		return responseDto;
	}

	@Override
	public CommonResponseDto<List<APIRequestDto>> getRetryDetails() {
		CommonResponseDto<List<APIRequestDto>> responseDto = new CommonResponseDto<List<APIRequestDto>>();
		logger.info("CommonRestTemplateServiceImpl-getRetryDetails-end");
		try {
			String url = CommonUtils.fetchApi("FETCHRETRYDETAILS", getProperty());
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			logger.info("API => " + url);
			responseDto = restTemplate.exchange(url, HttpMethod.GET, null,
					new ParameterizedTypeReference<CommonResponseDto<List<APIRequestDto>>>() {
					}, headers).getBody();
		} catch (Exception e) {
			logger.info("Exception-CommonRestTemplateServiceImpl-getRetryDetails-", e);
		}
		logger.info("CommonRestTemplateServiceImpl-getRetryDetails-end");
		return responseDto;
	}

	@Override
	public CommonResponseDto<String> getClaimCount(CommonRequestDto requestDto) {
		CommonResponseDto<String> responseDto = new CommonResponseDto<String>();
		logger.info("CommonRestTemplateServiceImpl-getClaimCount-end");
		String url = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			url = CommonUtils.fetchApi("GETCLAIMCOUNT", getProperty());
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.set(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("API => " + url);
			requestDto.setAgentCode(requestDto.getImdCode());
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(requestDto, headers);
			responseDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<String>>() {
					}, headers).getBody();
			if (responseDto.getApplicationError() != null) {
				if (responseDto.getApplicationError().getErrorCode().equals(CommonConstants.ZERO_STRING)) {
					responseDto.setStatus(CommonConstants.SUCCESS);
				}
			} else {
				responseDto.setStatus(CommonConstants.ERROR);
			}
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("CommonRestTemplateServiceImpl-getClaimCount-end", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.info("Exception-CommonRestTemplateServiceImpl-getClaimCount-", e);
		}
		logger.info("CommonRestTemplateServiceImpl-getClaimCount-end");
		return responseDto;
	}

	@Override
	public CommonResponseDto<NotifyConfigDto> getNotifyConfig(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonResponseDto<NotifyConfigDto> commonResponseDto = new CommonResponseDto<>();
		logger.info("CommonRestTemplateServiceImpl-getNotifyConfig-start");
		try {
			String url = CommonUtils.fetchApi("GETNOTIFYCONFIG", getProperty());
			logger.info("GETNOTIFYCONFIG----", url);
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			String plain = "{\"action\":\"" + commonRequestDto.getAction() + "\"}";
			String encode = new String(java.util.Base64.getEncoder().encodeToString(plain.getBytes()));
			url = url + "?payload=" + encode;
			logger.info("url----", url);
			commonResponseDto = restTemplate.exchange(url, HttpMethod.GET, null,
					new ParameterizedTypeReference<CommonResponseDto<NotifyConfigDto>>() {
					}, headers).getBody();
		} catch (Exception e) {
			logger.error("Exception-CommonRestTemplateServiceImpl-getNotifyConfig", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "CommonRestTemplateServiceImpl", "getNotifyConfig", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("CommonRestTemplateServiceImpl-getNotifyConfig-end");
		return commonResponseDto;
	}

	@Override
	public CommonMasterDto sendEmailRequest(EmailDto dto, HttpServletRequest request) {
		CommonMasterDto commonDto = new CommonMasterDto();
		commonDto.setStatus(CommonConstants.ERROR);
		logger.info("CommonRestTemplateServiceImpl-sendEmailRequest-start");
		String baseUrl = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			baseUrl = CommonUtils.fetchApi("COMM_HUB_SEND_EMAIL", getProperty());
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("Authorization", keycloakUtils.getKeycloakToken());
			headers.add("corelationid", "C-" + DateUtils.uniqueNoMilli());
			headers.add("businesscorelationid", "B-" + DateUtils.uniqueNoMilli());
			HttpEntity<EmailDto> entity = new HttpEntity<EmailDto>(dto, headers);
			ResponseEntity<String> exchange = restTemplate.exchange(baseUrl, HttpMethod.POST, entity, String.class);
			if (exchange != null && exchange.getBody() != null) {
				logger.info("Response Body:\n" + exchange.getBody());
				JSONObject responseOb = new JSONObject(exchange.getBody());
				commonDto.setResult(responseOb != null ? responseOb.toString() : null);
				JSONObject errorStatus = new JSONObject(responseOb.get("applicationError").toString());
				String status = errorStatus.get("errorCode").toString();
				if (StringUtils.isNotBlank(status) && status.equalsIgnoreCase(CommonConstants.ZERO_STRING)) {
					String emailUniqueId = new String(responseOb.get("emailUniqueId").toString());
					commonDto.setStatus(CommonConstants.SUCCESS);
					commonDto.setCode(String.valueOf(emailUniqueId));
					commonDto.setEmailSentDate(DateUtils.sysDate());
				} else {
					commonDto.setMessage(
							errorStatus.get("errorDescription") != null ? errorStatus.get("errorDescription").toString()
									: null);
				}
			} else {
				logger.info("Error Response Body:\n" + exchange);
			}
		} catch (HttpClientErrorException e) {
			commonDto.setMessage(e.getMessage());
			logger.error("CommonRestTemplateServiceImpl-sendEmailRequest-end", e);
		} catch (Exception e) {
			logger.error("Exception-CommonRestTemplateServiceImpl-sendEmailRequest-", e);
			commonDto.setMessage(e.getMessage());
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(dto), "sendEmailRequest",
					"sendEmailRequest", "sendEmailRequest", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(commonDto), "", baseUrl, headers);
		}
		logger.info("CommonRestTemplateServiceImpl-sendEmailRequest-end");
		return commonDto;
	}

	@Override
	public CommonMasterDto sendSmsRequest(SmsDto smsDto, HttpServletRequest request) {
		CommonMasterDto commonDto = new CommonMasterDto();
		commonDto.setStatus(CommonConstants.ERROR);
		logger.info("Enter into CommonRestTemplateServiceImpl sendSmsRequest start");
		String baseUrl = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			baseUrl = CommonUtils.fetchApi("COMM_HUB_SEND_SMS", getProperty());
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("Authorization", keycloakUtils.getKeycloakToken());
			headers.add("corelationid", "C-" + DateUtils.uniqueNoMilli());
			headers.add("businesscorelationid", "B-" + DateUtils.uniqueNoMilli());
			HttpEntity<SmsDto> entity = new HttpEntity<SmsDto>(smsDto, headers);
			ResponseEntity<String> exchange = restTemplate.exchange(baseUrl, HttpMethod.POST, entity, String.class);
			if (exchange != null && exchange.getBody() != null) {
				logger.info("Response Body:\n" + exchange.getBody());
				JSONObject responseOb = new JSONObject(exchange.getBody());
				commonDto.setResult(responseOb != null ? responseOb.toString() : null);
				JSONObject errorStatus = new JSONObject(responseOb.get("applicationError").toString());
				String status = errorStatus.get("errorCode").toString();
				if (StringUtils.isNotBlank(status) && status.equalsIgnoreCase(CommonConstants.ZERO_STRING)) {
					String emailUniqueId = new String(responseOb.get("emailUniqueId").toString());
					commonDto.setStatus(CommonConstants.SUCCESS);
					commonDto.setCode(String.valueOf(emailUniqueId));
					commonDto.setEmailSentDate(DateUtils.sysDate());
				} else {
					commonDto.setMessage(
							errorStatus.get("errorDescription") != null ? errorStatus.get("errorDescription").toString()
									: null);
				}
			} else {
				logger.info("Error Response Body:\n" + exchange);
			}
		} catch (HttpClientErrorException e) {
			commonDto.setMessage(e.getMessage());
			logger.error("CommonRestTemplateServiceImpl-sendSmsRequest- Exception", e);
		} catch (Exception e) {
			logger.info("Exception-CommonRestTemplateServiceImpl-sendSmsRequest-", e);
			commonDto.setMessage(e.getMessage());
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(smsDto),
					"CommonRestTemplateServiceImpl - sendSmsRequest", "sendSmsRequest", "sendSmsRequest", message,
					errorMessage, "", "", NumericUtils.convertPojoClassToString(commonDto), "", baseUrl, headers);
		}
		logger.info("Enter into CommonRestTemplateServiceImpl sendSmsRequest end");
		return commonDto;
	}

	@Override
	public CommonResponseDto<String> saveinvoicedtls(CommonDetailsDto commonDetailsDto, HttpServletRequest request) {
		logger.info("CommonRestTemplateServiceImpl-saveinvoicedtls-start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			String url = CommonUtils.fetchApi("SAVEINVDTLS", getProperty());
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.set(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("API => " + url);
			HttpEntity<CommonDetailsDto> entity = new HttpEntity<CommonDetailsDto>(commonDetailsDto, headers);
			commonResponseDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<String>>() {
					}, headers).getBody();
		} catch (Exception e) {
			logger.error("Enter into CommonRestTemplateServiceImpl-saveinvoicedtls Exception", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "CommonRestTemplateServiceImpl", "saveinvoicedtls", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("CommonRestTemplateServiceImpl-saveinvoicedtls-end");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<String> saveNeftDtls(CommonDetailsDto commonDetailsDto, HttpServletRequest request) {
		logger.info("CommonRestTemplateServiceImpl-saveNeftDtls-start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			String url = CommonUtils.fetchApi("SAVENEFTDTLS", getProperty());
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.set(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("API => " + url);
			HttpEntity<CommonDetailsDto> entity = new HttpEntity<CommonDetailsDto>(commonDetailsDto, headers);
			commonResponseDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<String>>() {
					}, headers).getBody();
		} catch (Exception e) {
			logger.error("Enter into CommonRestTemplateServiceImpl-saveNeftDtls Exception", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "CommonRestTemplateServiceImpl", "saveNeftDtls", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("CommonRestTemplateServiceImpl-saveNeftDtls-end");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<String> updateClaimantPanDetail(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("CommonRestTemplateServiceImpl-updateClaimantPanDetail-start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			String url = CommonUtils.fetchApi("UPDATECLAIMANTPANDTLS", getProperty());
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.set(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("updateClaimantPanDetail --> " + NumericUtils.convertPojoClassToJSONString(commonRequestDto));
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(commonRequestDto, headers);
			commonResponseDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<String>>() {
					}, headers).getBody();
		} catch (HttpClientErrorException e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setStatusCode(CommonConstants.ONE_STRING);
			logger.error("Exception-CommonRestTemplateServiceImpl-updateClaimantPanDetail-HttpClientErrorException", e);
		} catch (HttpServerErrorException e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setStatusCode(CommonConstants.ONE_STRING);
			logger.error("Exception-CommonRestTemplateServiceImpl-updateClaimantPanDetail-HttpServerErrorException", e);
		} catch (Exception e) {
			logger.error("Enter into CommonRestTemplateServiceImpl-updateClaimantPanDetail Exception", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "CommonRestTemplateServiceImpl", "updateClaimantPanDetail", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("CommonRestTemplateServiceImpl-updateClaimantPanDetail-end");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<String> getOutstandingClmReport(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("CommonRestTemplateServiceImpl-getOutstandingClmReport-start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			String url = CommonUtils.fetchApi("GETOUTSTANDINGCLMREP", getProperty());
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.set(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("GETOUTSTANDINGCLMREP API => " + url);
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(commonRequestDto, headers);
			commonResponseDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<String>>() {
					}, headers).getBody();
		} catch (Exception e) {
			logger.error("Enter into CommonRestTemplateServiceImpl-getOutstandingClmReport Exception", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "CommonRestTemplateServiceImpl", "getOutstandingClmReport", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("CommonRestTemplateServiceImpl-getOutstandingClmReport-end");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<String> getSurveyorPaymentClaimsReport(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("CommonRestTemplateServiceImpl-getSurveyorPaymentClaimsReport-start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			String url = CommonUtils.fetchApi("SURVEYORPAIDREPORT", getProperty());
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.set(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("SURVEYORPAIDREPORT API => " + url);
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(commonRequestDto, headers);
			commonResponseDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<String>>() {
					}, headers).getBody();
		} catch (Exception e) {
			logger.error("Enter into CommonRestTemplateServiceImpl-getSurveyorPaymentClaimsReport Exception", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "CommonRestTemplateServiceImpl", "getSurveyorPaymentClaimsReport",
					"", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("CommonRestTemplateServiceImpl-getSurveyorPaymentClaimsReport-end");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<String> getClmServingReport(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("CommonRestTemplateServiceImpl-getClmServingReport-start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			String url = CommonUtils.fetchApi("GETCLMSERVICEREPORT", getProperty());
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.set(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("SURVEYORPAIDREPORT API => " + url);
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(commonRequestDto, headers);
			commonResponseDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<String>>() {
					}, headers).getBody();
		} catch (Exception e) {
			logger.error("Enter into CommonRestTemplateServiceImpl-getClmServingReport Exception", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "CommonRestTemplateServiceImpl", "getClmServingReport", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("CommonRestTemplateServiceImpl-getClmServingReport-end");
		return commonResponseDto;
	}

	@Override
	public UserDto getSurveyorprofileDtls(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("CommonRestTemplateServiceImpl-getSurveyorprofileDtls-start");
		UserDto userDto = new UserDto();
		try {
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			String url = CommonUtils.fetchApi("GETSURPROFILE", getProperty());
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.set(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("GETSURPROFILE API => " + url);
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(commonRequestDto, headers);
			userDto = restTemplate.exchange(url, HttpMethod.POST, entity, new ParameterizedTypeReference<UserDto>() {
			}, headers).getBody();
		} catch (Exception e) {
			logger.error("Enter into CommonRestTemplateServiceImpl-getSurveyorprofileDtls Exception", e);
			CommonRequestUtil.errorInfo(request, "", "CommonRestTemplateServiceImpl", "getSurveyorprofileDtls", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("CommonRestTemplateServiceImpl-getSurveyorprofileDtls-end");
		return userDto;
	}

	@Override
	public CommonResponseDto<String> getUpdateClaimList(CommonRequestDto dto, HttpServletRequest request) {
		CommonResponseDto<String> response = new CommonResponseDto<>();
		try {
			String url = CommonUtils.fetchApi("GETUPDATECLAIMLIST", getProperty());
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("GETUPDATECLAIMLIST API => " + url);
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(dto, headers);
			response = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<String>>() {
					}, headers).getBody();
		} catch (Exception e) {
			logger.error("Enter into CommonRestTemplateServiceImpl-getUpdateClaimList Exception", e);
			CommonRequestUtil.errorInfo(request, "", "CommonRestTemplateServiceImpl", "getUpdateClaimList", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		return response;
	}

	@Override
	public MaximusClmIntimationRespDto saveMaximusClaimIntimation(MaximusClaimSaveDto commonRequestDto,
			HttpServletRequest request) {
		MaximusClmIntimationRespDto resDto = new MaximusClmIntimationRespDto();
		logger.info("CommonRestTemplateServiceImpl-saveMaximusClaimIntimation-Start");
		// String baseUrl = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();

		try {
			MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getMaximusToken();
			// baseUrl =
			// "https://microsrv.bagicsit2.bajajallianz.com/claim/claimIntimation";
			String baseUrl = CommonUtils.fetchApi("MAXIMUSCLAIMINTIMATION", getProperty());

			logger.info("maximus token response -> " + NumericUtils.convertPojoClassToJSONString(maximusResponseToken));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (maximusResponseToken != null) {
				logger.info("CommonRestTemplateServiceImpl-getMax-1");

				if (maximusResponseToken.getAccess_token() != null) {
					logger.info("CommonRestTemplateServiceImpl-getMax-2");
					headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
				}
			} else {
				logger.error("maximusResponseToken null");
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			HttpEntity<MaximusClaimSaveDto> entity = new HttpEntity<MaximusClaimSaveDto>(commonRequestDto, headers);
			logger.info("saveMaximusClaimIntimation  req -> "
					+ NumericUtils.convertPojoClassToJSONString(commonRequestDto));

			resDto = restTemplate.exchange(baseUrl, HttpMethod.POST, entity,
					new ParameterizedTypeReference<MaximusClmIntimationRespDto>() {
					}, headers).getBody();

			logger.info("saveMaximusClaimIntimation json Response---------------->"
					+ NumericUtils.convertPojoClassToJSONString(resDto));
		} catch (Exception e) {
			logger.error("CommonRestTemplateServiceImpl saveMaximusClaimIntimation Exception", e);
		}
		return resDto;
	}

	@Override
	public PolicyResponseDto getMaximusPolicyDetails(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		PolicyResponseDto policyResponseDto = new PolicyResponseDto();
		MaximusPolicyResDto policyResDto = new MaximusPolicyResDto();
		logger.info("CommonRestTemplateServiceImpl-getPolicyDetails-Start");
		String baseUrl = null;
		String code = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		MaximusPolicyReqDto reqDto = new MaximusPolicyReqDto();
		try {
//			MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getMaximusToken();
//			logger.info("maximus token response -> " + NumericUtils.convertPojoClassToJSONString(maximusResponseToken));
//			baseUrl=CommonUtils.fetchApi("GETMAXPOLICYDETAILS", getProperty());
			headers.setContentType(MediaType.APPLICATION_JSON);
//			if (maximusResponseToken != null) {
//				logger.info("CommonRestTemplateServiceImpl-getMax-1");
//				if (maximusResponseToken.getAccess_token() != null) {
//					logger.info("CommonRestTemplateServiceImpl-getMax-2");
//					headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
//				}
//			} else {
//				logger.error("maximusResponseToken null");
//			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			reqDto.setPolicyNumber(commonRequestDto.getPolicyNumber());
			// UAT - Comment for PROD Start
//			List<String> arrayList = Arrays.asList("6621", "5002", "5003", "5004", "5007", "5008", "5009", "6623",
//					"4070", "6622");
			List<String> arrayList = notifyRepository.findByActiveProductCode();
			// List<String> arrayList = Arrays.asList("5002", "5003", "5004", "5007",
			// "5008", "5009", "6623","6622"); // 16 Jan 25 - Cattle RCS prod deployment
			String[] splitted = commonRequestDto.getPolicyNumber().split("-");
			if (splitted != null && splitted.length > 1 && arrayList.contains(splitted[1])) {
				MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getMaximusToken();
				if (maximusResponseToken != null && maximusResponseToken.getAccess_token() != null) {
					headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
				}
				baseUrl = CommonUtils.fetchApi("VALUES14", getProperty());
				code = "VALUES14";
			} else {
				MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getSITMaximusToken();
				if (maximusResponseToken != null && maximusResponseToken.getAccess_token() != null) {
					headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
				}
				baseUrl = CommonUtils.fetchApi("GETMAXPOLICYDETAILS", getProperty());
				code = "GETMAXPOLICYDETAILS";
			}
			// UAT - Comment for PROD End
			HttpEntity<MaximusPolicyReqDto> entity = new HttpEntity<>(reqDto, headers);
			logger.info("maximus  req -> " + NumericUtils.convertPojoClassToJSONString(reqDto));
			policyResDto = restTemplate
					.exchange(baseUrl, HttpMethod.POST, entity, new ParameterizedTypeReference<MaximusPolicyResDto>() {
					}, headers).getBody();

			logger.info(
					"Maximus json Response---------------->" + NumericUtils.convertPojoClassToJSONString(policyResDto));
			ArrayList<MaximusCommonSearchDto> maxPolicyList = policyResDto.getCommonSearchDetails();
			List<PolicyDetailsDto> policyList = new ArrayList<>();
			for (MaximusCommonSearchDto dto : maxPolicyList) {
				PolicyDetailsDto policyDetailsDto = new PolicyDetailsDto();
				BeanUtils.copyProperties(dto, policyDetailsDto);
				policyDetailsDto.setPolicyNumber(dto.getPolicyNumber());
				policyDetailsDto.setInsuredName(dto.getProposerName());
				policyDetailsDto.setInspectionDate(dto.getStartDate());
				policyDetailsDto.setExpiryDate(dto.getEndDate());
				policyDetailsDto.setProductCode(dto.getProductCode());
				policyDetailsDto.setProductDescription(dto.getProduct());
				policyDetailsDto.setSumInsured(CommonConstants.NA);
				policyDetailsDto.setPolicyStatus(dto.getSubStatus());
				MaximusSinglePolicySearchDto response = this.getSavedQuote(commonRequestDto.getPolicyNumber(), request);
				if (response != null && response.getApplicationError() != null
						&& CommonConstants.ZERO_STRING.equals(response.getApplicationError().getErrorCode())) {
					if (response.getAdditionalPolicyDetails() != null)
						policyDetailsDto.setImdChannel(response.getAdditionalPolicyDetails().getImdCode());
					if (response.getBasicDetails() != null)
						policyDetailsDto.setPolicyStatus(response.getBasicDetails().getStatus());
				} else if (response != null && response.getApplicationError() != null)
					logger.error("Maximus single policy search error",
							NumericUtils.convertPojoClassToString(response.getApplicationError()));
				else
					logger.error("Maximus single policy search error Null response");
				policyList.add(policyDetailsDto);
			}
			policyResponseDto.setTotal(NumericUtils.convertIntegerToString(policyList.size()));
			policyResponseDto.setPolicyDetailsList(policyList);
			logger.info("maximus  res -> " + NumericUtils.convertPojoClassToJSONString(policyResponseDto));
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-CommonRestTemplateServiceImpl-getMaximusPolicyDetails-HttpClientErrorException", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-CommonRestTemplateServiceImpl-getMaximusPolicyDetails-HttpServerErrorException", e);
		} catch (ResourceAccessException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-CommonRestTemplateServiceImpl-getMaximusPolicyDetails-ResourceAccessException", e);
		} catch (JSONException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-CommonRestTemplateServiceImpl-getMaximusPolicyDetails-JSONException", e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-CommonRestTemplateServiceImpl-getMaximusPolicyDetails-Exception", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(reqDto), code,
					"getMaximusPolicyDetails", "getMaximusPolicyDetails", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(policyResDto), "", baseUrl, headers);
		}
		logger.info("CommonRestTemplateServiceImpl-getMaxPolicyDetails-end");
		return policyResponseDto;
	}

	@Override
	public MaximusSinglePolicySearchDto getSavedQuote(String policyNo, HttpServletRequest request) {
		logger.info("CommonRestTemplateServiceImpl getSavedQuote Start...");
		String baseUrl = null;
		String code = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		MaximusSinglePolicySearchDto responseDto = new MaximusSinglePolicySearchDto();
		try {
//			baseUrl = CommonUtils.fetchApi("GETSAVEDQUOTE", getProperty());
//			MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getMaximusToken();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
//			if (maximusResponseToken != null) {
//				logger.info("CommonRestTemplateServiceImpl-getMax-1");
//				if (maximusResponseToken.getAccess_token() != null) {
//					logger.info("CommonRestTemplateServiceImpl-getMax-2");
//					headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
//				}
//			} else {
//				logger.error("maximusResponseToken null");
//			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			// UAT - Comment for PROD Start
//			List<String> arrayList = Arrays.asList("6621", "5002", "5003", "5004", "5007", "5008", "5009", "6623",
//					"4070", "6622");
			List<String> arrayList = notifyRepository.findByActiveProductCode();
			// List<String> arrayList = Arrays.asList("6621", "5002", "5003", "5004",
			// "5007", "5008", "5009", "6623",
			// "6622"); // 16 Jan 25 - Cattle RCS prod deployment
			String[] splitted = policyNo.split("-");
			if (splitted != null && splitted.length > 1 && arrayList.contains(splitted[1])) {
				MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getMaximusToken();
				if (maximusResponseToken != null && maximusResponseToken.getAccess_token() != null) {
					headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
				}
				baseUrl = CommonUtils.fetchApi("VALUES6", getProperty());
				code = "VALUES6";
			} else {
				MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getSITMaximusToken();
				if (maximusResponseToken != null && maximusResponseToken.getAccess_token() != null) {
					headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
				}
				baseUrl = CommonUtils.fetchApi("GETSAVEDQUOTE", getProperty());
				code = "GETSAVEDQUOTE";
			}
			// UAT - Comment for PROD End
			HttpEntity<String> entity = new HttpEntity<>(headers);
			logger.info("maximus  req  url -> " + baseUrl);
			ResponseEntity<MaximusSinglePolicySearchDto> responseEntity = restTemplate.exchange(baseUrl, HttpMethod.GET,
					entity, MaximusSinglePolicySearchDto.class, policyNo);
			responseDto = responseEntity.getBody();
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-CommonRestTemplateServiceImpl-getSavedQuote-HttpClientErrorException", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-CommonRestTemplateServiceImpl-getSavedQuote-HttpServerErrorException", e);
		} catch (ResourceAccessException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-CommonRestTemplateServiceImpl-getSavedQuote-ResourceAccessException", e);
		} catch (JSONException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-CommonRestTemplateServiceImpl-getSavedQuote-JSONException", e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-CommonRestTemplateServiceImpl-getSavedQuote-Exception", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, policyNo, code, "getSavedQuote", "getSavedQuote", message,
					errorMessage, "", "", NumericUtils.convertPojoClassToString(responseDto), "", baseUrl, headers);
		}
		logger.info("CommonRestTemplateServiceImpl getSavedQuote End...");
		return responseDto;
	}

	@Override
	public MaximusClmIntimationRespDto claimIntimation(MaximusClaimSaveDto maximusClaimSaveDto,
			HttpServletRequest request) {
		MaximusClmIntimationRespDto resDto = new MaximusClmIntimationRespDto();
		logger.info("Enter into CommonRestTemplateServiceImpl claimIntimation Start");
		String baseUrl = null;
		String code = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
//			MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getMaximusToken();
//			baseUrl = CommonUtils.fetchApi("MAXIMUSCLAIMINTIMATION", getProperty());
			headers.setContentType(MediaType.APPLICATION_JSON);
//			if (maximusResponseToken != null && maximusResponseToken.getAccess_token() != null) {
//				headers.add(CommonConstants.AUTHORIZATION, maximusResponseToken.getAccess_token());
//			}
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			// UAT - Comment for PROD Start
//			List<String> arrayList = Arrays.asList("6621", "5002", "5003", "5004", "5007", "5008", "5009", "6623",
//					"4070", "6622");
			List<String> arrayList = notifyRepository.findByActiveProductCode();
			// List<String> arrayList = Arrays.asList("5002", "5003", "5004", "5007",
			// "5008", "5009", "6623", "6622"); // 16
			// Jan
			// 25
			// -
			// Cattle
			// RCS
			// prod
			// deployment
			String[] splitted = maximusClaimSaveDto.getStrPolicyQuoteNumber().split("-");
			if (splitted != null && splitted.length > 1 && arrayList.contains(splitted[1])) {
				MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getMaximusToken();
				if (maximusResponseToken != null && maximusResponseToken.getAccess_token() != null) {
					headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
				}
				baseUrl = CommonUtils.fetchApi("VALUES5", getProperty());
				code = "VALUES5";
			} else {
				MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getSITMaximusToken();
				if (maximusResponseToken != null && maximusResponseToken.getAccess_token() != null) {
					headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
				}
				baseUrl = CommonUtils.fetchApi("MAXIMUSCLAIMINTIMATION", getProperty());
				code = "MAXIMUSCLAIMINTIMATION";
			}
			// UAT - Comment for PROD End
			HttpEntity<MaximusClaimSaveDto> entity = new HttpEntity<>(maximusClaimSaveDto, headers);
			resDto = restTemplate.exchange(baseUrl, HttpMethod.POST, entity,
					new ParameterizedTypeReference<MaximusClmIntimationRespDto>() {
					}, headers).getBody();
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-claimIntimation-HttpClientErrorException", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-claimIntimation-HttpServerErrorException", e);
		} catch (ResourceAccessException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-claimIntimation-ResourceAccessException", e);
		} catch (JSONException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-claimIntimation-JSONException", e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-claimIntimation-Exception", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(maximusClaimSaveDto), code,
					"claimIntimation", "claimIntimation", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(resDto), "", baseUrl, headers);
		}
		logger.info("Enter into ClaimRestServiceImpl claimIntimation End");
		return resDto;
	}

	@Override
	public String getStateCityAreaByPincode(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("Enter into ClaimRestServiceImpl getStateCityAreaByPincode Start...");
		String message = null;
		String errorMessage = null;
		String baseUrl = null;
		HttpHeaders headers = new HttpHeaders();
		String responceString = null;
		try {
			baseUrl = CommonUtils.fetchApi("GETSTATECITYBYPINCODE", getProperty());
			logger.info("GETSTATECITYBYPINCODE: ", baseUrl);
			MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getMaximusToken();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (maximusResponseToken != null && maximusResponseToken.getAccess_token() != null) {
				headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			HttpEntity<String> entity = new HttpEntity<>(headers);
			ResponseEntity<String> responseEntity = restTemplate.exchange(baseUrl, HttpMethod.GET, entity, String.class,
					commonRequestDto.getPincode());
			responceString = responseEntity.getBody();
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-getStateCityAreaByPincode-HttpClientErrorException", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-getStateCityAreaByPincode-HttpServerErrorException", e);
		} catch (ResourceAccessException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-getStateCityAreaByPincode-ResourceAccessException", e);
		} catch (JSONException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-getStateCityAreaByPincode-JSONException", e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-getSavedQuote-Exception-end", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, commonRequestDto.getIfscCode(), "getStateCityAreaByPincode",
					"getStateCityAreaByPincode", "getStateCityAreaByPincode", message, errorMessage, "", "",
					responceString, "", baseUrl, headers);
		}
		logger.info("Enter into ClaimRestServiceImpl getStateCityAreaByPincode End...");
		return responceString;
	}

}
