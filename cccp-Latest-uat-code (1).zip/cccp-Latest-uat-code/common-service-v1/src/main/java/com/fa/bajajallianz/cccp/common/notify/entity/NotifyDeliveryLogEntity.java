/**
 * 
 */
package com.fa.bajajallianz.cccp.common.notify.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

/**
 * @author santhosh
 *
 */
@Entity
@Table(name = "notify_delivery_log")
public class NotifyDeliveryLogEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	@Column(name = "id", length = 20, nullable = false)
	private Long id;

	@Column(name = "content", length = 50)
	private String content;

	@Column(name = "delivery_type", length = 50)
	private String deliveryType;

	@Column(name = "error_msg", length = 100)
	private String errorMsg;

	@Column(name = "is_sent")
	private Boolean isSent;

	@Column(name = "is_success")
	private Boolean isSuccess;

	@Column(name = "recipient", length = 300)
	private String recipient;

	@Column(name = "subject", length = 100)
	private String subject;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_date")
	private Date modifiedDate;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, targetEntity = NotificationLogEntity.class)
	@JoinColumn(name = "notify_log_id")
	private NotificationLogEntity notifyLogEntity;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public Boolean getIsSent() {
		return isSent;
	}

	public void setIsSent(Boolean isSent) {
		this.isSent = isSent;
	}

	public Boolean getIsSuccess() {
		return isSuccess;
	}

	public void setIsSuccess(Boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getRecipient() {
		return recipient;
	}

	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public NotificationLogEntity getNotifyLogEntity() {
		return notifyLogEntity;
	}

	public void setNotifyLogEntity(NotificationLogEntity notifyLogEntity) {
		this.notifyLogEntity = notifyLogEntity;
	}

}