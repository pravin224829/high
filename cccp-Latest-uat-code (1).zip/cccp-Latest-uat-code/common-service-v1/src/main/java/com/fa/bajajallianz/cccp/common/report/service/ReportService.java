package com.fa.bajajallianz.cccp.common.report.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.common.dto.ClaimAnalysisDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimSummaryCountDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.dto.ReportResponseDto;
import com.fa.bajajallianz.cccp.common.dto.UserCountDto;

public interface ReportService {

	CommonResponseDto<ClaimSummaryCountDto> fetchClaimSummaryCount(CommonRequestDto requestDto,
			HttpServletRequest request);

	CommonResponseDto<UserCountDto> fetchUserCount(CommonRequestDto requestDto, HttpServletRequest request);

	CommonResponseDto<List<ClaimAnalysisDto>> fetchClaimAnalysisCount(CommonRequestDto requestDto,
			HttpServletRequest request);

	CommonResponseDto<ClaimAnalysisDto> refreshClaimCount(HttpServletRequest request);

	CommonResponseDto<UserCountDto> refreshUserCount(HttpServletRequest request);

	DataTableDto<List<ReportResponseDto>> getOutstandingReport(CommonRequestDto commonRequestDto, String main_filter,
			String sort, String page, String per_page, HttpServletRequest request);

	CommonResponseDto<String> retryfailure(HttpServletRequest request);

	CommonResponseDto<List<ReportResponseDto>> getMISReport(CommonRequestDto commonRequestDto, HttpServletRequest request);

}
