package com.fa.bajajallianz.cccp.common.claim.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.common.claim.service.ClaimService;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsListDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDocListResponseDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.dto.PolicyDetailsDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.mis.common.dto.CommonMisResponseDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClaimSaveDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClmIntimationRespDto;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/common/claim/api/" })
public class ClaimController {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	ClaimService claimService;
	
	@GetMapping(value = { "healthCheck" })
	public String healthCheck() {
		logger.info("CommonController-healthCheck-started 26-09-2022");
		return CommonConstants.COMMONHEALTHCHECK;
	}
		
	@GetMapping("/getClaimDocList")
	public ResponseEntity<?> getClaimDocList(@RequestParam String payload, HttpServletRequest request) {
		logger.info("Enter into ClaimController -getClaimDocList - Start");
		ClaimDocListResponseDto commonResponseDto = new ClaimDocListResponseDto();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = claimService.getClaimDocList(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("Enter into ClaimController -getClaimDocList - End");
		return new ResponseEntity<ClaimDocListResponseDto>(commonResponseDto, HttpStatus.OK);
	}
	
	@PostMapping("getClaimList")
	public ResponseEntity<?> getClaimList(@RequestBody CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("ClaimController-getClaimList-start");
		CommonResponseDto<List<ClaimDetailsListDto>> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = claimService.getClaimList(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("ClaimController - getClaimList" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<List<ClaimDetailsListDto>>>(commonResponseDto, HttpStatus.OK);
	}
	
	@GetMapping("/getClaimDetails")
	public ResponseEntity<?> getClaimDetails(@RequestParam String claimNumber, HttpServletRequest request) {
		logger.info("ClaimController-getClaimDetails-start");
		ClaimDetailsDto claimDetailsDto = new ClaimDetailsDto();
		try {
			claimDetailsDto = claimService.getClaimDetails(claimNumber, request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("ClaimController - getClaimDetails");
		return new ResponseEntity<ClaimDetailsDto>(claimDetailsDto, HttpStatus.OK);
	}
	
	@PostMapping("getMisClaimDetails")
	public ResponseEntity<?> getMisClaimDetails(@RequestBody CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("ClaimController-getMisClaimDetails-start");
		CommonMisResponseDto<String> claimDetailsDto = new CommonMisResponseDto<>();
		try {
			claimDetailsDto = claimService.getMisClaimDetails(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("ClaimController - getMisClaimDetails End...");
		return new ResponseEntity<CommonMisResponseDto<String>>(claimDetailsDto, HttpStatus.OK);
	}
	
	@GetMapping("/searchPolicyList")
	public ResponseEntity<?> fetchPolicyDetails(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("ClaimController-fetchPolicyDetails-start");
		DataTableDto<List<PolicyDetailsDto>> dataTableDto = new DataTableDto<List<PolicyDetailsDto>>();
		try {
			dataTableDto = claimService.getPolicyDetails(payload, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			logger.error("Enter into ClaimController searchPolicyList Exception",e);
			e.printStackTrace();
			dataTableDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("ClaimController-fetchPolicyDetails-End");
		return new ResponseEntity<DataTableDto<List<PolicyDetailsDto>>>(dataTableDto, HttpStatus.OK);
	}
	
	@PostMapping("claimIntimation")
	public ResponseEntity<?> claimIntimation(@RequestBody MaximusClaimSaveDto maximusClaimSaveDto,
			HttpServletRequest request) {
		logger.info("Enter into ClaimController claimIntimation start...");
		MaximusClmIntimationRespDto commonResponseDto = new MaximusClmIntimationRespDto();
		try {
			commonResponseDto = claimService.claimIntimation(maximusClaimSaveDto, request);
		} catch (Exception e) {
			logger.error("Enter into ClaimController claimIntimation Exception", e);
			e.printStackTrace();
			commonResponseDto.getApplicationError().setErrorCode(CommonConstants.ZERO_STRING);
		}
		logger.info("Enter into ClaimController claimIntimation end...");
		return new ResponseEntity<MaximusClmIntimationRespDto>(commonResponseDto, HttpStatus.OK);
	}
	@PostMapping("getStateCityAreaByPincode")
	public ResponseEntity<?> getStateCityAreaByPincode(@RequestBody CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("Enter into ClaimController getStateCityAreaByPincode Start...");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = claimService.getStateCityAreaByPincode(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Enter into ClaimController getStateCityAreaByPincode Exception", e);
		}
		logger.info("Enter into ClaimController getStateCityAreaByPincode End...");
		return new ResponseEntity<CommonResponseDto<String>>(commonResponseDto, HttpStatus.OK);
	}
	
}
