package com.fa.bajajallianz.cccp.config.utils;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fa.bajajallianz.cccp.mis.common.dto.MaximusTokenDto;
import com.fa.bajajallianz.cccp.common.dto.TokenRequestDto;
import com.fa.bajajallianz.cccp.common.dto.TokenResponseDto;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;

@Service
public class PreAuthTokenUtils {
	
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private Environment env;
	
	public TokenResponseDto getPreAuthToken() {
		TokenResponseDto responseDto = new TokenResponseDto();
		RestTemplate restTemplate = new RestTemplate();
		logger.info("common - PreAuthTokenUtils-getPreAuthToken-start");
		try {
			String baseUrl = CommonUtils.fetchApi("GETPREAUTHTOKEN", env.getProperty("CONFIG_API_URL"));
			TokenRequestDto requestDto = new TokenRequestDto();
			String userName = CommonUtils.fetchApi("PREAUTHTOKEN_USERNAME", env.getProperty("CONFIG_API_URL"));
			String password = CommonUtils.fetchApi("PREAUTHTOKEN_PASSWORD", env.getProperty("CONFIG_API_URL"));
			requestDto.setUserName(userName);
			requestDto.setPassword(password);
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<TokenRequestDto> entity = new HttpEntity<TokenRequestDto>(requestDto, headers);
			responseDto = restTemplate
					.exchange(baseUrl, HttpMethod.POST, entity, new ParameterizedTypeReference<TokenResponseDto>() {
					}, headers).getBody();

		} catch (Exception e) {
			logger.error("Exception-common-PreAuthTokenUtils-getPreAuthToken-", e);
		}
		logger.info("common -PreAuthTokenUtils-getPreAuthToken-end");
		return responseDto;
	}
	
	public MaximusTokenDto getMaximusToken() {
		MaximusTokenDto responseDto = new MaximusTokenDto();
		logger.info("Enter into ClaimServiceImpl getMaximusToken Start");
		try {
			String url = CommonUtils.fetchApi("GETMAXIMUSTOKEN", env.getProperty("CONFIG_API_URL"));
			HttpHeaders headers = new HttpHeaders();
			headers.set("Content-Type", "application/x-www-form-urlencoded");
			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
			map.add("client_id", CommonUtils.fetchApi("CLIENTID", env.getProperty("CONFIG_API_URL")));
			map.add("grant_type", CommonUtils.fetchApi("GRANTTYPE", env.getProperty("CONFIG_API_URL")));
			map.add("client_secret", CommonUtils.fetchApi("CLIENTSECRET", env.getProperty("CONFIG_API_URL")));
			HttpEntity<MultiValueMap<String, String>> request1 = new HttpEntity<>(map, headers);
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<MaximusTokenDto> response = restTemplate.exchange(url, HttpMethod.POST, request1,
					MaximusTokenDto.class);
			responseDto = response.getBody();
			logger.info("Enter into ClaimServiceImpl getMaximusToken response--- " + responseDto.getAccess_token());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Enter into ClaimServiceImpl getMaximusToken Exception", e);
		}
		logger.info("Enter into ClaimServiceImpl getMaximusToken End..");
		return responseDto;
	}
	public MaximusTokenDto getSITMaximusToken() {
		MaximusTokenDto responseDto = new MaximusTokenDto();
		logger.info("Enter into PreAuthTokenUtils getSITMaximusToken Start");
		try {
			String url = CommonUtils.fetchApi("GETSITMAXIMUSTOKEN", env.getProperty("CONFIG_API_URL"));
			HttpHeaders headers = new HttpHeaders();
			headers.set("Content-Type", "application/x-www-form-urlencoded");
			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
			map.add("client_id", CommonUtils.fetchApi("SITCLIENTID", env.getProperty("CONFIG_API_URL")));
			map.add("grant_type", "client_credentials");
			map.add("client_secret", CommonUtils.fetchApi("SITCLIENTSECRET", env.getProperty("CONFIG_API_URL")));
			HttpEntity<MultiValueMap<String, String>> request1 = new HttpEntity<>(map, headers);
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<MaximusTokenDto> response = restTemplate.exchange(url, HttpMethod.POST, request1,
					MaximusTokenDto.class);
			responseDto = response.getBody();
			logger.info("Enter into PreAuthTokenUtils getSITMaximusToken response--- " + responseDto.getAccess_token());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Enter into PreAuthTokenUtils getSITMaximusToken Exception", e);
		}
		logger.info("Enter into PreAuthTokenUtils getSITMaximusToken End..");
		return responseDto;
	}
	

}
