package com.fa.bajajallianz.cccp.common.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/common/api/" })
public class CommonController {
	protected final Logger logger = LoggerFactory.getLogger(getClass());

}