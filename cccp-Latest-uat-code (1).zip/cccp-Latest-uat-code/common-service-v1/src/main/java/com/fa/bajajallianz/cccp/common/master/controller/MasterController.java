package com.fa.bajajallianz.cccp.common.master.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.common.dto.AreaResponseDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.UserDto;
import com.fa.bajajallianz.cccp.common.master.service.MasterService;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;



@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/common/master/api/" })
public class MasterController {
	
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	MasterService masterService;
	
	@GetMapping("/fetchLocationByPincode")
	public ResponseEntity<?> fetchLocationByPincode(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-getLocationByPincode-start");
		CommonResponseDto<AreaResponseDto> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchLocationByPincode(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("getLocationByPincode" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}
	
	@PostMapping("getSurveyorprofileDtls")
	public ResponseEntity<?> getSurveyorprofileDtls(@RequestBody CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("MasterController-getSurveyorprofileDtls-start");
		UserDto userDto = new UserDto();
		try {
			userDto = masterService.getSurveyorprofileDtls(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<UserDto>(userDto, HttpStatus.OK);
	}
	


}
