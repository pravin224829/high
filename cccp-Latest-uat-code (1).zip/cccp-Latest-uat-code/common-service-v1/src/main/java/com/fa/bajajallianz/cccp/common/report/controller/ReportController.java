package com.fa.bajajallianz.cccp.common.report.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.common.dto.ClaimAnalysisDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimSummaryCountDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.dto.ReportResponseDto;
import com.fa.bajajallianz.cccp.common.dto.UserCountDto;
import com.fa.bajajallianz.cccp.common.report.service.ReportService;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.config.utils.CommonRequestUtil;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/common/report/api/" })
public class ReportController {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	ReportService reportService;
 
	@GetMapping("/fetchClaimSummaryCount")
	public ResponseEntity<CommonResponseDto<ClaimSummaryCountDto>> fetchClaimSummaryCount(@RequestParam String payload,
			HttpServletRequest request) {
		logger.info("ReportController-fetchClaimSummaryCount-start");
		CommonResponseDto<ClaimSummaryCountDto> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = reportService.fetchClaimSummaryCount(commonRequestDto, request);
		} catch (Exception e) {
			logger.error("ReportController-fetchClaimSummaryCount ", e);
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
			commonResponseDto.setStatus(CommonConstants.ERROR);
			CommonRequestUtil.errorInfo(request, "", "ReportController-fetchClaimSummaryCount",
					"fetchClaimSummaryCount", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("ReportController-fetchClaimSummaryCount-end");

		return new ResponseEntity<CommonResponseDto<ClaimSummaryCountDto>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("/fetchUserCount")
	public ResponseEntity<CommonResponseDto<UserCountDto>> fetchUserCount(@RequestParam String payload,
			HttpServletRequest request) {
		logger.info("ReportController-fetchUserCount-start");
		CommonResponseDto<UserCountDto> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = reportService.fetchUserCount(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
			logger.error("ReportController-fetchUserCount ", e);
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
			CommonRequestUtil.errorInfo(request, "", "ReportController-fetchUserCount", "fetchUserCount", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("ReportController-fetchUserCount-end");

		return new ResponseEntity<CommonResponseDto<UserCountDto>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("/fetchClaimAnalysisCount")
	public ResponseEntity<CommonResponseDto<List<ClaimAnalysisDto>>> fetchClaimAnalysisCount(
			@RequestParam String payload, HttpServletRequest request) {
		logger.info("ReportController-fetchClaimAnalysisCount-start");
		CommonResponseDto<List<ClaimAnalysisDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = reportService.fetchClaimAnalysisCount(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
			logger.error("ReportController-fetchClaimAnalysisCount ", e);
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
			CommonRequestUtil.errorInfo(request, "", "ReportController-fetchClaimAnalysisCount", "fetchClaimAnalysisCount", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("ReportController-fetchClaimAnalysisCount-end");

		return new ResponseEntity<CommonResponseDto<List<ClaimAnalysisDto>>>(commonResponseDto, HttpStatus.OK);
	}

	@PostMapping("/refreshClaimCount")
	public ResponseEntity<CommonResponseDto<ClaimAnalysisDto>> refreshClaimCount(HttpServletRequest request) {
		logger.info("ReportController-refreshClaimCount-start");
		CommonResponseDto<ClaimAnalysisDto> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = reportService.refreshClaimCount(request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
			logger.error("ReportController-refreshClaimCount ", e);
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
			CommonRequestUtil.errorInfo(request, "", "ReportController-refreshClaimCount", "refreshClaimCount", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("ReportController-refreshClaimCount-end");

		return new ResponseEntity<CommonResponseDto<ClaimAnalysisDto>>(commonResponseDto, HttpStatus.OK);
	}

	@PostMapping("/refreshUserCount")
	public ResponseEntity<CommonResponseDto<UserCountDto>> refreshUserCount(HttpServletRequest request) {
		logger.info("ReportController-refreshUserCount-start");
		CommonResponseDto<UserCountDto> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = reportService.refreshUserCount(request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
			logger.error("ReportController-refreshUserCount ", e);
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
			CommonRequestUtil.errorInfo(request, "", "ReportController-refreshUserCount", "refreshUserCount", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("ReportController-refreshUserCount-end");

		return new ResponseEntity<CommonResponseDto<UserCountDto>>(commonResponseDto, HttpStatus.OK);
	}
	
	@PostMapping("/retryfailure")
	public ResponseEntity<CommonResponseDto<String>> retryfailure(HttpServletRequest request) {
		logger.info("ReportController-retryfailure-start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = reportService.retryfailure(request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
			logger.error("ReportController-fetchUserCount ", e);
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
			CommonRequestUtil.errorInfo(request, "", "ReportController-retryfailure", "retryfailure", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("ReportController-retryfailure-end");
		return new ResponseEntity<CommonResponseDto<String>>(commonResponseDto, HttpStatus.OK);
	}
	
	
	@GetMapping("getOutstandingReport")
	public ResponseEntity<?> getOutstandingReport(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page, HttpServletRequest request) {
		logger.info("ReportController-getOutstandingReport-start");
		DataTableDto<List<ReportResponseDto>> commonResponseDto = new DataTableDto<List<ReportResponseDto>>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = reportService.getOutstandingReport(commonRequestDto, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			logger.error("Exception-ReportController-getOutstandingReport", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("ReportController-getOutstandingReport-end");
		return new ResponseEntity<>(commonResponseDto, HttpStatus.OK);
	}
	
	@PostMapping("getMISReport")
	public ResponseEntity<?> getMISReport(@RequestBody CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("Enter into ReportController -getMISReport - Start");
		CommonResponseDto<List<ReportResponseDto>> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = reportService.getMISReport(commonRequestDto, request);
		} catch (Exception e) {
			logger.error("Exception-ReportController-getMISReport", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("Enter into ReportController -getMISReport - End");
		return new ResponseEntity<CommonResponseDto<List<ReportResponseDto>>>(commonResponseDto, HttpStatus.OK);
	}
	
	
}
