package com.fa.bajajallianz.cccp.common.logger.service;

import com.fa.bajajallianz.cccp.common.dto.APIRequestDto;
import com.fa.bajajallianz.cccp.common.dto.APIResponseDto;

public interface LoggerRestAPI {

	public APIResponseDto callInfoLogger(APIRequestDto apiRequestDto);

	public APIResponseDto callErrorLogger(APIRequestDto apiRequestDto);

	public APIResponseDto callTraceLogger(APIRequestDto apiRequestDto);
	
	public APIResponseDto callSaveApiLog(APIRequestDto apiRequestDto);
}
