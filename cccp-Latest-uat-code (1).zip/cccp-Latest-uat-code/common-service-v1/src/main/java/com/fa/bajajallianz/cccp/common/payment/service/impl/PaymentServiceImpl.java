package com.fa.bajajallianz.cccp.common.payment.service.impl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fa.bajajallianz.cccp.common.dto.CommonDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.payment.service.PaymentService;
import com.fa.bajajallianz.cccp.common.restapi.service.CommonRestTemplateService;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.ErrorCodeConstants;
import com.fa.bajajallianz.cccp.config.utils.CommonErrorMsg;
import com.fa.bajajallianz.cccp.config.utils.CommonRequestUtil;

@Service
public class PaymentServiceImpl implements PaymentService{
	
	private static final Logger logger = LoggerFactory.getLogger(PaymentServiceImpl.class);

	@Autowired
	CommonErrorMsg commonErrorMsg;

	@Autowired
	CommonRestTemplateService commonRestTemplateService;
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public CommonResponseDto<String> saveinvoicedtls(CommonDetailsDto commonDetailsDto, HttpServletRequest request) {
		logger.info("Enter into PaymentServiceImpl saveinvoicedtls Start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = commonRestTemplateService.saveinvoicedtls(commonDetailsDto, request);
		} catch (Exception e) {
			logger.error("Enter into PaymentServiceImpl-saveinvoicedtls Exception", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "PaymentServiceImpl", "saveinvoicedtls", "", e.getMessage(),
					CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("Enter into PaymentServiceImpl saveinvoicedtls Start");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<String> saveNeftDtls(CommonDetailsDto commonDetailsDto, HttpServletRequest request) {
		logger.info("Enter into PaymentServiceImpl saveNeftDtls Start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = commonRestTemplateService.saveNeftDtls(commonDetailsDto, request);
		} catch (Exception e) {
			logger.error("Enter into PaymentServiceImpl-saveNeftDtls Exception", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "PaymentServiceImpl", "saveNeftDtls", "", e.getMessage(),
					CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("Enter into PaymentServiceImpl saveNeftDtls Start");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<String> updateClaimantPanDetail(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("Enter into PaymentServiceImpl updateClaimantPanDetail Start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = commonRestTemplateService.updateClaimantPanDetail(commonRequestDto, request);
		} catch (Exception e) {
			logger.error("Enter into PaymentServiceImpl-updateClaimantPanDetail Exception", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "PaymentServiceImpl", "updateClaimantPanDetail", "", e.getMessage(),
					CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("Enter into PaymentServiceImpl updateClaimantPanDetail Start");
		return commonResponseDto;
	}

}
