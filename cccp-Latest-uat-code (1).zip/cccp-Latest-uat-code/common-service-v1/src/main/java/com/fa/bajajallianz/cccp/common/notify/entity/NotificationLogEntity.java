/**
 * 
 */
package com.fa.bajajallianz.cccp.common.notify.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author fasoftwares
 *
 */
@Entity
@Table(name = "notification_log")
public class NotificationLogEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "claim_number")
	private String claimNumber;

	@Column(name = "survey_number")
	private String surveyNumber;
	
	@Column(name = "template_id")
	private String templateId;

	@Column(name = "user_id")
	private String userId;

	@Column(name = "is_locked")
	private Boolean isLocked;

	@Column(name = "notify_type")
	private String notifyType;

	@Column(name = "notify_config_id")
	private Long notifyConfigId;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_date")
	private Date modifiedDate;
	
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "notifyLogEntity")
	private List<NotifyDeliveryLogEntity> notifyDeliveryLogs;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getSurveyNumber() {
		return surveyNumber;
	}

	public void setSurveyNumber(String surveyNumber) {
		this.surveyNumber = surveyNumber;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Boolean getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(Boolean isLocked) {
		this.isLocked = isLocked;
	}

	public String getNotifyType() {
		return notifyType;
	}

	public void setNotifyType(String notifyType) {
		this.notifyType = notifyType;
	}

	public Long getNotifyConfigId() {
		return notifyConfigId;
	}

	public void setNotifyConfigId(Long notifyConfigId) {
		this.notifyConfigId = notifyConfigId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public List<NotifyDeliveryLogEntity> getNotifyDeliveryLogs() {
		return notifyDeliveryLogs;
	}

	public void setNotifyDeliveryLogs(List<NotifyDeliveryLogEntity> notifyDeliveryLogs) {
		this.notifyDeliveryLogs = notifyDeliveryLogs;
	}

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

}
