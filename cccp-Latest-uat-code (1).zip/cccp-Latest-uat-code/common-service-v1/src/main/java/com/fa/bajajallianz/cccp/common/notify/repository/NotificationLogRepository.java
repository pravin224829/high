package com.fa.bajajallianz.cccp.common.notify.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.common.notify.entity.NotificationLogEntity;

@Repository
public interface NotificationLogRepository extends JpaRepository<NotificationLogEntity, Long> {

	List<NotificationLogEntity> findByIsLocked(Boolean false1);
	
	@Query(value = "select email from cccp_bagic.users u where user_id = ?1 and is_active = ?2", nativeQuery = true)
	String getUserEmailByUserId(String userId, Boolean isActive);

	@Query(value = "select subject from cccp_bagic.notify_email_template net where id = ?1 and is_active = ?2", nativeQuery = true)
	String getSubjectByConfigId(Long notifyConfigId, Boolean isActive);

	@Query(value = "select email_template_id  from cccp_bagic.notify_config where id = ?1", nativeQuery = true)
	Long getEmailTemplateId(Long notifyConfigId);

}
