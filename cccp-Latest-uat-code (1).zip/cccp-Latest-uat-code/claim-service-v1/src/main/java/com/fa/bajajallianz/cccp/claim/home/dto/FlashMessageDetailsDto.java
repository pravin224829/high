/**
 * 
 */
package com.fa.bajajallianz.cccp.claim.home.dto;

import java.io.Serializable;

/**
 * @author praveen
 *
 */
public class FlashMessageDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public String msgId;
	public String description;

	public String getMsgId() {
		return msgId;
	}

	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
