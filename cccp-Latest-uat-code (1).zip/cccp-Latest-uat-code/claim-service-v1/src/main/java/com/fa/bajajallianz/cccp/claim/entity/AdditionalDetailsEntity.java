package com.fa.bajajallianz.cccp.claim.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



@Entity
@Table(name = "additional_details")                
public class AdditionalDetailsEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id", length = 20)
	private Long id;
	
	@Column(name = "clientDivisionName", length = 50)
	private String clientDivisionName;
	
	@Column(name = "totalConsignmentValue", length = 50)
	private String totalConsignmentValue;
	
	@Column(name = "transportVehilceNo", length = 50)
	private String transportVehilceNo;
	
	@Column(name = "transporterName", length = 50)
	private String transporterName;
	
	@Column(name = "jirDate", length = 50)
	private String jirDate;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClientDivisionName() {
		return clientDivisionName;
	}

	public void setClientDivisionName(String clientDivisionName) {
		this.clientDivisionName = clientDivisionName;
	}

	public String getTotalConsignmentValue() {
		return totalConsignmentValue;
	}

	public void setTotalConsignmentValue(String totalConsignmentValue) {
		this.totalConsignmentValue = totalConsignmentValue;
	}

	public String getTransportVehilceNo() {
		return transportVehilceNo;
	}

	public void setTransportVehilceNo(String transportVehilceNo) {
		this.transportVehilceNo = transportVehilceNo;
	}

	public String getTransporterName() {
		return transporterName;
	}

	public void setTransporterName(String transporterName) {
		this.transporterName = transporterName;
	}

	public String getConsignmentOrCargoType() {
		return consignmentOrCargoType;
	}

	public void setConsignmentOrCargoType(String consignmentOrCargoType) {
		this.consignmentOrCargoType = consignmentOrCargoType;
	}

	public String getK2k3() {
		return k2k3;
	}

	public void setK2k3(String k2k3) {
		this.k2k3 = k2k3;
	}

	public ClaimEntity getClaimDetails() {
		return claimDetails;
	}

	public void setClaimDetails(ClaimEntity claimDetails) {
		this.claimDetails = claimDetails;
	}

	
	public String getJirDate() {
		return jirDate;
	}

	public void setJirDate(String jirDate) {
		this.jirDate = jirDate;
	}

	@Column(name = "clientDistrictName", length = 50)
	private String clientDistrictName;
	
	
	
	public String getClientDistrictName() {
		return clientDistrictName;
	}

	public void setClientDistrictName(String clientDistrictName) {
		this.clientDistrictName = clientDistrictName;
	}

	@Column(name = "consignmentOrCargoType", length = 50)
	private String consignmentOrCargoType;

	@Column(name = "k2k3", length = 50)
	private String k2k3;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "claimId")
	private ClaimEntity claimDetails;


	
	
	


	
	

}
