package com.fa.bajajallianz.cccp.claim.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.claim.entity.AdditionalDetailsEntity;

@Repository
public interface AdditionalDetailsRepository extends JpaRepository<AdditionalDetailsEntity, Long> {

	AdditionalDetailsEntity findByClaimDetailsId(Long id);

}
