package com.fa.bajajallianz.cccp.claim.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fa.bajajallianz.cccp.claim.entity.BankEntity;

public interface BankRepository extends JpaRepository<BankEntity, Long>{

}
