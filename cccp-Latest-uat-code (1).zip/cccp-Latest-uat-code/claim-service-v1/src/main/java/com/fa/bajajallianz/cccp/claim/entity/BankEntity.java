package com.fa.bajajallianz.cccp.claim.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "bank_details")
public class BankEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id", length = 20)
	private Long id;
	
	@Column(name = "pan_number", length = 20)
	private String panNumber;
	
	@Column(name = "gst_number", length = 50)
	private String gstNumber;
	
	@Column(name = "account_number", length = 50)
	private String accountNumber;
	
	@Column(name = "ifsc_code", length = 20)
	private String ifscCode;
	
	@Column(name = "account_type", length = 50)
	private String accountType;
	
	@Column(name = "registered_mobile_no", length = 20)
	private Long registeredMobileNo;
	
	@Column(name = "is_active")
	private Boolean isActive;
	
	@Column(name = "created_by", length = 100)
	private String createdBy;
	
	@Column(name = "created_date")
	private Date createdDate;	
	
	@Column(name = "modified_by", length = 100)
	private String modifiedBy;
	
	@Column(name = "modified_date")
	private Date modifiedDate;
	
	@Column(name = "confirm_bank_accountnumber", length = 100)
	private String confirmBankAccountnumber;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "claim_id")
	private ClaimEntity claimDetails;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Long getRegisteredMobileNo() {
		return registeredMobileNo;
	}

	public void setRegisteredMobileNo(Long registeredMobileNo) {
		this.registeredMobileNo = registeredMobileNo;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public ClaimEntity getClaimDetails() {
		return claimDetails;
	}

	public void setClaimDetails(ClaimEntity claimDetails) {
		this.claimDetails = claimDetails;
	}

	public String getConfirmBankAccountnumber() {
		return confirmBankAccountnumber;
	}

	public void setConfirmBankAccountnumber(String confirmBankAccountnumber) {
		this.confirmBankAccountnumber = confirmBankAccountnumber;
	}
	

}
