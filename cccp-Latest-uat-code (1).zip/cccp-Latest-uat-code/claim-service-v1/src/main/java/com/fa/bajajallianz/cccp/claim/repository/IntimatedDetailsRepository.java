package com.fa.bajajallianz.cccp.claim.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fa.bajajallianz.cccp.claim.entity.IntimatedDetailsEntity;

public interface IntimatedDetailsRepository extends JpaRepository<IntimatedDetailsEntity, Long> {

}
