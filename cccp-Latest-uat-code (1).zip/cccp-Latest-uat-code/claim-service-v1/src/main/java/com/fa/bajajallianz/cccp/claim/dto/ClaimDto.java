package com.fa.bajajallianz.cccp.claim.dto;

import java.io.Serializable;
import java.util.ArrayList;
/*
 * Manibharathi M
 */
import java.util.Date;
import java.util.List;

import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimResponseDto;
import com.fa.bajajallianz.cccp.common.dto.PolicyDetailsDto;

public class ClaimDto implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long Id;
	private String claimRefNo;
	private String policyNumber;
	private Long insuredMobileNumber;
	private String insuredMail;
	private Date lossDate;
	private String lossTime;
	private String lossDetails1;
	private String lossAddress;
	private String landmark;
	private Double lossAmount;
	private Integer pincode;
	private String state;
	private String city;
	private String area;
	private String areaClaimBehalfOffInsure;
	private String section;
	private String causeOffLoss;
	private Date notificationDate;
	private String claimNotifiedBy;
	private String lossDescription;
	private String goodsDamagedDetails;
	private Double lossEstimatedValue;
	private String invoiceNumber;
	private Date invoiceDate;
	private String blRrLrAwbNo;
	private Date lorryReceiptDate;
	private String journeyFrom;
	private String journeyTo;
	private String consigneeName;
	private String consigneeAddress;
	private String consigneePhoneNo;
	private String claimServicingOffice;
	private String claimNumber;
	private Boolean isActive;
	private Date createdDate;
	private String createdBy;
	private String modifiedBy;
	private String modifiedDate;
	
	private List<PolicyDetailsDto> data;
	private ClaimDetailsDto claimdata;
	
	
	public ClaimDetailsDto getClaimdata() {
		return claimdata;
	}

	public void setClaimdata(ClaimDetailsDto claimDetailsDto) {
		this.claimdata = claimDetailsDto;
	}
	

	private String total;
	private String current_page;
	private String last_page;
	private String from;
	private String to;
	private String per_page;
	private String next_page_url;
	private String prev_page_url;

	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public String getClaimRefNo() {
		return claimRefNo;
	}

	public void setClaimRefNo(String claimRefNo) {
		this.claimRefNo = claimRefNo;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Long getInsuredMobileNumber() {
		return insuredMobileNumber;
	}

	public void setInsuredMobileNumber(Long insuredMobileNumber) {
		this.insuredMobileNumber = insuredMobileNumber;
	}

	public String getInsuredMail() {
		return insuredMail;
	}

	public void setInsuredMail(String insuredMail) {
		this.insuredMail = insuredMail;
	}

	public Date getLossDate() {
		return lossDate;
	}

	public void setLossDate(Date lossDate) {
		this.lossDate = lossDate;
	}

	public String getLossTime() {
		return lossTime;
	}

	public void setLossTime(String lossTime) {
		this.lossTime = lossTime;
	}

	public String getLossAddress() {
		return lossAddress;
	}

	public void setLossAddress(String lossAddress) {
		this.lossAddress = lossAddress;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public Double getLossAmount() {
		return lossAmount;
	}

	public void setLossAmount(Double lossAmount) {
		this.lossAmount = lossAmount;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getAreaClaimBehalfOffInsure() {
		return areaClaimBehalfOffInsure;
	}

	public void setAreaClaimBehalfOffInsure(String areaClaimBehalfOffInsure) {
		this.areaClaimBehalfOffInsure = areaClaimBehalfOffInsure;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getCauseOffLoss() {
		return causeOffLoss;
	}

	public void setCauseOffLoss(String causeOffLoss) {
		this.causeOffLoss = causeOffLoss;
	}

	public Date getNotificationDate() {
		return notificationDate;
	}

	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}

	public String getClaimNotifiedBy() {
		return claimNotifiedBy;
	}

	public void setClaimNotifiedBy(String claimNotifiedBy) {
		this.claimNotifiedBy = claimNotifiedBy;
	}

	public String getLossDescription() {
		return lossDescription;
	}

	public void setLossDescription(String lossDescription) {
		this.lossDescription = lossDescription;
	}

	public String getGoodsDamagedDetails() {
		return goodsDamagedDetails;
	}

	public void setGoodsDamagedDetails(String goodsDamagedDetails) {
		this.goodsDamagedDetails = goodsDamagedDetails;
	}

	public Double getLossEstimatedValue() {
		return lossEstimatedValue;
	}

	public void setLossEstimatedValue(Double lossEstimatedValue) {
		this.lossEstimatedValue = lossEstimatedValue;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getBlRrLrAwbNo() {
		return blRrLrAwbNo;
	}

	public void setBlRrLrAwbNo(String blRrLrAwbNo) {
		this.blRrLrAwbNo = blRrLrAwbNo;
	}

	public Date getLorryReceiptDate() {
		return lorryReceiptDate;
	}

	public void setLorryReceiptDate(Date lorryReceiptDate) {
		this.lorryReceiptDate = lorryReceiptDate;
	}

	public String getJourneyFrom() {
		return journeyFrom;
	}

	public void setJourneyFrom(String journeyFrom) {
		this.journeyFrom = journeyFrom;
	}

	public String getJourneyTo() {
		return journeyTo;
	}

	public void setJourneyTo(String journeyTo) {
		this.journeyTo = journeyTo;
	}

	public String getConsigneeName() {
		return consigneeName;
	}

	public void setConsigneeName(String consigneeName) {
		this.consigneeName = consigneeName;
	}

	public String getConsigneeAddress() {
		return consigneeAddress;
	}

	public void setConsigneeAddress(String consigneeAddress) {
		this.consigneeAddress = consigneeAddress;
	}

	public String getConsigneePhoneNo() {
		return consigneePhoneNo;
	}

	public void setConsigneePhoneNo(String consigneePhoneNo) {
		this.consigneePhoneNo = consigneePhoneNo;
	}

	public String getClaimServicingOffice() {
		return claimServicingOffice;
	}

	public void setClaimServicingOffice(String claimServicingOffice) {
		this.claimServicingOffice = claimServicingOffice;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getLossDetails1() {
		return lossDetails1;
	}

	public void setLossDetails1(String lossDetails1) {
		this.lossDetails1 = lossDetails1;
	}
	
	public List<PolicyDetailsDto> getData() {
		return data;
	}

	public void setData(List<PolicyDetailsDto> data) {
		this.data = data;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public String getCurrent_page() {
		return current_page;
	}

	public void setCurrent_page(String current_page) {
		this.current_page = current_page;
	}

	public String getLast_page() {
		return last_page;
	}

	public void setLast_page(String last_page) {
		this.last_page = last_page;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getPer_page() {
		return per_page;
	}

	public void setPer_page(String per_page) {
		this.per_page = per_page;
	}

	public String getNext_page_url() {
		return next_page_url;
	}

	public void setNext_page_url(String next_page_url) {
		this.next_page_url = next_page_url;
	}

	public String getPrev_page_url() {
		return prev_page_url;
	}

	public void setPrev_page_url(String prev_page_url) {
		this.prev_page_url = prev_page_url;
	}

	

	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	

}
