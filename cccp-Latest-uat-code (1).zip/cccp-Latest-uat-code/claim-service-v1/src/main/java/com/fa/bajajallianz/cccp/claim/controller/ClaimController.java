package com.fa.bajajallianz.cccp.claim.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.claim.restservice.ClaimRestService;
import com.fa.bajajallianz.cccp.claim.service.ClaimService;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsListDto;
import com.fa.bajajallianz.cccp.common.dto.ClientsFieldsConfigDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/claim/api/" })

public class ClaimController {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	public ClaimService claimService;

	@Autowired
	public ClaimRestService claimRestService;

	@GetMapping(value = { "healthCheck" })
	public String healthCheck() {
		logger.info("CommonController-healthCheck-started 21-09-2022");
		return CommonConstants.CLAIMHEALTHCHECK;
	}

	@PostMapping("saveClaimDetails")
	public ResponseEntity<?> saveClaimDetails(@RequestBody ClaimDetailsDto dto, HttpServletRequest request) {
		logger.info("ClaimController-saveClaimDetails-start");
		CommonResponseDto<ClaimDetailsDto> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = claimService.saveClaimDetails(dto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("saveClaimDetails" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("searchClaimList")
	public ResponseEntity<?> searchClaimList(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("ClaimController-searchClaimList-start");
		DataTableDto<List<ClaimDetailsListDto>> commonResponseDto = new DataTableDto<List<ClaimDetailsListDto>>();
		try {
			commonResponseDto = claimService.searchClaimList(payload, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("searchClaimList" + commonResponseDto.getStatus());
		return new ResponseEntity<DataTableDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchClaimDetails")
	public ResponseEntity<?> fetchClaimDetails(@RequestParam String payload, HttpServletRequest request) {
		logger.info("ClaimController-fetchClaimDetails-start");
		CommonResponseDto<ClaimDetailsDto> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = claimService.fetchClaimDetails(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("ClaimController - fetchClaimDetails" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<ClaimDetailsDto>>(commonResponseDto, HttpStatus.OK);
	}
	
	@PostMapping("getUDYAMClaimDetails")
	public ResponseEntity<?> getUDYAMClaimDetails(@RequestBody CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("Enter into ClaimController getUDYAMClaimDetails start...");
		CommonResponseDto<ClaimDetailsDto> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = claimService.getUDYAMClaimDetails(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("ClaimController - getUDYAMClaimDetails" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<ClaimDetailsDto>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("searchRuntimeFieldsConfig")
	public ResponseEntity<?> searchRuntimeFieldsConfig(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		DataTableDto<List<ClientsFieldsConfigDto>> dataTableDto = new DataTableDto<List<ClientsFieldsConfigDto>>();
		logger.info("Enter into ClaimController - searchRuntimeFieldsConfig -start");
		try {
			dataTableDto = claimService.searchRuntimeFieldsList(payload, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			e.printStackTrace();
			dataTableDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("Enter into ClaimController - searchRuntimeFieldsConfig -End");
		return new ResponseEntity<DataTableDto<List<ClientsFieldsConfigDto>>>(dataTableDto, HttpStatus.OK);
	}

	@PostMapping("saveRuntimeFields")
	public ResponseEntity<?> saveRuntimeFields(@RequestBody ClientsFieldsConfigDto dto, HttpServletRequest request) {
		logger.info("CommonController-saveRuntimeFields-start");
		CommonResponseDto<ClientsFieldsConfigDto> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = claimService.saveRuntimeFields(dto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("saveRuntimeFields" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}
	
	@GetMapping("fetchRuntimeFields")
	public ResponseEntity<?> fetchRuntimeFields(@RequestParam String policyNumber, HttpServletRequest request) {
		logger.info("ClaimController-fetchRuntimeFields-start");
		CommonResponseDto<ClientsFieldsConfigDto> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = claimService.fetchRuntimeFields(policyNumber, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("ClaimController - fetchRuntimeFields" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<ClientsFieldsConfigDto>>(commonResponseDto, HttpStatus.OK);
	}
	
	@PostMapping("getUpdateClaimList")
	public ResponseEntity<?> getUpdateClaimDetails(@RequestBody CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("CommonController-getUpdateClaimList-start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = claimService.getUpdateClaimList(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("getUpdateClaimList" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}
	
}