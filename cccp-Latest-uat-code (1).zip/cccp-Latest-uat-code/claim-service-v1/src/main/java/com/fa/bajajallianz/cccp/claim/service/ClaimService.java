package com.fa.bajajallianz.cccp.claim.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;


import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsListDto;
import com.fa.bajajallianz.cccp.common.dto.ClientsFieldsConfigDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;


public interface ClaimService {

	CommonResponseDto<ClaimDetailsDto> saveClaimDetails(ClaimDetailsDto dto, HttpServletRequest request);

	DataTableDto<List<ClaimDetailsListDto>> searchClaimList(String payload,
			String main_filter, String sort, String page, String per_page, HttpServletRequest request);

	CommonResponseDto<ClaimDetailsDto> fetchClaimDetails(CommonRequestDto commonRequestDto, HttpServletRequest request);

	DataTableDto<List<ClientsFieldsConfigDto>> searchRuntimeFieldsList(String payload,
			String main_filter, String sort, String page, String per_page, HttpServletRequest request);

	CommonResponseDto<ClientsFieldsConfigDto> saveRuntimeFields(ClientsFieldsConfigDto dto, HttpServletRequest request);

	CommonResponseDto<ClientsFieldsConfigDto> fetchRuntimeFields(String policyNumber,
			HttpServletRequest request);

	CommonResponseDto<String> getUpdateClaimList(CommonRequestDto commonRequestDto, HttpServletRequest request);
	
	CommonResponseDto<ClaimDetailsDto> getUDYAMClaimDetails(CommonRequestDto commonRequestDto, HttpServletRequest request);
	
	DataTableDto<List<ClaimDetailsListDto>> searchUDYAMClaimList(String payload,
			String main_filter, String sort, String page, String per_page, HttpServletRequest request);

}