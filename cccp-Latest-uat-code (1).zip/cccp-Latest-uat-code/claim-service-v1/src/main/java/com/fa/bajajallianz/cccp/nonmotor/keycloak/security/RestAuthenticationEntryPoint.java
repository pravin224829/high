package com.fa.bajajallianz.cccp.nonmotor.keycloak.security;

import java.io.IOException;
import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.LoggerFactory;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

/**
 * @author Muruganandam
 * 
 *         Version 1.0, Created Date:21-06-2020, Updated Date:21-06-2020 This is
 *         invoked when user tries to access a secured REST resource without
 *         supplying any credentials We should just send a 401 Unauthorized
 *         response.
 */
@Component
public class RestAuthenticationEntryPoint implements AuthenticationEntryPoint, Serializable {

	private static final long serialVersionUID = 3798723588865329956L;

	protected static final org.slf4j.Logger logger = LoggerFactory.getLogger(RestAuthenticationEntryPoint.class);

	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException {
		logger.info("Enter Into RestAuthenticationEntryPoint--commence Started");
		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
//		response.addHeader("status", "Unauthorized");
		logger.info("Enter Into RestAuthenticationEntryPoint--commence Ended");
	}
}