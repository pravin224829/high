/**
 * 
 */
package com.fa.bajajallianz.cccp.nonmotor.keycloak.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.util.AntPathMatcher;

/**
 * @author Muruganandam
 *
 *         Version 1.0, Created Date:21-06-2020, Updated Date:21-06-2020
 */

public class KeycloakFilter implements Filter {

	protected final Logger LOGGER = LoggerFactory.getLogger(getClass());
	private static final String HEADER_PREFIX = "Bearer ";
	// private static final String MATCH_ALL = "/**";

	public void doFilter(HttpServletRequest servletRequest, HttpServletResponse servletResponse,
			FilterChain filterChain) throws IOException, ServletException {

		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		List<String> errors = new ArrayList<>();
		LOGGER.info("Logging Request  {} : {}" + request.getRequestURL());

		boolean isTrue = shouldNotFilterUrl(request);
		if (!isTrue) {
			Boolean authValid = false;
			Boolean contentTypeValid = false;
			Boolean businessValid = false;
			Boolean correlationValid = false;
			try {
				authValid = validateAuthorization(request);
				contentTypeValid = validateContentType(request);
				businessValid = validateBusinessCorelationId(request);
				correlationValid = validateCorelationId(request);
			} catch (Exception e) {
				errors.add(e.getMessage());
			}
			if (!authValid) {
				response.setStatus(HttpStatus.SC_BAD_REQUEST);
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
				return;
			} else if (!contentTypeValid) {
				response.setStatus(HttpStatus.SC_BAD_REQUEST);
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
				return;
			} else if (!businessValid) {
				response.setStatus(HttpStatus.SC_BAD_REQUEST);
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
				return;
			} else if (!correlationValid) {
				response.setStatus(HttpStatus.SC_BAD_REQUEST);
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
				return;
			}
			// if (errors == null || errors.size() == 0) {
			// try {
			// KeycloakTokenVerifier keycloakTokenVerifier = new
			// KeycloakTokenVerifier();
			// String token = extractToken(request);
			// if (!keycloakTokenVerifier.isLoggedInKeycloak(token)) {
			// errors.add("Token Expired");
			// response.setStatus(HttpStatus.SC_UNAUTHORIZED);
			// response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
			// String.join(",", errors));
			// }
			// } catch (VerificationException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// errors.add(e.getMessage());
			// response.setStatus(HttpStatus.SC_BAD_REQUEST);
			// response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
			// String.join(",", errors));
			// }
			// }
		}
		try {
			filterChain.doFilter(request, response);
		} catch (Exception e) {
			errors.add(e.getMessage());
		}

	}

	protected boolean shouldNotFilterUrl(HttpServletRequest request) throws ServletException {
		AntPathMatcher pathMatcher = new AntPathMatcher();
		List<String> matchers = excludeUrls();
		return matchers.stream().anyMatch(p -> pathMatcher.match(p, request.getServletPath()));
	}

	public List<String> excludeUrls() {
		List<String> paths = java.util.Arrays.asList(SecurityConstants.SWAGGERPATHTOSKIP);
		List<String> paths1 = java.util.Arrays.asList(SecurityConstants.PATHTOSKIP);
		List<String> matchers = Stream.of(paths, paths1).flatMap(x -> x.stream()).collect(Collectors.toList());
		return matchers;
	}

//	public void applyFilter(HttpServletRequest request, HttpServletResponse response)
//			throws IOException, ServletException {
//		LOGGER.info("Logging Request  {} : {}" + request.getRequestURL());
//
//		Boolean authValid = false;
//		Boolean contentTypeValid = false;
//		Boolean businessValid = false;
//		Boolean correlationValid = false;
//
//		List<String> errors = new ArrayList<>();
//		try {
//			authValid = validateAuthorization(request);
//			contentTypeValid = validateContentType(request);
//			businessValid = validateBusinessCorelationId(request);
//			correlationValid = validateCorelationId(request);
//		} catch (Exception e) {
//			errors.add(e.getMessage());
//		}
//		if (!authValid) {
//			response.setStatus(HttpStatus.SC_BAD_REQUEST);
//			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
//		} else if (!contentTypeValid) {
//			response.setStatus(HttpStatus.SC_BAD_REQUEST);
//			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
//		} else if (!businessValid) {
//			response.setStatus(HttpStatus.SC_BAD_REQUEST);
//			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
//		} else if (!correlationValid) {
//			response.setStatus(HttpStatus.SC_BAD_REQUEST);
//			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
//		}
//
//	}

	private Boolean validateAuthorization(HttpServletRequest request) {
		String header = request.getHeader("auth");
		if (StringUtils.isBlank(header)) {
			throw new AuthenticationServiceException("Authorization header cannot be blank!");
		}

		if (header.length() < HEADER_PREFIX.length()) {
			throw new AuthenticationServiceException("Invalid authorization header size.");
		}
		String substring = header.substring(HEADER_PREFIX.length(), header.length());
		return StringUtils.isNotBlank(substring) ? true : false;
	}

	private Boolean validateContentType(HttpServletRequest request) {
		String header = request.getHeader("Content-Type");
		if (StringUtils.isBlank(header)) {
			throw new AuthenticationServiceException("Content-Type header cannot be blank!");
		}

		if (header.equalsIgnoreCase("application/json")) {
			return true;
		} else {
			throw new AuthenticationServiceException("Invalid Content-Type header. It should be application/json.");
		}
	}

	private Boolean validateBusinessCorelationId(HttpServletRequest request) {
		String header = request.getHeader("businesscorelationid");
		if (StringUtils.isBlank(header)) {
			throw new AuthenticationServiceException("businesscorelationid header cannot be blank!");
		}
		return true;

		// throw new AuthenticationServiceException("Invalid
		// BusinessCorelationId.");

	}

	private Boolean validateCorelationId(HttpServletRequest request) {
		String header = request.getHeader("corelationid");
		if (StringUtils.isBlank(header)) {
			throw new AuthenticationServiceException("corelationid header cannot be blank!");
		}
		return true;

		// throw new AuthenticationServiceException("Invalid
		// BusinessCorelationId.");

	}

	private String extract(String header) {
		if (StringUtils.isBlank(header)) {
			throw new AuthenticationServiceException("Authorization header cannot be blank!");
		}

		if (header.length() < HEADER_PREFIX.length()) {
			throw new AuthenticationServiceException("Invalid authorization header size.");
		}
		return header.substring(HEADER_PREFIX.length(), header.length());
	}

	public String extractToken(HttpServletRequest request) {
		String tokenPayload = request.getHeader("auth");
		return extract(tokenPayload);
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		List<String> errors = new ArrayList<>();
		LOGGER.info("Logging Request  {} : {}" + request.getRequestURL());
		boolean isTrue = shouldNotFilterUrl(request);
		if (!isTrue) {
			Boolean authValid = false;
			Boolean contentTypeValid = false;
			Boolean businessValid = false;
			Boolean correlationValid = false;
			try {
				authValid = validateAuthorization(request);
				contentTypeValid = validateContentType(request);
				businessValid = validateBusinessCorelationId(request);
				correlationValid = validateCorelationId(request);
			} catch (Exception e) {
				errors.add(e.getMessage());
			}
			if (!authValid) {
				response.setStatus(HttpStatus.SC_BAD_REQUEST);
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
			} else if (!contentTypeValid) {
				response.setStatus(HttpStatus.SC_BAD_REQUEST);
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
			} else if (!businessValid) {
				response.setStatus(HttpStatus.SC_BAD_REQUEST);
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
			} else if (!correlationValid) {
				response.setStatus(HttpStatus.SC_BAD_REQUEST);
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
			}
			// if (errors == null || errors.size() == 0) {
			// try {
			// KeycloakTokenVerifier keycloakTokenVerifier = new
			// KeycloakTokenVerifier();
			// String token = extractToken(request);
			// if (!keycloakTokenVerifier.isLoggedInKeycloak(token)) {
			// errors.add("Token Expired");
			// response.setStatus(HttpStatus.SC_UNAUTHORIZED);
			// response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
			// String.join(",", errors));
			// }
			// } catch (VerificationException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// errors.add(e.getMessage());
			// response.setStatus(HttpStatus.SC_BAD_REQUEST);
			// response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
			// String.join(",", errors));
			// }
			// }
		} else {
			try {
				chain.doFilter(request, response);
			} catch (Exception e) {
				errors.add(e.getMessage());
			}
		}

	}

}
