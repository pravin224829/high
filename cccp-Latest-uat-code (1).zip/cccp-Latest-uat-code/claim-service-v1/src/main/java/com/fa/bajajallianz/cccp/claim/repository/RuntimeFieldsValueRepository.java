package com.fa.bajajallianz.cccp.claim.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.claim.entity.RunTimeFieldsValueEntity;

@Repository
public interface RuntimeFieldsValueRepository extends JpaRepository<RunTimeFieldsValueEntity, Long>{

	RunTimeFieldsValueEntity findByFieldCode(String fieldCode);

	List<RunTimeFieldsValueEntity> findByClaimNumber(String claimNumber);

	List<RunTimeFieldsValueEntity> findByClaimDetailsId(Long id);

	RunTimeFieldsValueEntity findByClaimNumberAndFieldCode(String claimNumber, String fieldCode);
	
}
