/**
 * 
 */
package com.fa.bajajallianz.cccp.claim.home.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.claim.home.entity.FlashMessageDetailsEntity;



/**
 * @author praveen
 *
 */

@Repository
public interface FlashMessageDetailsRepository  extends JpaRepository<FlashMessageDetailsEntity, Long> {


}
