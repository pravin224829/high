package com.fa.bajajallianz.cccp.claim.home.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.claim.dto.ClaimDto;
import com.fa.bajajallianz.cccp.claim.home.dto.FlashMessageDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
 
public interface HomeService {

	

}
