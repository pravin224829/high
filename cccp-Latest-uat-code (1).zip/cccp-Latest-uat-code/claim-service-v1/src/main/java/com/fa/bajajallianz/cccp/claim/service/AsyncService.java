package com.fa.bajajallianz.cccp.claim.service;

import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;

public interface AsyncService {
	
	void misClaimIntimation(ClaimDetailsDto claimDto, CommonRequestDto commonRequestDto,
			HttpServletRequest request);
	
	void sendNotification(CommonRequestDto commonRequestDto, HttpServletRequest request);

}
