package com.fa.bajajallianz.cccp.claim.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fa.bajajallianz.cccp.claim.entity.ClaimEntity;

public interface ClaimRepository extends JpaRepository<ClaimEntity, Long> {

	ClaimEntity findByClaimNumberAndIsActive(String claimNumber, Boolean true1);

	ClaimEntity findAllById(Long id);

	ClaimEntity findByclaimRefNo(String claimRefNo);

	List<ClaimEntity> findByClaimNumberOrClaimRefNoAndIsActive(String claimNumber, String claimRefNo, Boolean true1);

	List<ClaimEntity> findByIsActiveTrueAndBlRrLrAwbNo(String blRrLrAwbNo);

	List<ClaimEntity> findByPolicyNumberAndIsActiveTrueAndAndInvoiceNumberAndClaimNumberNotNull(String policyNumber,
			Date lossDate);

	List<ClaimEntity> findByPolicyNumberAndIsActiveTrueAndLossDateAndClaimNumberNotNull(String policyNumber,
			Date lossDate);

	List<ClaimEntity> findByPolicyNumberAndIsActiveTrueAndInvoiceNumberAndClaimNumberNotNull(String policyNumber,
			String invoiceNumber);

	List<ClaimEntity> findByCreatedDateBetweenAndClaimNumberIsNotNull(Date fromDate, Date toDate);

	List<ClaimEntity> findByPolicyNumberAndModifiedDateBetweenAndClaimNumberIsNotNull(String policyNumber,
			Date convertDateTimeToString, Date convertDateTimeToString2);

	@Query(value = " select pm.product_category from cccp_bagic.product_master pm where pm.code=:productCode ", nativeQuery = true)
	String findByProductCatgoryByCode(String productCode);

	@Query(value = " select cd.status, cd.sub_status, cd.deficiency_reason from rcs_claims.claim_details cd where cd.claim_number = ?1 and cd.is_active = ?2 ;", nativeQuery = true)
	List<Object[]> getClaimStatusByClaimNumber(String claimNumber, Boolean true1);

	@Query(value = "select sm.name from cccp_bagic.status_master sm where code = ?1 ;", nativeQuery = true)
	String getStatusNameByCode(String code);

	@Query(value = "select ssm.name from cccp_bagic.sub_status_master ssm where code = ?1 ;", nativeQuery = true)
	String getSubStatusNameByCode(String code);

	@Query(value = "select dr.name from cccp_bagic.deficiency_reason_details dr where code = ?1 and is_active = ?2 limit 1", nativeQuery = true)
	String getDeficiencyReasonNameByCode(String string, Boolean true1);

	@Query(value = "select pd.source_flag from cccp_bagic.policy_details pd where pd.policy_number = ?1 and pd.is_active = true limit 1", nativeQuery = true)
	String getPolicySourceFlagByPolicyNumber(String policyNumber);

	@Query(value = "select gmlm.email from cccp_bagic.group_mail_location_master gmlm where gmlm.location_code = ?1 and gmlm.is_active = ?2 order by gmlm.id limit 1 ;", nativeQuery = true)
	String getGroupMailByCode(String locationCode, Boolean true1);

	@Query(value = "select cv.value from cccp_bagic.common_values cv where cv.key = ?1 and cv.is_active = ?2 ;", nativeQuery = true)
	String getCommonValueByKey(String docvisrole, Boolean true1);

	@Query(value = "select cd.policy_number from cccp_bagic.claim_details cd where cd.claim_number = ?1 and cd.is_active = ?2 ;", nativeQuery = true)
	String getPolicyByClaimNumber(String claimNumber, Boolean true1);

	@Query(value = "select * from cccp_bagic.claim_details cd where cd.policy_number = :policyNumber", nativeQuery = true)
	List<ClaimEntity> getClaimByPolicy(String policyNumber);
	
	@Query(value = "select product_code from cccp_bagic.maximus_product_master where is_active =true", nativeQuery = true)
	List<String> findByActiveProductCode();

}