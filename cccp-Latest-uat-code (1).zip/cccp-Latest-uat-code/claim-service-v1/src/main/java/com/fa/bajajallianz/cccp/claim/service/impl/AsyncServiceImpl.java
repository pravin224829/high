package com.fa.bajajallianz.cccp.claim.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.fa.bajajallianz.cccp.claim.entity.ClaimEntity;
import com.fa.bajajallianz.cccp.claim.repository.ClaimRepository;
import com.fa.bajajallianz.cccp.claim.restservice.ClaimRestService;
import com.fa.bajajallianz.cccp.claim.service.AsyncService;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimantDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.CommonDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.LossDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.MobileNoDto;
import com.fa.bajajallianz.cccp.common.dto.PolicyDetailsDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.DateUtils;
import com.fa.bajajallianz.cccp.common.utils.NumericUtils;
import com.fa.bajajallianz.cccp.mis.common.dto.ClaimAttributeDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.ClaimMisDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.ClaimReserveDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.CommonMisResponseDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusAdditionalPolicyDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusBasicDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusBasicPolicyDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClaimPartyDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusInsuredDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusInsuredInfoDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusSinglePolicySearchDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimPartiesDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ReserveDetailsDto;

@Service
public class AsyncServiceImpl implements AsyncService {
	
	@Autowired
	ClaimRestService claimRestService;
	
	@Autowired
	private ClaimRepository claimRepository;
	
	private static final Logger logger = LoggerFactory.getLogger(AsyncServiceImpl.class);

	@Async(value = "asyncExecutor")
	@Override
	public void misClaimIntimation(ClaimDetailsDto claimDto, CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("Enter into ClaimServiceImpl misClaimIntimation Start...");
		try {
			CommonMisResponseDto<String> response = claimRestService.fetchMisClaimDetails(commonRequestDto, request);
			if(response != null && response.getClaimDetails() != null && claimDto != null) {
				ClaimMisDetailsDto misClaimDetails = response.getClaimDetails();
				if(misClaimDetails.getClaimNumber() != null && StringUtils.isNotBlank(misClaimDetails.getClaimNumber())) {
					CommonDto commonDto = new CommonDto();
					commonDto.setUserId(claimDto.getUserId());
					PolicyDetailsDto policyDetails = new PolicyDetailsDto();
					ClaimDetailsDto claimDetails = new ClaimDetailsDto();
					ClaimantDetailsDto claimantDetails = new ClaimantDetailsDto();
					List<ClaimPartiesDetailsDto> claimParties = new ArrayList<>();
					List<ReserveDetailsDto> reserveDetails = new ArrayList<>();
					ClaimEntity claimEntity = claimRepository
							.findByClaimNumberAndIsActive(misClaimDetails.getClaimNumber(), CommonConstants.TRUE);
					if(claimEntity != null) {
						claimDetails.setPlaceOfLoss(claimEntity.getLossAddress());
					}
					MaximusSinglePolicySearchDto policyResponse = claimRestService.getSavedQuote(misClaimDetails.getPolicyNumber(), request);
					if(policyResponse != null && policyResponse.getApplicationError() != null) {
						if(CommonConstants.ZERO_STRING.equals(policyResponse.getApplicationError().getErrorCode())) {
							if(policyResponse.getBasicPolicyDetails() != null) {
								MaximusBasicPolicyDetailsDto basicDetails = policyResponse.getBasicPolicyDetails();
								policyDetails.setPolicyNumber(basicDetails.getStrPolicyNumber());
								policyDetails.setInspectionDate(DateUtils.dateToStringDDMMYYYYWith(
										DateUtils.convertStringToDate(basicDetails.getStrPolicyInceptionDate())));
								policyDetails.setExpiryDate(DateUtils.dateToStringDDMMYYYYWith(
										DateUtils.convertStringToDate(basicDetails.getStrPolicyExpiryDate())));
								policyDetails.setProductCode(basicDetails.getStrProductCode());
								policyDetails.setProductDescription(basicDetails.getProductName());
								policyDetails.setPolicyStatus(basicDetails.getStrPolicyStatusDesc());
							}
							if (policyResponse.getBasicDetails() != null) {
								MaximusBasicDetailsDto basicDetails = policyResponse.getBasicDetails();
								if("O".equals(basicDetails.getPartyType())) {
									policyDetails.setInsuredName(basicDetails.getBusinessName());
								} else {
									policyDetails.setInsuredName(Stream
											.of(basicDetails.getFirstName(), basicDetails.getMiddleName(),
													basicDetails.getLastName())
											.filter(name -> name != null && !name.isEmpty())
											.collect(Collectors.joining(" ")));
								}
							}
							if (policyResponse.getInsureds() != null) {
								List<MaximusInsuredDetailsDto> maximusInsuredDetailsDtoList = policyResponse.getInsureds()
										.getInsuredDetails();
								if (maximusInsuredDetailsDtoList != null && !maximusInsuredDetailsDtoList.isEmpty()) {
									for (MaximusInsuredDetailsDto maximusInsuredDetailsDto : maximusInsuredDetailsDtoList) {
										if (maximusInsuredDetailsDto.getInsuredInfo() != null) {
											MaximusInsuredInfoDto insuredInfo = maximusInsuredDetailsDto
													.getInsuredInfo();
											if("6622".equals(policyDetails.getProductCode())) {
												policyDetails.setSumInsured(insuredInfo.getRiskSumInsuredinTransactionCurrency());
											} else {
												policyDetails.setSumInsured(insuredInfo.getTotalSumInsured());
											}
										}
									}
								}
							}
							if(policyResponse.getAdditionalPolicyDetails() != null) {
								MaximusAdditionalPolicyDetailsDto additionalDetails = policyResponse.getAdditionalPolicyDetails();
								if("6621".equals(policyDetails.getProductCode())) {
									policyDetails.setSumInsured(additionalDetails.getBondSumInsured());
								}
							}
						}
					}
					LossDetailsDto lossDetails = claimDto.getLossDetails();
					if(lossDetails != null) {
						claimDetails.setHowLossOccured(lossDetails.getLossDetails());
						claimDetails.setLossEstmatedValue((lossDetails.getLossAmount() != null
								&& StringUtils.isNotBlank(lossDetails.getLossAmount())) ? lossDetails.getLossAmount()
										: lossDetails.getLossEstmatedValue());
					}
					claimDetails.setIntimationDate(DateUtils.convertStringToStringddMMMyyyy(misClaimDetails.getIntimationDate()));
					claimDetails.setSalvageStatus(CommonConstants.NA);
					claimDetails.setLossDate(DateUtils.convertStringToStringddMMMyyyy(misClaimDetails.getLossDate()));
					claimDetails.setRegistrationDate(DateUtils.convertStringToStringddMMMyyyy(misClaimDetails.getIntimationDate()));
					claimDetails.setLocationCode(misClaimDetails.getClaimbranch());
					claimDetails.setClaimNumber(misClaimDetails.getClaimNumber());
					claimDetails.setIntimationSource(claimDto.getUserId());
					if(misClaimDetails.getClaimParty() != null && !misClaimDetails.getClaimParty().isEmpty()) {
						for (MaximusClaimPartyDto claimPartyDto : misClaimDetails.getClaimParty()) {
							ClaimPartiesDetailsDto claimParty = new ClaimPartiesDetailsDto();
							claimParty.setStakeType(claimPartyDto.getStakeCode());
							claimParty.setPartyId(claimPartyDto.getPartyCode());
							claimParty.setPartyName(Stream
									.of(claimPartyDto.getFirstName(), claimPartyDto.getMiddleName(),
											claimPartyDto.getLastName())
									.filter(name -> name != null && !name.isEmpty()).collect(Collectors.joining(" ")));
							if(CommonConstants.POLICY_HOL.equals(claimPartyDto.getStakeCode())) {
								claimantDetails.setFirstName(claimPartyDto.getFirstName());
								claimantDetails.setMiddleName(claimPartyDto.getMiddleName());
								claimantDetails.setLastName(claimPartyDto.getLastName());
							}
							claimParties.add(claimParty);
						}
					}
					if(misClaimDetails.getClaimReserve() != null && !misClaimDetails.getClaimReserve().isEmpty()) {
						for (ClaimReserveDetailsDto claimReserveDto : misClaimDetails.getClaimReserve()) {
							ReserveDetailsDto reserveDetail = new ReserveDetailsDto();
							reserveDetail.setOutstandingReserveAmount(claimReserveDto.getPendingAmount());
							reserveDetail.setPartyCode(claimReserveDto.getReserveParty());
							reserveDetail.setReserveAmount(claimReserveDto.getReserveAmount());
							reserveDetail.setPartyType(claimReserveDto.getReserveStake());
							if(CommonConstants.POLICY_HOL.equals(claimReserveDto.getReserveStake())) {
								reserveDetail.setPartyName(policyDetails.getInsuredName());
								reserveDetail.setPartyCode(claimReserveDto.getReserveParty());
								reserveDetail.setReserveType(CommonConstants.LOSS);
								claimDetails.setReserveAmount(claimReserveDto.getReserveAmount());
								claimantDetails.setPartyCode(claimReserveDto.getReserveParty());
								claimantDetails.setSubType(claimReserveDto.getReserveStake());
							}
							reserveDetails.add(reserveDetail);
						}
					}
					if (misClaimDetails.getClaimAttribute() != null
							&& misClaimDetails.getClaimAttribute().getClaimAttributeDetails() != null
							&& !misClaimDetails.getClaimAttribute().getClaimAttributeDetails().isEmpty()) {
						for (ClaimAttributeDetailsDto claimAttrDtlsDto : misClaimDetails.getClaimAttribute().getClaimAttributeDetails()) {
							policyDetails.setLob(claimAttrDtlsDto.getStoredLOBCode());
						}
					}
					commonDto.setPolicyDetails(policyDetails);
					commonDto.setClaimDetails(claimDetails);
					commonDto.setClaimantDetails(claimantDetails);
					commonDto.setClaimParties(claimParties);
					commonDto.setReserveDetails(reserveDetails);
					claimRestService.saveClaimIntimation(commonDto, request);
				}
			}
		} catch (Exception e) {
			logger.error("Enter into ClaimServiceImpl misClaimIntimation Exception", e);
			e.printStackTrace();
		}
		logger.info("Enter into ClaimServiceImpl misClaimIntimation End...");	
	}
	
	@Async(value = "asyncExecutor")
	@Override
	public void sendNotification(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("Enter into ClaimServiceImpl sendNotification Start...");
		try {
			ClaimEntity claimEntity = claimRepository.findByClaimNumberAndIsActive(commonRequestDto.getClaimNumber(), CommonConstants.TRUE);
			Map<String, String> emailBodyMap = new HashMap<>();
			Map<String, String> smsBodyMap = new HashMap<>();
			emailBodyMap.put("$CLAIM_NO", NumericUtils.checkNull(commonRequestDto.getClaimNumber()));
			emailBodyMap.put("$CLM_NO", NumericUtils.checkNull(commonRequestDto.getClaimNumber()));
			smsBodyMap.put("$LINK", "https://rcsportal.bagicuat.bajajallianz.com");
			smsBodyMap.put("$REF_NO", NumericUtils.checkNull(commonRequestDto.getClaimNumber()));
//			if (commonRequestDto.getLocationCode() != null) {
				smsBodyMap.put("$GROUP_MAIL_ID", "");
//			}
			if(claimEntity != null) {
				emailBodyMap.put("$INS_NAME", NumericUtils.checkNull(claimEntity.getInsuredName()));
				emailBodyMap.put("$POLICY_NO", NumericUtils.checkNull(claimEntity.getPolicyNumber()));
				emailBodyMap.put("$INSURED_NAME", NumericUtils.checkNull(claimEntity.getInsuredName()));
				emailBodyMap.put("$LOSS_DATE", NumericUtils.checkNull(DateUtils.dateToStringFormatddMmYyyy(claimEntity.getLossDate())));
				emailBodyMap.put("$LOSS_DESC", NumericUtils.checkNull(claimEntity.getLossDetails()));
				emailBodyMap.put("$DOL_ACCIDENT", NumericUtils.checkNull(DateUtils.dateToStringFormatddMmYyyy(claimEntity.getLossDate())));
				emailBodyMap.put("$PIN_CODE", NumericUtils.checkNull(NumericUtils.convertIntegerToString(claimEntity.getPincode())));
				emailBodyMap.put("$STATE", NumericUtils.checkNull(claimEntity.getState()));
				emailBodyMap.put("$CITY", NumericUtils.checkNull(claimEntity.getCity()));
				emailBodyMap.put("$AREA", NumericUtils.checkNull(claimEntity.getArea()));
				emailBodyMap.put("$ESTIMATED_LOSS",
						NumericUtils.checkNull((claimEntity.getLossAmount() != null)
								? NumericUtils.roundOffvalues(claimEntity.getLossAmount())
								: NumericUtils.roundOffvalues(claimEntity.getLossEstimatedValue())));
				List<MobileNoDto> smsTo = new ArrayList<>();
				for (String num : List.of("9511261188", "9730343077", "7812862505")) {
					MobileNoDto mobileNoDto = new MobileNoDto();
					mobileNoDto.setMobileNo(num);
					smsTo.add(mobileNoDto);
				}
				commonRequestDto.setSmsTo(smsTo);
			}
			commonRequestDto.setEmailTo(List.of("arunkumar.d@fasoftwares.com", "shirish.patil@bajajallianz.co.in",
					"shivshankar.panage@bajajallianz.co.in", "dipali.gawde01@bajajallianz.co.in",
					"pratiksha.khedkar@bajajallianz.co.in"));
			commonRequestDto.setIsMaximusClaim(CommonConstants.TRUE);
			commonRequestDto.setEmailBodyMap(emailBodyMap);
			commonRequestDto.setSmsBodyMap(smsBodyMap);
			commonRequestDto.setAction(CommonConstants.CLAIMREGISTRATION);
 			claimRestService.sendNotification(commonRequestDto, request);
		} catch (Exception e) {
			logger.error("Enter into ClaimServiceImpl sendNotification Exception", e);
			e.printStackTrace();
		}
		logger.info("Enter into ClaimServiceImpl sendNotification End...");
		
	}

}
