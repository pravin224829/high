/**
 * 
 */
package com.fa.bajajallianz.cccp.nonmotor.keycloak.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

//import com.fa.comp.bagic.security.constants.SecurityConstants;
//import com.fa.comp.bagic.security.keycloak.config.filter.KeycloakAuthorizationFilter;
//import com.fa.comp.bagic.security.keycloak.config.filter.RestAuthenticationEntryPoint;

@EnableWebSecurity
@Configuration
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	RestAuthenticationEntryPoint authenticationEntryPoint;

//	@Value("${CORS_ORIGIN_URL}")
//	private String corsOrigin;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// http.cors().and().csrf().disable().authorizeRequests().antMatchers(HttpMethod.GET,
		// SecurityConstants.swaggerPathToSkip).permitAll();
		http.cors().and().csrf().disable().authorizeRequests().antMatchers("/").permitAll().antMatchers("/login")
				.permitAll().antMatchers(HttpMethod.GET, "/actuator/**").permitAll()
				.antMatchers(HttpMethod.GET, SecurityConstants.SWAGGERPATHTOSKIP).permitAll()
				.antMatchers(SecurityConstants.PATHTOSKIP).permitAll().and().authorizeRequests().anyRequest()
				.authenticated().and().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
				.exceptionHandling().authenticationEntryPoint(authenticationEntryPoint).and()
				.addFilterBefore(new KeycloakAuthorizationFilter(), UsernamePasswordAuthenticationFilter.class)
				.headers().cacheControl();
	}

	// @Bean
	// CorsConfigurationSource corsConfigurationSource() {
	//
	// CorsConfiguration configuration = new CorsConfiguration();
	// configuration.setAllowedOrigins(Arrays.asList("*"));
	// configuration.setAllowedMethods(Arrays.asList("GET", "POST"));
	// configuration.setExposedHeaders(Arrays.asList("auth-token", "auth"));
	// configuration.setMaxAge((long) 3600);
	// UrlBasedCorsConfigurationSource source = new
	// UrlBasedCorsConfigurationSource();
	// source.registerCorsConfiguration("/**", configuration);
	// return source;
	// }

	// @Bean
	// public FilterRegistrationBean filterRegistrationBean() {
	// FilterRegistrationBean filterRegistrationBean = new
	// FilterRegistrationBean();
	// KeycloakFilter tokenAuthenticationFilter = new KeycloakFilter();
	// filterRegistrationBean.setFilter(tokenAuthenticationFilter);
	// filterRegistrationBean.setEnabled(true);
	// return filterRegistrationBean;
	// }
}