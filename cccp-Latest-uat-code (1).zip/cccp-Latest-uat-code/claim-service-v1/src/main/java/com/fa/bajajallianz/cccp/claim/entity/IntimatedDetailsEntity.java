package com.fa.bajajallianz.cccp.claim.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "intimated_details")
public class IntimatedDetailsEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id", length = 20)
	private Long id;
	
	@Column(name = "name", length = 255)
	private String name;
	
	@Column(name = "identificationNumber", length = 100)
	private String identificationNumber;	
	
	@Column(name = "email", length = 100)
	private String email;
	
	@Column(name = "telephoneNumber", length = 20)
	private Long telephoneNumber;
	
	@Column(name = "mobileNumber", length = 20)
	private Long mobileNumber;
	
	@Column(name = "remarks", length = 1000)
	private String remarks;
		
	@Column(name = "is_active")
	private Boolean isActive;
	
	@Column(name = "created_by", length = 100)
	private String createdBy;
	
	@Column(name = "created_date")
	private Date createdDate;	
	
	@Column(name = "modified_by", length = 100)
	private String modifiedBy;
	
	@Column(name = "modified_date")
	private Date modifiedDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "claim_id")
	private ClaimEntity claimDetails;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIdentificationNumber() {
		return identificationNumber;
	}

	public void setIdentificationNumber(String identificationNumber) {
		this.identificationNumber = identificationNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getTelephoneNumber() {
		return telephoneNumber;
	}

	public void setTelephoneNumber(Long telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public ClaimEntity getClaimDetails() {
		return claimDetails;
	}

	public void setClaimDetails(ClaimEntity claimDetails) {
		this.claimDetails = claimDetails;
	}


	
}
