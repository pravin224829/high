/**
 * 
 */
package com.fa.bajajallianz.cccp.nonmotor.keycloak.security;

/**
 * @author Muruganandam
 *
 *         Version 1.0, Created Date:21-06-2020, Updated Date:21-06-2020
 */
public interface SecurityConstants {

	static String STATUS_ACTIVE = "ACTIVE";
	static String STATUS_INACTIVE = "INACTIVE";
	String[] PATHTOSKIP = {
			"/cccp/claim/api/healthCheck",
			"/cccp/config/master/api/fetchAPIUrlByCode",
			"/cccp/claim/api/saveRuntimeFields",
			"/cccp/claim/api/fetchRuntimeFields",
			"/cccp/claim/api/getUpdateClaimList",
			"/cccp/claim/api/getUDYAMClaimDetails"
			};
	String[] SWAGGERPATHTOSKIP = {
//			"/v2/api-docs", "/swagger-resources/**", "/swagger-ui.html**", "/swagger-ui.html/**",
//			"/css/**", "/js/**", "/doc**", "/webjars/**", "/favicon.ico", "/api/doc/**", "/csrf/**" 
	};

}
