package com.fa.bajajallianz.cccp.nonmotor.keycloak.security;

import org.springframework.security.core.AuthenticationException;

/**
 * Thrown if an JWT Token is expired.
 *
 * @author Muruganandam
 *
 *         Version 1.0, Created Date:21-06-2020, Updated Date:21-06-2020
 */
public class JwtExpiredTokenException extends AuthenticationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructs a <code>JwtExpiredTokenException</code> with the specified
	 * message.
	 *
	 * @param msg
	 *            the detail message
	 */
	public JwtExpiredTokenException(String msg) {
		super(msg);
	}

	/**
	 * Constructs a <code>JwtExpiredTokenException</code> with the specified
	 * message and root cause.
	 *
	 * @param msg
	 *            the detail message
	 * @param t
	 *            root cause
	 */
	public JwtExpiredTokenException(String msg, Throwable t) {
		super(msg, t);
	}
}
