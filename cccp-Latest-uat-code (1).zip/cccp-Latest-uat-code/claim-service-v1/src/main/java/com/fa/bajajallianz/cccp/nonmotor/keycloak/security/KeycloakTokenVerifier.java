/**
 * 
 */
package com.fa.bajajallianz.cccp.nonmotor.keycloak.security;

import java.util.ArrayList;
import java.util.List;


import org.apache.commons.lang3.StringUtils;
import org.keycloak.TokenVerifier;
import org.keycloak.common.VerificationException;
import org.keycloak.common.util.Time;
import org.keycloak.representations.AccessToken;
import org.keycloak.representations.AccessToken.Access;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * @author Muruganandam
 *
 *         Version 1.0, Created Date:21-06-2020, Updated Date:21-06-2020
 */
@Service
public class KeycloakTokenVerifier {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	public String preferredUsername = null;
	public List<String> authorities = null;

	public KeycloakTokenVerifier() {
	}

	public KeycloakTokenVerifier(String preferredUsername, List<String> authorities) {
		super();
		this.preferredUsername = preferredUsername;
		this.authorities = authorities;
	}

	public boolean isLoggedInKeycloak(String accessToken, String clientId) throws VerificationException {
		if (StringUtils.isBlank(accessToken)) {
			return false;
		}
		return !isTokenExpired(accessToken, clientId);
	}

	private boolean isTokenExpired(String accessToken, String clientId) {
		AccessToken token = null;

		try {
			token = TokenVerifier.create(accessToken, AccessToken.class).getToken();
		} catch (VerificationException e) {
			throw new JwtExpiredTokenException("JWT Token expired", e);
		}
		if (token != null) {
			// Date currentDate = new Date(Time.currentTime());
			// System.out.println("current Date:" + currentDate + "\t" +
			// Time.currentTime());

			// Date expDate = new Date(token.getExp());
			// System.out.println("expiry Date :" + expDate + "\t" +
			// token.getExp());
			boolean isExpiried = Time.currentTime() > token.getExp();
			if (token.isExpired()) {
				logger.error("User token is expired... " + accessToken + "\t" + isExpiried + "\t" + token.getExp());
				return true;
			}
			this.preferredUsername = token.getPreferredUsername();
			// Map<String, Access> resourceAccess = token.getResourceAccess();
			// authorities = new
			// ArrayList<>(resourceAccess.get(clientId).getRoles());
			Access realmAccess = token.getRealmAccess();
			if (realmAccess != null) {
				authorities = new ArrayList<>(realmAccess.getRoles());
			}
		}

		return false;
	}

//	public static KeycloakSecurityContext getKeycloakSecurityContextToken(HttpServletRequest httpServletRequest) {
//		KeycloakSecurityContext keycloakSecurityContext = (KeycloakSecurityContext) httpServletRequest
//				.getAttribute(KeycloakSecurityContext.class.getName());
//		return keycloakSecurityContext;
//	}

//	public static void main(String[] args) {
//
//	}
}
