/**
 * 
 */
package com.fa.bajajallianz.cccp.claim.restservice.Impl;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fa.bajajallianz.cccp.claim.repository.ClaimRepository;
import com.fa.bajajallianz.cccp.claim.restservice.ClaimRestService;
import com.fa.bajajallianz.cccp.claim.utils.CommonErrorMsg;
import com.fa.bajajallianz.cccp.claim.utils.CommonRequestUtil;
import com.fa.bajajallianz.cccp.claim.utils.PreAuthTokenUtils;
import com.fa.bajajallianz.cccp.common.dto.APIRequestDto;
import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsListDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimResponseDto;
import com.fa.bajajallianz.cccp.common.dto.CommonDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.SaveRegistrationClaimRequestDto;
import com.fa.bajajallianz.cccp.common.dto.SaveRegistrationClaimResponse;
import com.fa.bajajallianz.cccp.common.dto.TokenResponseDto;
import com.fa.bajajallianz.cccp.common.dto.UserDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.DateUtils;
import com.fa.bajajallianz.cccp.common.utils.ErrorCodeConstants;
import com.fa.bajajallianz.cccp.common.utils.NumericUtils;
import com.fa.bajajallianz.cccp.mis.common.dto.CommonMisResponseDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClaimSaveDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClmIntimationRespDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusInsuredDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusSinglePolicySearchDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusTokenDto;

/**
 * @author arunkumar
 *
 */
@Service
public class ClaimRestServiceImpl implements ClaimRestService {

	@Autowired
	private Environment environment;

	private static final Logger logger = LoggerFactory.getLogger(ClaimRestServiceImpl.class);

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	PreAuthTokenUtils preAuthTokenUtils;
	
	@Autowired
	private ClaimRepository claimRepo;

	@Autowired
	private CommonErrorMsg commonErrorMsg;
	
	@Autowired
//	private NotifyRepository notifyRepository;

	public String getProperty() {
		return environment.getProperty("CONFIG_API_URL");
	}

	@Override
	public SaveRegistrationClaimResponse saveRegistrationClaim(ClaimResponseDto dto, HttpServletRequest request) {
		logger.info("ClaimRestServiceImpl--saveRegistrationClaim--Start");
		SaveRegistrationClaimResponse saveRegistrationClaimResponse = new SaveRegistrationClaimResponse();
		String baseUrl = null;
		String message = null;
		String errorMessage = null;
		SaveRegistrationClaimRequestDto saveRegistrationClaimRequestDto = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			saveRegistrationClaimRequestDto = mapClaimTosaveRegistrationClaimDto(dto);
			TokenResponseDto authResponse = preAuthTokenUtils.getPreAuthToken();
			baseUrl = CommonUtils.fetchApi("SAVEREGISTRATIONCLAIM", getProperty());
//			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (authResponse != null) {
				if (authResponse.getTokenBeanObj() != null) {
					headers.add(CommonConstants.AUTHORIZATION, authResponse.getTokenBeanObj().getPreAuthToken());
				}
			}
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			logger.info("saveRegistrationClaim --->"
					+ NumericUtils.convertPojoClassToString(saveRegistrationClaimRequestDto));
			HttpEntity<SaveRegistrationClaimRequestDto> entity = new HttpEntity<SaveRegistrationClaimRequestDto>(
					saveRegistrationClaimRequestDto, headers);
			saveRegistrationClaimResponse = restTemplate.exchange(baseUrl, HttpMethod.POST, entity,
					new ParameterizedTypeReference<SaveRegistrationClaimResponse>() {
					}, headers).getBody();
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("ClaimRestServiceImpl-saveRegistrationClaim-end", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("ClaimRestServiceImpl-saveRegistrationClaim-end", e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-MasterRestServiceImpl-saveRegistrationClaim-", e);
		} finally {
			CommonRequestUtil.saveApiLog(request,
					NumericUtils.convertPojoClassToString(saveRegistrationClaimRequestDto), "saveRegistrationClaim",
					"saveClaimDetails", "saveClaimDetails", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(saveRegistrationClaimResponse), "", baseUrl, headers);
		}
		logger.info("ClaimRestServiceImpl-saveRegistrationClaim-end");
		return saveRegistrationClaimResponse;
	}

	private SaveRegistrationClaimRequestDto mapClaimTosaveRegistrationClaimDto(ClaimResponseDto dto) {
		logger.info("ClaimRestServiceImpl-mapClaimTosaveRegistrationClaimDto-Start");
		SaveRegistrationClaimRequestDto saveRegistrationClaimRequestDto = new SaveRegistrationClaimRequestDto();
		try {
			if (dto.getClaimDetails() != null) {
				saveRegistrationClaimRequestDto.setUserId(dto.getClaimDetails().getUserId());
				saveRegistrationClaimRequestDto.setRoleCode(dto.getClaimDetails().getRoleCode());
				saveRegistrationClaimRequestDto.setAgentCode(dto.getClaimDetails().getImdCode());
				saveRegistrationClaimRequestDto.setClaimIntimatedDto(dto.getClaimDetails().getIntimatedDetails());
				saveRegistrationClaimRequestDto.setBankDetailsDto(dto.getClaimDetails().getBankDetails());
				saveRegistrationClaimRequestDto.setInsuredDetails(dto.getClaimDetails().getInsuredDetails());
				saveRegistrationClaimRequestDto.setLossDetailsDto(dto.getClaimDetails().getLossDetails());
			}
		} catch (Exception e) {
			logger.error("ClaimRestServiceImpl-mapClaimTosaveRegistrationClaimDto-end", e);
		}
		logger.info("ClaimRestServiceImpl-mapClaimTosaveRegistrationClaimDto-End");
		return saveRegistrationClaimRequestDto;
	}

	@Override
	public CommonResponseDto<List<ClaimDetailsListDto>> searchClaimDetails(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonResponseDto<List<ClaimDetailsListDto>> response = new CommonResponseDto<List<ClaimDetailsListDto>>();
		logger.info("ClaimRestServiceImpl--searchClaimDetails--Start");
		String baseUrl = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			baseUrl = CommonUtils.fetchApi("SEARCHCLAIMLIST", getProperty());
//			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			HttpEntity<CommonRequestDto> entity = new HttpEntity<CommonRequestDto>(commonRequestDto, headers);
			response = restTemplate.exchange(baseUrl, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<List<ClaimDetailsListDto>>>() {
					}, headers).getBody();
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-searchClaimDetails", e);
		} finally {
			CommonRequestUtil.saveApiLog(request,
					NumericUtils.convertPojoClassToString(commonRequestDto), "searchClaimDetails",
					"searchClaimDetails", "searchClaimDetails", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(response), "", baseUrl, headers);
		}
		logger.info("ClaimRestServiceImpl--searchClaimDetails--End");
		return response;
	}

	@Override
	public UserDto fetchUserProfile(ClaimDetailsDto claimDto, HttpServletRequest request) {
		UserDto userDto = new UserDto();
		logger.info("ClaimServiceImpl--searchPolicyList--Start");
		try {
			APIRequestDto requestDto = new APIRequestDto();
			String payload1 = "?payload=" + claimDto.getUserId();
		 // String url = env.getProperty("SEARCHCLAIMDETAILS") + payload1;
			String url = "http://localhost/cccp/config/user/api/fetchUserProfile" + payload1;
			logger.info("api request: " + url + payload1);
//			requestDto.setApiUrl((url + payload1));
			requestDto.setApiUrl(url);
			requestDto.setRequestMethod("GET");
			requestDto.setContentType("application/json");
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			System.err.println(url);
			claimDto = restTemplate
					.exchange(url, HttpMethod.GET, null, new ParameterizedTypeReference<ClaimDetailsDto>() {
					}, headers).getBody();

			if (userDto != null) {
				userDto.setUserId(claimDto.getUserId());
				JSONObject jsnobject = new JSONObject(userDto);
				System.err.println("JSON Object");
				System.out.println(jsnobject);

				JSONArray jsonArray = jsnobject.getJSONArray("data");
				System.err.println("JSON Array");
				System.out.println(jsonArray);
//		        claimdto1.add(jsonArray);
//				PolicyResponseDto1.add(obj);
//				claimdto1.add(dto);

//				commonResponseDto.setResponseData(dto);
			}

		} catch (Exception e) {
			logger.error("Exception-ClaimRepository-searchPolicyList", e);
//			commonResponseDto.setStatus(CommonConstants.ERROR);
//			commonResponseDto.setError(e.getMessage());
		}
		logger.info("ClaimRepository--searchPolicyList--End");
		return userDto;
	}

	@Override
	public ClaimDetailsDto fetchClaimDetails(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		ClaimDetailsDto claimDetailsDto = new ClaimDetailsDto();
		logger.info("Enter into ClaimRestServiceImpl -fetchClaimDetails - Start");
		try {
			String url = CommonUtils.fetchApi("FETCHCLAIMDETAILS", getProperty());
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url).queryParam("claimNumber",
					commonRequestDto.getClaimNumber());
			claimDetailsDto = restTemplate.exchange(uriBuilder.toUriString(), HttpMethod.GET, null,
					new ParameterizedTypeReference<ClaimDetailsDto>() {
					}, headers).getBody();
		} catch (Exception e) {
			logger.error("Exception--- ClaimServiceImpl--fetchClaimDetails---", e);
			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-fetchClaimDetails", "fetchClaimDetails", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("Enter into ClaimRestServiceImpl -fetchClaimDetails - End");
		return claimDetailsDto;
	}
	@Override
	public MaximusClmIntimationRespDto saveMaximusClaimIntimation(MaximusClaimSaveDto commonRequestDto,
			HttpServletRequest request) {
		MaximusClmIntimationRespDto resDto = new MaximusClmIntimationRespDto();
		logger.info("Enter into CommonRestTemplateServiceImpl saveMaximusClaimIntimation Start");
		String baseUrl = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			baseUrl = CommonUtils.fetchApi("CLAIMINTIMATION", getProperty());
			logger.info("CLAIMINTIMATION -- ", baseUrl);
			commonRequestDto.setPolRiskCovList(CommonConstants.FLEXA);
			commonRequestDto.setRiskSerialNo(CommonConstants.ONE_STRING);
			MaximusSinglePolicySearchDto policySearchDto = getSavedQuote(commonRequestDto.getStrPolicyQuoteNumber(), request);
			if(policySearchDto != null) {
				if(policySearchDto.getBasicPolicyDetails() != null) {
					commonRequestDto.setStrPolicyHolderCode(policySearchDto.getBasicPolicyDetails().getStrPolicyHolderCode());
					commonRequestDto.setPolicyBranch(policySearchDto.getBasicPolicyDetails().getStrPolicyBranchName());
				}
				if(policySearchDto.getInsureds() != null) {
					if(policySearchDto.getInsureds().getInsuredDetails() != null && !policySearchDto.getInsureds().getInsuredDetails().isEmpty() ) {
						for (MaximusInsuredDetailsDto dto : policySearchDto.getInsureds().getInsuredDetails()) {
							if(dto != null && dto.getInsuredInfo() != null) {
								commonRequestDto.setRiskCode(dto.getInsuredInfo().getStrRiskCode());
								commonRequestDto.setRiskDesc(dto.getInsuredInfo().getStrRiskCode());
							}
						}
					}
				}
			}
			String responseStr = claimRepo.getCommonValueByKey(ErrorCodeConstants.VALUES5, CommonConstants.TRUE);
			if(responseStr != null) {
				JSONObject obj = new JSONObject(responseStr);
				if (commonRequestDto.getStrProductCode() != null
						&& StringUtils.isNotEmpty(commonRequestDto.getStrProductCode())) {
					if (obj.has(commonRequestDto.getStrProductCode())) {
						JSONObject obj2 = new JSONObject(obj.get(commonRequestDto.getStrProductCode()).toString());
						//commonRequestDto.setClaimCause(obj2.optString("claimCause", ""));
						commonRequestDto.setLossNature(obj2.optString("lossNature", ""));
						commonRequestDto.setClaimType(obj2.optString("claimType", ""));
						commonRequestDto.setStrLOB(obj2.optString("strLOB", ""));
						commonRequestDto.setPolRiskCovList(obj2.optString("polRiskCovList", ""));
						commonRequestDto.setRiskCode(obj2.optString("riskCode", ""));
						commonRequestDto.setRiskDesc(obj2.optString("riskDesc", ""));
						commonRequestDto.setClaimBranch(obj2.optString("claimBranch", ""));
					}
				}
			}
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			HttpEntity<MaximusClaimSaveDto> entity = new HttpEntity<>(commonRequestDto, headers);
			resDto = restTemplate.exchange(baseUrl, HttpMethod.POST, entity,
					new ParameterizedTypeReference<MaximusClmIntimationRespDto>() {
					}, headers).getBody();
		} catch (Exception e) {
			logger.error("Enter into ClaimRestServiceImpl saveMaximusClaimIntimation Exception", e);
			e.printStackTrace();
			CommonRequestUtil.errorInfo(request, "", "ClaimRestServiceImpl", "saveMaximusClaimIntimation", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		} finally {
			CommonRequestUtil.saveApiLog(request, NumericUtils.convertPojoClassToString(commonRequestDto),
					"saveMaximusClaimIntimation", "saveMaximusClaimIntimation", "saveMaximusClaimIntimation", message,
					errorMessage, "", "", NumericUtils.convertPojoClassToString(resDto), "", baseUrl, headers);
		}
		logger.info("Enter into ClaimRestServiceImpl saveMaximusClaimIntimation End");
		return resDto;
	}
	
	@Override
	public MaximusSinglePolicySearchDto getSavedQuote(String policyNo, HttpServletRequest request) {
		logger.info("Enter into ClaimRestServiceImpl getSavedQuote Start...");
		MaximusSinglePolicySearchDto responseDto = new MaximusSinglePolicySearchDto();
		String message = null;
		String code = null;
		String errorMessage = null;
		String baseUrl = null;
		HttpHeaders headers = new HttpHeaders();
		try {
//			MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getMaximusToken();
//			baseUrl = CommonUtils.fetchApi("GETSAVEDQUOTE", getProperty());
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
//			if (maximusResponseToken != null && maximusResponseToken.getAccess_token() != null) {
//				headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
//			}
			headers.set(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.set(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			//UAT - Comment for PROD Start
			//List<String> arrayList = Arrays.asList("6621", "5002", "5003", "5004", "5007", "5008", "5009", "6623","4070","6622");
			List<String> arrayList =claimRepo.findByActiveProductCode();
			//List<String> arrayList = Arrays.asList("6621", "5002", "5003", "5004", "5007", "5008", "5009", "6623","6622"); // 16 Jan 25 - Cattle RCS prod deployment

			String[] splitted = policyNo.split("-");
			if(splitted != null && splitted.length > 1 && arrayList.contains(splitted[1])) {
				MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getMaximusToken();
				if (maximusResponseToken != null && maximusResponseToken.getAccess_token() != null) {
					headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
				}
				baseUrl = CommonUtils.fetchApi("VALUES6", getProperty());
				code = "VALUES6";
			} else {
				MaximusTokenDto maximusResponseToken = preAuthTokenUtils.getSITMaximusToken();
				if (maximusResponseToken != null && maximusResponseToken.getAccess_token() != null) {
					headers.add(CommonConstants.AUTHORIZATION, "Bearer " + maximusResponseToken.getAccess_token());
				}
				baseUrl = CommonUtils.fetchApi("GETSAVEDQUOTE", getProperty());
				code = "GETSAVEDQUOTE";
			}
			//UAT - Comment for PROD End
			HttpEntity<String> entity = new HttpEntity<>(headers);
			logger.info("url: ", baseUrl);
			ResponseEntity<MaximusSinglePolicySearchDto> responseEntity = restTemplate.exchange(baseUrl, HttpMethod.GET,
					entity, MaximusSinglePolicySearchDto.class, policyNo);
			responseDto = responseEntity.getBody();
			logger.info("Maximus json Response: " + NumericUtils.convertPojoClassToJSONString(responseDto));
		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-getSavedQuote-HttpClientErrorException", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-getSavedQuote-HttpServerErrorException", e);
		} catch (ResourceAccessException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-getSavedQuote-ResourceAccessException", e);
		} catch (JSONException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-getSavedQuote-JSONException", e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-ClaimRestServiceImpl-getSavedQuote-Exception-end", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, policyNo, "getSavedQuote",
					code, "getSavedQuote", message, errorMessage, "", "",
					NumericUtils.convertPojoClassToString(responseDto), "", baseUrl, headers);
		}
		logger.info("Enter into ClaimRestServiceImpl getSavedQuote End...");
		return responseDto;
	}

	@Override
	public CommonMisResponseDto<String> fetchMisClaimDetails(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonMisResponseDto<String> commonResponseDto = new CommonMisResponseDto<>();
		logger.info("Enter into ClaimServiceImpl fetchMisClaimDetails Start...");
		try {
			String url = CommonUtils.fetchApi("FETCHMISCLAIMDETAILS", getProperty());
			//String url ="http://localhost:8892/cccp/common/claim/api/getMisClaimDetails";
			logger.info("FETCHMISCLAIMDETAILS -- ", url);
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			logger.info("fetchMisClaimDetails --->" + NumericUtils.convertPojoClassToString(commonRequestDto));
			HttpEntity<CommonRequestDto> entity = new HttpEntity<>(commonRequestDto, headers);
			commonResponseDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonMisResponseDto<String>>() {
					}, headers).getBody();
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setStatusCode(CommonConstants.ONE_STRING);
			logger.error("Exception-RestTemplateServiceImpl fetchMisClaimDetails - Exception", e);
		} 
		logger.info("Enter into ClaimServiceImpl fetchMisClaimDetails End...");
		return commonResponseDto;
	}

	@Override
	public ApplicationErrorDto saveClaimIntimation(CommonDto commonDto, HttpServletRequest request) {
		ApplicationErrorDto applicationErrorDto = new ApplicationErrorDto();
		logger.info("Enter into ClaimRestServiceImpl saveClaimIntimation Start...");
		try {
			String url = CommonUtils.fetchApi("MISCLAIMINTIMATION", getProperty());
			logger.info("MISCLAIMINTIMATION -- ", url);
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			logger.info("claim saveClaimIntimation --->" + NumericUtils.convertPojoClassToString(commonDto));
			HttpEntity<CommonDto> entity = new HttpEntity<>(commonDto, headers);
			applicationErrorDto = restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<ApplicationErrorDto>() {
					}, headers).getBody();
			logger.info("Response saveClaimIntimation --->" + NumericUtils.convertPojoClassToString(applicationErrorDto));
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception-ClaimRestServiceImpl saveClaimIntimation - Exception", e);
		} 
		
		logger.info("Enter into ClaimRestServiceImpl saveClaimIntimation End...");
		return applicationErrorDto;
	}

	@Override
	public void sendNotification(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("Enter into ClaimRestServiceImpl sendNotification Start...");
		try {
			String url = CommonUtils.fetchApi("SENDNOTIFICATION", getProperty());
			logger.info("SENDNOTIFICATION -- ", url);
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			logger.info("sendNotification --->" + NumericUtils.convertPojoClassToString(commonRequestDto));
			HttpEntity<CommonRequestDto> entity = new HttpEntity<>(commonRequestDto, headers);
			restTemplate.exchange(url, HttpMethod.POST, entity,
					new ParameterizedTypeReference<CommonResponseDto<String>>() {
					}, headers).getBody();
		} catch (Exception e) {
			logger.error("Enter into ClaimRestServiceImpl sendNotification Exception...", e);
			e.printStackTrace();
		}
		logger.info("Enter into ClaimRestServiceImpl sendNotification End...");
	}

}
