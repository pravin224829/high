package com.fa.bajajallianz.cccp.claim.entity;

import java.io.Serializable;
/*
 * manibharathi 
 */
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

@Entity
@Table(name = "claim_details")
public class ClaimEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name = "id", length = 20, nullable = false)
	private Long id;

	@Column(name = "claim_ref_no", length = 30, unique = true)
	private String claimRefNo;

	@Column(name = "policy_number", length = 50)
	private String policyNumber;

	@Column(name = "insured_mobile_mumber", length = 20)
	private Long insuredMobileNumber;

	@Column(name = "insured_Mail", length = 100)
	private String insuredMail;

	@Column(name = "loss_date")
	private Date lossDate;

	@Column(name = "loss_time", length = 30)
	private Date lossTime;

	@Column(name = "loss_details", length = 1000)
	private String lossDetails;

	@Column(name = "loss_Address", length = 300)
	private String lossAddress;

	@Column(name = "land_mark", length = 200)
	private String landMark;

	@Column(name = "loss_account", length = 10)
	private Double lossAccount;
	
	@Column(name = "loss_amount", length = 10)
	private Double lossAmount;

	@Column(name = "pincode")
	private Integer pincode;

	@Column(name = "state", length = 100)
	private String state;

	@Column(name = "city", length = 100)
	private String city;

	@Column(name = "area", length = 100)
	private String area;

	@Column(name = "area_claim_behalf_offI_insure", length = 10)
	private String areaClaimBehalfOffInsure;

	@Column(name = "section", length = 100)
	private String section;

	@Column(name = "cause_off_Loss", length = 100)
	private String causeOffLoss;

	@Column(name = "notification_date")
	private Date notificationDate;

	@Column(name = "claim_notified_by", length = 100)
	private String claimNotifiedBy;

	@Column(name = "loss_description", length = 1000)
	private String lossDescription;

	@Column(name = "goods_damaged_details", length = 100)
	private String goodsDamagedDetails;

	@Column(name = "loss_estimated_value", length = 100)
	private Double lossEstimatedValue;

	@Column(name = "invoice_number", length = 50)
	private String invoiceNumber;

	@Column(name = "invoice_date")
	private Date invoiceDate;

	@Column(name = "bl_rr_lr_awb_no", length = 50)
	private String blRrLrAwbNo;

	@Column(name = "lorry_receipt_date")
	private Date lorryReceiptDate;

	@Column(name = "journey_from", length = 100)
	private String journeyFrom;

	@Column(name = "journey_to", length = 100)
	private String journeyTo;

	@Column(name = "consignee_name", length = 100)
	private String consigneeName;

	@Column(name = "consignee_address", length = 300)
	private String consigneeAddress;

	@Column(name = "consignee_phone_no", length = 20)
	private String consigneePhoneNo;

	@Column(name = "claim_servicing_Office", length = 100)
	private String claimServicingOffice;

	@Column(name = "claim_number", length = 50)
	private String claimNumber;

	@Column(name = "is_Active")
	private Boolean isActive;

	@Column(name = "created_date", length = 300)
	private Date createdDate;

	@Column(name = "created_by", length = 100)
	private String createdBy;

	@Column(name = "modified_by", length = 100)
	private String modifiedBy;

	@Column(name = "modified_date", length = 100)
	private Date modifiedDate;

	@Column(name = "insured_name", length = 255)
	private String insuredName;

	@Column(name = "is_doc_uploaded")
	private Boolean isDocUploaded;

	@Column(name = "is_claim_updated")
	private Boolean isClaimUpdated;
	
	@Column(name = "imd_channel", length = 50)
	private String imdChannel;
	
	@Column(name = "product_name", length = 255)
	private String productName;
	
	@Column(name = "product_code", length = 100)
	private String productCode;
	
	@Column(name = "sum_insured", length = 100)
	private Long sumInsured;
	
	@Column(name = "remarks", length = 300)
	private String remarks;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "claimDetails", cascade = CascadeType.ALL)
	@OrderBy("id")
	private List<BankEntity> bankDetails;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "claimDetails", cascade = CascadeType.ALL)
	@OrderBy("id")
	private List<IntimatedDetailsEntity> intimatedDetails;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "claimDetails", cascade = CascadeType.ALL)
	@OrderBy("id")
	private List<AdditionalDetailsEntity> additionalDetails;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "claimDetails", cascade = CascadeType.ALL)
	@OrderBy("id")
	private List<RunTimeFieldsValueEntity> runTimeFields;

	public List<AdditionalDetailsEntity> getAdditionalDetails() {
		return additionalDetails;
	}

	public void setAdditionalDetails(List<AdditionalDetailsEntity> additionalDetails) {
		this.additionalDetails = additionalDetails;
	}

	public String getClaimRefNo() {
		return claimRefNo;
	}

	public void setClaimRefNo(String claimRefNo) {
		this.claimRefNo = claimRefNo;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Long getInsuredMobileNumber() {
		return insuredMobileNumber;
	}

	public void setInsuredMobileNumber(Long insuredMobileNumber) {
		this.insuredMobileNumber = insuredMobileNumber;
	}

	public String getInsuredMail() {
		return insuredMail;
	}

	public void setInsuredMail(String insuredMail) {
		this.insuredMail = insuredMail;
	}

	public Date getLossDate() {
		return lossDate;
	}

	public void setLossDate(Date lossDate) {
		this.lossDate = lossDate;
	}

	public Date getLossTime() {
		return lossTime;
	}

	public void setLossTime(Date lossTime) {
		this.lossTime = lossTime;
	}

	public String getLossDetails() {
		return lossDetails;
	}

	public void setLossDetails(String lossDetails) {
		this.lossDetails = lossDetails;
	}

	public String getLossAddress() {
		return lossAddress;
	}

	public void setLossAddress(String lossAddress) {
		this.lossAddress = lossAddress;
	}

	public String getLandMark() {
		return landMark;
	}

	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}

	public Double getLossAccount() {
		return lossAccount;
	}

	public void setLossAccount(Double lossAccount) {
		this.lossAccount = lossAccount;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getAreaClaimBehalfOffInsure() {
		return areaClaimBehalfOffInsure;
	}

	public void setAreaClaimBehalfOffInsure(String areaClaimBehalfOffInsure) {
		this.areaClaimBehalfOffInsure = areaClaimBehalfOffInsure;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getCauseOffLoss() {
		return causeOffLoss;
	}

	public void setCauseOffLoss(String causeOffLoss) {
		this.causeOffLoss = causeOffLoss;
	}

	public Date getNotificationDate() {
		return notificationDate;
	}

	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}

	public String getClaimNotifiedBy() {
		return claimNotifiedBy;
	}

	public void setClaimNotifiedBy(String claimNotifiedBy) {
		this.claimNotifiedBy = claimNotifiedBy;
	}

	public String getLossDescription() {
		return lossDescription;
	}

	public void setLossDescription(String lossDescription) {
		this.lossDescription = lossDescription;
	}

	public String getGoodsDamagedDetails() {
		return goodsDamagedDetails;
	}

	public void setGoodsDamagedDetails(String goodsDamagedDetails) {
		this.goodsDamagedDetails = goodsDamagedDetails;
	}

	public Double getLossEstimatedValue() {
		return lossEstimatedValue;
	}

	public void setLossEstimatedValue(Double lossEstimatedValue) {
		this.lossEstimatedValue = lossEstimatedValue;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getBlRrLrAwbNo() {
		return blRrLrAwbNo;
	}

	public void setBlRrLrAwbNo(String blRrLrAwbNo) {
		this.blRrLrAwbNo = blRrLrAwbNo;
	}

	public Date getLorryReceiptDate() {
		return lorryReceiptDate;
	}

	public void setLorryReceiptDate(Date lorryReceiptDate) {
		this.lorryReceiptDate = lorryReceiptDate;
	}

	public String getJourneyFrom() {
		return journeyFrom;
	}

	public void setJourneyFrom(String journeyFrom) {
		this.journeyFrom = journeyFrom;
	}

	public String getJourneyTo() {
		return journeyTo;
	}

	public void setJourneyTo(String journeyTo) {
		this.journeyTo = journeyTo;
	}

	public String getConsigneeName() {
		return consigneeName;
	}

	public void setConsigneeName(String consigneeName) {
		this.consigneeName = consigneeName;
	}

	public String getConsigneeAddress() {
		return consigneeAddress;
	}

	public void setConsigneeAddress(String consigneeAddress) {
		this.consigneeAddress = consigneeAddress;
	}

	public String getConsigneePhoneNo() {
		return consigneePhoneNo;
	}

	public void setConsigneePhoneNo(String consigneePhoneNo) {
		this.consigneePhoneNo = consigneePhoneNo;
	}

	public String getClaimServicingOffice() {
		return claimServicingOffice;
	}

	public void setClaimServicingOffice(String claimServicingOffice) {
		this.claimServicingOffice = claimServicingOffice;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<BankEntity> getBankDetails() {
		return bankDetails;
	}

	public void setBankDetails(List<BankEntity> bankDetails) {
		this.bankDetails = bankDetails;
	}

	public List<IntimatedDetailsEntity> getIntimatedDetails() {
		return intimatedDetails;
	}

	public void setIntimatedDetails(List<IntimatedDetailsEntity> intimatedDetails) {
		this.intimatedDetails = intimatedDetails;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public Boolean getIsDocUploaded() {
		return isDocUploaded;
	}

	public void setIsDocUploaded(Boolean isDocUploaded) {
		this.isDocUploaded = isDocUploaded;
	}

	public Boolean getIsClaimUpdated() {
		return isClaimUpdated;
	}

	public void setIsClaimUpdated(Boolean isClaimUpdated) {
		this.isClaimUpdated = isClaimUpdated;
	}

	public String getImdChannel() {
		return imdChannel;
	}

	public void setImdChannel(String imdChannel) {
		this.imdChannel = imdChannel;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	public Long getSumInsured() {
		return sumInsured;
	}

	public void setSumInsured(Long sumInsured) {
		this.sumInsured = sumInsured;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Double getLossAmount() {
		return lossAmount;
	}

	public void setLossAmount(Double lossAmount) {
		this.lossAmount = lossAmount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public List<RunTimeFieldsValueEntity> getRunTimeFields() {
		return runTimeFields;
	}

	public void setRunTimeFields(List<RunTimeFieldsValueEntity> runTimeFields) {
		this.runTimeFields = runTimeFields;
	}
	
	

}
