/**
 * 
 */
package com.fa.bajajallianz.cccp.claim.home.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fa.bajajallianz.cccp.claim.home.dto.FlashMessageDetailsDto;
import com.fa.bajajallianz.cccp.claim.home.entity.FlashMessageDetailsEntity;
import com.fa.bajajallianz.cccp.claim.home.repository.FlashMessageDetailsRepository;
import com.fa.bajajallianz.cccp.claim.home.service.HomeService;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;

/**
 * @author fasoftwares
 *
 */

@Service
public class HomeServiceImpl implements HomeService {


}
