package com.fa.bajajallianz.cccp.claim.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.claim.entity.RunTimeFieldsEntity;

@Repository
public interface RuntimeFieldsRepository extends JpaRepository<RunTimeFieldsEntity, Long>{

	RunTimeFieldsEntity findByPartnerIdAndPolicyNumberAndFieldCode(String partnerId, String policyNumber,
			String fieldCode);

	List<RunTimeFieldsEntity> findByPolicyNumberAndIsActive(String policyNumber, Boolean true1);

	List<RunTimeFieldsEntity> findByPartnerIdAndPolicyNumberOrderById(String partnerId, String policyNumber);

	List<RunTimeFieldsEntity> findByPolicyNumberOrderById(String policyNumber);

	RunTimeFieldsEntity findByPolicyNumberAndFieldCode(String policyNumber, String fieldCode);

	List<RunTimeFieldsEntity> findByIsActiveAndPolicyNumberOrderByOrderNoAsc(Boolean true1, String policyNumber);

}
