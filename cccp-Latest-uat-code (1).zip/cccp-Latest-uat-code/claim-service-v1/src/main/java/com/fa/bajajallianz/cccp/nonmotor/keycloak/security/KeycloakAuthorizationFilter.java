/**
* 
*/
package com.fa.bajajallianz.cccp.nonmotor.keycloak.security;

/**
 * @author Muruganandam
 *
 *         Version 1.0, Created Date:21-06-2020, Updated Date:21-06-2020
 */
import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.commons.codec.binary.Base64;
import org.json.JSONObject;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.keycloak.TokenVerifier;
import org.keycloak.representations.AccessToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;

import com.fa.bajajallianz.cccp.common.dto.KeycloakPropertyDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;

//import com.fa.comp.bagic.security.keycloak.dto.KeycloakPropertyDto;

//import com.fa.comp.bagic.hospitalportal.constants.Constants;
//import com.fa.comp.bagic.hospitalportal.utils.LoadKeycloakProperties;
//import com.fa.comp.bagic.security.constants.SecurityConstants;
//import com.fa.comp.bagic.security.keycloak.config.token.KeycloakTokenVerifier;
//import com.fa.comp.bagic.security.keycloak.dto.KeycloakPropertyDto;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;

public class KeycloakAuthorizationFilter extends OncePerRequestFilter {

	@Autowired
	private Environment environment;

	protected final Logger logger = LoggerFactory.getLogger(getClass());

//	@Value("${CORS_ORIGIN_URL}")
//	private String corsOrigin;

	private final String AUTH = "auth";
	private final String AUTHORIZATION = "Authorization";
	private final String PREFIX = "Bearer ";
	private final String SECRET = "mySecretKey";

	private static final String HEADER_PREFIX = "Bearer ";

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		try {
			logger.info("KeycloakAuthorizationFilter-doFilterInternal-Start");
			logger.info("KeycloakAuthorizationFilter-doFilterInternal-Token Authorization "
					+ request.getHeader("Authorization"));
			logger.info("KeycloakAuthorizationFilter-doFilterInternal-Token auth " + request.getHeader("auth"));
//			logger.info("environment.getProperty(\"ISSIT\") " + environment.getProperty("ISSIT"));
			if (CommonConstants.TRUE) {
				KeycloakPropertyDto loadKeycloakProperties = loadKeycloakProperties();
				List<String> doFilter = doFilter(request, response, filterChain);
				logger.info("doFilter : {} " + doFilter);
				String isValidate = "";
				logger.info("Logging Request  {} : {} " + request.getRequestURL());
				if (doFilter != null && doFilter.size() > 0) {
					isValidate = doFilter.get(0);
				}
				logger.info("isValidate : {} " + isValidate);

				if (StringUtils.isNotBlank(isValidate) && isValidate.equalsIgnoreCase("Validate")
						&& doFilter.size() == 1) {
					if (checkJWTToken(request, response)) {
						KeycloakTokenVerifier KeycloakTokenVerifier = new KeycloakTokenVerifier();
//					Claims claims1 = validateToken(request);
//					System.out.println("claims1 " + claims1);
						logger.info("preferredUsername : {} " + KeycloakTokenVerifier.preferredUsername);
						boolean claims = false;
						claims = KeycloakTokenVerifier.isLoggedInKeycloak(extractToken(request),
								loadKeycloakProperties.getClientId());

						String[] split_string = extractToken(request).split("\\.");
						if(split_string.length > 0) {
							String base64EncodedHeader = split_string[0];
							Base64 base64Url = new Base64(true);
							String header = new String(base64Url.decode(base64EncodedHeader));
							JSONObject jsonObject = new JSONObject(header);
							String jsonObject3 = jsonObject.get("alg").toString();
							logger.info("jsonObject3 " + jsonObject3);
							if (jsonObject3 != null &&  CommonConstants.RS256.equals(jsonObject3) ) {
								
							}else {
								throw new AuthenticationServiceException("Token Algorithm must be RS256!");
							}
							logger.info("split_string --->" + split_string.length);
							if(split_string.length > 2) {
								
							}else {
								throw new AuthenticationServiceException("Token signature must not be blank!");
							}
						}
						
						Principal userPrincipal = request.getUserPrincipal();
						AccessToken token = TokenVerifier.create(extractToken(request), AccessToken.class).getToken();
						logger.info("token.getPreferredUsername() " + token.getPreferredUsername());

						String username = KeycloakTokenVerifier.preferredUsername;
						if (userPrincipal != null) {
							username = userPrincipal.getName();
						}
						logger.info("userPrincipal.getName() : {} " + username);
						if (claims) {
							setUpSpringAuthentication(username, KeycloakTokenVerifier.authorities);
						} else {
							SecurityContextHolder.clearContext();
						}
					} else {
						SecurityContextHolder.clearContext();
					}
					response.setHeader("Access-Control-Allow-Origin", "*");
					response.setHeader("Access-Control-Allow-Methods", "POST, GET, PUT, OPTIONS, DELETE");
					response.setHeader("Access-Control-Max-Age", "3600");
					response.setHeader("Access-Control-Allow-Headers", "X-requested-with, Content-Type, Authorization");
					filterChain.doFilter(request, response);
				} else if (StringUtils.isNotBlank(isValidate) && isValidate.equalsIgnoreCase("Skip Validate")) {
					// ******
					filterChain.doFilter(request, response);
					response.setStatus(HttpServletResponse.SC_FORBIDDEN);
					SecurityContextHolder.clearContext();
//					filterChain.doFilter(request, response);
//				return;
				} else {
					response.setStatus(HttpServletResponse.SC_FORBIDDEN);
					SecurityContextHolder.clearContext();
					// ******
//					filterChain.doFilter(request, response);
//				return;
				}
			} else {
//				response.setStatus(HttpServletResponse.SC_ACCEPTED);
//				logger.info("environment.getProperty(\"ISSIT\") " + environment.getProperty("ISSIT"));
			}
		} catch (ExpiredJwtException | UnsupportedJwtException | MalformedJwtException e) {
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			SecurityContextHolder.clearContext();
			filterChain.doFilter(request, response);
//			((HttpServletResponse) response).sendError(HttpServletResponse.SC_FORBIDDEN, e.getMessage());
			logger.error("Error-KeycloakAuthorizationFilter-doFilterInternal:", e);
//			return;
		} catch (Exception e) {
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			SecurityContextHolder.clearContext();
			filterChain.doFilter(request, response);
//			((HttpServletResponse) response).sendError(HttpServletResponse.SC_FORBIDDEN, e.getMessage());
			logger.error("Error-KeycloakAuthorizationFilter-doFilterInternal:", e);
//			return;
		}
		logger.info("KeycloakAuthorizationFilter-doFilterInternal-end");
	}

	private Claims validateToken(HttpServletRequest request) {
		String requestHeaders = requestHeaders(request);
		String jwtToken = request.getHeader(requestHeaders).replace(PREFIX, "");
		return Jwts.parser().setSigningKey(SECRET.getBytes()).parseClaimsJws(jwtToken).getBody();
	}

	/**
	 * Authentication method in Spring flow
	 * 
	 * @param claims
	 */
	private void setUpSpringAuthentication(String username, List<String> authoritiesList) {
		List<String> authorities = authoritiesList;
		if (authorities != null) {
			UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(username, null,
					authorities.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList()));
			SecurityContextHolder.getContext().setAuthentication(auth);
		} else {
			logger.info("authorities is null for Token ", authorities);
		}
	}

	private boolean checkJWTToken(HttpServletRequest request, HttpServletResponse res) {
		String requestHeaders = requestHeaders(request);
		String authenticationHeader = request.getHeader(requestHeaders);
		if (authenticationHeader == null || !authenticationHeader.startsWith(PREFIX))
			return false;
		return true;
	}

	private String extract(String header) {
		if (StringUtils.isBlank(header)) {
			throw new AuthenticationServiceException("Authorization header cannot be blank!");
		}

		if (header.length() < HEADER_PREFIX.length()) {
			throw new AuthenticationServiceException("Invalid authorization header size.");
		}
		return header.substring(HEADER_PREFIX.length(), header.length());
	}

	public String extractToken(HttpServletRequest request) {
		String requestHeaders = requestHeaders(request);
		String tokenPayload = request.getHeader(requestHeaders);
		return extract(tokenPayload);
	}

	public List<String> doFilter(HttpServletRequest servletRequest, HttpServletResponse servletResponse,
			FilterChain filterChain) throws IOException, ServletException {

		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		List<String> errors = new ArrayList<>();
		boolean isTrue = shouldNotFilterUrl(request);
		if (!isTrue) {
			errors.add("Validate");
			Boolean authValid = false;
			Boolean contentTypeValid = true;
			Boolean businessValid = true;
			Boolean correlationValid = true;
			try {
				authValid = validateAuthorization(request);
				// contentTypeValid = validateContentType(request);
//				businessValid = validateBusinessCorelationId(request);
//				correlationValid = validateCorelationId(request);
			} catch (Exception e) {
				errors.add(e.getMessage());
			}
			if (!authValid) {
				response.setStatus(HttpStatus.SC_BAD_REQUEST);
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
				// response.sendRedirect("/");
				return errors;
			} else if (!contentTypeValid) {
				// response.setStatus(HttpStatus.SC_BAD_REQUEST);
				// response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
				// String.join(",", errors));
				// return errors;
			} else if (!businessValid) {
//				response.setStatus(HttpStatus.SC_BAD_REQUEST);
//				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
//				return errors;
			} else if (!correlationValid) {
//				response.setStatus(HttpStatus.SC_BAD_REQUEST);
//				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, String.join(",", errors));
//				return errors;
			}
		} else {
			errors.add("Skip Validate");
		}

		return errors;

	}

	protected boolean shouldNotFilterUrl(HttpServletRequest request) throws ServletException {
		AntPathMatcher pathMatcher = new AntPathMatcher();
		List<String> matchers = excludeUrls();
		return matchers.stream().anyMatch(p -> pathMatcher.match(p, request.getServletPath()));
	}

	public List<String> excludeUrls() {
		List<String> paths = java.util.Arrays.asList(SecurityConstants.SWAGGERPATHTOSKIP);
		List<String> paths1 = java.util.Arrays.asList(SecurityConstants.PATHTOSKIP);
		List<String> matchers = Stream.of(paths, paths1).flatMap(x -> x.stream()).collect(Collectors.toList());
		return matchers;
	}

	private String requestHeaders(HttpServletRequest request) {
		logger.info("KeycloakAuthorizationFilter-requestHeaders-start:");
		String requestHeaders = request.getHeader(AUTH);
		if (StringUtils.isNotBlank(requestHeaders)) {
			return AUTH;
		}
		logger.info("KeycloakAuthorizationFilter-requestHeaders-end");
		return AUTHORIZATION;
	}

	private Boolean validateAuthorization(HttpServletRequest request) {
		String requestHeaders = requestHeaders(request);
		String header = CommonConstants.EMPTY_STRING;
		header = request.getHeader(requestHeaders);
		if (StringUtils.isBlank(header)) {
			throw new AuthenticationServiceException("Authorization header cannot be blank!");
		}

		if (header.length() < HEADER_PREFIX.length()) {
			throw new AuthenticationServiceException("Invalid authorization header size.");
		}
		String substring = header.substring(HEADER_PREFIX.length(), header.length());
		return StringUtils.isNotBlank(substring) ? true : false;
	}

	private Boolean validateContentType(HttpServletRequest request) {
		String header = request.getHeader("Content-Type");
		if (StringUtils.isBlank(header)) {
			throw new AuthenticationServiceException("Content-Type header cannot be blank!");
		}

		if (header.equalsIgnoreCase("application/json")) {
			return true;
		} else {
			throw new AuthenticationServiceException("Invalid Content-Type header. It should be application/json.");
		}
	}

	private Boolean validateBusinessCorelationId(HttpServletRequest request) {
		String header = request.getHeader("businesscorelationid");
		if (StringUtils.isBlank(header)) {
			throw new AuthenticationServiceException("businesscorelationid header cannot be blank!");
		}
		return true;

		// throw new AuthenticationServiceException("Invalid
		// BusinessCorelationId.");

	}

	private Boolean validateCorelationId(HttpServletRequest request) {
		String header = request.getHeader("corelationid");
		if (StringUtils.isBlank(header)) {
			throw new AuthenticationServiceException("corelationid header cannot be blank!");
		}
		return true;

		// throw new AuthenticationServiceException("Invalid
		// BusinessCorelationId.");

	}

	public static KeycloakPropertyDto loadKeycloakProperties() {
		KeycloakPropertyDto dto = new KeycloakPropertyDto();
		try {
//			ClassPathResource output = new ClassPathResource("application-dev.properties");
//			ClassPathResource output = new ClassPathResource("application-sit2.properties");
			ClassPathResource output = new ClassPathResource("application-prod.properties");
			Properties prop = new Properties();
			// load a properties file
			prop.load(output.getInputStream());
			// get the property value and print it out
//			dto.setServerUrl(prop.getProperty("keycloak.auth-server-url"));
//			dto.setRealmId(prop.getProperty("keycloak.realm"));
			dto.setClientId(prop.getProperty("keycloak.resource"));
//			dto.setClientSecret(prop.getProperty("keycloak.credentials.secret"));
//			dto.setSslRequired(prop.getProperty("keycloak.ssl-required"));
//			dto.setConfidentialPort(prop.getProperty("keycloak.confidential.port"));
//			dto.setPublicClient(prop.getProperty("keycloak.public.client"));
//			dto.setRoleMapping(prop.getProperty("keycloak.use.resource.role.mappings"));

		} catch (Exception io) {
			io.printStackTrace();
		}
		return dto;
	}

}