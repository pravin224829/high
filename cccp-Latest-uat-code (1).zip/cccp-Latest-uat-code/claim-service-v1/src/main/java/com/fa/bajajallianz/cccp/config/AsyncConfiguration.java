/**
 * 
 */
package com.fa.bajajallianz.cccp.config;

import java.util.concurrent.Executor;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * @author Kathir
 *
 */
@Configuration
@EnableAsync
public class AsyncConfiguration {

	@Bean(name = "asyncExecutor")
	public Executor asyncExcutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor(); // create ThreadPoolTaskExecutor object
		executor.setCorePoolSize(100); // thread capacity. it means how many task running based on repository
		executor.setMaxPoolSize(500); // max thread count
		executor.setQueueCapacity(100); // queue capacity it means at a time how many records wait
		executor.setThreadNamePrefix("AsynchThread-"); // thread name
		executor.initialize();
		return executor;
	}

}
