package com.fa.bajajallianz.cccp.claim.restservice;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsListDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimResponseDto;
import com.fa.bajajallianz.cccp.common.dto.CommonDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.SaveRegistrationClaimResponse;
import com.fa.bajajallianz.cccp.common.dto.UserDto;
import com.fa.bajajallianz.cccp.mis.common.dto.CommonMisResponseDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClaimSaveDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClmIntimationRespDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusSinglePolicySearchDto;

public interface ClaimRestService {

	SaveRegistrationClaimResponse saveRegistrationClaim(ClaimResponseDto claimResponseDto1, HttpServletRequest request );

	CommonResponseDto<List<ClaimDetailsListDto>> searchClaimDetails(CommonRequestDto commonRequestDto, HttpServletRequest request);

	UserDto fetchUserProfile(ClaimDetailsDto claimDto, HttpServletRequest request);

	ClaimDetailsDto fetchClaimDetails(CommonRequestDto commonRequestDto, HttpServletRequest request);

//	ClaimDetailsDto fetchMisClaimDetails(CommonRequestDto commonRequestDto, HttpServletRequest request);

	MaximusClmIntimationRespDto saveMaximusClaimIntimation(MaximusClaimSaveDto claimSaveDto,
			HttpServletRequest request);

	CommonMisResponseDto<String> fetchMisClaimDetails(CommonRequestDto commonRequestDto,
			HttpServletRequest request);

	ApplicationErrorDto saveClaimIntimation(CommonDto commonDto, HttpServletRequest request);

	void sendNotification(CommonRequestDto commonRequestDto, HttpServletRequest request);

	MaximusSinglePolicySearchDto getSavedQuote(String policyNo, HttpServletRequest request);

}
