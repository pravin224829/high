package com.fa.bajajallianz.cccp.claim.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fa.bajajallianz.cccp.claim.entity.AdditionalDetailsEntity;
import com.fa.bajajallianz.cccp.claim.entity.BankEntity;
import com.fa.bajajallianz.cccp.claim.entity.ClaimEntity;
import com.fa.bajajallianz.cccp.claim.entity.IntimatedDetailsEntity;
import com.fa.bajajallianz.cccp.claim.entity.RunTimeFieldsEntity;
import com.fa.bajajallianz.cccp.claim.entity.RunTimeFieldsValueEntity;
import com.fa.bajajallianz.cccp.claim.repository.AdditionalDetailsRepository;
import com.fa.bajajallianz.cccp.claim.repository.BankRepository;
import com.fa.bajajallianz.cccp.claim.repository.ClaimRepository;
import com.fa.bajajallianz.cccp.claim.repository.IntimatedDetailsRepository;
import com.fa.bajajallianz.cccp.claim.repository.RuntimeFieldsRepository;
import com.fa.bajajallianz.cccp.claim.repository.RuntimeFieldsValueRepository;
import com.fa.bajajallianz.cccp.claim.restservice.ClaimRestService;
import com.fa.bajajallianz.cccp.claim.service.AsyncService;
import com.fa.bajajallianz.cccp.claim.service.ClaimService;
import com.fa.bajajallianz.cccp.claim.utils.CommonErrorMsg;
import com.fa.bajajallianz.cccp.claim.utils.CommonRequestUtil;
import com.fa.bajajallianz.cccp.common.dto.AdditionalDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ApplicationErrorDto;
import com.fa.bajajallianz.cccp.common.dto.BankDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimDetailsListDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimIntimatedDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimRefNo;
import com.fa.bajajallianz.cccp.common.dto.ClaimResponseDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimantDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.ClientsFieldsConfigDto;
import com.fa.bajajallianz.cccp.common.dto.CommonDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.dto.InsuredDetails;
import com.fa.bajajallianz.cccp.common.dto.LossDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.MobileNoDto;
import com.fa.bajajallianz.cccp.common.dto.PolicyDetailsDto;
import com.fa.bajajallianz.cccp.common.dto.RunTimeFieldsValueDto;
import com.fa.bajajallianz.cccp.common.dto.RuntimeFields;
import com.fa.bajajallianz.cccp.common.dto.SaveRegistrationClaimResponse;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.DateUtils;
import com.fa.bajajallianz.cccp.common.utils.ErrorCodeConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.common.utils.NumericUtils;
import com.fa.bajajallianz.cccp.mis.common.dto.ClaimAttributeDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.ClaimMisDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.ClaimReserveDetailsDto;
import com.fa.bajajallianz.cccp.mis.common.dto.CommonMisResponseDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClaimPartyDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClaimSaveDto;
import com.fa.bajajallianz.cccp.mis.common.dto.MaximusClmIntimationRespDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimPartiesDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ReserveDetailsDto;

@Service
public class ClaimServiceImpl implements ClaimService {

	@Autowired
	private ClaimRepository claimRepository;

	@Autowired
	private CommonErrorMsg commonErrorMsg;

	@Resource
	private BankRepository bankRepository;

	@Autowired
	ClaimRestService claimRestService;

	@Autowired
	AsyncService asyncService;

	@Resource
	private IntimatedDetailsRepository intimatedDetailsRepository;

	@Autowired
	EntityManager entityManager;

	@Autowired
	AdditionalDetailsRepository additionalDetailsRepository;

	@Autowired
	RuntimeFieldsRepository runTimeFieldsRepository;

	@Autowired
	RuntimeFieldsValueRepository runtimeFieldsValueRepository;

	@Autowired
	Environment env;

	public String getProperty() {
		return env.getProperty("CONFIG_API_URL");
	}

	private static final Logger logger = LoggerFactory.getLogger(ClaimServiceImpl.class);

	@SuppressWarnings("unchecked")
	private String generateClaimref(String code, String year) {
		logger.info("SaveClaimDetails-getSequence-start");
		String response = null;
		try {
			StoredProcedureQuery storedProcedureQuery = entityManager
					.createStoredProcedureQuery("cccp_bagic.claimRefNo");
			storedProcedureQuery.registerStoredProcedureParameter("code", String.class, ParameterMode.IN);
			storedProcedureQuery.setParameter("code", code);
			storedProcedureQuery.registerStoredProcedureParameter("year", String.class, ParameterMode.IN);
			storedProcedureQuery.setParameter("year", year);
			List<String> sequenceNumber = storedProcedureQuery.execute() ? storedProcedureQuery.getResultList() : null;
			if (sequenceNumber != null && sequenceNumber.size() > 0) {
				response = sequenceNumber.get(0);
			}
		} catch (Exception e) {
			logger.error("Exception-SaveClaimDetails-getSequence-", e);
		}
		logger.info("SaveClaimDetails-getSequence-end");
		return response;
	}

	@Override
	public CommonResponseDto<ClaimDetailsDto> saveClaimDetails(ClaimDetailsDto claimDto, HttpServletRequest request) {
		CommonResponseDto<ClaimDetailsDto> commonResponseDto = new CommonResponseDto<>();
		logger.info("ClaimServiceImpl--saveClaimDetails--Start");
		try {
			ClaimEntity claimEntity = new ClaimEntity();
			if (claimDto.getInsuredDetails() != null) {
				InsuredDetails insuredDetails = claimDto.getInsuredDetails();
				if (claimDto.getClaimRefNo() != null && StringUtils.isNotEmpty(claimDto.getClaimRefNo())) {
					ClaimEntity entity = claimRepository.findByclaimRefNo(claimDto.getClaimRefNo());
					if (entity != null) {
						entity.setInsuredMail(insuredDetails.getInsuredEmailId());
						entity.setInsuredName(insuredDetails.getInsuredName());
						entity.setInsuredMobileNumber(NumericUtils.convertStringToLong(insuredDetails.getMobileNo()));
						entity.setPolicyNumber(insuredDetails.getPolicyNumber());
						entity.setImdChannel(insuredDetails.getImdChannel());
						entity.setProductCode(insuredDetails.getProductCode());
						entity.setProductName(insuredDetails.getProductDescription());
						entity.setSumInsured(NumericUtils.convertStringToLong(insuredDetails.getSumInsured()));
						entity.setModifiedBy(claimDto.getUserId());
						entity.setModifiedDate(DateUtils.sysDate());
						claimRepository.save(entity);
						commonResponseDto.setClaimRefNo(entity.getClaimRefNo());
					}
				} else {
					claimEntity.setInsuredMail(insuredDetails.getInsuredEmailId());
					claimEntity.setInsuredName(insuredDetails.getInsuredName());
					claimEntity.setInsuredMobileNumber(NumericUtils.convertStringToLong(insuredDetails.getMobileNo()));
					claimEntity.setClaimRefNo(this.generateClaimref(ClaimRefNo.REFNO, ClaimRefNo.YEAR1));
					claimEntity.setPolicyNumber(insuredDetails.getPolicyNumber());
					claimEntity.setIsActive(CommonConstants.TRUE);
					claimEntity.setImdChannel(insuredDetails.getImdChannel());
					claimEntity.setProductCode(insuredDetails.getProductCode());
					claimEntity.setProductName(insuredDetails.getProductDescription());
					claimEntity.setSumInsured(NumericUtils.convertStringToLong(insuredDetails.getSumInsured()));
					claimEntity.setCreatedBy(claimDto.getUserId());
					claimEntity.setCreatedDate(DateUtils.sysDate());
					claimRepository.save(claimEntity);
					commonResponseDto.setClaimRefNo(claimEntity.getClaimRefNo());
				}
				commonResponseDto.setStatus(CommonConstants.SUCCESS);
			} else if (claimDto.getLossDetails() != null) {
				ClaimEntity entity = claimRepository.findByclaimRefNo(claimDto.getClaimRefNo());
				LossDetailsDto lossDetailsDto = claimDto.getLossDetails();
				if (StringUtils.isNotBlank(lossDetailsDto.getLossDate()) && lossDetailsDto.getLossDate() != null) {
					entity.setLossDate(DateUtils.convertStringToDate(lossDetailsDto.getLossDate()));
				}
				if (lossDetailsDto.getLossTime() != null && StringUtils.isNotBlank(lossDetailsDto.getLossTime())) {
					entity.setLossTime(
							DateUtils.convertStringToDateTimeWithPeriodMMDDYYYY(lossDetailsDto.getLossTime()));
				}
				entity.setLossAddress(lossDetailsDto.getLossAddress());
				entity.setLandMark(lossDetailsDto.getLandmark());
				entity.setLossAmount(NumericUtils.convertStringToDouble(lossDetailsDto.getLossAmount()));
				entity.setPincode(NumericUtils.convertStringToInteger(lossDetailsDto.getPincode()));
				entity.setState(lossDetailsDto.getState());
				entity.setCity(lossDetailsDto.getCity());
				entity.setArea(lossDetailsDto.getArea());
				entity.setSection(lossDetailsDto.getSection());
				entity.setCauseOffLoss(lossDetailsDto.getCauseOfLoss());
				entity.setLossDetails(lossDetailsDto.getLossDescription());
				entity.setGoodsDamagedDetails(lossDetailsDto.getGoodsDamagedDetails());
				entity.setLossEstimatedValue(NumericUtils.convertStringToDouble(lossDetailsDto.getLossEstmatedValue()));
				if (lossDetailsDto.getInvoiceNumber() != null
						&& StringUtils.isNotEmpty(lossDetailsDto.getInvoiceNumber())) {
					List<ClaimEntity> entities = claimRepository
							.findByPolicyNumberAndIsActiveTrueAndInvoiceNumberAndClaimNumberNotNull(
									entity.getPolicyNumber(), lossDetailsDto.getInvoiceNumber());
					if (entities != null && !entities.isEmpty()) {
						commonResponseDto.setMessage(CommonConstants.EXITINVOICENUMBER);
						commonResponseDto.setStatus(CommonConstants.ERROR);
						return commonResponseDto;
					}
				}
				entity.setNotificationDate(DateUtils.convertStringToDate(lossDetailsDto.getNotificationDate()));
				entity.setInvoiceDate(DateUtils.convertStringToDate(lossDetailsDto.getInvoiceDate()));
				entity.setLorryReceiptDate(DateUtils.convertStringToDate(lossDetailsDto.getLorryReceiptDate()));
				entity.setInvoiceNumber(lossDetailsDto.getInvoiceNumber());
				entity.setBlRrLrAwbNo(lossDetailsDto.getBlRrLrAwbNo());
				entity.setJourneyFrom(lossDetailsDto.getJourneyFrom());
				entity.setJourneyTo(lossDetailsDto.getJourneyTo());
				entity.setConsigneeName(lossDetailsDto.getConsigneeName());
				entity.setConsigneeAddress(lossDetailsDto.getConsigneeAddress());
				entity.setConsigneePhoneNo(lossDetailsDto.getConsigneePhoneNo());
				entity.setClaimServicingOffice(lossDetailsDto.getClaimServicingOffice());
				entity.setAreaClaimBehalfOffInsure(lossDetailsDto.getAreaClaimBehalfOffInsure());
				entity.setCreatedBy(claimDto.getUserId());
				entity.setIsActive(CommonConstants.TRUE);
				entity.setCreatedDate(DateUtils.sysDate());
				entity.setClaimNotifiedBy("Insured");
				claimRepository.save(entity);
				commonResponseDto.setClaimRefNo(entity.getClaimRefNo());
				commonResponseDto.setStatus(CommonConstants.SUCCESS);
			} else if (claimDto.getBankDetails() != null) {
				ClaimEntity entity = claimRepository.findByclaimRefNo(claimDto.getClaimRefNo());
				BankDetailsDto bankDetailsDto = claimDto.getBankDetails();
				if (entity != null && entity.getBankDetails() != null && !entity.getBankDetails().isEmpty()) {
					for (BankEntity bankEntity : entity.getBankDetails()) {
						bankEntity.setAccountNumber(bankDetailsDto.getAccountNumber());
						bankEntity.setAccountType(bankDetailsDto.getAccountType());
						bankEntity.setGstNumber(bankDetailsDto.getGstNumber());
						bankEntity.setIfscCode(bankDetailsDto.getIfscCode());
						bankEntity.setPanNumber(bankDetailsDto.getPanNumber());
						bankEntity.setConfirmBankAccountnumber(bankDetailsDto.getConfirmBankAccountnumber());
						bankEntity.setCreatedDate(DateUtils.sysDate());
						bankEntity.setRegisteredMobileNo(
								NumericUtils.convertStringToLong(bankDetailsDto.getRegisteredMobileNumber()));
						bankRepository.save(bankEntity);
					}
				} else {
					BankEntity bankEntity1 = new BankEntity();
					bankEntity1.setAccountNumber(bankDetailsDto.getAccountNumber());
					bankEntity1.setAccountType(bankDetailsDto.getAccountType());
					bankEntity1.setGstNumber(bankDetailsDto.getGstNumber());
					bankEntity1.setIfscCode(bankDetailsDto.getIfscCode());
					bankEntity1.setPanNumber(bankDetailsDto.getPanNumber());
					bankEntity1.setConfirmBankAccountnumber(bankDetailsDto.getConfirmBankAccountnumber());
					bankEntity1.setCreatedDate(DateUtils.sysDate());
					bankEntity1.setIsActive(CommonConstants.TRUE);
					bankEntity1.setRegisteredMobileNo(
							NumericUtils.convertStringToLong(bankDetailsDto.getRegisteredMobileNumber()));
					bankEntity1.setClaimDetails(entity);
					bankRepository.save(bankEntity1);
				}
				commonResponseDto.setClaimRefNo(entity.getClaimRefNo());
				commonResponseDto.setStatus(CommonConstants.SUCCESS);
			} else if (claimDto.getIntimatedDetails() != null) {
				ClaimEntity entity = claimRepository.findByclaimRefNo(claimDto.getClaimRefNo());
				ClaimIntimatedDto claimIntimatedDto = claimDto.getIntimatedDetails();
				if (entity != null && entity.getIntimatedDetails() != null && !entity.getIntimatedDetails().isEmpty()) {
					for (IntimatedDetailsEntity intimatedDetails : entity.getIntimatedDetails()) {
						intimatedDetails.setName(claimIntimatedDto.getName());
						intimatedDetails
								.setMobileNumber(NumericUtils.convertStringToLong(claimIntimatedDto.getMobileNumber()));
						intimatedDetails.setEmail(claimIntimatedDto.getEmail());
						intimatedDetails.setIdentificationNumber(claimIntimatedDto.getIdentificationNumber());
						intimatedDetails.setTelephoneNumber(
								NumericUtils.convertStringToLong(claimIntimatedDto.getTelephoneNumber()));
						intimatedDetails.setRemarks(claimIntimatedDto.getRemarks());
						intimatedDetails.setCreatedDate(DateUtils.sysDate());
						intimatedDetails.setClaimDetails(entity);
						intimatedDetailsRepository.save(intimatedDetails);
					}
				} else {
					IntimatedDetailsEntity intimatedDetailsEntity = new IntimatedDetailsEntity();
					intimatedDetailsEntity.setName(claimIntimatedDto.getName());
					intimatedDetailsEntity
							.setMobileNumber(NumericUtils.convertStringToLong(claimIntimatedDto.getMobileNumber()));
					intimatedDetailsEntity.setIdentificationNumber(claimIntimatedDto.getIdentificationNumber());
					intimatedDetailsEntity.setTelephoneNumber(
							NumericUtils.convertStringToLong(claimIntimatedDto.getTelephoneNumber()));
					intimatedDetailsEntity.setEmail(claimIntimatedDto.getEmail());
					intimatedDetailsEntity.setRemarks(claimIntimatedDto.getRemarks());
					intimatedDetailsEntity.setCreatedDate(DateUtils.sysDate());
					intimatedDetailsEntity.setIsActive(CommonConstants.TRUE);
					intimatedDetailsEntity.setCreatedBy(claimDto.getUserId());
					intimatedDetailsEntity.setClaimDetails(entity);
					intimatedDetailsRepository.save(intimatedDetailsEntity);
				}
				commonResponseDto.setClaimRefNo(entity.getClaimRefNo());
				commonResponseDto.setStatus(CommonConstants.SUCCESS);
			}
			if (CommonConstants.TRUE.equals(claimDto.getIsFinalSubmission())) {
				CommonResponseDto<SaveRegistrationClaimResponse> commonResponseDto1 = new CommonResponseDto<SaveRegistrationClaimResponse>();
				ClaimEntity claimEntitys = claimRepository.findByclaimRefNo(claimDto.getClaimRefNo());
				ClaimResponseDto claimResponseDto1 = new ClaimResponseDto();
				ClaimDetailsDto claimDetailsDto = new ClaimDetailsDto();
				InsuredDetails insuredDetails = new InsuredDetails();
				ClaimIntimatedDto claimIntimatedDto1 = new ClaimIntimatedDto();
				if (claimDto != null) {
					if (claimDto.getIntimatedDetails() != null) {
						claimIntimatedDto1 = claimDto.getIntimatedDetails();
						claimIntimatedDto1.setName(claimIntimatedDto1.getName());
						claimIntimatedDto1.setIdentificationNumber(claimIntimatedDto1.getIdentificationNumber());
						claimIntimatedDto1.setEmail(claimIntimatedDto1.getEmail());
						claimIntimatedDto1.setTelephoneNumber(claimIntimatedDto1.getTelephoneNumber());
						claimIntimatedDto1.setMobileNumber(claimIntimatedDto1.getMobileNumber());
						claimIntimatedDto1.setRemarks(claimIntimatedDto1.getRemarks());
					}
				}
				claimDetailsDto.setIntimatedDetails(claimIntimatedDto1);
				insuredDetails.setPolicyNumber(claimEntitys.getPolicyNumber());
				insuredDetails.setInsuredEmailId(claimEntitys.getInsuredMail());
				insuredDetails.setInsuredName(claimEntitys.getInsuredName());
				insuredDetails.setMobileNo(NumericUtils.convertLongToString(claimEntitys.getInsuredMobileNumber()));
				claimDetailsDto.setInsuredDetails(insuredDetails);
				LossDetailsDto lossDetailsDto = new LossDetailsDto();
				if (claimEntitys.getLossDate() != null) {
					lossDetailsDto.setLossDate(DateUtils.dateToStringDDMMYYYYWith(claimEntitys.getLossDate()));
				}
				if (claimEntitys.getLossTime() != null) {
					lossDetailsDto.setLossTime(DateUtils.dateToStringFormatHhMmSs(claimEntitys.getLossTime()));
				}
				lossDetailsDto.setLossAddress(claimEntitys.getLossAddress());
				lossDetailsDto.setLandmark(claimEntitys.getLandMark());
				lossDetailsDto.setLossAmount(NumericUtils.convertDoubleToString(claimEntitys.getLossAmount()));
				lossDetailsDto.setPincode(NumericUtils.convertIntegerToString(claimEntitys.getPincode()));
				lossDetailsDto.setState(claimEntitys.getState());
				lossDetailsDto.setCity(claimEntitys.getCity());
				lossDetailsDto.setArea(claimEntitys.getArea());
				lossDetailsDto.setSection(claimEntitys.getSection());
				lossDetailsDto.setCauseOfLoss(claimEntitys.getCauseOffLoss());
				if (claimEntitys.getNotificationDate() != null) {
					lossDetailsDto.setNotificationDate(
							DateUtils.dateToStringDDMMYYYYWith(claimEntitys.getNotificationDate()));
				}
				lossDetailsDto.setLossDetails(claimEntitys.getLossDetails());
				lossDetailsDto.setGoodsDamagedDetails(claimEntitys.getGoodsDamagedDetails());
				lossDetailsDto
						.setLossEstmatedValue(NumericUtils.convertDoubleToString(claimEntitys.getLossEstimatedValue()));
				lossDetailsDto.setInvoiceNumber(claimEntitys.getInvoiceNumber());
				if (claimEntitys.getNotificationDate() != null) {
					lossDetailsDto.setNotificationDate(
							DateUtils.dateToStringDDMMYYYYWith(claimEntitys.getNotificationDate()));
				}
				if (claimEntitys.getInvoiceDate() != null) {
					lossDetailsDto.setInvoiceDate(DateUtils.dateToStringDDMMYYYYWith(claimEntitys.getInvoiceDate()));
				}
				if (claimEntitys.getLorryReceiptDate() != null) {
					lossDetailsDto.setLorryReceiptDate(
							DateUtils.dateToStringDDMMYYYYWith(claimEntitys.getLorryReceiptDate()));
				}
				lossDetailsDto.setBlRrLrAwbNo(claimEntitys.getBlRrLrAwbNo());
				lossDetailsDto.setJourneyFrom(claimEntitys.getJourneyFrom());
				lossDetailsDto.setJourneyTo(claimEntitys.getJourneyTo());
				lossDetailsDto.setConsigneeName(claimEntitys.getConsigneeName());
				lossDetailsDto.setConsigneeAddress(claimEntitys.getConsigneeAddress());
				lossDetailsDto.setConsigneePhoneNo(claimEntitys.getConsigneePhoneNo());
				lossDetailsDto.setClaimServicingOffice(claimEntitys.getClaimServicingOffice());
				lossDetailsDto.setAreaClaimBehalfOffInsure(claimEntitys.getAreaClaimBehalfOffInsure());
				lossDetailsDto.setClaimNotifiedBy(claimEntitys.getClaimNotifiedBy());
				claimDetailsDto.setLossDetails(lossDetailsDto);
				MaximusClaimSaveDto claimSaveDto = new MaximusClaimSaveDto();
				List<BankEntity> bankEntities = claimEntitys.getBankDetails();
				BankDetailsDto bankDetailsDto = new BankDetailsDto();
				bankEntities.forEach(bankDetails -> {
					claimSaveDto.setPanNumber(bankDetails.getPanNumber());
					claimSaveDto.setBankAccountNumber(bankDetails.getAccountNumber());
					bankDetailsDto.setAccountNumber(bankDetails.getAccountNumber());
					bankDetailsDto.setAccountType(bankDetails.getAccountType());
					bankDetailsDto.setConfirmBankAccountnumber(bankDetails.getConfirmBankAccountnumber());
					bankDetailsDto.setGstNumber(bankDetails.getGstNumber());
					bankDetailsDto.setIfscCode(bankDetails.getIfscCode());
					bankDetailsDto.setPanNumber(bankDetails.getPanNumber());
					bankDetailsDto.setRegisteredMobileNumber(
							NumericUtils.convertLongToString(bankDetails.getRegisteredMobileNo()));
				});
				claimDetailsDto.setBankDetails(bankDetailsDto);
				claimDetailsDto.setUserId(claimDto.getUserId());
				claimDetailsDto.setRoleCode(claimDto.getRoleCode());
				claimDetailsDto.setImdCode(claimDto.getImdCode());
				claimResponseDto1.setClaimDetails(claimDetailsDto);
				claimEntitys.setCreatedBy(claimDto.getUserId());
				claimEntitys.setModifiedDate(DateUtils.sysDate());
				claimEntitys.setModifiedBy(claimDto.getUserId());
				String flag = claimRepository.getPolicySourceFlagByPolicyNumber(claimEntitys.getPolicyNumber());
				if (CommonConstants.MAXIMUSFLAG.equals(flag)) {
					claimSaveDto.setStrPolicyQuoteNumber(claimEntitys.getPolicyNumber());
					claimSaveDto.setAreaCode(NumericUtils.convertIntegerToString(claimEntitys.getPincode()));
					claimSaveDto.setStrState(CommonConstants.ALL);
					claimSaveDto.setStrLOB("PROPERTY");
					claimSaveDto.setStrProductCode(claimEntitys.getProductCode());
					claimSaveDto.setStrCountryCode(CommonConstants.INDIA);
					claimSaveDto.setStrCompany(CommonConstants.BAGIC);
					claimSaveDto.setStrInsuredName(claimEntitys.getInsuredName());
					claimSaveDto.setStrPremiumCurrency(CommonConstants.INR);
					claimSaveDto.setStrprivilegeCode(CommonConstants.SUPERUSER);
					claimSaveDto.setStrApplicationCode(CommonConstants.PRODUCT);
					claimSaveDto.setStrBaseCurrency(CommonConstants.INR);
					claimSaveDto.setPolicyBranch(CommonConstants.EMPTY_STRING);
					claimSaveDto.setClaimType("PR");
					claimSaveDto.setClaimIntimationDate(
							DateUtils.dateToStringFormatddMmYyyy(claimEntitys.getNotificationDate()));
					claimSaveDto.setLossDate(DateUtils.dateToStringFormatddMmYyyy(claimEntitys.getLossDate()));
					claimSaveDto.setLossTime(DateUtils.dateToStringFormatHhMmSs(claimEntitys.getLossTime()));
					claimSaveDto.setEventCode(CommonConstants.EMPTY_STRING);
					// claimSaveDto.setClaimCause(CommonConstants.ALL);
					claimSaveDto.setClaimCause(lossDetailsDto.getCauseOfLoss());
					claimSaveDto.setLossNature(CommonConstants.ALL);
					claimSaveDto.setEstimatedLossAmount(claimEntitys.getLossAmount() != null
							? NumericUtils.roundOffvalues(claimEntitys.getLossAmount())
							: NumericUtils.roundOffvalues(claimEntitys.getLossEstimatedValue()));
					claimSaveDto.setClaimCircumstances(claimEntitys.getLossDescription());
					claimSaveDto
							.setClaimIntTime(DateUtils.dateToStringFormatHhMmSs(claimEntitys.getNotificationDate()));
					claimSaveDto
							.setInsContactNo(NumericUtils.convertLongToString(claimEntitys.getInsuredMobileNumber()));
					claimSaveDto.setPolRiskCovList(CommonConstants.EMPTY_STRING);
					claimSaveDto.setRiskSerialNo(CommonConstants.ONE_STRING);
					claimSaveDto.setRiskCode(CommonConstants.EMPTY_STRING);
					claimSaveDto.setRiskDesc(CommonConstants.EMPTY_STRING);
					claimSaveDto.setIntClaimComments(claimEntitys.getRemarks());
					claimSaveDto.setClaimBranch(CommonConstants.EMPTY_STRING);
					if (claimEntitys.getBankDetails().get(0) != null)
						claimSaveDto.setBankIFSCCode(claimEntitys.getBankDetails().get(0).getIfscCode());
					claimSaveDto.setRegisteredMobileNumber(
							NumericUtils.convertLongToString(claimEntitys.getInsuredMobileNumber()));
					claimSaveDto.setLossDescription(claimEntitys.getLossDescription());
					claimSaveDto.setNameOfPerson(claimEntitys.getInsuredName());
					claimSaveDto
							.setMobileNumber(NumericUtils.convertLongToString(claimEntitys.getInsuredMobileNumber()));
					claimSaveDto.setEmail(claimEntitys.getInsuredMail());
					claimSaveDto.setTelephoneNumber(
							NumericUtils.convertLongToString(claimEntitys.getInsuredMobileNumber()));
					claimSaveDto.setIdentificationNumber(CommonConstants.EMPTY_STRING);
					claimSaveDto.setLossAddress(claimEntitys.getLossAddress());
					claimSaveDto.setGstnNumber(CommonConstants.EMPTY_STRING);
					claimSaveDto.setCity(claimEntitys.getCity());
					claimSaveDto.setState(claimEntitys.getState());
					MaximusClmIntimationRespDto maximusClmIntimationRespDto = claimRestService
							.saveMaximusClaimIntimation(claimSaveDto, request);
					if (maximusClmIntimationRespDto != null
							&& maximusClmIntimationRespDto.getApplicationError() != null) {
						if (CommonConstants.ZERO_STRING
								.equals(maximusClmIntimationRespDto.getApplicationError().getErrorCode())) {
							claimEntitys.setClaimNumber(
									maximusClmIntimationRespDto.getClaimIntimationDetails().getStrClaimNumber());
							commonResponseDto.setClaimNumber(
									maximusClmIntimationRespDto.getClaimIntimationDetails().getStrClaimNumber());
							claimRepository.save(claimEntitys);
							commonResponseDto.setStatus(CommonConstants.SUCCESS);
							if (claimEntitys.getClaimNumber() != null
									&& StringUtils.isNotBlank(claimEntitys.getClaimNumber())) {
								CommonRequestDto commonRequestDto = new CommonRequestDto();
								commonRequestDto.setClaimNumber(claimEntitys.getClaimNumber());
								commonRequestDto.setUserId(claimDto.getUserId());
								commonRequestDto.setPolicyNumber(claimEntitys.getPolicyNumber());
								asyncService.sendNotification(commonRequestDto, request);
								asyncService.misClaimIntimation(claimDetailsDto, commonRequestDto, request);
							}
						} else {
							commonResponseDto
									.setMessage(maximusClmIntimationRespDto.getApplicationError().getErrorMessage());
							commonResponseDto.setStatus(CommonConstants.ERROR);
						}
					} else {
						commonResponseDto.setMessage("Maximus Response Empty");
						commonResponseDto.setStatus(CommonConstants.ERROR);
					}
				} else {
					SaveRegistrationClaimResponse saveRegistrationClaimResponse = claimRestService
							.saveRegistrationClaim(claimResponseDto1, request);
					commonResponseDto1.setResponseData(saveRegistrationClaimResponse);
					if (saveRegistrationClaimResponse.getError_code().equals("0")) {
						claimEntitys.setClaimNumber(commonResponseDto1.getResponseData().getP_clm_ref());
						commonResponseDto.setClaimNumber(commonResponseDto1.getResponseData().getP_clm_ref());
						claimRepository.save(claimEntitys);
						commonResponseDto.setStatus(CommonConstants.SUCCESS);
					} else {
						commonResponseDto.setError(saveRegistrationClaimResponse.getError_msg());
						commonResponseDto.setMessage(saveRegistrationClaimResponse.getError_msg());
						commonResponseDto.setStatus(CommonConstants.ERROR);
					}
				}
			} else if (StringUtils.isNoneBlank(claimDto.getClaimNumber())) {
				ClaimEntity updateClaimEntity = claimRepository.findByClaimNumberAndIsActive(claimDto.getClaimNumber(),
						CommonConstants.TRUE);
				if (updateClaimEntity != null) {
					updateClaimEntity.setIsClaimUpdated(CommonConstants.TRUE);
					if (claimDto.getAdditionalDetails() != null) {
						AdditionalDetailsEntity additionalDetailsEntity1 = additionalDetailsRepository
								.findByClaimDetailsId(updateClaimEntity.getId());
						AdditionalDetailsDto additionalDetailsDto = claimDto.getAdditionalDetails();
						if (additionalDetailsEntity1 == null) {
							AdditionalDetailsEntity additionalDetailsEntity = new AdditionalDetailsEntity();
							additionalDetailsEntity.setClientDistrictName(additionalDetailsDto.getClientDistrictName());
							additionalDetailsEntity.setClientDivisionName(additionalDetailsDto.getClientDivisionName());
							additionalDetailsEntity
									.setConsignmentOrCargoType(additionalDetailsDto.getConsignmentOrCargoType());
							additionalDetailsEntity.setJirDate(additionalDetailsDto.getJirDate());
							additionalDetailsEntity.setK2k3(additionalDetailsDto.getK2k3());
							additionalDetailsEntity
									.setTotalConsignmentValue(additionalDetailsDto.getTotalConsignmentValue());
							additionalDetailsEntity.setTransporterName(additionalDetailsDto.getTransporterName());
							additionalDetailsEntity.setTransportVehilceNo(additionalDetailsDto.getTransportVehilceNo());
							additionalDetailsEntity.setClaimDetails(updateClaimEntity);
							additionalDetailsRepository.save(additionalDetailsEntity);
							commonResponseDto.setMessage(CommonConstants.SUCCESS);
							commonResponseDto.setStatus(CommonConstants.SUCCESS);
						} else {
							additionalDetailsEntity1
									.setClientDistrictName(additionalDetailsDto.getClientDistrictName());
							additionalDetailsEntity1
									.setClientDivisionName(additionalDetailsDto.getClientDivisionName());
							additionalDetailsEntity1
									.setConsignmentOrCargoType(additionalDetailsDto.getConsignmentOrCargoType());
							additionalDetailsEntity1.setJirDate(additionalDetailsDto.getJirDate());
							additionalDetailsEntity1.setK2k3(additionalDetailsDto.getK2k3());
							additionalDetailsEntity1
									.setTotalConsignmentValue(additionalDetailsDto.getTotalConsignmentValue());
							additionalDetailsEntity1.setTransporterName(additionalDetailsDto.getTransporterName());
							additionalDetailsEntity1
									.setTransportVehilceNo(additionalDetailsDto.getTransportVehilceNo());
							additionalDetailsEntity1.setClaimDetails(updateClaimEntity);
							additionalDetailsRepository.save(additionalDetailsEntity1);
							commonResponseDto.setMessage(CommonConstants.SUCCESS);
							commonResponseDto.setStatus(CommonConstants.SUCCESS);
						}
					}
					if (claimDto.getAdditionalDetails() != null && claimDto.getAdditionalDetails().getRuntime() != null
							&& !claimDto.getAdditionalDetails().getRuntime().isEmpty()) {
						List<RuntimeFields> runtimeFields1 = new ArrayList<>();
						runtimeFields1=claimDto.getAdditionalDetails().getRuntime();/////Added
						updateClaimEntity.setModifiedDate(DateUtils.sysDate());
						for (RuntimeFields runtimeFields : runtimeFields1) {
							RunTimeFieldsValueEntity entity = runtimeFieldsValueRepository
									.findByClaimNumberAndFieldCode(claimDto.getClaimNumber(),
											runtimeFields.getFieldCode());
							if (entity != null) {
								entity.setFieldName(runtimeFields.getFieldName());
								entity.setFieldValue(runtimeFields.getFieldValue());
								entity.setOrderNo(NumericUtils.convertStringToInteger(runtimeFields.getOrderNo()));
								entity.setClaimNumber(claimDto.getClaimNumber());
								entity.setModifiedBy(claimDto.getUserId());
								entity.setModifiedDate(DateUtils.sysDate());
								entity.setClaimDetails(updateClaimEntity);
								runtimeFieldsValueRepository.save(entity);
							} else {
								RunTimeFieldsValueEntity runTimeFieldsEntity = new RunTimeFieldsValueEntity();
								runTimeFieldsEntity.setFieldCode(runtimeFields.getFieldCode());
								runTimeFieldsEntity.setFieldName(runtimeFields.getFieldName());
								runTimeFieldsEntity.setFieldValue(runtimeFields.getFieldValue());
								runTimeFieldsEntity.setClaimNumber(claimDto.getClaimNumber());
								runTimeFieldsEntity
										.setOrderNo(NumericUtils.convertStringToInteger(runtimeFields.getOrderNo()));
								runTimeFieldsEntity.setClaimDetails(updateClaimEntity);
								runTimeFieldsEntity.setCreatedBy(claimDto.getUserId());
								runTimeFieldsEntity.setCreatedDate(DateUtils.sysDate());
								runtimeFieldsValueRepository.save(runTimeFieldsEntity);
							}
						}
						commonResponseDto.setStatus(CommonConstants.SUCCESS);
					}
				} else {
					commonResponseDto.setStatus(CommonConstants.ERROR);
					commonResponseDto.setMessage("Claim number is not registered in this portal.");
				}
			}
		} catch (Exception e) {
			logger.error("Exception-ClaimServiceImpl-saveClaimDetails", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setError(e.getMessage());
		}
		logger.info("ClaimServiceImpl--saveClaimDetails--End");
		return commonResponseDto;
	}

//	@Override
//	public DataTableDto<List<ClaimDetailsListDto>> searchClaimList(String payload, String main_filter, String sort,
//			String page, String per_page, HttpServletRequest request) {
//		DataTableDto<List<ClaimDetailsListDto>> dataTableDto = new DataTableDto<>();
//		List<ClaimDetailsListDto> dtos = new ArrayList<>();
//		logger.info("ClaimServiceImpl--searchClaimList--Start");
//		try {
//			JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
//			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
//			if (commonRequestDto != null) {
//				if (commonRequestDto.getClaimRegDateFrom() != null
//						&& StringUtils.isNotEmpty(commonRequestDto.getClaimRegDateFrom())) {
//					commonRequestDto.setClaimRegDateFrom(DateUtils.dateToStringDDMMYYYYWith(
//							DateUtils.convertStringToDate(commonRequestDto.getClaimRegDateFrom())));
//				}
//				if (commonRequestDto.getClaimRegDateTo() != null
//						&& StringUtils.isNotEmpty(commonRequestDto.getClaimRegDateTo())) {
//					commonRequestDto.setClaimRegDateTo(DateUtils.dateToStringDDMMYYYYWith(
//							DateUtils.convertStringToDate(commonRequestDto.getClaimRegDateTo())));
//				}
//				if (commonRequestDto.getImdCode() != null && StringUtils.isNotEmpty(commonRequestDto.getImdCode())) {
//					commonRequestDto.setAgentCode(commonRequestDto.getImdCode());
//				}
//				if (StringUtils.isNotBlank(page) && page != null) {
//					if (page.equals("1")) {
//						commonRequestDto.setStartRownum(NumericUtils.convertIntegerToString(1));
//						commonRequestDto.setEndRownum((NumericUtils.convertIntegerToString(
//								NumericUtils.convertStringToInteger(commonRequestDto.getStartRownum()) + 7)));
//					} else {
//						commonRequestDto.setEndRownum(
//								NumericUtils.convertIntegerToString(NumericUtils.convertStringToInteger(page) * 8));
//						commonRequestDto.setStartRownum(NumericUtils.convertIntegerToString(
//								((NumericUtils.convertStringToInteger(commonRequestDto.getEndRownum()) - 8) + 1)));
//					}
//				}
//				CommonResponseDto<List<ClaimDetailsListDto>> response = new CommonResponseDto<>();
//				if (commonRequestDto.getClaimNumber() != null
//						&& StringUtils.isNotBlank(commonRequestDto.getClaimNumber())
//						&& !"OC".equals(commonRequestDto.getClaimNumber().split("-")[0])) {
//					String policyNo = claimRepository.getPolicyByClaimNumber(commonRequestDto.getClaimNumber(),
//							CommonConstants.TRUE);
//					commonRequestDto.setPolicyNumber(policyNo);
//					response = mapMisClaimDetailsList(commonRequestDto, request);
//				} else if (commonRequestDto.getPolicyNumber() != null
//						&& StringUtils.isNotBlank(commonRequestDto.getPolicyNumber())) {
//					List<ClaimEntity> claimList=claimRepository.getClaimByPolicy(commonRequestDto.getPolicyNumber());
//					for (ClaimEntity obj : claimList) {
//						//response.set);=obj.getInsuredName();
//					}
//					
////				String policyNumber = claimRepository.getPolicySourceFlagByPolicyNumber(commonRequestDto.getPolicyNumber());
////				commonRequestDto.setPolicyNumber(policyNumber);
////					response = mapMisClaimDetailsList(commonRequestDto, request);
//				} else {
//					response = claimRestService.searchClaimDetails(commonRequestDto, request);
//				}
//				Integer totalCount = 0;
//				if (response != null) {
//					if (CommonConstants.SUCCESS.equals(response.getStatus())) {
//						totalCount = NumericUtils.convertStringToInteger(response.getTotal());
//						if (response.getResponseData() != null && !response.getResponseData().isEmpty()) {
//							dataTableDto.setData(response.getResponseData());
//						} else {
//							dataTableDto.setData(dtos);
//						}
//					} else {
//						dataTableDto.setData(dtos);
//					}
//					Integer pageCount;
//					if (page != null) {
//						pageCount = NumericUtils.convertStringToInteger(page);
//					} else {
//						pageCount = 0;
//					}
//					dataTableDto.setLast_page("0");
//					dataTableDto.setTotal("0");
//					Integer limit = NumericUtils.convertStringToInteger(per_page);
//					if (response.getResponseData() != null && !response.getResponseData().isEmpty()) {
//						Integer lastReminder = (response.getResponseData().size() % limit);
//						Integer last = (response.getResponseData().size() / limit);
//						if (lastReminder == 0) {
//							dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
//						} else {
//							dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
//						}
//					}
//					Integer from = (pageCount * limit) - limit + 1;
//					Integer to = pageCount * limit;
//					dataTableDto.setPer_page(NumericUtils.convertIntegerToString(limit));
//					dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
//					dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
//					dataTableDto.setCurrent_page(NumericUtils.convertIntegerToString(pageCount));
//					dataTableDto.setTotal(NumericUtils.convertIntegerToString(totalCount));
//					Integer lastReminder = (totalCount.intValue() % limit);
//					Integer last = (totalCount.intValue() / limit);
//					if (lastReminder == 0) {
//						dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
//					} else {
//						dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
//					}
//					Integer nextPage = pageCount + 1;
//					Integer prevPage = pageCount - 1;
//					dataTableDto.setTotal(NumericUtils.convertIntegerToString(totalCount));
//					String rootUrl = CommonUtils.fetchApi("CLAIMROOTURL", getProperty());
//					dataTableDto.setNext_page_url(
//							rootUrl + "/cccp/claim/api/searchClaimList?payload=" + payload + "&main_filter="
//									+ main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
//					dataTableDto.setPrev_page_url(
//							rootUrl + "/cccp/claim/api/searchClaimList?payload=" + payload + "&main_filter="
//									+ main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
//				}
//			}
//		} catch (Exception e) {
//			logger.error("Exception--- ClaimServiceImpl--searchClaimList---", e);
//			dataTableDto.setStatus(CommonConstants.ERROR);
//			dataTableDto.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
//			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-searchClaimList", "searchClaimList", "",
//					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
//		}
//		logger.info("ClaimRepository--searchClaimList--End");
//		return dataTableDto;
//	}
	
	@Override
	public DataTableDto<List<ClaimDetailsListDto>> searchClaimList(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request) {
		DataTableDto<List<ClaimDetailsListDto>> dataTableDto = new DataTableDto<>();
		List<ClaimDetailsListDto> dtos = new ArrayList<>();
		logger.info("ClaimServiceImpl--searchClaimList--Start");
		try {
			JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			if (commonRequestDto != null) {
				if (commonRequestDto.getClaimRegDateFrom() != null
						&& StringUtils.isNotEmpty(commonRequestDto.getClaimRegDateFrom())) {
					commonRequestDto.setClaimRegDateFrom(DateUtils.dateToStringDDMMYYYYWith(
							DateUtils.convertStringToDate(commonRequestDto.getClaimRegDateFrom())));
				}
				if (commonRequestDto.getClaimRegDateTo() != null
						&& StringUtils.isNotEmpty(commonRequestDto.getClaimRegDateTo())) {
					commonRequestDto.setClaimRegDateTo(DateUtils.dateToStringDDMMYYYYWith(
							DateUtils.convertStringToDate(commonRequestDto.getClaimRegDateTo())));
				}
				if (commonRequestDto.getImdCode() != null && StringUtils.isNotEmpty(commonRequestDto.getImdCode())) {
					commonRequestDto.setAgentCode(commonRequestDto.getImdCode());
				}
				if (StringUtils.isNotBlank(page) && page != null) {
					if (page.equals("1")) {
						commonRequestDto.setStartRownum(NumericUtils.convertIntegerToString(1));
						commonRequestDto.setEndRownum((NumericUtils.convertIntegerToString(
								NumericUtils.convertStringToInteger(commonRequestDto.getStartRownum()) + 7)));
					} else {
						commonRequestDto.setEndRownum(
								NumericUtils.convertIntegerToString(NumericUtils.convertStringToInteger(page) * 8));
						commonRequestDto.setStartRownum(NumericUtils.convertIntegerToString(
								((NumericUtils.convertStringToInteger(commonRequestDto.getEndRownum()) - 8) + 1)));
					}
				}
				CommonResponseDto<List<ClaimDetailsListDto>> response = new CommonResponseDto<>();
				if ((commonRequestDto.getClaimNumber() != null && StringUtils.isNotBlank(commonRequestDto.getClaimNumber())
						&& !"OC".equals(commonRequestDto.getClaimNumber().split("-")[0])) 
						|| (commonRequestDto.getPolicyNumber() != null && StringUtils.isNotBlank(commonRequestDto.getPolicyNumber())
						&& !"OG".equals(commonRequestDto.getPolicyNumber().split("-")[0]))) {
//					String policyNo = claimRepository.getPolicyByClaimNumber(commonRequestDto.getClaimNumber(), CommonConstants.TRUE);
//					commonRequestDto.setPolicyNumber(policyNo);
//					response = mapMisClaimDetailsList(commonRequestDto, request);
					return searchUDYAMClaimList(payload, main_filter, sort, page, per_page, request);
				} else {
					response = claimRestService.searchClaimDetails(commonRequestDto, request);
				}
				Integer totalCount = 0;
				if (response != null) {
					if (CommonConstants.SUCCESS.equals(response.getStatus())) {
						totalCount = NumericUtils.convertStringToInteger(response.getTotal());
						if (response.getResponseData() != null && !response.getResponseData().isEmpty()) {
							dataTableDto.setData(response.getResponseData());
						} else {
							dataTableDto.setData(dtos);
						}
					} else {
						dataTableDto.setData(dtos);
					}
					Integer pageCount;
					if (page != null) {
						pageCount = NumericUtils.convertStringToInteger(page);
					} else {
						pageCount = 0;
					}
					dataTableDto.setLast_page("0");
					dataTableDto.setTotal("0");
					Integer limit = NumericUtils.convertStringToInteger(per_page);
					if (response.getResponseData() != null && !response.getResponseData().isEmpty()) {
						Integer lastReminder = (response.getResponseData().size() % limit);
						Integer last = (response.getResponseData().size() / limit);
						if (lastReminder == 0) {
							dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
						} else {
							dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
						}
					}
					Integer from = (pageCount * limit) - limit + 1;
					Integer to = pageCount * limit;
					dataTableDto.setPer_page(NumericUtils.convertIntegerToString(limit));
					dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
					dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
					dataTableDto.setCurrent_page(NumericUtils.convertIntegerToString(pageCount));
					dataTableDto.setTotal(NumericUtils.convertIntegerToString(totalCount));
					Integer lastReminder = (totalCount.intValue() % limit);
					Integer last = (totalCount.intValue() / limit);
					if (lastReminder == 0) {
						dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
					} else {
						dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
					}
					Integer nextPage = pageCount + 1;
					Integer prevPage = pageCount - 1;
					dataTableDto.setTotal(NumericUtils.convertIntegerToString(totalCount));
					String rootUrl = CommonUtils.fetchApi("CLAIMROOTURL", getProperty());
					dataTableDto.setNext_page_url(
							rootUrl + "/cccp/claim/api/searchClaimList?payload=" + payload + "&main_filter="
									+ main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
					dataTableDto.setPrev_page_url(
							rootUrl + "/cccp/claim/api/searchClaimList?payload=" + payload + "&main_filter="
									+ main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
				}
			}
		} catch (Exception e) {
			logger.error("Exception--- ClaimServiceImpl--searchClaimList---", e);
			dataTableDto.setStatus(CommonConstants.ERROR);
			dataTableDto.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-searchClaimList", "searchClaimList", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("ClaimRepository--searchClaimList--End");
		return dataTableDto;
	}
	
	@Override
	public DataTableDto<List<ClaimDetailsListDto>> searchUDYAMClaimList(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request) {
		DataTableDto<List<ClaimDetailsListDto>> dataTableDto = new DataTableDto<List<ClaimDetailsListDto>>();
		List<ClaimDetailsListDto> dtos = new ArrayList<ClaimDetailsListDto>();
		logger.info("ClaimServiceImpl--searchClaimList--Start");
		try {
			JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			Integer pageCount;
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<ClaimEntity> query = builder.createQuery(ClaimEntity.class);
			Root<ClaimEntity> root = query.from(ClaimEntity.class);
			List<Predicate> conditions = new ArrayList<>(1);
			
			conditions.add(builder.isNotNull(root.get("claimNumber")));
			conditions.add(builder.notEqual(root.get("claimNumber"), ""));
			if (commonRequestDto.getClaimNumber() != null
					&& StringUtils.isNotBlank(commonRequestDto.getClaimNumber())) {
				conditions.add(builder.equal(root.get("claimNumber"), commonRequestDto.getClaimNumber()));
			} else if (commonRequestDto.getPolicyNumber() != null
					&& StringUtils.isNotBlank(commonRequestDto.getPolicyNumber())) {
				conditions.add(builder.equal(root.get("policyNumber"), commonRequestDto.getPolicyNumber()));
			}
			
			query.select(root).where(conditions.toArray(new Predicate[] {}));
			if (page != null) {
				pageCount = NumericUtils.convertStringToInteger(page);
			} else {
				pageCount = 0;
			}
			Integer limit = NumericUtils.convertStringToInteger(per_page);
			Integer offset = CommonUtils.calculateOffset(pageCount, limit);

			List<ClaimEntity> list = entityManager.createQuery(query).setFirstResult(offset).setMaxResults(limit).getResultList();

			for (ClaimEntity entity : list) {
				ClaimDetailsListDto dto = new ClaimDetailsListDto();
				dto.setClaimNumber(entity.getClaimNumber());
				dto.setInsuredName(entity.getInsuredName());
				dto.setPolicyNumber(entity.getPolicyNumber());
				dto.setLossDescriptions(entity.getLossDetails());
				dto.setPlaceOfLoss(entity.getLossAddress());
				dto.setImdchannel(entity.getImdChannel());
				dto.setProductCode(entity.getProductCode());
				dto.setProductName(entity.getProductName());
				if (entity.getLossDate() != null) {
					dto.setDateOfLoss(DateUtils.dateToStringDDMMYYYYWith(entity.getLossDate()));
				}
				dto.setSumInsured(NumericUtils.convertLongToString(entity.getSumInsured()));
				dtos.add(dto);
			}
			Integer totalCount = 0;
			list = entityManager.createQuery(query).getResultList();
			totalCount = list.size();

			dataTableDto.setData(dtos);
			Integer from = (pageCount * limit) - limit + 1;
			Integer to = pageCount * limit;
			dataTableDto.setPer_page(NumericUtils.convertIntegerToString(limit));
			dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
			dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
			dataTableDto.setCurrent_page(NumericUtils.convertIntegerToString(pageCount));
			dataTableDto.setTotal(NumericUtils.convertIntegerToString(totalCount.intValue()));
			Integer lastReminder = (totalCount.intValue() % limit);
			Integer last = (totalCount.intValue() / limit);
			if (lastReminder == 0) {
				dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
			} else {
				dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
			}
			Integer nextPage = pageCount + 1;
			Integer prevPage = pageCount - 1;
			String rootUrl = CommonUtils.fetchApi("CLAIMROOTURL", getProperty());
			dataTableDto.setNext_page_url(rootUrl + "/claim/cccp/claim/api/searchClaimList?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
			dataTableDto.setPrev_page_url(rootUrl + "/claim/cccp/claim/api/searchClaimList?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
			dataTableDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Exception--- ClaimServiceImpl--searchClaimList---", e);
			dataTableDto.setStatus(CommonConstants.ERROR);
			dataTableDto.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-searchClaimList", "searchClaimList", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("ClaimRepository--searchClaimList--End");
		return dataTableDto;
	}

	private CommonResponseDto<List<ClaimDetailsListDto>> mapMisClaimDetailsList(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonResponseDto<List<ClaimDetailsListDto>> commonResponseDto = new CommonResponseDto<>();
		List<ClaimDetailsListDto> dtos = new ArrayList<>();
		logger.info("Enter into ClaimServiceImpl mapMisClaimDetails  Start");
		try {
			ClaimDetailsListDto dto = new ClaimDetailsListDto();
			CommonMisResponseDto<String> response = claimRestService.fetchMisClaimDetails(commonRequestDto, request);
			if (response != null && response.getClaimDetails() != null) {
				ClaimMisDetailsDto claimDetail = response.getClaimDetails();
				if (claimDetail.getClaimNumber() != null && StringUtils.isNotBlank(claimDetail.getClaimNumber())) {
					dto.setClaimNumber(claimDetail.getClaimNumber());
					dto.setPolicyNumber(claimDetail.getPolicyNumber());
					dto.setStatus(claimDetail.getClaimStatus());
					dto.setLossDescriptions(claimDetail.getLossDesc());
					dto.setDateOfLoss(DateUtils.convertStringToStringddMMMyyyy(claimDetail.getLossDate()));
					if (claimDetail.getClaimParty() != null && !claimDetail.getClaimParty().isEmpty()) {
						for (MaximusClaimPartyDto claimPartyDto : claimDetail.getClaimParty()) {
							dto.setInsuredName(Stream
									.of(claimPartyDto.getFirstName(), claimPartyDto.getMiddleName(),
											claimPartyDto.getLastName())
									.filter(name -> name != null && !name.isEmpty()).collect(Collectors.joining(" ")));
						}
					}
					if (claimDetail.getClaimAttribute() != null
							&& claimDetail.getClaimAttribute().getClaimAttributeDetails() != null
							&& !claimDetail.getClaimAttribute().getClaimAttributeDetails().isEmpty()) {
						for (ClaimAttributeDetailsDto claimAttributeDetailsDto : claimDetail.getClaimAttribute()
								.getClaimAttributeDetails()) {
							dto.setProductCode(claimAttributeDetailsDto.getStoredProductCode());
						}
					}
					dtos.add(dto);
				}
			}
			commonResponseDto.setTotal(NumericUtils.convertIntegerToString(dtos.size()));
			commonResponseDto.setResponseData(dtos);
			commonResponseDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Enter into ClaimServiceImpl mapMisClaimDetails Exception", e);
			e.printStackTrace();
		}
		logger.info("Enter into ClaimServiceImpl mapMisClaimDetails End");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<ClaimDetailsDto> fetchClaimDetails(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonResponseDto<ClaimDetailsDto> commonResponseDto = new CommonResponseDto<ClaimDetailsDto>();
		ClaimDetailsDto claimDetailsDto = new ClaimDetailsDto();
		logger.info("Enter into ClaimServiceImpl - fetchClaimDetails - Start");
		try {
			if ((commonRequestDto.getClaimNumber() == null && StringUtils.isBlank(commonRequestDto.getClaimNumber()))
					&& (commonRequestDto.getClaimRefNo() == null
							&& StringUtils.isBlank(commonRequestDto.getClaimRefNo()))) {
				commonResponseDto.setStatus(CommonConstants.ERROR);
				commonResponseDto.setMessage("Invalid Claim Number");
				return commonResponseDto;
			}
			if (commonRequestDto.getClaimNumber() != null
					&& StringUtils.isNotBlank(commonRequestDto.getClaimNumber())) {
				if (!"OC".equals(commonRequestDto.getClaimNumber().split("-")[0])) {
					claimDetailsDto = mapMisClaimDetails(commonRequestDto, request);

				} else {
					claimDetailsDto = claimRestService.fetchClaimDetails(commonRequestDto, request);
				}
				if (claimDetailsDto != null) {
					AdditionalDetailsDto additionalDetailsDto = new AdditionalDetailsDto();
					List<RuntimeFields> runtimeFieldsDto = new ArrayList<>();
					if (claimDetailsDto.getClaimNumber() != null
							&& StringUtils.isNotBlank(claimDetailsDto.getClaimNumber())) {
						if (claimDetailsDto.getClaimNumber() != null
								&& StringUtils.isNotBlank(claimDetailsDto.getClaimNumber())) {
							ClaimEntity claimEntity = claimRepository.findByClaimNumberAndIsActive(
									claimDetailsDto.getClaimNumber(), CommonConstants.TRUE);
							if (claimEntity != null) {
								if (claimEntity.getRunTimeFields() != null
										&& !claimEntity.getRunTimeFields().isEmpty()) {
									for (RunTimeFieldsValueEntity entity : claimEntity.getRunTimeFields()) {
										RuntimeFields dto = new RuntimeFields();
										dto.setFieldCode(entity.getFieldCode());
										dto.setFieldName(entity.getFieldName());
										dto.setFieldValue(entity.getFieldValue());
										runtimeFieldsDto.add(dto);
									}
									additionalDetailsDto.setRuntime(runtimeFieldsDto);
								}
							}
						}
					}
					if (claimDetailsDto.getAdditionalDetails() != null) {
						additionalDetailsDto.setSurveyorName(claimDetailsDto.getAdditionalDetails().getSurveyorName());
						additionalDetailsDto
								.setLossApprovedAmount(claimDetailsDto.getAdditionalDetails().getLossApprovedAmount());
						additionalDetailsDto
								.setBeneficiaryName(claimDetailsDto.getAdditionalDetails().getBeneficiaryName());
						additionalDetailsDto
								.setSurveyorRefNumber(claimDetailsDto.getAdditionalDetails().getSurveyorRefNumber());
						additionalDetailsDto.setClaimPaymentUTRNumber(
								claimDetailsDto.getAdditionalDetails().getClaimPaymentUTRNumber());
						additionalDetailsDto.setUtrDate(claimDetailsDto.getAdditionalDetails().getUtrDate());
					}
					additionalDetailsDto.setClaimNumber(claimDetailsDto.getClaimNumber());
					additionalDetailsDto.setPolicyNumber(claimDetailsDto.getPolicyNumber());
					additionalDetailsDto.setClaimHandler(claimDetailsDto.getClaimHandler());
					additionalDetailsDto.setClaimStatus(claimDetailsDto.getClaimStatus());
					additionalDetailsDto.setInsuredName(claimDetailsDto.getInsuredName());
					additionalDetailsDto.setPendingAge(claimDetailsDto.getPendingAge());
					List<Object[]> data = claimRepository.getClaimStatusByClaimNumber(commonRequestDto.getClaimNumber(),
							CommonConstants.TRUE);
					if (data != null && !data.isEmpty()) {
						for (Object[] obj : data) {
							if (obj[0] != null) {
								claimDetailsDto.setStatus(claimRepository.getStatusNameByCode(obj[0].toString()));
							}
							if (obj[1] != null) {
								claimDetailsDto.setSubStatus(claimRepository.getSubStatusNameByCode(obj[1].toString()));
							}
							if (obj[2] != null) {
								claimDetailsDto.setDeficiencyReason(claimRepository
										.getDeficiencyReasonNameByCode(obj[2].toString(), CommonConstants.TRUE));
							}
						}
					}
					claimDetailsDto.setAdditionalDetails(additionalDetailsDto);
					commonResponseDto.setResponseData(claimDetailsDto);
					commonResponseDto.setMessage(claimDetailsDto.getApplicationErr() != null
							? claimDetailsDto.getApplicationErr().getErrorDescription()
							: null);
					commonResponseDto.setStatus(CommonConstants.SUCCESS);
				} else {
					commonResponseDto.setStatus(CommonConstants.ERROR);
				}
			}

			if (commonRequestDto.getClaimRefNo() != null && StringUtils.isNotBlank(commonRequestDto.getClaimRefNo())) {
				ClaimEntity claimEntity = claimRepository.findByclaimRefNo(commonRequestDto.getClaimRefNo());
				if (claimEntity != null) {
					InsuredDetails insuredDetails = new InsuredDetails();
					insuredDetails.setPolicyNumber(claimEntity.getPolicyNumber());
					insuredDetails.setInsuredEmailId(claimEntity.getInsuredMail());
					insuredDetails.setMobileNo(NumericUtils.convertLongToString(claimEntity.getInsuredMobileNumber()));
					insuredDetails.setInsuredName(claimEntity.getInsuredName());
					claimDetailsDto.setInsuredDetails(insuredDetails);
					LossDetailsDto lossDetailsDto = new LossDetailsDto();
					lossDetailsDto.setAreaClaimBehalfOffInsure(claimEntity.getAreaClaimBehalfOffInsure());
					lossDetailsDto.setSection(claimEntity.getSection());
					lossDetailsDto.setCauseOfLoss(claimEntity.getCauseOffLoss());
					lossDetailsDto.setNotificationDate(DateUtils.convertDateTimeToString(DateUtils.sysDate()));
					lossDetailsDto.setInvoiceDate(DateUtils.convertDateTimeToString(claimEntity.getInvoiceDate()));
					lossDetailsDto.setLossAddress(claimEntity.getLossAddress());
					lossDetailsDto.setLandmark(claimEntity.getLandMark());

					lossDetailsDto.setLossDate(DateUtils.convertDateTimeToString(claimEntity.getLossDate()));
					lossDetailsDto.setLossTime(DateUtils.convertDateTimeToStringWithPeriod(claimEntity.getLossTime()));
					lossDetailsDto.setBlRrLrAwbNo(claimEntity.getBlRrLrAwbNo());
					lossDetailsDto.setLorryReceiptDate(
							DateUtils.convertDateTimeToStringWithPeriod(claimEntity.getLorryReceiptDate()));
					lossDetailsDto.setJourneyFrom(claimEntity.getJourneyFrom());
					lossDetailsDto.setJourneyTo(claimEntity.getJourneyTo());
					lossDetailsDto.setConsigneeName(claimEntity.getConsigneeName());
					lossDetailsDto.setConsigneeAddress(claimEntity.getConsigneeAddress());
					lossDetailsDto.setConsigneePhoneNo(claimEntity.getConsigneePhoneNo());
					lossDetailsDto.setClaimServicingOffice(claimEntity.getClaimServicingOffice());
					lossDetailsDto.setClaimNotifiedBy("Insured");
					lossDetailsDto.setGoodsDamagedDetails(claimEntity.getGoodsDamagedDetails());
//					lossDetailsDto.setLossEstmatedValue(
//							NumericUtils.convertDoubleToString(claimEntity.getLossEstimatedValue()));
					lossDetailsDto
							.setLossEstmatedValue(NumericUtils.roundOffvalues(claimEntity.getLossEstimatedValue()));
					lossDetailsDto.setLossAmount(NumericUtils.roundOffvalues(claimEntity.getLossAmount()));
//					lossDetailsDto.setLossAmount(NumericUtils.convertDoubleToString(claimEntity.getLossAmount()));
					lossDetailsDto.setInvoiceNumber(claimEntity.getInvoiceNumber());
					lossDetailsDto.setState(claimEntity.getState());
					lossDetailsDto.setCity(claimEntity.getCity());
					lossDetailsDto.setArea(claimEntity.getArea());
					lossDetailsDto.setLossDescription(claimEntity.getLossDetails());
					lossDetailsDto.setPincode(NumericUtils.convertIntegerToString(claimEntity.getPincode()));
					claimDetailsDto.setLossDetails(lossDetailsDto);
					if (!claimEntity.getBankDetails().isEmpty()) {
						BankDetailsDto bankDetailsDto = new BankDetailsDto();
						for (BankEntity bankEntity : claimEntity.getBankDetails()) {
							bankDetailsDto.setGstNumber(bankEntity.getGstNumber());
							bankDetailsDto.setAccountNumber(bankEntity.getAccountNumber());
							bankDetailsDto.setIfscCode(bankEntity.getIfscCode());
							bankDetailsDto.setAccountType(bankEntity.getAccountType());
							bankDetailsDto.setRegisteredMobileNumber(
									NumericUtils.convertLongToString(bankEntity.getRegisteredMobileNo()));
							bankDetailsDto.setPanNumber(bankEntity.getPanNumber());
							bankDetailsDto.setConfirmBankAccountnumber(bankEntity.getConfirmBankAccountnumber());
						}
						claimDetailsDto.setBankDetails(bankDetailsDto);
						AdditionalDetailsDto additionalDetailsDto = new AdditionalDetailsDto();
						claimDetailsDto.setAdditionalDetails(additionalDetailsDto);
					}
					commonResponseDto.setResponseData(claimDetailsDto);
					commonResponseDto.setStatus(CommonConstants.SUCCESS);
				} else {
					commonResponseDto.setStatus(CommonConstants.ERROR);
					commonResponseDto.setMessage("Invalid Claim Number");
				}
			}
		} catch (Exception e) {
			logger.error("Exception--- ClaimServiceImpl--fetchClaimDetails---", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-fetchClaimDetails", "fetchClaimDetails", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("Enter into ClaimServiceImpl - fetchClaimDetails - End");
		return commonResponseDto;
	}

	private ClaimDetailsDto mapMisClaimDetails(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		ClaimDetailsDto claimDetailsDto = new ClaimDetailsDto();
		logger.info("Enter into ClaimServiceImpl mapMisClaimDetails  Start");
		try {
			CommonMisResponseDto<String> response = claimRestService.fetchMisClaimDetails(commonRequestDto, request);
			if (response != null && response.getClaimDetails() != null) {
				ClaimMisDetailsDto claimDetail = response.getClaimDetails();
				if (claimDetail.getClaimNumber() != null && StringUtils.isNotBlank(claimDetail.getClaimNumber())) {
					claimDetailsDto.setClaimNumber(claimDetail.getClaimNumber());
					claimDetailsDto.setPolicyNumber(claimDetail.getPolicyNumber());
					claimDetailsDto.setClaimStatus(claimDetail.getClaimStatus());
					claimDetailsDto.setHowLossOccured(claimDetail.getLossDesc());
					claimDetailsDto.setDateOfLoss(DateUtils.convertStringToStringddMMMyyyy(claimDetail.getLossDate()));
					if (claimDetail.getClaimParty() != null && !claimDetail.getClaimParty().isEmpty()) {
						for (MaximusClaimPartyDto claimPartyDto : claimDetail.getClaimParty()) {
							claimDetailsDto.setInsuredName(Stream
									.of(claimPartyDto.getFirstName(), claimPartyDto.getMiddleName(),
											claimPartyDto.getLastName())
									.filter(name -> name != null && !name.isEmpty()).collect(Collectors.joining(" ")));
						}
					}
					if (claimDetail.getClaimAttribute() != null
							&& claimDetail.getClaimAttribute().getClaimAttributeDetails() != null
							&& !claimDetail.getClaimAttribute().getClaimAttributeDetails().isEmpty()) {
						for (ClaimAttributeDetailsDto claimAttributeDetailsDto : claimDetail.getClaimAttribute()
								.getClaimAttributeDetails()) {
							claimDetailsDto.setProductCode(claimAttributeDetailsDto.getStoredProductCode());
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("Enter into ClaimServiceImpl mapMisClaimDetails Exception", e);
			e.printStackTrace();
		}
		logger.info("Enter into ClaimServiceImpl mapMisClaimDetails End");
		return claimDetailsDto;
	}

	@Override
	public DataTableDto<List<ClientsFieldsConfigDto>> searchRuntimeFieldsList(String payload, String main_filter,
			String sort, String page, String per_page, HttpServletRequest request) {

		DataTableDto<List<ClientsFieldsConfigDto>> dataTableDto = new DataTableDto<List<ClientsFieldsConfigDto>>();
		logger.info("Enter into ClaimServiceImpl - searchRuntimeFieldsList Start");
		List<ClientsFieldsConfigDto> dtos = new ArrayList<>();
		try {

			JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			Integer pageCount;
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<RunTimeFieldsEntity> query = builder.createQuery(RunTimeFieldsEntity.class);
			Root<RunTimeFieldsEntity> root = query.from(RunTimeFieldsEntity.class);
			List<RunTimeFieldsEntity> list = new ArrayList<RunTimeFieldsEntity>();
			List<Predicate> conditions = new ArrayList<>(1);
			if (!StringUtils.isEmpty(commonRequestDto.getPolicyNumber())
					|| !StringUtils.isEmpty(commonRequestDto.getPartnerId())) {
				if (!StringUtils.isEmpty(commonRequestDto.getPartnerId())
						&& !StringUtils.isEmpty(commonRequestDto.getPolicyNumber())) {
					Predicate partnerId = builder.equal(root.get("partnerId"), commonRequestDto.getPartnerId());
					Predicate policyNumber = builder.equal(root.get("policyNumber"),
							commonRequestDto.getPolicyNumber());
					Predicate policyNumberAndPartnerId = builder.and(policyNumber, partnerId);
					conditions.add(policyNumberAndPartnerId);
				} else if (!StringUtils.isEmpty(commonRequestDto.getPolicyNumber())) {
					conditions.add(builder.equal(root.get("policyNumber"), commonRequestDto.getPolicyNumber()));
				} else if (!StringUtils.isEmpty(commonRequestDto.getPartnerId())) {
					conditions.add(builder.equal(root.get("partnerId"), commonRequestDto.getPartnerId()));
				}

				query.select(root).where(conditions.toArray(new Predicate[] {}));
				query.select(root.get("policyNumber")).distinct(true);
				if (page != null) {
					pageCount = NumericUtils.convertStringToInteger(page);
				} else {
					pageCount = 0;
				}
				String sortName = sort;
				String order = "";
				if (StringUtils.isNotBlank(sort)) {
					String[] splitted = sort.split("\\-");
					sortName = splitted[0];
					order = splitted.length >= 2 ? splitted[1] : "createdDate";
				}
				System.out.println(sortName);
				Integer limit = NumericUtils.convertStringToInteger(per_page);
				Integer offset = CommonUtils.calculateOffset(pageCount, limit);

				list = entityManager.createQuery(query).setFirstResult(offset).setMaxResults(limit).getResultList();
				List<RunTimeFieldsEntity> list1 = new ArrayList<RunTimeFieldsEntity>();
				list1 = entityManager.createQuery(query).getResultList();
				if (StringUtils.isNotBlank(order) && order.equalsIgnoreCase(CommonConstants.ASC)
						&& StringUtils.isNotBlank(sortName)) {
					if (sortName.equalsIgnoreCase("partnerId")) {
						query.orderBy(builder.asc(root.get("partnerId")));
					} else if (sortName.equalsIgnoreCase("policyNumber")) {
						query.orderBy(builder.asc(root.get("policyNumber")));
					} else if (sortName.equalsIgnoreCase("fieldCode")) {
						query.orderBy(builder.asc(root.get("fieldCode")));
					} else if (sortName.equalsIgnoreCase("fieldType")) {
						query.orderBy(builder.asc(root.get("fieldType")));
					} else if (sortName.equalsIgnoreCase("fieldName")) {
						query.orderBy(builder.desc(root.get("fieldName")));
					} else if (sortName.equalsIgnoreCase("effectiveFromDate")) {
						query.orderBy(builder.desc(root.get("effectiveFromDate")));
					} else if (sortName.equalsIgnoreCase("effectiveToDate")) {
						query.orderBy(builder.desc(root.get("effectiveToDate")));
					} else if (sortName.equalsIgnoreCase("createdBy")) {
						query.orderBy(builder.desc(root.get("createdBy")));
					} else if (sortName.equalsIgnoreCase("createdDate")) {
						query.orderBy(builder.desc(root.get("createdDate")));
					} else if (sortName.equalsIgnoreCase("modifiedBy")) {
						query.orderBy(builder.desc(root.get("modifiedBy")));
					} else if (sortName.equalsIgnoreCase("modifiedDate")) {
						query.orderBy(builder.desc(root.get("modifiedDate")));
					}

				} else if (StringUtils.isNotBlank(order) && order.equalsIgnoreCase(CommonConstants.DESC)
						&& StringUtils.isNotBlank(sortName)) {
					if (sortName.equalsIgnoreCase("partnerId")) {
						query.orderBy(builder.desc(root.get("partnerId")));
					} else if (sortName.equalsIgnoreCase("policyNumber")) {
						query.orderBy(builder.desc(root.get("policyNumber")));
					} else if (sortName.equalsIgnoreCase("effectiveFromDate")) {
						query.orderBy(builder.desc(root.get("effectiveFromDate")));
					} else if (sortName.equalsIgnoreCase("effectiveToDate")) {
						query.orderBy(builder.desc(root.get("effectiveToDate")));
					} else if (sortName.equalsIgnoreCase("createdDate")) {
						query.orderBy(builder.desc(root.get("createdDate")));
					} else if (sortName.equalsIgnoreCase("modifiedDate")) {
						query.orderBy(builder.desc(root.get("modifiedDate")));
					} else if (sortName.equalsIgnoreCase("fieldCode")) {
						query.orderBy(builder.desc(root.get("fieldCode")));
					} else if (sortName.equalsIgnoreCase("fieldType")) {
						query.orderBy(builder.desc(root.get("fieldType")));
					} else if (sortName.equalsIgnoreCase("fieldName")) {
						query.orderBy(builder.desc(root.get("fieldName")));
					} else if (sortName.equalsIgnoreCase("createdBy")) {
						query.orderBy(builder.desc(root.get("createdBy")));
					} else if (sortName.equalsIgnoreCase("modifiedBy")) {
						query.orderBy(builder.desc(root.get("modifiedBy")));
					}
				}

				dtos = mapEntityToDto(list, commonRequestDto.getPartnerId());

//				ClientsFieldsConfigDto rolessDto = mapEntityToDto(list);
//				dtos.add(rolessDto);

//				list.forEach(entity -> {
//					ClientsFieldsConfigDto rolessDto = mapEntityToDto(entity);
//					dtos.add(rolessDto);
//				});

				Integer totalCount = 0;
//				list = entityManager.createQuery(query).getResultList();
				totalCount = list1.size();

				dataTableDto.setData(dtos);
				Integer from = (pageCount * limit) - limit + 1;
				Integer to = pageCount * limit;

				dataTableDto.setPer_page(NumericUtils.convertIntegerToString(limit));
				dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
				dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
				dataTableDto.setCurrent_page(NumericUtils.convertIntegerToString(pageCount));
				dataTableDto.setTotal(NumericUtils.convertIntegerToString(totalCount.intValue()));
				Integer lastReminder = (totalCount.intValue() % limit);
				Integer last = (totalCount.intValue() / limit);
				if (lastReminder == 0) {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
				} else {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
				}

				Integer nextPage = pageCount + 1;
				Integer prevPage = pageCount - 1;
				String rootUrl = CommonUtils.fetchApi("CLAIMROOTURL", getProperty());
				dataTableDto.setNext_page_url(
						rootUrl + "/cccp/claim/api/searchRuntimeFieldsConfig?payload=" + payload + "&main_filter="
								+ main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
				dataTableDto.setPrev_page_url(
						rootUrl + "/cccp/claim/api/searchRuntimeFieldsConfig?payload=" + payload + "&main_filter="
								+ main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
				dataTableDto.setStatus(CommonConstants.SUCCESS);
			} else {
				dataTableDto.setStatus(CommonConstants.ERROR);
				dataTableDto.setMessage("Policy Number not nullable");
			}
		} catch (Exception e) {
			dataTableDto.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-searchRuntimeFieldsList",
					"searchRuntimeFieldsList", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
			logger.error("Exception-ClaimServiceImpl-searchRuntimeFieldsList", e);
			dataTableDto.setStatus(CommonConstants.ERROR);
			dataTableDto.setError(e.getMessage());
		}
		logger.info("ClaimServiceImpl - searchRuntimeFieldsList--End");
		return dataTableDto;
	}

	private List<ClientsFieldsConfigDto> mapEntityToDto(List<RunTimeFieldsEntity> list, String partnerId) {
//		ClientsFieldsConfigDto dto = new ClientsFieldsConfigDto();
		logger.info("Enter into ClaimServiceImpl - mapEntityToDto -Start");
		List<ClientsFieldsConfigDto> clientsFieldsConfigDtos = new ArrayList<ClientsFieldsConfigDto>();
		try {

			for (Object data : list) {
				String policyNumber = (String) data;
				ClientsFieldsConfigDto clientsFieldsConfigDto = new ClientsFieldsConfigDto();
				clientsFieldsConfigDto.setPartnerId(partnerId);
				clientsFieldsConfigDto.setPolicyNumber(policyNumber);
				List<RunTimeFieldsEntity> entity = new ArrayList<>();
				if (!partnerId.isEmpty()) {
					entity = runTimeFieldsRepository.findByPartnerIdAndPolicyNumberOrderById(partnerId, policyNumber);
				} else {
					entity = runTimeFieldsRepository.findByPolicyNumberOrderById(policyNumber);
				}

				List<RuntimeFields> dtos = new ArrayList<>();
				for (RunTimeFieldsEntity task : entity) {
					if (entity.size() > 0) {
						if (task.getPolicyNumber().equalsIgnoreCase(policyNumber)) {
							RuntimeFields dto1 = new RuntimeFields();
							dto1.setFieldCode(task.getFieldCode());
							dto1.setFieldName(task.getFieldName());
							dto1.setFieldType(task.getFieldType());
							dto1.setIsActive(task.getIsActive());
							clientsFieldsConfigDto.setPartnerId(task.getPartnerId());
							clientsFieldsConfigDto.setEffectiveFromDate(
									DateUtils.convertDateTimeToString(task.getEffectiveFromDate()));
							dtos.add(dto1);
						} else {
							continue;
						}
					}
				}

				clientsFieldsConfigDto.setFieldDetails(dtos);
				clientsFieldsConfigDtos.add(clientsFieldsConfigDto);
			}

		} catch (Exception e) {
			logger.error("Exception-ClaimServiceImpl-mapEntityToDto", e);
		}
		logger.info("Enter into ClaimServiceImpl - mapEntityToDto -End");
		return clientsFieldsConfigDtos;
	}

//	private ClientsFieldsConfigDto mapEntityToDto(List<RunTimeFieldsEntity> list) {
//		ClientsFieldsConfigDto dto = new ClientsFieldsConfigDto();
//		logger.info("Enter into ClaimServiceImpl - mapEntityToDto -Start");
//		try {
//			
//			List<RuntimeFields> dtos = new ArrayList<>();
//			
//			for (RunTimeFieldsEntity task : list) {
//				RuntimeFields dto1 = new RuntimeFields();
//				dto1.setFieldCode(task.getFieldCode());
//				dto1.setFieldName(task.getFieldName());
//				dto1.setFieldType(task.getFieldType());
//				dto1.setIsActive(task.getIsActive());
////				dto1.setFieldValue(task.getFieldValue());
//				dto.setPartnerId(task.getPartnerId());
//				dto.setPolicyNumber(task.getPolicyNumber());
//				dtos.add(dto1);
//			}
// 			dto.setFieldDetails(dtos);
////			dto.setPolicyNumber(list.getPolicyNumber());
////			dto.setPartnerId(list.getPartnerId());
////			dto.setCreatedDate(DateUtils.convertDateTimeToString(entity.getCreatedDate()));
////			dto.setStatus(String.valueOf(entity.getIsActive()));
////			dto.setCorporateUserId(entity.getCorporateId());
//		} catch (Exception e) {
//			logger.error("Exception-ClaimServiceImpl-mapEntityToDto", e);
//		}
//		logger.info("Enter into ClaimServiceImpl - mapEntityToDto -End");
//		return dto;
//	}

	@Override
	public CommonResponseDto<ClientsFieldsConfigDto> saveRuntimeFields(ClientsFieldsConfigDto dto,
			HttpServletRequest request) {
		CommonResponseDto<ClientsFieldsConfigDto> commonResponseDto = new CommonResponseDto<>();
		logger.info("ClaimServiceImpl--saveRuntimeFieldsConfig--Start");
		try {
			if (dto.getClientsFieldsConfigDto() != null) {
				for (ClientsFieldsConfigDto dto1 : dto.getClientsFieldsConfigDto()) {
					List<RuntimeFields> runtimeField = dto1.getFieldDetails();
					if (!runtimeField.isEmpty()) {
						for (RuntimeFields field : runtimeField) {
							RunTimeFieldsEntity entity1 = runTimeFieldsRepository
									.findByPolicyNumberAndFieldCode(dto1.getPolicyNumber(), field.getFieldCode());
							if (entity1 != null) {
								entity1.setPolicyNumber(dto1.getPolicyNumber());
								entity1.setPartnerId(dto1.getPartnerId());
//								entity1.setEffectiveFromDate(DateUtils.convertStringToDate(dto.getEffectiveFromDate()));
//								entity1.setFieldCode(currentTimeMillis);
								entity1.setFieldName(field.getFieldName());
								entity1.setFieldType(field.getFieldType());
								entity1.setOrderNo(NumericUtils.convertStringToInteger(field.getOrderNo()));
								entity1.setIsActive(field.getIsActive());
								entity1.setModifiedDate(DateUtils.sysDate());
								runTimeFieldsRepository.save(entity1);
							} else {
								RunTimeFieldsEntity entity = new RunTimeFieldsEntity();
								entity.setPolicyNumber(dto1.getPolicyNumber());
								entity.setPartnerId(dto1.getPartnerId());
								entity.setEffectiveFromDate(new Date());
								entity.setFieldCode(field.getFieldCode());
								entity.setFieldName(field.getFieldName());
								entity.setFieldType(field.getFieldType());
								entity.setIsActive(field.getIsActive());
								entity.setOrderNo(NumericUtils.convertStringToInteger(field.getOrderNo()));
								entity.setCreatedDate(DateUtils.sysDate());
								runTimeFieldsRepository.save(entity);
							}
						}
						commonResponseDto.setStatus(CommonConstants.SUCCESS);
					} else {
						commonResponseDto.setStatus(CommonConstants.ERROR);
					}
//					commonResponseDto.setStatus(CommonConstants.SUCCESS);
				}

			} else {
				List<RuntimeFields> runtimeField = dto.getFieldDetails();
				if (!runtimeField.isEmpty()) {
					for (RuntimeFields field : runtimeField) {
//						RunTimeFieldsEntity entity1 = runTimeFieldsRepository
//								.findByPartnerIdAndPolicyNumberAndFieldCode(dto.getPartnerId(), dto.getPolicyNumber(),
//										field.getFieldCode());
						RunTimeFieldsEntity entity1 = runTimeFieldsRepository
								.findByPolicyNumberAndFieldCode(dto.getPolicyNumber(), field.getFieldCode());
						if (entity1 != null) {
							entity1.setPolicyNumber(dto.getPolicyNumber());
							entity1.setPartnerId(dto.getPartnerId());
//							entity1.setEffectiveFromDate(DateUtils.convertStringToDate(dto.getEffectiveFromDate()));
//							entity1.setFieldCode(currentTimeMillis);
							entity1.setFieldName(field.getFieldName());
							entity1.setOrderNo(NumericUtils.convertStringToInteger(field.getOrderNo()));
							entity1.setFieldType(field.getFieldType());
							entity1.setIsActive(field.getIsActive());
							entity1.setModifiedDate(new Date());
							runTimeFieldsRepository.save(entity1);
						} else {
							RunTimeFieldsEntity entity = new RunTimeFieldsEntity();
//							String currentTimeMillis = NumericUtils.convertLongToString(System.currentTimeMillis());
							entity.setPolicyNumber(dto.getPolicyNumber());
							entity.setPartnerId(dto.getPartnerId());
							entity.setEffectiveFromDate(DateUtils.convertStringToDate(dto.getEffectiveFromDate()));
							entity.setFieldCode(field.getFieldCode());
							entity.setFieldName(field.getFieldName());
							entity.setOrderNo(NumericUtils.convertStringToInteger(field.getOrderNo()));
							entity.setFieldType(field.getFieldType());
							entity.setIsActive(field.getIsActive());
							entity.setCreatedDate(new Date());
							runTimeFieldsRepository.save(entity);
						}
					}
				}
				commonResponseDto.setStatus(CommonConstants.SUCCESS);
			}
		} catch (Exception e) {
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl--saveRuntimeFieldsConfig", "saveRuntimeFields",
					"", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
			logger.error("Exception-ClaimServiceImpl--saveRuntimeFieldsConfig", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setError(e.getMessage());
		}
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<ClientsFieldsConfigDto> fetchRuntimeFields(String policyNumber,
			HttpServletRequest request) {
		CommonResponseDto<ClientsFieldsConfigDto> commonResponseDto = new CommonResponseDto<ClientsFieldsConfigDto>();
		ClientsFieldsConfigDto clientsFieldsConfigDto = new ClientsFieldsConfigDto();
		logger.info("Enter into ClaimServiceImpl - fetchRuntimeFields - Start");
		try {
			if (policyNumber == null && StringUtils.isBlank(policyNumber)) {
				commonResponseDto.setStatus(CommonConstants.ERROR);
				commonResponseDto.setMessage("Invalid Policy Number");
				return commonResponseDto;
			}
			if (policyNumber != null && StringUtils.isNotBlank(policyNumber)) {
				List<RunTimeFieldsEntity> entity = runTimeFieldsRepository.findByPolicyNumberAndIsActive(policyNumber,
						CommonConstants.TRUE);
				List<RuntimeFields> dtos = new ArrayList<>();
				for (RunTimeFieldsEntity task : entity) {
					if (entity.size() > 0) {
						if (task.getPolicyNumber().equalsIgnoreCase(policyNumber)) {
							RuntimeFields dto1 = new RuntimeFields();
							dto1.setFieldCode(task.getFieldCode());
							dto1.setFieldName(task.getFieldName());
							dto1.setFieldType(task.getFieldType());
							dto1.setIsActive(task.getIsActive());
							dto1.setOrderNo(NumericUtils.convertIntegerToString(task.getOrderNo()));
							clientsFieldsConfigDto.setPolicyNumber(task.getPolicyNumber());
							clientsFieldsConfigDto.setPartnerId(task.getPartnerId());
							clientsFieldsConfigDto.setEffectiveFromDate(
									DateUtils.convertDateTimeToString(task.getEffectiveFromDate()));
							dtos.add(dto1);
						}
					}
				}

				clientsFieldsConfigDto.setFieldDetails(dtos);
			}
			commonResponseDto.setResponseData(clientsFieldsConfigDto);
			commonResponseDto.setStatus("SUCCESS");

		} catch (Exception e) {
			logger.error("Exception--- ClaimServiceImpl--fetchRuntimeFields---", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-fetchRuntimeFields", "fetchRuntimeFields", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("Enter into ClaimServiceImpl - fetchRuntimeFields - End");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<String> getUpdateClaimList(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		try {
			String productCatgory = null;
			List<RuntimeFields> runtimeFieldsList = new ArrayList<>();
			if ((commonRequestDto.getStartDate() != null && StringUtils.isNotEmpty(commonRequestDto.getStartDate()))
					&& (commonRequestDto.getEndDate() != null
							&& StringUtils.isNotEmpty(commonRequestDto.getEndDate()))) {
				List<ClaimEntity> claimEntities = claimRepository
						.findByPolicyNumberAndModifiedDateBetweenAndClaimNumberIsNotNull(
								commonRequestDto.getPolicyNumber(),
								DateUtils.convertDateTimeToString(commonRequestDto.getStartDate() + " 00:00:00"),
								DateUtils.convertDateTimeToString(commonRequestDto.getEndDate() + " 23:59:59"));
				if (!claimEntities.isEmpty()) {
					productCatgory = claimRepository.findByProductCatgoryByCode(claimEntities.get(0).getProductCode());
					for (ClaimEntity claimEntity : claimEntities) {
						RuntimeFields runtimeFields = new RuntimeFields();
						List<RunTimeFieldsValueDto> fieldsValueDtos = new ArrayList<>();
						runtimeFields.setClaimNumber(claimEntity.getClaimNumber());
						runtimeFields.setPolicyNumber(claimEntity.getPolicyNumber());
						runtimeFields.setBlRrLrAwbNo(claimEntity.getBlRrLrAwbNo());
						runtimeFields.setCreatedDate(DateUtils.dateToStringDDMMYYYYWith(claimEntity.getCreatedDate()));
						runtimeFields.setCreatedBy(claimEntity.getCreatedBy());
						runtimeFields.setEmail(claimEntity.getInsuredMail());
						runtimeFields
								.setMobileNo(NumericUtils.convertLongToString(claimEntity.getInsuredMobileNumber()));
						if (!claimEntity.getRunTimeFields().isEmpty()) {
							List<RunTimeFieldsValueEntity> sortedList = claimEntity.getRunTimeFields().stream()
									.sorted(Comparator.comparingInt(RunTimeFieldsValueEntity::getOrderNo))
									.collect(Collectors.toList());
							for (RunTimeFieldsValueEntity runTimeFieldsValue : sortedList) {
								RunTimeFieldsValueDto fieldsValue = new RunTimeFieldsValueDto();
								fieldsValue.setFieldValue(runTimeFieldsValue.getFieldValue());
								fieldsValue.setFieldName(runTimeFieldsValue.getFieldName());
								fieldsValueDtos.add(fieldsValue);
							}
						}
						runtimeFields.setRunTimeFieldsValue(fieldsValueDtos);
						runtimeFieldsList.add(runtimeFields);
					}
				}
				commonResponseDto.setTotal(NumericUtils.convertIntegerToString(claimEntities.size()));
			}

			// workbook object
			XSSFWorkbook workbook = new XSSFWorkbook();
			// spreadsheet object
			XSSFSheet spreadsheet = workbook.createSheet(" Update Claim Details ");
			// creating a row object
			XSSFRow row;
			// This data needs to be written (Object[])

			Map<String, Object[]> menuData = new TreeMap<>();

			List<RunTimeFieldsEntity> runtimeFields = runTimeFieldsRepository
					.findByIsActiveAndPolicyNumberOrderByOrderNoAsc(CommonConstants.TRUE,
							commonRequestDto.getPolicyNumber());
//			Integer size = 7 + (runtimeFields.size() == 0 ? 0 : runtimeFields.size());
			List<String> listStr = new ArrayList<>();
			listStr.add("Claim Number");
			listStr.add("Policy No");
			listStr.add("Claim Registartion date");
			listStr.add("Insured Email");
			listStr.add("Insured MobileNo");
			listStr.add("Claim Reg By");
			if (productCatgory != null && productCatgory.equals(CommonConstants.MARINE)) {
				listStr.add("Bl Rr Lr Awb No");
			}
			Integer staticHeaderSize = listStr.size();
			Integer size = listStr.size() + (runtimeFields.size() == 0 ? 0 : runtimeFields.size());
			Object[] header = new Object[size];
			for (RunTimeFieldsEntity field : runtimeFields) {
				listStr.add(field.getFieldName());
			}
			for (int i = 0; i < listStr.size(); i++) {
				header[i] = listStr.get(i);
			}
			menuData.put("1", header);
			if (!runtimeFieldsList.isEmpty()) {
				for (int i = 0; i < runtimeFieldsList.size(); i++) {
					RuntimeFields runtimeDto = runtimeFieldsList.get(i);
					Object[] body = new Object[size];
					body[0] = runtimeDto.getClaimNumber() == null ? "" : runtimeDto.getClaimNumber();
					body[1] = runtimeDto.getPolicyNumber() == null ? "" : runtimeDto.getPolicyNumber();
					body[2] = runtimeDto.getCreatedDate() == null ? "" : runtimeDto.getCreatedDate();
					body[3] = runtimeDto.getEmail() == null ? "" : runtimeDto.getEmail();
					body[4] = runtimeDto.getMobileNo() == null ? "" : runtimeDto.getMobileNo();
					body[5] = runtimeDto.getCreatedBy() == null ? "" : runtimeDto.getCreatedBy();
					if (productCatgory != null && productCatgory.equals(CommonConstants.MARINE)) {
						body[6] = runtimeDto.getBlRrLrAwbNo() == null ? "" : runtimeDto.getBlRrLrAwbNo();
					}
//					if(!runtimeDto.getRunTimeFieldsValue().isEmpty()) {
//						for (int j = 7; j < header.length; j++) {
//							body[j] = runtimeDto.getRunTimeFieldsValue().get(i).getFieldValue();
//							
//						}	
//					}
					if (!runtimeDto.getRunTimeFieldsValue().isEmpty()) {
						for (int j = 0; j < runtimeDto.getRunTimeFieldsValue().size(); j++) {
							body[staticHeaderSize + j] = runtimeDto.getRunTimeFieldsValue().get(j).getFieldValue();
						}
					}
					menuData.put(NumericUtils.convertIntegerToString(i + 2), body);
				}
			}
			Set<String> keyid = menuData.keySet();
			int rowid = 0;
			// writing the data into the sheets...
			for (String key : keyid) {
				row = spreadsheet.createRow(rowid++);
				Object[] objectArr = menuData.get(key);
				int cellid = 0;
				for (Object obj : objectArr) {
//					System.err.println(obj);
					Cell cell = row.createCell(cellid++);
					cell.setCellValue((String) obj);
				}
			}
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbook.write(bos);
			String base64String = null;
			byte[] bytes = bos.toByteArray();
			base64String = org.apache.commons.codec.binary.Base64.encodeBase64String(bytes);
			workbook.close();
			commonResponseDto.setResponseData(base64String);
			commonResponseDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Exception--- ClaimServiceImpl--getUpdateClaimList---", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "ClaimServiceImpl-getUpdateClaimList", "getUpdateClaimList", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<ClaimDetailsDto> getUDYAMClaimDetails(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("Enter into ClaimServiceImpl getUDYAMClaimDetails start...");
		CommonResponseDto<ClaimDetailsDto> commonResponseDto = new CommonResponseDto<>();
		ClaimDetailsDto claimDetailsDto = new ClaimDetailsDto();
		try {
			if (commonRequestDto != null && commonRequestDto.getClaimNumber() != null
					&& StringUtils.isNotBlank(commonRequestDto.getClaimNumber())) {
				ClaimEntity claimEntity = claimRepository
						.findByClaimNumberAndIsActive(commonRequestDto.getClaimNumber(), CommonConstants.TRUE);
				if (claimEntity != null) {
					claimDetailsDto.setProductCode(claimEntity.getProductCode());
					InsuredDetails insuredDetails = new InsuredDetails();
					insuredDetails.setPolicyNumber(claimEntity.getPolicyNumber());
					insuredDetails.setInsuredEmailId(claimEntity.getInsuredMail());
					insuredDetails.setMobileNo(NumericUtils.convertLongToString(claimEntity.getInsuredMobileNumber()));
					insuredDetails.setInsuredName(claimEntity.getInsuredName());
					claimDetailsDto.setInsuredDetails(insuredDetails);
					LossDetailsDto lossDetailsDto = new LossDetailsDto();
					lossDetailsDto.setAreaClaimBehalfOffInsure(claimEntity.getAreaClaimBehalfOffInsure());
					lossDetailsDto.setSection(claimEntity.getSection());
					lossDetailsDto.setCauseOfLoss(claimEntity.getCauseOffLoss());
					lossDetailsDto.setNotificationDate(DateUtils.convertDateTimeToString(DateUtils.sysDate()));
					lossDetailsDto.setInvoiceDate(DateUtils.convertDateTimeToString(claimEntity.getInvoiceDate()));
					lossDetailsDto.setLossAddress(claimEntity.getLossAddress());
					lossDetailsDto.setLandmark(claimEntity.getLandMark());
					lossDetailsDto.setLossDate(DateUtils.dateToStringFormatddMmYyyy(claimEntity.getLossDate()));
					lossDetailsDto.setLossTime(DateUtils.dateToStringFormatHhMmSsWithA(claimEntity.getLossTime()));
					lossDetailsDto.setBlRrLrAwbNo(claimEntity.getBlRrLrAwbNo());
					lossDetailsDto.setLorryReceiptDate(
							DateUtils.convertDateTimeToStringWithPeriod(claimEntity.getLorryReceiptDate()));
					lossDetailsDto.setJourneyFrom(claimEntity.getJourneyFrom());
					lossDetailsDto.setJourneyTo(claimEntity.getJourneyTo());
					lossDetailsDto.setConsigneeName(claimEntity.getConsigneeName());
					lossDetailsDto.setConsigneeAddress(claimEntity.getConsigneeAddress());
					lossDetailsDto.setConsigneePhoneNo(claimEntity.getConsigneePhoneNo());
					lossDetailsDto.setClaimServicingOffice(claimEntity.getClaimServicingOffice());
					lossDetailsDto.setClaimNotifiedBy("Insured");
					lossDetailsDto.setGoodsDamagedDetails(claimEntity.getGoodsDamagedDetails());
					lossDetailsDto
							.setLossEstmatedValue(NumericUtils.roundOffvalues(claimEntity.getLossEstimatedValue()));
					lossDetailsDto.setLossAmount(NumericUtils.roundOffvalues(claimEntity.getLossAmount()));
					lossDetailsDto.setInvoiceNumber(claimEntity.getInvoiceNumber());
					lossDetailsDto.setState(claimEntity.getState());
					lossDetailsDto.setCity(claimEntity.getCity());
					lossDetailsDto.setArea(claimEntity.getArea());
					lossDetailsDto.setLossDescription(claimEntity.getLossDetails());
					lossDetailsDto.setPincode(NumericUtils.convertIntegerToString(claimEntity.getPincode()));
					claimDetailsDto.setLossDetails(lossDetailsDto);
					if (!claimEntity.getBankDetails().isEmpty()) {
						BankDetailsDto bankDetailsDto = new BankDetailsDto();
						for (BankEntity bankEntity : claimEntity.getBankDetails()) {
							bankDetailsDto.setGstNumber(bankEntity.getGstNumber());
							bankDetailsDto.setAccountNumber(bankEntity.getAccountNumber());
							bankDetailsDto.setIfscCode(bankEntity.getIfscCode());
							bankDetailsDto.setAccountType(bankEntity.getAccountType());
							bankDetailsDto.setRegisteredMobileNumber(
									NumericUtils.convertLongToString(bankEntity.getRegisteredMobileNo()));
							bankDetailsDto.setPanNumber(bankEntity.getPanNumber());
							bankDetailsDto.setConfirmBankAccountnumber(bankEntity.getConfirmBankAccountnumber());
						}
						claimDetailsDto.setBankDetails(bankDetailsDto);
						AdditionalDetailsDto additionalDetailsDto = new AdditionalDetailsDto();
						claimDetailsDto.setAdditionalDetails(additionalDetailsDto);
					}
					commonResponseDto.setResponseData(claimDetailsDto);
					commonResponseDto.setStatus(CommonConstants.SUCCESS);
				} else {
					commonResponseDto.setStatus(CommonConstants.ERROR);
					commonResponseDto.setMessage("Invalid Claim Number");
				}
			}
		} catch (Exception e) {
			logger.error("Enter into ClaimServiceImpl getUDYAMClaimDetails Exception", e);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
		}
		logger.info("Enter into ClaimServiceImpl getUDYAMClaimDetails end...");
		return commonResponseDto;
	}

}
