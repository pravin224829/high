//package com.fa.bajajallianz.cccp;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class ClaimServiceV1ApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
