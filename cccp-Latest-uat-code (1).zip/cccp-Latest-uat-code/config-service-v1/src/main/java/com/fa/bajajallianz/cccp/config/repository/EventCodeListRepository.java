package com.fa.bajajallianz.cccp.config.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.master.entity.EventCodeListEntity;
import com.fa.bajajallianz.cccp.master.entity.GradeQuestionnaireMasterEntity;

public interface EventCodeListRepository extends JpaRepository<EventCodeListEntity, Long> {

	List<EventCodeListEntity> findByIsActive(Boolean true1);
}
