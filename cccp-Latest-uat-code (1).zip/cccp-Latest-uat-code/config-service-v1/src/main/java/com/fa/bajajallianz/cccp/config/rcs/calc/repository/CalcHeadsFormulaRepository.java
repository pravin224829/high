package com.fa.bajajallianz.cccp.config.rcs.calc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.master.entity.CalcHeadsFormulaEntity;
@Repository
public interface CalcHeadsFormulaRepository  extends JpaRepository<CalcHeadsFormulaEntity, Long>{


	List<CalcHeadsFormulaEntity> findByCalcHeadsAttributeIdAndIsActive(String code,Boolean true1);

}
