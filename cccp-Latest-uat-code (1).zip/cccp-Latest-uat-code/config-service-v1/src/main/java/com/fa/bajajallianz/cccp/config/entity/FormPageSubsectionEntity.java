package com.fa.bajajallianz.cccp.config.entity;

/**
 * @author praveen
 *
 */

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "form_page_sub_sections")
public class FormPageSubsectionEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", length = 20, nullable = false)
	private Long id;

	@Column(name = "additional_info", length = 5000)
	private String additionalInfo;

	@Column(name = "description", length = 5000)
	private String description;

	@Column(name = "display_name", length = 300)
	private String displayName;

	@Column(name = "is_active", nullable = false)
	private Boolean isActive;

	@Column(name = "order_no", length = 10, nullable = false)
	private Integer orderNo;

	@Column(name = "subsection_code", length = 50, nullable = false, unique = true)
	private String subsectionCode;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_date")
	private Date modifiedDate;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, targetEntity = FormPageSectionEntity.class)
	@JoinColumn(name = "section_id")
	private FormPageSectionEntity formPageSection;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "formPageSubsection")
	private Set<FormPageFieldgroupEntity> fieldGroup;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}

	public String getSubsectionCode() {
		return subsectionCode;
	}

	public void setSubsectionCode(String subsectionCode) {
		this.subsectionCode = subsectionCode;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public FormPageSectionEntity getFormPageSection() {
		return formPageSection;
	}

	public void setFormPageSection(FormPageSectionEntity formPageSection) {
		this.formPageSection = formPageSection;
	}

	public Set<FormPageFieldgroupEntity> getFieldGroup() {
		return fieldGroup;
	}

	public void setFieldGroup(Set<FormPageFieldgroupEntity> fieldGroup) {
		this.fieldGroup = fieldGroup;
	}

}
