package com.fa.bajajallianz.cccp.config.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.config.dto.DeficiencyReasonDetailsDto;
import com.fa.bajajallianz.cccp.config.dto.FormPageDto;
import com.fa.bajajallianz.cccp.config.dto.FormPageSubsectionsDto;
import com.fa.bajajallianz.cccp.master.dto.EventCodeListDto;

public interface ConfigurationService {

	CommonResponseDto<List<FormPageDto>> fetchFormPage(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonResponseDto<List<FormPageSubsectionsDto>> fetchFormPageFields(CommonRequestDto commonRequestDto,
			HttpServletRequest request);

	CommonResponseDto<List<DeficiencyReasonDetailsDto>> fetchDeficiencyReason(CommonRequestDto commonRequestDto,
			HttpServletRequest request);

	CommonResponseDto<List<EventCodeListDto>> fetchEventCodeList(CommonRequestDto commonRequestDto,
			HttpServletRequest request);

//	CommonResponseDto<List<FormPageDto>> fetchUserHierarchyDetails(CommonRequestDto commonRequestDto,
//			HttpServletRequest request);
//	

	
}
