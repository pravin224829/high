package com.fa.bajajallianz.cccp.master.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.common.dto.ApiConfigDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimInsurerHistoryDto;
import com.fa.bajajallianz.cccp.common.dto.CommonMasterDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.dto.DocumentDto;
import com.fa.bajajallianz.cccp.common.dto.LookUpValuesDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.master.dto.MasterDto;
import com.fa.bajajallianz.cccp.master.dto.MenuPagesDto;
import com.fa.bajajallianz.cccp.master.dto.ReportTypeDto;
import com.fa.bajajallianz.cccp.master.dto.CauseOfLossDto;
import com.fa.bajajallianz.cccp.master.dto.GradeQuestionnaireMasterDto;
import com.fa.bajajallianz.cccp.master.dto.LookupTypeDto;
import com.fa.bajajallianz.cccp.master.restservice.MasterRestService;
import com.fa.bajajallianz.cccp.master.service.MasterService;
import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimDataDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.ClaimantLorDocDetailsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.TransporterDetailsDto;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/config/master/api/" })
public class MasterController {
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	public MasterService masterService;

	@Autowired
	public MasterRestService masterRestService;

	@GetMapping("fetchClaimStatusMaster")
	public ResponseEntity<?> fetchFlashMessageDetails(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchClaimStatusMaster-start");
		CommonResponseDto<List<MasterDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchClaimStatusMaster(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);

		}
		logger.info("fetchClaimStatusMaster" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchMenuPages")
	public ResponseEntity<?> fetchMenuPages(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchMenuPages-start");
		CommonResponseDto<List<MenuPagesDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchMenuPages(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("fetchUserProfile" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("getClaimStatusMaster")
	public ResponseEntity<?> getClaimStatusMaster(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-getClaimStatusMaster-start");
		CommonResponseDto<MenuPagesDto> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.getClaimStatusMaster(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("getClaimStatusMaster" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchLookUpByType")
	public ResponseEntity<?> fetchLookUpByType(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-getClaimStatusMaster-start");
		CommonResponseDto<LookupTypeDto> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchLookUpTypeDetails(commonRequestDto.getCode(), request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("getClaimStatusMaster" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchLOBList")
	public ResponseEntity<?> fetchLOBList(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchLOBList-start");
		CommonResponseDto<List<MasterDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchLOBList(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("fetchLOBList" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchproductList")
	public ResponseEntity<?> fetchProductList(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchProductList-start");
		CommonResponseDto<List<MasterDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchProductList(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("fetchProductList" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchAPIDetails")
	public ResponseEntity<?> fetchAPIDetails() {
		logger.info("Enter into MasterController fetchAPIDetails Started...");
		List<ApiConfigDto> responseDto = null;
		responseDto = masterService.fetchAPIDetails();
		logger.info("Enter into MasterController fetchAPIDetails End...");
		return new ResponseEntity<List<ApiConfigDto>>(responseDto, HttpStatus.OK);
	}

	@GetMapping("fetchAPIUrlByCode")
	public ResponseEntity<?> fetchAPIUrlByCode(@RequestParam String code, HttpServletRequest request) {
		logger.info("Enter into MasterController fetchAPIDetails Started...");
		ApiConfigDto responseDto = null;
		responseDto = masterService.fetchAPIUrlByCode(code, request);
		logger.info("Enter into MasterController fetchAPIDetails End...");
		return new ResponseEntity<ApiConfigDto>(responseDto, HttpStatus.OK);
	}

	@GetMapping("fetchReportTypes")
	public ResponseEntity<?> fetchReportTypes(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchReportTypes-start");
		CommonResponseDto<List<ReportTypeDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchReportTypes(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("fetchReportTypes" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchCauseOffLoss")
	public ResponseEntity<?> fetchCauseOffLoss(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchCauseOffLoss-start");
		CommonResponseDto<List<CauseOfLossDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchCauseOffLoss(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("fetchCauseOffLoss" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("getDocumentName")
	public ResponseEntity<?> getDocumentName(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-getDocumentName-start");
		CommonResponseDto<List<DocumentDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.getDocumentName(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("getDocumentName" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<List<DocumentDto>>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchDocumentName")
	public ResponseEntity<?> fetchDocumentName(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchDocumentName-start");
		CommonResponseDto<List<DocumentDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchDocumentName(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("fetchDocumentName" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<List<DocumentDto>>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchGradeQuestionnaire")
	public ResponseEntity<?> fetchGradeQuestionnaire(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterV1Controller-fetchGradeQuestionnaire-start");
		CommonResponseDto<List<GradeQuestionnaireMasterDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchGradeQuestionnaire(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);

		}
		logger.info("fetchMenuPages" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchClaimHistoryBypolicyNumber")
	public ResponseEntity<?> fetchClaimHistoryBypolicyNumber(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchReportTypes-start");
		CommonResponseDto<List<ClaimInsurerHistoryDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchClaimHistoryBypolicyNumber(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("fetchReportTypes" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchZoneCode")
	public ResponseEntity<?> fetchZoneCode(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchZoneCode-start");
		CommonResponseDto<List<LookUpValuesDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchZoneCode(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("MasterController-fetchZoneCode-end");
		return new ResponseEntity<CommonResponseDto<List<LookUpValuesDto>>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchDocDetailsByDocType")
	public ResponseEntity<?> getDocumentList(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("MasterController-fetchDocDetailsByDocType-start");
		DataTableDto<List<ClaimantLorDocDetailsDto>> commonResponseDto = new DataTableDto<>();
		try {
			commonResponseDto = masterService.fetchDocDetailsByDocType(payload, main_filter, sort, page, per_page,
					request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("fetchDocDetailsByDocType" + commonResponseDto.getStatus());
		return new ResponseEntity<DataTableDto<List<ClaimantLorDocDetailsDto>>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchCommonData")
	public ResponseEntity<?> fetchCommonData(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchCommonData-start");
		CommonResponseDto<List<CommonMasterDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchCommonData(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("MasterController-fetchCommonData-end");
		return new ResponseEntity<CommonResponseDto<List<CommonMasterDto>>>(commonResponseDto, HttpStatus.OK);
	}

	@PostMapping("/saveTransporterDetails")
	public ResponseEntity<?> saveTransporterDetails(@RequestBody CommonRequestDto commonRequestDto, HttpServletRequest request) {
		logger.info("MasterController-saveTransporterDetails-start");
		CommonResponseDto<?> commonResponse = new CommonResponseDto<>();
		try {
			commonResponse = masterService.saveTransporterDetails(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponse.setStatus(CommonConstants.ERROR);
			logger.error("MasterController-saveTransporterDetails-", e);
		}
		logger.info("MasterController-saveTransporterDetails-" + commonResponse.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponse, HttpStatus.OK);
	}
	
	@GetMapping("fetchTransportDetails")
	public ResponseEntity<?> fetchTransportDetails(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("MasterController-fetchTransportDetails-start");
		DataTableDto<List<TransporterDetailsDto>> commonResponseDto = new DataTableDto<>();
		try {
			commonResponseDto = masterService.fetchTransportDetails(payload, main_filter, sort, page, per_page,
					request);
		} catch (Exception e) {
			e.printStackTrace();
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("fetchTransportDetails" + commonResponseDto.getStatus());
		return new ResponseEntity<DataTableDto<List<TransporterDetailsDto>>>(commonResponseDto, HttpStatus.OK);
	}
	
	

}
