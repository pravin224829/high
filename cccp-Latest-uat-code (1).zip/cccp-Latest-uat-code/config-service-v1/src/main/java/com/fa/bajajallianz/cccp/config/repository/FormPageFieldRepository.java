package com.fa.bajajallianz.cccp.config.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.config.entity.FormPageFieldgroupEntity;
import com.fa.bajajallianz.cccp.config.entity.FormPageFieldEntity;

@Repository
public interface FormPageFieldRepository extends JpaRepository<FormPageFieldEntity, Long> {

	List<FormPageFieldEntity> findByFormPageFieldgroupAndFormPageFieldgroupIsActiveAndIsActive(
			FormPageFieldgroupEntity fieldGroupEntity, Boolean true1, Boolean true2);

}
