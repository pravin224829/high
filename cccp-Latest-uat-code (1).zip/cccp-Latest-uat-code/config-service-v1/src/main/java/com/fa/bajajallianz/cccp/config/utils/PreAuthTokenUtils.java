package com.fa.bajajallianz.cccp.config.utils;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fa.bajajallianz.cccp.common.dto.TokenRequestDto;
import com.fa.bajajallianz.cccp.common.dto.TokenResponseDto;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;

@Service
public class PreAuthTokenUtils {
	
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private Environment env;
	
	public TokenResponseDto getPreAuthToken() {
		TokenResponseDto responseDto = new TokenResponseDto();
		RestTemplate restTemplate = new RestTemplate();
		logger.info("config - PreAuthTokenUtils-getPreAuthToken-start");
		try {
			String baseUrl = CommonUtils.fetchApi("GETPREAUTHTOKEN", env.getProperty("CONFIG_API_URL"));
			TokenRequestDto requestDto = new TokenRequestDto();
			String userName = CommonUtils.fetchApi("PREAUTHTOKEN_USERNAME", env.getProperty("CONFIG_API_URL"));
			String password = CommonUtils.fetchApi("PREAUTHTOKEN_PASSWORD", env.getProperty("CONFIG_API_URL"));
			requestDto.setUserName(userName);
			requestDto.setPassword(password);
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<TokenRequestDto> entity = new HttpEntity<TokenRequestDto>(requestDto, headers);
			responseDto = restTemplate
					.exchange(baseUrl, HttpMethod.POST, entity, new ParameterizedTypeReference<TokenResponseDto>() {
					}, headers).getBody();

		} catch (Exception e) {
			logger.info("Exception-config-PreAuthTokenUtils-getPreAuthToken-", e);
		}
		logger.info("config -PreAuthTokenUtils-getPreAuthToken-end");
		return responseDto;
	}

}
