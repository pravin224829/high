package com.fa.bajajallianz.cccp.config.dto;

import java.io.Serializable;
import java.util.List;

public class FormPageFieldgroupDto implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long id;
	private String attributes;
	private String additionalInfo;
	private Long authorityCode;
	private String description;
	private String displayName;
	private String fieldGroupCode;
	private Boolean isActive;
	private String model;
	private Integer orderNo;
	private List<FormPageFieldsDto> formPageFields;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAttributes() {
		return attributes;
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public Long getAuthorityCode() {
		return authorityCode;
	}

	public void setAuthorityCode(Long authorityCode) {
		this.authorityCode = authorityCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	
	public String getFieldGroupCode() {
		return fieldGroupCode;
	}

	public void setFieldGroupCode(String fieldGroupCode) {
		this.fieldGroupCode = fieldGroupCode;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Integer getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}

	public List<FormPageFieldsDto> getFormPageFields() {
		return formPageFields;
	}

	public void setFormPageFields(List<FormPageFieldsDto> formPageFields) {
		this.formPageFields = formPageFields;
	}

}
