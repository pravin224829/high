package com.fa.bajajallianz.cccp.config.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.config.entity.FormPageFieldgroupEntity;

@Repository
public interface FormPageFieldgroupRepository extends JpaRepository<FormPageFieldgroupEntity, Long> {

	List<FormPageFieldgroupEntity> findByFormPageSubsectionSubsectionCodeAndFormPageSubsectionIsActiveAndIsActive(
			String subsectionCode, Boolean isPageActive, Boolean isSubSectionActive);

}
