/**
 * 
 */
package com.fa.bajajallianz.cccp.config.admin.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author arunkumar
 *
 */

@Entity
@Table(name = "prod_doc_staging_data_details")
public class ProductDocStagingDetailsEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", length = 20, unique = true)
	private Long id;

	@Column(name = "file_id", length = 30)
	private String fileId;

	@Column(name = "doc_code", length = 30)
	private String docCode;

	@Column(name = "product_code", length = 30)
	private String productCode;

	@Column(name = "activation_status", length = 10)
	private String activationStatus;

	@Column(name = "mandatory_flag", length = 10)
	private String mandatoryFlag;

	@Column(name = "error_description")
	private String errorDescription;

	@Column(name = "label", length = 100)
	private String label;

	@Column(name = "slw", length = 10)
	private String slw;

	@Column(name = "saw", length = 10)
	private String saw;

	@Column(name = "inw", length = 10)
	private String inw;

	@Column(name = "is_read")
	private Boolean isRead;

	@Column(name = "status", length = 10)
	private String status;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "created_by", length = 250)
	private String createdBy;

	@Column(name = "modified_date")
	private Date modifiedDate;

	@Column(name = "modified_by", length = 250)
	private String modifiedBy;

	@Column(name = "reason")
	private String reason;

	@Column(name = "row_num")
	private Integer rowNum;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getDocCode() {
		return docCode;
	}

	public void setDocCode(String docCode) {
		this.docCode = docCode;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getActivationStatus() {
		return activationStatus;
	}

	public void setActivationStatus(String activationStatus) {
		this.activationStatus = activationStatus;
	}

	public String getMandatoryFlag() {
		return mandatoryFlag;
	}

	public void setMandatoryFlag(String mandatoryFlag) {
		this.mandatoryFlag = mandatoryFlag;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getSlw() {
		return slw;
	}

	public void setSlw(String slw) {
		this.slw = slw;
	}

	public String getSaw() {
		return saw;
	}

	public void setSaw(String saw) {
		this.saw = saw;
	}

	public String getInw() {
		return inw;
	}

	public void setInw(String inw) {
		this.inw = inw;
	}

	public Boolean getIsRead() {
		return isRead;
	}

	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Integer getRowNum() {
		return rowNum;
	}

	public void setRowNum(Integer rowNum) {
		this.rowNum = rowNum;
	}

}
