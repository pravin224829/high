package com.fa.bajajallianz.cccp.config.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.config.entity.FormPageSubsectionEntity;

@Repository
public interface FormPageSubsectionRepository extends JpaRepository<FormPageSubsectionEntity, Long> {

	List<FormPageSubsectionEntity> findByFormPageSectionSectionCodeAndFormPageSectionIsActiveAndIsActive(
			String sectionCode, Boolean true1, Boolean true2);

}
