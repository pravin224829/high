package com.fa.bajajallianz.cccp.config.logger.service.impl;

import java.net.URI;
import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.fa.bajajallianz.cccp.common.dto.APIRequestDto;
import com.fa.bajajallianz.cccp.common.dto.APIResponseDto;
import com.fa.bajajallianz.cccp.common.dto.CommonDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.config.logger.service.LoggerRestAPI;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class LoggerRestAPIImpl implements LoggerRestAPI {

	private static final Logger logger = LoggerFactory.getLogger(LoggerRestAPIImpl.class);

	private static RestTemplate restTemplate = new RestTemplate();

	private ObjectMapper mapper = new ObjectMapper();

	@Autowired
	private Environment env;

	@Override
	@Async
	public APIResponseDto callInfoLogger(APIRequestDto apiRequestDto) {
		logger.info("RestTemplateServiceImpl-LoggerRestAPIImpl-start");

		CommonDto exchange = null;
		APIResponseDto apiResponseDto = new APIResponseDto();
		String responseString = null;
		try {
			String url1 = CommonUtils.fetchApi("INFOLOGGER", env.getProperty("CONFIG_API_URL"));
			apiRequestDto.setApiUrl(url1);
			// apiRequestDto.setApiUrl("http://localhost:8888/ilm/log/api/saveApiInfoLogs");
			apiRequestDto.setRequestMethod("POST");
			apiRequestDto.setContentType("application/json");
			String requestWriteValueAsString = mapper.writeValueAsString(apiRequestDto);
			logger.info("Request :  " + requestWriteValueAsString.toString());
			// logger.info("API : " + env.getProperty(""));
			exchange = exchange(requestWriteValueAsString, apiRequestDto);
			if (StringUtils.isNotBlank(exchange.getMessage())
					&& exchange.getStatus().equalsIgnoreCase(CommonConstants.SUCCESS)) {
				responseString = exchange.getMessage();
			}
			mapper.writerWithDefaultPrettyPrinter();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			logger.info("Response :  " + responseString);
			if (responseString != null) {
				JSONObject responseOb = new JSONObject(responseString);
				if (responseOb != null && responseOb.getString("status").toString() != null
						&& responseOb.getString("status").toString().equalsIgnoreCase(CommonConstants.SUCCESS)) {
					apiResponseDto.setResponseStatus(CommonConstants.SUCCESS);
				} else {
					apiResponseDto.setResponseStatus(CommonConstants.ERROR);
				}
			} else {
				apiResponseDto.setResponseStatus(CommonConstants.SUCCESS);
			}

		} catch (HttpClientErrorException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-HttpClientErrorException", e);
		} catch (HttpServerErrorException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-HttpServerErrorException", e);
		} catch (ResourceAccessException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-ResourceAccessException", e);
		} catch (JSONException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-JSONException", e);
		} catch (Exception e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-Exception-end", e);
		}
		logger.info("RestTemplateServiceImpl-callInfoLogger-end");
		apiResponseDto.setResponseStatus(CommonConstants.SUCCESS);
		return apiResponseDto;
	}

	public CommonDto exchange(String requestString, APIRequestDto apiRequestDto) {
		CommonDto commonDto = new CommonDto();
		String responseJson = null;
		try {
			commonDto.setStatus(CommonConstants.ERROR);
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			logger.info("API URL " + apiRequestDto.getApiUrl());
			RequestEntity<String> requestEntity = new RequestEntity<>(requestString, headers,
					HttpMethod.valueOf(apiRequestDto.getRequestMethod()), new URI(apiRequestDto.getApiUrl()));
			ResponseEntity<String> result = restTemplate.exchange(requestEntity, String.class);
			if (result != null) {
				responseJson = result.getBody();
				commonDto.setMessage(responseJson);
				commonDto.setStatus(CommonConstants.SUCCESS);
			}
		} catch (HttpClientErrorException e) {
			logger.error("Exception-RestTemplateServiceImpl-HttpClientErrorException", e);
		} catch (HttpServerErrorException e) {
			logger.error("Exception-RestTemplateServiceImpl-HttpServerErrorException", e);
		} catch (ResourceAccessException e) {
			logger.error("Exception-RestTemplateServiceImpl-ResourceAccessException", e);
		} catch (JSONException e) {
			logger.error("Exception-RestTemplateServiceImpl-JSONException", e);
		} catch (Exception e) {
			logger.error("Exception-RestTemplateServiceImpl-Exception-end", e);
		}
		return commonDto;
	}

	@Override
	@Async
	public APIResponseDto callErrorLogger(APIRequestDto apiRequestDto) {
		logger.info("RestTemplateServiceImpl-LoggerRestAPIImpl-start");

		CommonDto exchange = null;
		APIResponseDto apiResponseDto = new APIResponseDto();
		String responseString = null;
		try {

			String url1 = CommonUtils.fetchApi("ERRORLOGGER", env.getProperty("CONFIG_API_URL"));
			apiRequestDto.setApiUrl(url1);
			// apiRequestDto.setApiUrl("http://localhost:8888/ilm/log/api/saveApiErrorLogs");
			apiRequestDto.setRequestMethod("POST");
			apiRequestDto.setContentType("application/json");
			String requestWriteValueAsString = mapper.writeValueAsString(apiRequestDto);
			logger.info("Request :  " + requestWriteValueAsString.toString());
			// logger.info("API : " + env.getProperty(""));
			exchange = exchange(requestWriteValueAsString, apiRequestDto);
			if (StringUtils.isNotBlank(exchange.getMessage())
					&& exchange.getStatus().equalsIgnoreCase(CommonConstants.SUCCESS)) {
				responseString = exchange.getMessage();
			}
			mapper.writerWithDefaultPrettyPrinter();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			if (responseString != null) {
				JSONObject responseOb = new JSONObject(responseString);
				if (responseOb != null && responseOb.getString("status").toString() != null
						&& responseOb.getString("status").toString().equalsIgnoreCase(CommonConstants.SUCCESS)) {
					apiResponseDto.setResponseStatus(CommonConstants.SUCCESS);
				} else {
					apiResponseDto.setResponseStatus(CommonConstants.ERROR);
				}
			} else {
				apiResponseDto.setResponseStatus(CommonConstants.SUCCESS);
			}

		} catch (HttpClientErrorException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-HttpClientErrorException", e);
		} catch (HttpServerErrorException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-HttpServerErrorException", e);
		} catch (ResourceAccessException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-ResourceAccessException", e);
		} catch (JSONException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-JSONException", e);
		} catch (Exception e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-Exception-end", e);
		}
		logger.info("RestTemplateServiceImpl-callErrorLogger-end");
		return apiResponseDto;
	}

	@Override
	@Async
	public APIResponseDto callTraceLogger(APIRequestDto apiRequestDto) {
		logger.info("RestTemplateServiceImpl-LoggerRestAPIImpl-start");

		CommonDto exchange = null;
		APIResponseDto apiResponseDto = new APIResponseDto();
		String responseString = null;
		try {
			String url1 = CommonUtils.fetchApi("TRACELOGGER", env.getProperty("CONFIG_API_URL"));
			apiRequestDto.setApiUrl(url1);

			// apiRequestDto.setApiUrl("http://localhost:8888/ilm/log/api/saveApiTraceLogs");
			apiRequestDto.setRequestMethod("POST");
			apiRequestDto.setContentType("application/json");
			String requestWriteValueAsString = mapper.writeValueAsString(apiRequestDto);
			logger.info("Request :  " + requestWriteValueAsString.toString());
			// logger.info("API : " + env.getProperty(""));
			exchange = exchange(requestWriteValueAsString, apiRequestDto);
			if (StringUtils.isNotBlank(exchange.getMessage())
					&& exchange.getStatus().equalsIgnoreCase(CommonConstants.SUCCESS)) {
				responseString = exchange.getMessage();
			}
			mapper.writerWithDefaultPrettyPrinter();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			if (responseString != null) {
				JSONObject responseOb = new JSONObject(responseString);
				if (responseOb != null && responseOb.getString("status").toString() != null
						&& responseOb.getString("status").toString().equalsIgnoreCase(CommonConstants.SUCCESS)) {
					apiResponseDto.setResponseStatus(CommonConstants.SUCCESS);
				} else {
					apiResponseDto.setResponseStatus(CommonConstants.ERROR);
				}
			} else {
				apiResponseDto.setResponseStatus(CommonConstants.SUCCESS);
			}

		} catch (HttpClientErrorException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-HttpClientErrorException", e);
		} catch (HttpServerErrorException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-HttpServerErrorException", e);
		} catch (ResourceAccessException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-ResourceAccessException", e);
		} catch (JSONException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-JSONException", e);
		} catch (Exception e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-Exception-end", e);
		}
		logger.info("RestTemplateServiceImpl-callTraceLogger-end");
		return apiResponseDto;
	}

	public APIResponseDto callSaveApiLog(APIRequestDto apiRequestDto) {
		logger.info("RestTemplateServiceImpl-callsaveApiLog-start");

		CommonDto exchange = null;
		APIResponseDto apiResponseDto = new APIResponseDto();
		String responseString = null;
		try {
			String url1 = CommonUtils.fetchApi("SAVEAPILOG", env.getProperty("CONFIG_API_URL"));
//			url1 = "http://localhost:8889/cccp/log/api/saveApiLog";
			apiRequestDto.setApiUrl(url1);
			apiRequestDto.setRequestMethod("POST");
			apiRequestDto.setContentType("application/json");
			String requestWriteValueAsString = mapper.writeValueAsString(apiRequestDto);
			logger.info(
					"Request :  " + requestWriteValueAsString != null ? requestWriteValueAsString.toString() : "null");
			exchange = exchange(requestWriteValueAsString, apiRequestDto);
			if (StringUtils.isNotBlank(exchange.getMessage())
					&& exchange.getStatus().equalsIgnoreCase(CommonConstants.SUCCESS)) {
				responseString = exchange.getMessage();
			}
			mapper.writerWithDefaultPrettyPrinter();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			if (responseString != null) {
				JSONObject responseOb = new JSONObject(responseString);
				if (responseOb != null && responseOb.getString("status").toString() != null
						&& responseOb.getString("status").toString().equalsIgnoreCase(CommonConstants.SUCCESS)) {
					apiResponseDto.setResponseStatus(CommonConstants.SUCCESS);
				} else {
					apiResponseDto.setResponseStatus(CommonConstants.ERROR);
				}
			} else {
				apiResponseDto.setResponseStatus(CommonConstants.SUCCESS);
			}

		} catch (HttpClientErrorException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-HttpClientErrorException", e);
		} catch (HttpServerErrorException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-HttpServerErrorException", e);
		} catch (ResourceAccessException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-ResourceAccessException", e);
		} catch (JSONException e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-JSONException", e);
		} catch (Exception e) {
			apiResponseDto.setResponseStatus(CommonConstants.ERROR);
			logger.error("Exception-RestTemplateServiceImpl-Exception-end", e);
		}
		logger.info("RestTemplateServiceImpl-callsaveApiLog-end");
		return apiResponseDto;
	}
}
