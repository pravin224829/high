package com.fa.bajajallianz.cccp.config.rcs.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.config.dto.DeficiencyReasonDetailsDto;
import com.fa.bajajallianz.cccp.config.service.ConfigurationService;
import com.fa.bajajallianz.cccp.master.dto.EventCodeListDto;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/config/rcs/config/api/" })
public class RcsConfigController {
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	public ConfigurationService configService;

	@GetMapping("fetchDeficiencyReason")
	public ResponseEntity<?> fetchDeficiencyReason(@RequestParam String payload, HttpServletRequest request) {
		logger.info("ConfigurationController-fetchDeficiencyReason-start");
		CommonResponseDto<List<DeficiencyReasonDetailsDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = configService.fetchDeficiencyReason(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("ConfigurationController-fetchDeficiencyReason-end");
		return new ResponseEntity<CommonResponseDto<List<DeficiencyReasonDetailsDto>>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchEventCodeList")
	public ResponseEntity<?> fetchEventCodeList(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchEventCodeList-start");
		CommonResponseDto<List<EventCodeListDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = configService.fetchEventCodeList(commonRequestDto, request);
		} catch (Exception e) {
			logger.error("MasterController-fetchEventCodeList-error", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setMessage("EventCodeList not fetched");
		}
		logger.info("MasterController-fetchEventCodeList-start");
		commonResponseDto.setStatus(CommonConstants.SUCCESS);
		commonResponseDto.setMessage("EventCodeList fetched Successfully");
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}
}
