package com.fa.bajajallianz.cccp.config.rcs.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.config.rcs.master.entity.ClaimMileStonesEntity;

@Repository
public interface RcsMasterRepository extends JpaRepository<ClaimMileStonesEntity, Long> {

	List<ClaimMileStonesEntity> findByIsActive(Boolean isActive);

	List<ClaimMileStonesEntity> findByIsActiveAndRequestTypeIsNullOrRequestTypeOrderByOrderNoAsc(Boolean true1,
			String processType);

}
