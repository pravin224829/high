package com.fa.bajajallianz.cccp.config.entity;

/**
 * @author praveen
 *
 */

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "form_page_sections")
public class FormPageSectionEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", length = 20, nullable = false)
	private Long id;

	@Column(name = "additional_info", length = 5000)
	private String additionalInfo;
	
	@Column(name = "attributes", length = 5000)
	private String attributes;

	@Column(name = "description", length = 5000)
	private String description;

	@Column(name = "display_name", length = 300)
	private String displayName;

	@Column(name = "is_active", nullable = false)
	private Boolean isActive;

	@Column(name = "is_questionaire")
	private Boolean isQuestionaire;

	@Column(name = "obj_name", length = 200)
	private String objName;

	@Column(name = "order_no", nullable = false)
	private Integer orderNo;

	@Column(name = "section_code", length = 50, nullable = false, unique = true)
	private String sectionCode;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_date")
	private Date modifiedDate;
	
	@Column(name = "product_category", length = 50)
	private String productCategory;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, targetEntity = FormPageEntity.class)
	@JoinColumn(name = "page_id")
	private FormPageEntity formPage;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "formPageSection")
	private Set<FormPageSubsectionEntity> subSection;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean getIsQuestionaire() {
		return isQuestionaire;
	}

	public void setIsQuestionaire(Boolean isQuestionaire) {
		this.isQuestionaire = isQuestionaire;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public Integer getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}

	public String getSectionCode() {
		return sectionCode;
	}

	public void setSectionCode(String sectionCode) {
		this.sectionCode = sectionCode;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public FormPageEntity getFormPage() {
		return formPage;
	}

	public void setFormPage(FormPageEntity formPage) {
		this.formPage = formPage;
	}

	public Set<FormPageSubsectionEntity> getSubSection() {
		return subSection;
	}

	public void setSubSection(Set<FormPageSubsectionEntity> subSection) {
		this.subSection = subSection;
	}

	public String getAttributes() {
		return attributes;
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

}
