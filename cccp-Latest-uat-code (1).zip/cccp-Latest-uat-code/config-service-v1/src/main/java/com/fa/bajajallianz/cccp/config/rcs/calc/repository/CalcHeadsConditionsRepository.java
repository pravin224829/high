package com.fa.bajajallianz.cccp.config.rcs.calc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.master.entity.CalcHeadsConditionEntity;

@Repository
public interface CalcHeadsConditionsRepository extends JpaRepository<CalcHeadsConditionEntity, Long> {

	List<CalcHeadsConditionEntity> findByCodeAndIsActive(String code, Boolean true1);

	List<CalcHeadsConditionEntity> findByIsActive(Boolean true1);

}
