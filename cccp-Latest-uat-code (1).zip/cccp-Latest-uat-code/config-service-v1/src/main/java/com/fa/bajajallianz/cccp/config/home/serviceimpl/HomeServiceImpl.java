package com.fa.bajajallianz.cccp.config.home.serviceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.DateUtils;
import com.fa.bajajallianz.cccp.common.utils.ErrorCodeConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.common.utils.NumericUtils;
import com.fa.bajajallianz.cccp.config.home.dto.FlashMessageDetailsDto;
import com.fa.bajajallianz.cccp.config.home.entity.FlashMessageDetailsEntity;
import com.fa.bajajallianz.cccp.config.home.repository.FlashMessageDetailsRepository;
import com.fa.bajajallianz.cccp.config.home.service.HomeService;
import com.fa.bajajallianz.cccp.config.utils.CommonErrorMsg;
import com.fa.bajajallianz.cccp.config.utils.CommonRequestUtil;

@Service
public class HomeServiceImpl implements HomeService {

	@Autowired
	private FlashMessageDetailsRepository flashMessageDetailsRepository;
	
	@Autowired
	Environment env;
	
	@Autowired
	EntityManager entityManager;

	@Autowired
	private CommonErrorMsg commonErrorMsg;

	public String getProperty() {
		return env.getProperty("CONFIG_API_URL");
	}

	private static final Logger logger = LoggerFactory.getLogger(HomeServiceImpl.class);

	@Override
	public CommonResponseDto<FlashMessageDetailsDto> saveFlashMessageDetails(FlashMessageDetailsDto dto,
			HttpServletRequest request) {
		CommonResponseDto<FlashMessageDetailsDto> commonResponseDto = new CommonResponseDto<>();
		logger.info("HomeServiceImpl--saveFlashMessageDetails--Start");
		try {			
			if (dto != null) {
				if (dto.getMsgId().isEmpty()) {
					FlashMessageDetailsEntity entity = new FlashMessageDetailsEntity();
					String currentTimeMillis = NumericUtils.convertLongToString(System.currentTimeMillis());
					entity.setUserId(dto.getSearchUserId());
					entity.setCorporateId(dto.getCorporateUserId());
					entity.setMsgDescription(dto.getMessage());
					entity.setMsgId(currentTimeMillis);
					entity.setRoleCode(dto.getRoleCode());
					if(dto.getIsEnable().equals(CommonConstants.ACTIVE)) {
						entity.setIsEnable(CommonConstants.TRUE);
					}else {
						entity.setIsEnable(CommonConstants.FALSE);
					}
					entity.setIsActive(CommonConstants.TRUE);
					entity.setCreatedBy(dto.getUserId());
					entity.setCreatedDate(DateUtils.sysDate());
					flashMessageDetailsRepository.save(entity);
				} else {
					FlashMessageDetailsEntity data = flashMessageDetailsRepository.findByMsgId(dto.getMsgId());
					data.setMsgDescription(dto.getMessage());
					data.setModifiedDate(DateUtils.sysDate());
					data.setCreatedDate(DateUtils.sysDate());
					if(dto.getIsEnable().equals(CommonConstants.ACTIVE)) {
						data.setIsEnable(CommonConstants.TRUE);
					}else {
						data.setIsEnable(CommonConstants.FALSE);
					}
					flashMessageDetailsRepository.save(data);
					commonResponseDto.setMessageId(data.getMsgId());
				}
				commonResponseDto.setStatus(CommonConstants.SUCCESS);
			}
		}
		catch (Exception e) {
			CommonRequestUtil.errorInfo(request, "", "HomeServiceImpl-saveFlashMessageDetails",
					"saveFlashMessageDetails", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
			logger.error("Exception-HomeServiceImpl-saveFlashMessageDetails", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setError(e.getMessage());
		}
		logger.info("HomeServiceImpl--saveFlashMessageDetails--End");
		return commonResponseDto;
	}
	
	@Override
	public CommonResponseDto<List<FlashMessageDetailsDto>> fetchFlashMessageDetails(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonResponseDto<List<FlashMessageDetailsDto>> commonResponseDto = new CommonResponseDto<>();
		logger.info("HomeServiceImpl--fetchFlashMessageDetails--Start");
		try {
			List<FlashMessageDetailsDto> dtos = new ArrayList<FlashMessageDetailsDto>();
			if(commonRequestDto.getUserId() != null && StringUtils.isNotEmpty(commonRequestDto.getUserId())) {
				List<FlashMessageDetailsEntity> entities = flashMessageDetailsRepository.findTop5ByUserIdAndIsActiveOrderByCreatedDateDesc(commonRequestDto.getUserId(), CommonConstants.TRUE);
				if(entities.size() > 0) {
					for (FlashMessageDetailsEntity flashMessageDetailsEntity : entities) {
						if (flashMessageDetailsEntity.getIsEnable().equals(CommonConstants.TRUE)) {
							FlashMessageDetailsDto dto = new FlashMessageDetailsDto();
							dto.setMsgId(flashMessageDetailsEntity.getMsgId());
							dto.setIsEnable(NumericUtils.convertBooleanToString(flashMessageDetailsEntity.getIsEnable()));
							dto.setDescription(flashMessageDetailsEntity.getMsgDescription());
							dto.setCreatedDate(DateUtils.dateToStringFormatYyyyMmDdHhMmSsHyphen(flashMessageDetailsEntity.getCreatedDate()));
							dtos.add(dto);
						}
					}
					commonResponseDto.setResponseData(dtos);
					commonResponseDto.setStatus(CommonConstants.SUCCESS);
				}else {
					commonResponseDto.setStatus(CommonConstants.SUCCESS);
					commonResponseDto.setMessage("No Record Found");
				}
			}else {
				commonResponseDto.setStatus(CommonConstants.ERROR);
				commonResponseDto.setMessage("Invalid User Id");
			}

		} catch (Exception e) {
			logger.error("Exception-HomeServiceImpl-fetchFlashMessageDetails", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setError(e.getMessage());
		}
		logger.info("HomeServiceImpl--fetchFlashMessageDetails--End");
		return commonResponseDto;

	}

	@Override
	public CommonResponseDto<DataTableDto<List<FlashMessageDetailsDto>>> fetchFalshMessageList(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonResponseDto<DataTableDto<List<FlashMessageDetailsDto>>> response = new CommonResponseDto<DataTableDto<List<FlashMessageDetailsDto>>>();
		DataTableDto<List<FlashMessageDetailsDto>> dataTableDto = new DataTableDto<List<FlashMessageDetailsDto>>();
		logger.info("Enter into HomeServiceImpl - fetchFalshMessageList Start");
		List<FlashMessageDetailsDto> dtos = new ArrayList<>();
		logger.info("HomeServiceImpl--fetchFlashMessageDetails--Start");
		try {
			if(commonRequestDto.getSearchUserId() != null && StringUtils.isNotEmpty(commonRequestDto.getSearchUserId())) {
				List<FlashMessageDetailsEntity> entities = flashMessageDetailsRepository.findTop5ByUserIdAndIsActiveOrderByCreatedDateDesc(commonRequestDto.getSearchUserId(), CommonConstants.TRUE);
				if(entities.size() > 0) {
					for (FlashMessageDetailsEntity flashMessageDetailsEntity : entities) {
						FlashMessageDetailsDto dto = new FlashMessageDetailsDto();
						dto.setMsgId(flashMessageDetailsEntity.getMsgId());
						dto.setMessage(flashMessageDetailsEntity.getMsgDescription());
						dto.setCreatedDate(DateUtils.dateToStringFormatYyyyMmDdHhMmSsHyphen(flashMessageDetailsEntity.getCreatedDate()));
						if(flashMessageDetailsEntity.getIsEnable().equals(CommonConstants.TRUE)) {
							dto.setIsEnable(CommonConstants.ACTIVE);
						}else {
							dto.setIsEnable(CommonConstants.INACTIVE);
						}
						
						dtos.add(dto);
					}
					dataTableDto.setData(dtos);
					response.setResponseData(dataTableDto);
					response.setStatus(CommonConstants.SUCCESS);
				}else {
					dataTableDto.setData(dtos);
					response.setResponseData(dataTableDto);
					response.setStatus(CommonConstants.SUCCESS);
				}
			}
		} catch (Exception e) {
			response.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "HomeServiceImpl-fetchFalshMessageList",
					"fetchHeirarchyUserDetails", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
			logger.error("Exception-HomeServiceImpl-fetchFalshMessageList", e);
			response.setStatus(CommonConstants.ERROR);
			response.setMessage(e.getMessage());
		}
		return response;
	}
	
//	@Override
//	public CommonResponseDto<DataTableDto<List<FlashMessageDetailsDto>>> fetchFalshMessageList(String payload, HttpServletRequest request) {
//		CommonResponseDto<DataTableDto<List<FlashMessageDetailsDto>>> response = new CommonResponseDto<DataTableDto<List<FlashMessageDetailsDto>>>();
//		DataTableDto<List<FlashMessageDetailsDto>> dataTableDto = new DataTableDto<List<FlashMessageDetailsDto>>();
//		logger.info("Enter into HomeServiceImpl - fetchHeirarchyUserDetails Start");
//		List<FlashMessageDetailsDto> dtos = new ArrayList<>();
//		try {
//			JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
//			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
//			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
//			CriteriaQuery<FlashMessageDetailsEntity> query = builder.createQuery(FlashMessageDetailsEntity.class);
//			Root<FlashMessageDetailsEntity> root = query.from(FlashMessageDetailsEntity.class);
//			List<FlashMessageDetailsEntity> list = new ArrayList<FlashMessageDetailsEntity>();
//			List<Predicate> conditions = new ArrayList<>(1);
//
//			if (commonRequestDto.getRoleCode().equalsIgnoreCase(CommonConstants.ROLE_ADMIN)) {
//				if (StringUtils.isEmpty(commonRequestDto.getSearchUserId())) {
//					conditions.add(builder.equal(root.get("isActive"), CommonConstants.TRUE));
//					query.orderBy(builder.desc(root.get("createdDate")));
//				} else {
//					Predicate searchUserId = builder.equal(root.get("userId"), commonRequestDto.getSearchUserId());
//					Predicate isActive = builder.equal(root.get("isActive"), CommonConstants.TRUE);
//					Predicate searchUserIdAndIsActive = builder.and(searchUserId, isActive);
//					conditions.add(searchUserIdAndIsActive);
//					query.orderBy(builder.desc(root.get("createdDate")));
//				}
//			} else if (commonRequestDto.getRoleCode().equalsIgnoreCase(CommonConstants.ROLE_CORPADMIN)) {
//				if (StringUtils.isEmpty(commonRequestDto.getSearchUserId())) {
//
//					Predicate userId = builder.equal(root.get("corporateId"), commonRequestDto.getUserId());
//					Predicate isActive = builder.equal(root.get("isActive"), CommonConstants.TRUE);
//					Predicate corporateIdAndIsActive = builder.and(userId, isActive);
//					conditions.add(corporateIdAndIsActive);
//					query.orderBy(builder.desc(root.get("createdDate")));
//				} else {
//					Predicate userId = builder.equal(root.get("userId"), commonRequestDto.getSearchUserId());
//					Predicate corporateUserId = builder.equal(root.get("corporateId"), commonRequestDto.getUserId());
//					Predicate isActive = builder.equal(root.get("isActive"), CommonConstants.TRUE);
//					Predicate userIdAndcorporateIdAndIsActive = builder.and(corporateUserId, userId, isActive);
//					conditions.add(userIdAndcorporateIdAndIsActive);
//					query.orderBy(builder.desc(root.get("createdDate")));
//				}
//			}
//			query.select(root).where(conditions.toArray(new Predicate[] {}));
//			list = entityManager.createQuery(query).getResultList();
//			list.forEach(entity -> {
//				FlashMessageDetailsDto rolessDto = mapEntityToDto(entity);
//				dtos.add(rolessDto);
//			});
//			list = entityManager.createQuery(query).getResultList();
//			response.setStatus(CommonConstants.SUCCESS);
//			dataTableDto.setData(dtos);
//			response.setResponseData(dataTableDto);
//		} catch (Exception e) {
//			dataTableDto.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
//			CommonRequestUtil.errorInfo(request, "", "HomeServiceImpl-fetchFalshMessageList",
//					"fetchHeirarchyUserDetails", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
//			logger.error("Exception-HomeServiceImpl-fetchFalshMessageList", e);
//			response.setStatus(CommonConstants.ERROR);
//			response.setMessage(e.getMessage());
//		}
//		logger.info("Enter into HomeServiceImpl - fetchFalshMessageList End");
//		return response;
//	}
//
//	private FlashMessageDetailsDto mapEntityToDto(FlashMessageDetailsEntity entity) {
//		FlashMessageDetailsDto dto = new FlashMessageDetailsDto();
//		logger.info("Enter into HomeServiceImpl - mapEntityToDto -Start");
//		try {
//			dto.setMessage(entity.getMsgDescription());
//			dto.setUserId(entity.getUserId());
//			dto.setCreatedDate(DateUtils.convertDateTimeToString(entity.getCreatedDate()));
//			dto.setStatus(String.valueOf(entity.getIsActive()));
//			dto.setMsgId(entity.getMsgId());
//			dto.setCorporateUserId(entity.getCorporateId());
//		} catch (Exception e) {
//			logger.error("Exception-HomeServiceImpl-mapRolesEntityToDto", e);
//		}
//		logger.info("Enter into HomeServiceImpl - mapRolesEntityToDto -End");
//		return dto;
//	}

}
