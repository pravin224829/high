package com.fa.bajajallianz.cccp.config.home.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.config.home.service.HomeService;
import com.fa.bajajallianz.cccp.config.home.dto.FlashMessageDetailsDto;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/config/home/api/" })
public class HomeController {
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	HomeService homeService;
	
	@PostMapping("saveFalshMessage")
	public CommonResponseDto<?> saveFlashMessage(@RequestBody FlashMessageDetailsDto dto, HttpServletRequest request) {
		logger.info("HomeController-saveFlashMessage-start");
		CommonResponseDto<FlashMessageDetailsDto> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = homeService.saveFlashMessageDetails(dto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("saveFlashMessage" + commonResponseDto.getStatus());
		logger.info("HomeController-saveFlashMessage-END");
		return commonResponseDto;
	}

	@GetMapping("fetchFlashMessages")
	public ResponseEntity<?> fetchFlashMessageDetails(@RequestParam String payload, HttpServletRequest request) {
		logger.info("homeController-fetchFlashMessageDetails-start");
		CommonResponseDto<List<FlashMessageDetailsDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = homeService.fetchFlashMessageDetails(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);

		}
		logger.info("fetchFlashMessageDetails" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchFalshMessageList")
	public ResponseEntity<?> fetchFalshMessageList(@RequestParam String payload,
			HttpServletRequest request) {
		logger.info("Enter into HomeController - fetchFalshMessageList -start");
		CommonResponseDto<DataTableDto<List<FlashMessageDetailsDto>>> dataTableDto = new CommonResponseDto<DataTableDto<List<FlashMessageDetailsDto>>>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			dataTableDto = homeService.fetchFalshMessageList(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			dataTableDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("Enter into HomeController - fetchFalshMessageList -End");
		return new ResponseEntity<CommonResponseDto<DataTableDto<List<FlashMessageDetailsDto>>>>(dataTableDto, HttpStatus.OK);
	}
}
