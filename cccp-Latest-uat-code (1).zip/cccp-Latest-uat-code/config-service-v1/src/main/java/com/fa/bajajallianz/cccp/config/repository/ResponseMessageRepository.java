package com.fa.bajajallianz.cccp.config.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.config.entity.ResponseMessageEntity;

@Repository
public interface ResponseMessageRepository extends JpaRepository<ResponseMessageEntity, Long> {

	ResponseMessageEntity findByCode(String code);

}
