package com.fa.bajajallianz.cccp.config.rcs.master.serviceimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fa.bajajallianz.cccp.common.dto.CalcConditionValuesDto;
import com.fa.bajajallianz.cccp.common.dto.ClaimMileStonesDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.PartiesDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.DateUtils;
import com.fa.bajajallianz.cccp.common.utils.ErrorCodeConstants;
import com.fa.bajajallianz.cccp.common.utils.NumericUtils;
import com.fa.bajajallianz.cccp.config.rcs.calc.repository.CalcHeadsAttributesRepository;
import com.fa.bajajallianz.cccp.config.rcs.calc.repository.CalcHeadsConditionsRepository;
import com.fa.bajajallianz.cccp.config.rcs.calc.repository.CalcHeadsFormulaRepository;
import com.fa.bajajallianz.cccp.config.rcs.calc.repository.CalcTypeRepository;
import com.fa.bajajallianz.cccp.config.rcs.master.entity.ClaimMileStonesEntity;
import com.fa.bajajallianz.cccp.config.rcs.master.entity.ClosingReasonMasterEntity;
import com.fa.bajajallianz.cccp.config.rcs.master.entity.LossAssessmentHeadersMasterEntity;
import com.fa.bajajallianz.cccp.config.rcs.master.entity.MarineVoyageMasterEntity;
import com.fa.bajajallianz.cccp.config.rcs.master.entity.PortNameMasterEntity;
import com.fa.bajajallianz.cccp.config.rcs.master.repository.LossAssessmentHeadersMasterRepository;
import com.fa.bajajallianz.cccp.config.rcs.master.repository.MarineVoyageMasterRepository;
import com.fa.bajajallianz.cccp.config.rcs.master.repository.PendingAgeBandRepository;
import com.fa.bajajallianz.cccp.config.rcs.master.repository.PortNameMasterRepository;
import com.fa.bajajallianz.cccp.config.rcs.master.repository.RcsMasterRepository;
import com.fa.bajajallianz.cccp.config.rcs.master.service.RcsMasterService;
import com.fa.bajajallianz.cccp.config.repository.ClosingReasonRepository;
import com.fa.bajajallianz.cccp.config.utils.CommonErrorMsg;
import com.fa.bajajallianz.cccp.config.utils.CommonRequestUtil;
import com.fa.bajajallianz.cccp.master.dto.LookupTypeDto;
import com.fa.bajajallianz.cccp.master.dto.LookupTypeValuesDto;
import com.fa.bajajallianz.cccp.master.dto.MasterDto;
import com.fa.bajajallianz.cccp.master.dto.StatusMasterDto;
import com.fa.bajajallianz.cccp.master.dto.SubStatusMasterDto;
import com.fa.bajajallianz.cccp.master.entity.CalcConditionValuesEntity;
import com.fa.bajajallianz.cccp.master.entity.CalcHeadsAttributesEntity;
import com.fa.bajajallianz.cccp.master.entity.CalcHeadsConditionEntity;
import com.fa.bajajallianz.cccp.master.entity.CalcHeadsEntity;
import com.fa.bajajallianz.cccp.master.entity.CalcHeadsFormulaEntity;
import com.fa.bajajallianz.cccp.master.entity.CalcSubHeadsEntity;
import com.fa.bajajallianz.cccp.master.entity.CalcTypeEntity;
import com.fa.bajajallianz.cccp.master.entity.DocumentNameEntity;
import com.fa.bajajallianz.cccp.master.entity.PendingAgeMasterEntity;
import com.fa.bajajallianz.cccp.master.entity.StatusMasterEntity;
import com.fa.bajajallianz.cccp.master.entity.SubCalcTypeEntity;
import com.fa.bajajallianz.cccp.master.entity.SubStatusMasterEntity;
import com.fa.bajajallianz.cccp.master.repository.StatusMasterRepository;
import com.fa.bajajallianz.cccp.master.repository.SubStatusMasterRepository;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcConditionsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcFormulaDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.PendingAgeBandDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.PendingAgeDto;
import com.fa.bajajallianz.cccp.user.entity.PartiesEntity;
import com.fa.bajajallianz.cccp.user.repository.PartiesRepository;

@Service
public class RcsMasterServiceImpl implements RcsMasterService {

	@Autowired
	private RcsMasterRepository rcsMasterRepository;

	@Autowired
	private StatusMasterRepository statusMasterRepository;

	@Autowired
	private PartiesRepository partiesRepository;

	@Autowired
	private CalcTypeRepository calcTypeRepository;

	@Autowired
	private CalcHeadsFormulaRepository calcHeadsFormulaRepository;

	@Autowired
	private PendingAgeBandRepository pendingAgeBandRepository;

	@Autowired
	private ClosingReasonRepository closingReasonRepository;

	@Autowired
	private CommonErrorMsg commonErrorMsg;

	@Autowired
	CalcHeadsConditionsRepository calcHeadsConditionsRepository;

	@Autowired
	PortNameMasterRepository portNameMasterRepository;

	@Autowired
	MarineVoyageMasterRepository marineVoyageMasterRepository;

	@Autowired
	LossAssessmentHeadersMasterRepository lossAssessmentHeadersMasterRepository;

	@Autowired
	Environment env;

	@Autowired
	EntityManager entityManager;

	public String getProperty() {
		return env.getProperty("CONFIG_API_URL");
	}

	private static final Logger logger = LoggerFactory.getLogger(RcsMasterServiceImpl.class);

	@Override
	public CommonResponseDto<?> fetchClaimMileStone(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		CommonResponseDto<LookupTypeDto> commonResponseDto = new CommonResponseDto<>();
		List<LookupTypeValuesDto> dtos = new ArrayList<>();
		logger.info("RcsMasterServiceImpl-fetchClaimMileStone-Start");
		try {
			List<ClaimMileStonesEntity> entities = rcsMasterRepository
					.findByIsActiveAndRequestTypeIsNullOrRequestTypeOrderByOrderNoAsc(CommonConstants.TRUE,
							commonRequestDto.getProcessType());
			if (!entities.isEmpty()) {
				for (ClaimMileStonesEntity claimMileStonesEntity : entities) {
					LookupTypeValuesDto lookUpValuesDto = new LookupTypeValuesDto();
					lookUpValuesDto.setId(claimMileStonesEntity.getId());
					lookUpValuesDto.setCode(claimMileStonesEntity.getCode());
					lookUpValuesDto.setValue(claimMileStonesEntity.getName());
					lookUpValuesDto.setOrderNo(claimMileStonesEntity.getOrderNo());
					dtos.add(lookUpValuesDto);

				}
				LookupTypeDto lookupTypeDto = new LookupTypeDto();
				lookupTypeDto.setLookupTypeValues(dtos);
				commonResponseDto.setResponseData(lookupTypeDto);
				commonResponseDto.setStatus(CommonConstants.SUCCESS);
			}
		} catch (Exception e) {
			logger.error("Exception-RcsMasterServiceImpl-fetchClaimMileStone", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setError(e.getMessage());
		}
		logger.info("RcsMasterServiceImpl--fetchClaimMileStone--End");
		return commonResponseDto;
	}

	@Override
	public Map<String, ClaimMileStonesDto> getClaimMileStone(HttpServletRequest request) {
		logger.info("RcsMasterServiceImpl-getClaimMileStone-Start");

		List<ClaimMileStonesEntity> claimMileStones = rcsMasterRepository.findByIsActive(CommonConstants.TRUE);
		Map<String, ClaimMileStonesDto> claimMileStonesMap = new HashMap<>();
		try {
			for (ClaimMileStonesEntity entity : claimMileStones) {
				ClaimMileStonesDto claimMileStonesDto = new ClaimMileStonesDto();
				claimMileStonesDto.setMileStonesCode(entity.getCode());
				claimMileStonesDto.setCreatedDate(DateUtils.convertDateTimeToString(entity.getCreatedDate()));
				claimMileStonesDto.setDescription(entity.getDescription());
				claimMileStonesDto.setIsActive(entity.getIsActive());
				claimMileStonesDto.setMileStonesName(entity.getName());
				claimMileStonesDto.setModifiedDate(DateUtils.convertDateTimeToString(entity.getModifiedDate()));
				claimMileStonesDto.setOrderNo(NumericUtils.convertIntegerToString(entity.getOrderNo()));
				claimMileStonesDto.setRequestType(entity.getRequestType());
				claimMileStonesDto.setSubRequestType(entity.getSubRequestType());

				claimMileStonesMap.put(entity.getCode(), claimMileStonesDto);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("RcsMasterServiceImpl-getClaimMileStone-" + e);

		}
		logger.info("RcsMasterServiceImpl-getClaimMileStone-end");

		return claimMileStonesMap;
	}

	// fetchClaimStatus

	@Override
	public CommonResponseDto<List<StatusMasterDto>> fetchClaimStatus(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("MasterServiceImpl--fetchClaimStatus--Start");
		CommonResponseDto<List<StatusMasterDto>> commonResponseDto = new CommonResponseDto<>();
		try {
			List<StatusMasterDto> statusMasterList = new ArrayList<>();
			List<StatusMasterEntity> statusMasterEntList = statusMasterRepository
					.findByTypeContainingAndIsActive(commonRequestDto.getSource(), CommonConstants.TRUE);
			if (!statusMasterEntList.isEmpty()) {
				for (StatusMasterEntity statusEnt : statusMasterEntList) {
					StatusMasterDto statusmasterDto = new StatusMasterDto();
					statusmasterDto.setId(statusEnt.getId());
					statusmasterDto.setDescription(statusEnt.getDescription());
					statusmasterDto.setCode(statusEnt.getCode());
					statusmasterDto.setIsActive(statusEnt.getIsActive());
					statusmasterDto.setName(statusEnt.getName());
					statusmasterDto.setOrderNo(statusEnt.getOrderNo());
					statusMasterList.add(statusmasterDto);
				}

				commonResponseDto.setResponseData(statusMasterList);
				commonResponseDto.setStatus(CommonConstants.SUCCESS);
				commonResponseDto.setMessage("Claim Status Fetched Successfully");
			}
		} catch (Exception e) {
			logger.error("MasterServiceImpl--fetchClaimStatus--Error...", e);
			commonResponseDto.setStatus(CommonConstants.SUCCESS);
			commonResponseDto.setMessage("Claim Status not Fetched");
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
		}
		logger.info("MasterServiceImpl--fetchClaimStatus--End");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<List<SubStatusMasterDto>> fetchClaimSubStatus(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonResponseDto<List<SubStatusMasterDto>> commonResponseDto = new CommonResponseDto<>();
		logger.info("MasterServiceImpl--fetchClaimSubStatus--Start");
		try {
			List<SubStatusMasterDto> statusMasterDtoList = new ArrayList<SubStatusMasterDto>();
			List<StatusMasterEntity> statusMaster = statusMasterRepository.findByTypeContainingAndCodeAndIsActive(
					commonRequestDto.getSource(), commonRequestDto.getMainStatus(), CommonConstants.TRUE);
			if (!statusMaster.isEmpty()) {
				for (StatusMasterEntity statusMasterEntity : statusMaster) {
					if (!statusMasterEntity.getSubStatusMaster().isEmpty()) {
						for (SubStatusMasterEntity subStatusMaster : statusMasterEntity.getSubStatusMaster()) {
							SubStatusMasterDto subMasterDto = new SubStatusMasterDto();
							BeanUtils.copyProperties(subStatusMaster, subMasterDto);
							subMasterDto.setId(NumericUtils.convertLongToString(subStatusMaster.getId()));
							statusMasterDtoList.add(subMasterDto);
						}
					}

				}
			}
//			List<SubStatusMasterDto> statusMasterDtoList = new ArrayList<SubStatusMasterDto>();
//			List<SubStatusMasterEntity> subStatusEntity = subStatusMasterRepository.findByStatusMasterIdAndIsActive(
//					NumericUtils.convertStringToLong(commonRequestDto.getStatusMasterId()), CommonConstants.TRUE);
//			if (!subStatusEntity.isEmpty()) {
//				for (SubStatusMasterEntity subEntity : subStatusEntity) {
//					SubStatusMasterDto subMasterDto = new SubStatusMasterDto();
//					BeanUtils.copyProperties(subEntity, subMasterDto);
//					subMasterDto.setId(NumericUtils.convertLongToString(subEntity.getId()));
//					statusMasterDtoList.add(subMasterDto);
//				}
//			}
			commonResponseDto.setResponseData(statusMasterDtoList);
			commonResponseDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("MasterServiceImpl--fetchClaimSubStatus--Error...", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
		}
		logger.info("MasterServiceImpl--fetchClaimSubStatus--End");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<?> savePartyDetails(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		CommonResponseDto<PartiesDto> responseDto = new CommonResponseDto<PartiesDto>();
		logger.info("MasterServiceImpl--savePartyDetails--Start");
		PartiesDto dto = new PartiesDto();
		try {
			if (commonRequestDto != null) {
				PartiesDto partiesDto = commonRequestDto.getPartyDetail();
				PartiesEntity entity = new PartiesEntity();
				entity.setStakeCode(partiesDto.getStakeCode());
				entity.setStakeName(partiesDto.getStakeName());
				entity.setPartyCode(partiesDto.getPartyCode());
				entity.setBusinessName(partiesDto.getBusinessName());
				entity.setCreatedDate(DateUtils.sysDate());
				entity.setIsActive(partiesDto.getIsActive());
				partiesRepository.save(entity);
				BeanUtils.copyProperties(partiesDto, dto);
			}
			responseDto.setResponseData(dto);
			responseDto.setStatus(CommonConstants.SUCCESS);
			responseDto.setMessage(" Status Fetched Successfully");
		} catch (Exception e) {
			logger.error("MasterServiceImpl--fetchClaimSubStatus--Error...", e);
			responseDto.setStatus(CommonConstants.ERROR);
			responseDto.setMessage("Claim Status not Fetched");
			responseDto.setError(CommonUtils.getStackTrace(e));
		}
		return responseDto;
	}

	@Override
	public CommonResponseDto<Map<String, List<CalcFormulaDto>>> getCalcFormula(String calcType,
			HttpServletRequest request) {
		logger.info("MasterServiceImpl--getCalcFormula--Start");
		CommonResponseDto<Map<String, List<CalcFormulaDto>>> responseDto = new CommonResponseDto<>();
		Map<String, List<CalcFormulaDto>> responseMap = new HashMap<>();
		try {
			if (calcType != null && StringUtils.isNotBlank(calcType)) {
				CalcTypeEntity calcTypeEntity = calcTypeRepository.findByCodeAndIsActive(calcType,
						CommonConstants.TRUE);
				if (calcTypeEntity != null) {
					List<SubCalcTypeEntity> subCalcTypeEntities = calcTypeEntity.getSubCalcType();
					if (subCalcTypeEntities != null && !subCalcTypeEntities.isEmpty()) {
						for (SubCalcTypeEntity subCalcType : subCalcTypeEntities) {
							if (CommonConstants.TRUE.equals(subCalcType.getIsActive())) {
								List<CalcHeadsEntity> calcHeads = subCalcType.getCalcHeads();
								if (calcHeads != null && !calcHeads.isEmpty()) {
									for (CalcHeadsEntity calcHead : calcHeads) {
										if (CommonConstants.TRUE.equals(calcHead.getIsActive())) {
											List<CalcSubHeadsEntity> calcSubHeadList = calcHead.getCalcSubHeads();
											if (calcSubHeadList != null && !calcSubHeadList.isEmpty()) {
												for (CalcSubHeadsEntity calcSubHead : calcSubHeadList) {
													if (CommonConstants.TRUE.equals(calcSubHead.getIsActive())) {
														List<CalcHeadsAttributesEntity> calcHeadAttributesList = calcSubHead
																.getCalcHeadsAttributes();
														if (calcHeadAttributesList != null
																&& !calcHeadAttributesList.isEmpty()) {
															for (CalcHeadsAttributesEntity calcHeadAttributeEntity : calcHeadAttributesList) {
																if (CommonConstants.TRUE.equals(
																		calcHeadAttributeEntity.getIsActive())) {
																	List<CalcHeadsFormulaEntity> calcHeadsFormulaList = calcHeadsFormulaRepository
																			.findByCalcHeadsAttributeIdAndIsActive(
																					calcHeadAttributeEntity.getCode(),
																					CommonConstants.TRUE);
//																	Optional<CalcHeadsAttributesEntity> optObj1 = calcHeadsAttributesRepository
//																			.findById(NumericUtils.convertStringToLong(
//																					calcHeadsFormula
//																							.getCalcHeadsAttributesId1()));
//																	Optional<CalcHeadsAttributesEntity> optObj2 = calcHeadsAttributesRepository
//																			.findById(NumericUtils.convertStringToLong(
//																					calcHeadsFormula
//																							.getCalcHeadsAttributesId2()));
//																	if (optObj1.isPresent() && optObj2.isPresent()) {
//																		CalcHeadsAttributesEntity attribute1 = optObj1
//																				.get();
//																		CalcHeadsAttributesEntity attribute2 = optObj2
//																				.get();
//
//																		calcFormula.setCalcHeadsAttributesId1(
//																				attribute1.getName());
//																		calcFormula.setCalcHeadsAttributesId2(
//																				attribute2.getName());
//
																	List<CalcFormulaDto> formulaDtoList = new ArrayList<>();
																	if (calcHeadsFormulaList != null
																			&& !calcHeadsFormulaList.isEmpty()) {
																		for (CalcHeadsFormulaEntity calcHeadsFormula : calcHeadsFormulaList) {
																			CalcFormulaDto calcFormula = new CalcFormulaDto();

																			BeanUtils.copyProperties(calcHeadsFormula,
																					calcFormula);
																			calcFormula.setOrderNo(
																					NumericUtils.convertIntegerToString(
																							calcHeadsFormula
																									.getOrder()));
																			formulaDtoList.add(calcFormula);
																		}
																		responseMap.put(
																				calcHeadAttributeEntity.getCode(),
																				formulaDtoList);
																		responseDto.setResponseData(responseMap);
																		responseDto.setStatus(CommonConstants.SUCCESS);
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("MasterServiceImpl--getCalcFormula--Error...", e);
			responseDto.setStatus(CommonConstants.ERROR);
			responseDto.setError(CommonUtils.getStackTrace(e));
		}
		logger.info("MasterServiceImpl--getCalcFormula--end");
		return responseDto;
	}

	@Override
	public CommonResponseDto<?> fetchPendingAgeBand(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		CommonResponseDto<List<PendingAgeDto>> commonResponseDto = new CommonResponseDto<>();
		try {
			List<PendingAgeDto> lookupTypeValuesDtos = new ArrayList<>();
			List<PendingAgeMasterEntity> pendingAgeList = pendingAgeBandRepository.findByIsActive(CommonConstants.TRUE);
			if (pendingAgeList != null && !pendingAgeList.isEmpty()) {
				for (PendingAgeMasterEntity pendingAgeMasterEntity : pendingAgeList) {
					PendingAgeDto pendingAgeDto = new PendingAgeDto();
					pendingAgeDto.setCode(pendingAgeMasterEntity.getCode());
					pendingAgeDto.setName(pendingAgeMasterEntity.getName());
					pendingAgeDto.setOrderNo(pendingAgeMasterEntity.getOrderNo());
					lookupTypeValuesDtos.add(pendingAgeDto);
				}
				commonResponseDto.setResponseData(lookupTypeValuesDtos);
				commonResponseDto.setStatus(CommonConstants.SUCCESS);
			}
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setMessage(CommonUtils.getStackTrace(e));
			e.printStackTrace();
		}
		return commonResponseDto;
	}

	@Override
	@Cacheable(value = "getCalcConditions", key = "{#calcType}", cacheManager = "twoMinsCacheManager")
	public CommonResponseDto<Map<String, List<CalcConditionsDto>>> getCalcConditions(String calcType,
			HttpServletRequest request) {logger.info("MasterServiceImpl--getCalcConditions--Start");
			CommonResponseDto<Map<String, List<CalcConditionsDto>>> responseDto = new CommonResponseDto<>();
			Map<String, List<CalcConditionsDto>> responseMap = new HashMap<>();
			try {
//				if (calcType != null && StringUtils.isNotBlank(calcType)) {
//					CalcTypeEntity calcTypeEntity = calcTypeRepository.findByCodeAndIsActive(calcType,
//							CommonConstants.TRUE);
//					List<CalcAssessmentHeaderMasterEntity> calcAssessmentHeaders = null;
//					if (calcTypeEntity.getCode().equals(CommonConstants.LOSSASSESSMENT)) {
//						calcAssessmentHeaders = calcAssessmentHeaderMasterRepository
//								.findByIsActiveAndProductCodeOrderByOrderNoAsc(CommonConstants.TRUE,
//										commonRequestDto.getProductCode());
//						if (calcAssessmentHeaders != null && calcAssessmentHeaders.size() > 25) {
//							calcAssessmentHeaders = calcAssessmentHeaders.stream()
//									.filter(h -> StringUtils.isNotBlank(h.getCauseOfLoss()))
//									.filter(h -> h.getCauseOfLoss().equals(commonRequestDto.getCauseOfLoss()))
//									.collect(Collectors.toList());
//						}
	//
////						calcAssessmentHeaders = calcAssessmentHeaders.stream()
////								.sorted(Comparator.comparingInt(h -> h.getOrderNo())).collect(Collectors.toList());
//					}
	//
//					if (calcTypeEntity != null) {
//						List<SubCalcTypeEntity> subCalcTypeEntities = calcTypeEntity.getSubCalcType();
//						if (subCalcTypeEntities != null && !subCalcTypeEntities.isEmpty()) {
//							for (SubCalcTypeEntity subCalcType : subCalcTypeEntities) {
//								if (CommonConstants.TRUE.equals(subCalcType.getIsActive())) {
//									List<CalcHeadsEntity> calcHeads = subCalcType.getCalcHeads();
//									if (calcHeads != null && !calcHeads.isEmpty()) {
//										for (CalcHeadsEntity calcHead : calcHeads) {
//											if (CommonConstants.TRUE.equals(calcHead.getIsActive())) {
//												List<CalcSubHeadsEntity> calcSubHeadList = calcHead.getCalcSubHeads();
//												if (calcSubHeadList != null && !calcSubHeadList.isEmpty()) {
//													for (CalcSubHeadsEntity calcSubHead : calcSubHeadList) {
//														if (CommonConstants.TRUE.equals(calcSubHead.getIsActive())) {
//															List<CalcHeadsAttributesEntity> calcHeadAttributesList = calcSubHead
//																	.getCalcHeadsAttributes();
//															if (calcHeadAttributesList != null
//																	&& !calcHeadAttributesList.isEmpty()) {
//																for (CalcHeadsAttributesEntity calcHeadAttributeEntity : calcHeadAttributesList) {
//																	if (CommonConstants.TRUE.equals(
//																			calcHeadAttributeEntity.getIsActive())) {
//																		if (calcSubHead.getName()
//																				.equals("Total_Deductible_Amount")
//																				&& calcHeadAttributeEntity.getName()
//																						.equals("AMT24")) {
//																			calcHeadAttributeEntity.setCode("AMT26");
//																		}
//																		List<CalcHeadsConditionEntity> calcHeadsConditionsList = calcHeadsConditionsRepository
//																				.findByCodeAndIsActive(
//																						calcHeadAttributeEntity.getCode(),
//																						CommonConstants.TRUE);
//																
	 
				List<CalcHeadsConditionEntity> calcHeadsConditionsList = calcHeadsConditionsRepository
						.findByIsActive(CommonConstants.TRUE);
	 
				List<CalcConditionsDto> conditionDtoList = new ArrayList<>();
				if (calcHeadsConditionsList != null && !calcHeadsConditionsList.isEmpty()) {
					for (CalcHeadsConditionEntity calcHeadsConditionEntity : calcHeadsConditionsList) {
						CalcConditionsDto calcConditionsDto = new CalcConditionsDto();
	 
						BeanUtils.copyProperties(calcHeadsConditionEntity, calcConditionsDto);
						List<CalcConditionValuesDto> calcConditionValuesDtos = new ArrayList<>();
						List<CalcConditionValuesEntity> calcConditionValuesEntities = calcHeadsConditionEntity
								.getCalcConditionValues();
						if (calcConditionValuesEntities != null && !calcConditionValuesEntities.isEmpty()) {
							for (CalcConditionValuesEntity calcConditionValuesEntity : calcConditionValuesEntities) {
								if (CommonConstants.TRUE.equals(calcConditionValuesEntity.getIsActive())) {
									CalcConditionValuesDto calcConditionValuesDto = new CalcConditionValuesDto();
									BeanUtils.copyProperties(calcConditionValuesEntity, calcConditionValuesDto);
									calcConditionValuesDtos.add(calcConditionValuesDto);
								}
							}
						}
						calcConditionsDto.setCalcConditionValues(calcConditionValuesDtos);
	 
						conditionDtoList.add(calcConditionsDto);
					}
					responseMap = conditionDtoList.stream().collect(Collectors.groupingBy(CalcConditionsDto::getCode));
				}
				responseDto.setResponseData(responseMap);
				responseDto.setStatus(CommonConstants.SUCCESS);
	 
			} catch (Exception e) {
				logger.error("MasterServiceImpl--getCalcConditions--Error...", e);
				responseDto.setStatus(CommonConstants.ERROR);
				responseDto.setError(CommonUtils.getStackTrace(e));
			}
			logger.info("MasterServiceImpl--getCalcConditions--end");
			return responseDto;}

	@Override
	public CommonResponseDto<List<MasterDto>> fetchClosingReason(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("RcsMasterServiceImpl--fetchClosingReason--Start");
		CommonResponseDto<List<MasterDto>> commonResponseDto = new CommonResponseDto<>();
		try {
			List<MasterDto> masterDtoList = new ArrayList<>();
			List<ClosingReasonMasterEntity> closingReasonMasterList = closingReasonRepository
					.findByIsActive(CommonConstants.TRUE);
			for (ClosingReasonMasterEntity closingReasonMasterEntity : closingReasonMasterList) {
				MasterDto masterDto = new MasterDto();
				masterDto.setId(closingReasonMasterEntity.getId());
				masterDto.setCode(closingReasonMasterEntity.getCode());
				masterDto.setName(closingReasonMasterEntity.getName());
				masterDto.setOrderNo(closingReasonMasterEntity.getOrderNo());
				masterDtoList.add(masterDto);
			}
			commonResponseDto.setResponseData(masterDtoList);
			commonResponseDto.setStatus(CommonConstants.SUCCESS);

		} catch (Exception e) {
			logger.error("Exception-RcsMasterServiceImpl-fetchClosingReason", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "RcsMasterServiceImpl-fetchClosingReason", "fetchLOBList", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");

		}
		logger.info("RcsMasterServiceImpl--fetchClosingReason--End");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<List<MasterDto>> fetchPortNames(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("RcsMasterServiceImpl--fetchPortNames--Start");
		CommonResponseDto<List<MasterDto>> commonResponseDto = new CommonResponseDto<>();
		try {
			List<MasterDto> masterDtoList = new ArrayList<>();
			List<PortNameMasterEntity> portNameMasterEntities = portNameMasterRepository
					.findByIsActive(CommonConstants.TRUE);
			for (PortNameMasterEntity portNameMasterEntity : portNameMasterEntities) {
				MasterDto masterDto = new MasterDto();
				masterDto.setId(portNameMasterEntity.getId());
				masterDto.setCode(portNameMasterEntity.getCode());
				masterDto.setName(portNameMasterEntity.getName());
				masterDto.setOrderNo(portNameMasterEntity.getOrderNo());
				masterDtoList.add(masterDto);
			}
			commonResponseDto.setResponseData(masterDtoList);
			commonResponseDto.setStatus(CommonConstants.SUCCESS);

		} catch (Exception e) {
			logger.error("Exception-RcsMasterServiceImpl-fetchPortNames", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "RcsMasterServiceImpl-fetchPortNames", "fetchPortNames", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");

		}
		logger.info("RcsMasterServiceImpl--fetchClosingReason--End");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<List<MasterDto>> fetchMarineVoyages(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("RcsMasterServiceImpl--fetchMarineVoyages--Start");
		CommonResponseDto<List<MasterDto>> commonResponseDto = new CommonResponseDto<>();
		try {
			List<MasterDto> masterDtoList = new ArrayList<>();
			List<MarineVoyageMasterEntity> marineVoyageMasterEntities = marineVoyageMasterRepository
					.findByIsActive(CommonConstants.TRUE);
			for (MarineVoyageMasterEntity marineVoyageMasterEntity : marineVoyageMasterEntities) {
				MasterDto masterDto = new MasterDto();
				masterDto.setId(marineVoyageMasterEntity.getId());
				masterDto.setCode(marineVoyageMasterEntity.getCode());
				masterDto.setName(marineVoyageMasterEntity.getName());
				masterDto.setOrderNo(marineVoyageMasterEntity.getOrderNo());
				masterDtoList.add(masterDto);
			}
			commonResponseDto.setResponseData(masterDtoList);
			commonResponseDto.setStatus(CommonConstants.SUCCESS);

		} catch (Exception e) {
			logger.error("Exception-RcsMasterServiceImpl-fetchMarineVoyages", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "RcsMasterServiceImpl-fetchMarineVoyages", "fetchMarineVoyages",
					"", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");

		}
		logger.info("RcsMasterServiceImpl--fetchClosingReason--End");
		return commonResponseDto;
	}

	@Override
	public CommonResponseDto<List<MasterDto>> fetchLossAssessmentHeaders(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("RcsMasterServiceImpl--fetchLossAssessmentHeaders--Start");
		CommonResponseDto<List<MasterDto>> commonResponseDto = new CommonResponseDto<>();
		try {
			List<MasterDto> masterDtoList = new ArrayList<>();
			List<LossAssessmentHeadersMasterEntity> lossAssessmentHeadersMasterEntities = lossAssessmentHeadersMasterRepository
					.findByProductCodeAndIsActiveTrueAndCauseOfLossOrCauseOfLossIsNull(
							commonRequestDto.getProductCode(), commonRequestDto.getCauseOfLoss());
			for (LossAssessmentHeadersMasterEntity lossAssessmentHeadersMasterEntity : lossAssessmentHeadersMasterEntities) {
				MasterDto masterDto = new MasterDto();
				masterDto.setId(lossAssessmentHeadersMasterEntity.getId());
				masterDto.setCode(lossAssessmentHeadersMasterEntity.getCode());
				masterDto.setName(lossAssessmentHeadersMasterEntity.getName());
				masterDto.setOrderNo(lossAssessmentHeadersMasterEntity.getOrderNo());
				masterDtoList.add(masterDto);
			}
			commonResponseDto.setResponseData(masterDtoList);
			commonResponseDto.setStatus(CommonConstants.SUCCESS);

		} catch (Exception e) {
			logger.error("Exception-RcsMasterServiceImpl-fetchLossAssessmentHeaders", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "RcsMasterServiceImpl-fetchLossAssessmentHeaders",
					"fetchLossAssessmentHeaders", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");

		}
		logger.info("RcsMasterServiceImpl--fetchLossAssessmentHeaders--End");
		return commonResponseDto;

	}

}