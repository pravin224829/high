package com.fa.bajajallianz.cccp.config.rcs.calc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.master.entity.CalcHeadsEntity;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcHeadsDto;

@Repository
public interface CalcHeadsRepository extends JpaRepository<CalcHeadsEntity, Long> {

	CalcHeadsEntity findByCodeAndIsActive(String calcHead, Boolean true1);

}
