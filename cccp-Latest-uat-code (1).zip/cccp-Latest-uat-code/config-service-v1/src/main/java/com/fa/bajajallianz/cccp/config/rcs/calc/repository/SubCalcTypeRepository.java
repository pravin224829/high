package com.fa.bajajallianz.cccp.config.rcs.calc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fa.bajajallianz.cccp.master.entity.SubCalcTypeEntity;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcHeadsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcTypeDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.SubCalcTypeDto;

public interface SubCalcTypeRepository extends JpaRepository<SubCalcTypeEntity,Long> {


	}


