package com.fa.bajajallianz.cccp.config.admin.service.impl;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.dto.DocumentDto;
import com.fa.bajajallianz.cccp.common.dto.PartiesDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.DateUtils;
import com.fa.bajajallianz.cccp.common.utils.ErrorCodeConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.common.utils.NumericUtils;
import com.fa.bajajallianz.cccp.config.admin.entity.AssessmentStagingDataDetailsEntity;
import com.fa.bajajallianz.cccp.config.admin.entity.ColStagingDataDetailsEntity;
import com.fa.bajajallianz.cccp.config.admin.entity.EventCodeStagingDataDetailsEntity;
import com.fa.bajajallianz.cccp.config.admin.entity.MasterHistoryLogEntity;
import com.fa.bajajallianz.cccp.config.admin.entity.ProductDocStagingDetailsEntity;
import com.fa.bajajallianz.cccp.config.admin.entity.UserLocStagingDataDetailsEntity;
import com.fa.bajajallianz.cccp.config.admin.entity.WfStagingDataDetailsEntity;
import com.fa.bajajallianz.cccp.config.admin.repository.AssessmentStagingDataDetailsRepository;
import com.fa.bajajallianz.cccp.config.admin.repository.MasterHistoryLogRepository;
import com.fa.bajajallianz.cccp.config.admin.service.AdminService;
import com.fa.bajajallianz.cccp.config.dto.DeficiencyReasonDetailsDto;
import com.fa.bajajallianz.cccp.config.entity.DeficiencyReasonDetailsEntity;
import com.fa.bajajallianz.cccp.config.repository.EventCodeListRepository;
import com.fa.bajajallianz.cccp.config.utils.CommonErrorMsg;
import com.fa.bajajallianz.cccp.config.utils.CommonRequestUtil;
import com.fa.bajajallianz.cccp.master.dto.EventCodeListDto;
import com.fa.bajajallianz.cccp.master.entity.CalcAssessmentHeaderMasterEntity;
import com.fa.bajajallianz.cccp.master.entity.CauseOfLossEntity;
import com.fa.bajajallianz.cccp.master.entity.DocumentNameEntity;
import com.fa.bajajallianz.cccp.master.entity.EventCodeListEntity;
import com.fa.bajajallianz.cccp.master.entity.LobMasterEntity;
import com.fa.bajajallianz.cccp.master.entity.LocationDetailsEntity;
import com.fa.bajajallianz.cccp.master.entity.MenuPageEntity;
import com.fa.bajajallianz.cccp.master.entity.ProductMasterEntity;
import com.fa.bajajallianz.cccp.master.entity.SubStatusMasterEntity;
import com.fa.bajajallianz.cccp.master.entity.UserLocationEntity;
import com.fa.bajajallianz.cccp.master.repository.CalcAssessmentHeaderMasterRepository;
import com.fa.bajajallianz.cccp.master.repository.CauseOfLossRepository;
import com.fa.bajajallianz.cccp.master.repository.DocumentNameRepository;
import com.fa.bajajallianz.cccp.master.repository.ProductMasterRepository;
import com.fa.bajajallianz.cccp.master.repository.UserLocationRepository;
import com.fa.bajajallianz.cccp.rcs.admin.common.dto.ErrorLogDto;
import com.fa.bajajallianz.cccp.rcs.admin.common.dto.SearchDataDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.SubStatusDto;
import com.fa.bajajallianz.cccp.surveyor.common.dto.CauseOfLossDto;
import com.fa.bajajallianz.cccp.user.entity.PartiesEntity;
import com.fa.bajajallianz.cccp.user.entity.RoleEntity;
import com.fa.bajajallianz.cccp.user.entity.UserEntity;
import com.fa.bajajallianz.cccp.user.repository.PartiesRepository;
import com.fa.bajajallianz.cccp.user.repository.RoleRepository;
import com.fa.bajajallianz.cccp.user.repository.UserRepository;

@Service
public class AdminServiceImpl implements AdminService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	Environment env;

	@Autowired
	private CommonErrorMsg commonErrorMsg;

	@Autowired
	private EntityManager entityManager;

	@Autowired
	AssessmentStagingDataDetailsRepository assessmentStagingDataDetailsRepository;

	@Autowired
	CalcAssessmentHeaderMasterRepository calcAssessmentHeaderMasterRepository;

	@Autowired
	ProductMasterRepository productMasterRepository;

	@Autowired
	DocumentNameRepository documentNameRepository;

	@Autowired
	UserLocationRepository userLocationRepository;

	@Autowired
	MasterHistoryLogRepository masterHistoryLogRepository;

	@Autowired
	CauseOfLossRepository causeOfLossRepository;

	@Autowired
	EventCodeListRepository eventCodeListRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	private PartiesRepository partiesRepository;

	public String getProperty() {
		return env.getProperty("CONFIG_API_URL");
	}

	@Override
	public DataTableDto<List<DocumentDto>> searchProductDocument(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request) {
		logger.info("Enter into AdminServiceImpl searchProductDocument start");
		DataTableDto<List<DocumentDto>> dataTableDto = new DataTableDto<>();
		List<DocumentDto> dtos = new ArrayList<>();
		try {
			JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<DocumentNameEntity> query = builder.createQuery(DocumentNameEntity.class);
			Root<DocumentNameEntity> root = query.from(DocumentNameEntity.class);
			List<DocumentNameEntity> list = new ArrayList<>();
			List<Predicate> conditions = new ArrayList<>(1);
			boolean isFilter = false;
			if (commonRequestDto.getDocumentId() != null && StringUtils.isNotBlank(commonRequestDto.getDocumentId())) {
				isFilter = true;
				conditions.add(builder.equal(root.get("documentId"), commonRequestDto.getDocumentId()));
			}
			if (commonRequestDto.getProductCode() != null
					&& StringUtils.isNoneBlank(commonRequestDto.getProductCode())) {
				isFilter = true;
				conditions.add(builder.equal(root.get("productCode"), commonRequestDto.getProductCode()));
			}
			if (CommonConstants.ENABLED.equals(commonRequestDto.getDocStatus())) {
				isFilter = true;
				conditions.add(builder.isTrue(root.get("isActive")));
			} else if (CommonConstants.DISABLE.equals(commonRequestDto.getDocStatus())) {
				isFilter = true;
				conditions.add(builder.isFalse(root.get("isActive")));
			}
			query.orderBy(builder.asc(root.get("id")));
			query.select(root).where(conditions.toArray(new Predicate[] {}));
			Integer pageCount = NumericUtils.convertStringToInteger(page);
			Integer limit = NumericUtils.convertStringToInteger(per_page);
			Integer offset = CommonUtils.calculateOffset(pageCount, limit);
			List<DocumentNameEntity> resultList = new ArrayList<>();

			if (isFilter) {
				query.orderBy(builder.asc(root.get("modifiedDate")));
				list = entityManager.createQuery(query).setFirstResult(offset).setMaxResults(limit).getResultList();
				resultList = entityManager.createQuery(query).getResultList();
			}
			for (DocumentNameEntity documentNameEntity : list) {
				DocumentDto documentDto = new DocumentDto();
				BeanUtils.copyProperties(documentNameEntity, documentDto);
				documentDto.setDocId(documentNameEntity.getDocumentId());
//				documentDto.setEffectiveDate(DateUtils.dateToStringDDMMYYYYWith(documentNameEntity.getEffectiveDate()));
				documentDto.setActivationStatus(
						CommonConstants.TRUE.equals(documentNameEntity.getIsActive()) ? CommonConstants.ENABLED
								: CommonConstants.DISABLE);
				dtos.add(documentDto);
			}
			dataTableDto.setLast_page("0");
			dataTableDto.setTotal("0");
			if (resultList != null && !resultList.isEmpty()) {
				Integer lastReminder = (resultList.size() % limit);
				Integer last = (resultList.size() / limit);
				if (lastReminder == 0) {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
				} else {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
				}
				dataTableDto.setTotal(NumericUtils.convertIntegerToString(resultList.size()));
			}
			dataTableDto.setCurrent_page(page);
			dataTableDto.setPer_page(per_page);
			dataTableDto.setData(dtos);
			Integer nextPage = pageCount + 1;
			Integer prevPage = pageCount - 1;
			Integer from = (pageCount * limit) - limit + 1;
			Integer to = pageCount * limit;
			dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
			dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
			String rootUrl = CommonUtils.fetchApi("CONFIGURATIONROOTURL", getProperty());
			dataTableDto.setNext_page_url(rootUrl + "/cccp/config/admin/api/searchProductDocument?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
			dataTableDto.setPrev_page_url(rootUrl + "/cccp/config/admin/api/searchProductDocument?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
			dataTableDto.setData(dtos);
			dataTableDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Enter into AdminServiceImpl-searchProductDocument Exception", e);
			dataTableDto.setStatus(CommonConstants.ERROR);
			dataTableDto.setMessage(CommonUtils.getStackTrace(e));
		}
		logger.info("Eneter into AdminServiceImpl searchProductDocument end");
		return dataTableDto;
	}

	@Override
	public CommonResponseDto<?> saveProductDocument(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		CommonResponseDto<?> commonResponse = new CommonResponseDto<>();
		try {

		} catch (Exception e) {
			logger.info("AdminServiceImpl-saveProductDocument..", e);
			commonResponse.setStatus(CommonConstants.ERROR);
			e.printStackTrace();
			commonResponse.setError(CommonUtils.getStackTrace(e));
		}

		return commonResponse;
	}

	@Override
	public DataTableDto<List<SearchDataDto>> searchAssessmentDetails(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request) {
		logger.info("Enter into AdminServiceImpl-searchAssessmentDetails-Started");
		DataTableDto<List<SearchDataDto>> response = new DataTableDto<List<SearchDataDto>>();
		List<SearchDataDto> dtos = new ArrayList<SearchDataDto>();
		try {
			JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			Integer pageCount;
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<CalcAssessmentHeaderMasterEntity> query = builder
					.createQuery(CalcAssessmentHeaderMasterEntity.class);
			Root<CalcAssessmentHeaderMasterEntity> root = query.from(CalcAssessmentHeaderMasterEntity.class);
			List<Predicate> conditions = new ArrayList<>(1);
			Join<CalcAssessmentHeaderMasterEntity, ProductMasterEntity> productEntities = root.join("product");
			List<CalcAssessmentHeaderMasterEntity> list = new ArrayList<>();

			if (StringUtils.isNotBlank(commonRequestDto.getProductCode())
					&& StringUtils.isNotBlank(commonRequestDto.getAssessmentId())) {
				conditions.add(builder.equal(productEntities.get("code"), commonRequestDto.getProductCode()));
				conditions.add(builder.equal(root.get("assessmentId"), commonRequestDto.getAssessmentId()));
//				conditions.add(builder.equal(root.get("isActive"), CommonConstants.TRUE));
			} else if (StringUtils.isNotBlank(commonRequestDto.getProductCode())) {
				conditions.add(builder.equal(productEntities.get("code"), commonRequestDto.getProductCode()));
//				conditions.add(builder.equal(root.get("isActive"), CommonConstants.TRUE));
			} else if (StringUtils.isNotBlank(commonRequestDto.getAssessmentId())) {
				conditions.add(builder.equal(root.get("assessmentId"), commonRequestDto.getAssessmentId()));
//				conditions.add(builder.equal(root.get("isActive"), CommonConstants.TRUE));
			}

			query.select(root).where(conditions.toArray(new Predicate[] {}));

			if (page != null) {
				pageCount = NumericUtils.convertStringToInteger(page);
			} else {
				pageCount = 0;
			}

			Integer limit = NumericUtils.convertStringToInteger(per_page);
			Integer offset = (pageCount * limit) - limit;

			list = entityManager.createQuery(query).setFirstResult(offset).setMaxResults(limit).getResultList();
			if (list.size() > 0) {
				for (CalcAssessmentHeaderMasterEntity calcAssessmentHeaderMasterEntity : list) {
					if (calcAssessmentHeaderMasterEntity != null) {
						SearchDataDto searchDataDto = new SearchDataDto();
						searchDataDto.setAssessmentId(calcAssessmentHeaderMasterEntity.getAssessmentId());
						searchDataDto.setDisplayName(calcAssessmentHeaderMasterEntity.getName());
						searchDataDto.setModifiedBy(calcAssessmentHeaderMasterEntity.getModifiedBy());
						searchDataDto.setModifiedDate(DateUtils.convertDateTimeToStringWithPeriodMMM(
								calcAssessmentHeaderMasterEntity.getModifiedDate()));
						if (calcAssessmentHeaderMasterEntity.getProduct() != null) {
							searchDataDto.setProductCode(calcAssessmentHeaderMasterEntity.getProduct().getCode());
						}
						searchDataDto.setStatus(calcAssessmentHeaderMasterEntity.getIsActive() ? CommonConstants.ENABLED
								: CommonConstants.DISABLED);
						searchDataDto.setVersion(null);
						dtos.add(searchDataDto);
					}
				}
			}

			if (page != null) {
				pageCount = NumericUtils.convertStringToInteger(page);
			} else {
				pageCount = 0;
			}
			Integer totalCount = 0;
			list = entityManager.createQuery(query).getResultList();
			totalCount = list.size();

			response.setData(dtos);
			Integer from = (pageCount * limit) - limit + 1;
			Integer to = pageCount * limit;
			response.setPer_page(NumericUtils.convertIntegerToString(limit));
			response.setFrom(NumericUtils.convertIntegerToString(from));
			response.setTo(NumericUtils.convertIntegerToString(to));
			response.setCurrent_page(NumericUtils.convertIntegerToString(pageCount));
			response.setTotal(NumericUtils.convertIntegerToString(totalCount.intValue()));
			Integer lastReminder = (totalCount.intValue() % limit);
			Integer last = (totalCount.intValue() / limit);
			if (lastReminder == 0) {
				response.setLast_page(NumericUtils.convertIntegerToString(last));
			} else {
				response.setLast_page(NumericUtils.convertIntegerToString(last + 1));
			}
			Integer nextPage = pageCount + 1;
			Integer prevPage = pageCount - 1;
			String rootUrl = CommonUtils.fetchApi("CONFIGURATIONROOTURL", getProperty());
			response.setNext_page_url(rootUrl + "/cccp/config/admin/api/searchAssessmentDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
			response.setPrev_page_url(rootUrl + "/cccp/config/admin/api/searchAssessmentDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
			response.setData(dtos);
			response.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			response.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "AdminServiceImpl-searchAssessmentDetails",
					"searchAssessmentDetails", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
			logger.error("Exception-AdminServiceImpl-searchAssessmentDetails", e);
			response.setStatus(CommonConstants.ERROR);
			response.setError(e.getMessage());
		}
		return response;
	}

	@Override
	public CommonResponseDto<?> saveAssessmentDetails(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		try {
			logger.info("Enter into AdminServiceImpl-saveAssessmentDetails-Started");
			List<AssessmentStagingDataDetailsEntity> assessmentStagingDataDetailsEntityList = assessmentStagingDataDetailsRepository
					.findByFileIdAndStatus(commonRequestDto.getFileId(), CommonConstants.SUCCESS);
			if (assessmentStagingDataDetailsEntityList != null && !assessmentStagingDataDetailsEntityList.isEmpty()) {
				for (AssessmentStagingDataDetailsEntity assessmentStagingDataDetailsEntity : assessmentStagingDataDetailsEntityList) {
					if (StringUtils.isNotBlank(assessmentStagingDataDetailsEntity.getAction())) {
						CalcAssessmentHeaderMasterEntity calcAssessmentHeaderMasterEntity = null;
						MasterHistoryLogEntity masterHistoryLogEntity = new MasterHistoryLogEntity();
						switch (assessmentStagingDataDetailsEntity.getAction()) {
						case CommonConstants.UPDATE:
							calcAssessmentHeaderMasterEntity = calcAssessmentHeaderMasterRepository
									.findByProductCodeAndAssessmentId(
											assessmentStagingDataDetailsEntity.getProductCode(),
											assessmentStagingDataDetailsEntity.getAssesmentCode());
							if (calcAssessmentHeaderMasterEntity != null) {
								masterHistoryLogEntity.setPreviousValue(
										NumericUtils.convertPojoClassToJSONString(calcAssessmentHeaderMasterEntity));
								calcAssessmentHeaderMasterEntity.setName(assessmentStagingDataDetailsEntity.getLabel());
								calcAssessmentHeaderMasterEntity.setModifiedBy(commonRequestDto.getUserId());
								calcAssessmentHeaderMasterEntity.setModifiedDate(DateUtils.sysDate());
								masterHistoryLogEntity.setCurrentValue(
										NumericUtils.convertPojoClassToJSONString(calcAssessmentHeaderMasterEntity));
								calcAssessmentHeaderMasterRepository.save(calcAssessmentHeaderMasterEntity);
								masterHistoryLogRepository.save(masterHistoryLogEntity);
							}
							break;

						case CommonConstants.REMOVE:
							calcAssessmentHeaderMasterEntity = calcAssessmentHeaderMasterRepository
									.findByProductCodeAndAssessmentId(
											assessmentStagingDataDetailsEntity.getProductCode(),
											assessmentStagingDataDetailsEntity.getAssesmentCode());

							if (calcAssessmentHeaderMasterEntity != null) {
								masterHistoryLogEntity.setPreviousValue(
										NumericUtils.convertPojoClassToJSONString(calcAssessmentHeaderMasterEntity));
								calcAssessmentHeaderMasterEntity.setIsActive(CommonConstants.FALSE);
								calcAssessmentHeaderMasterEntity.setModifiedBy(commonRequestDto.getUserId());
								calcAssessmentHeaderMasterEntity.setModifiedDate(DateUtils.sysDate());
								masterHistoryLogEntity.setCurrentValue(
										NumericUtils.convertPojoClassToJSONString(calcAssessmentHeaderMasterEntity));
								calcAssessmentHeaderMasterRepository.save(calcAssessmentHeaderMasterEntity);
								masterHistoryLogRepository.save(masterHistoryLogEntity);
							}
							break;

						case CommonConstants.ADD:
							calcAssessmentHeaderMasterEntity = new CalcAssessmentHeaderMasterEntity();
							calcAssessmentHeaderMasterEntity
									.setAssessmentId(assessmentStagingDataDetailsEntity.getAssesmentCode());
							if (assessmentStagingDataDetailsEntity.getProductCode() != null) {
								ProductMasterEntity product = productMasterRepository
										.findByCode(assessmentStagingDataDetailsEntity.getProductCode());
								if (product != null)
									calcAssessmentHeaderMasterEntity.setProduct(product);
							}
							calcAssessmentHeaderMasterEntity.setName(assessmentStagingDataDetailsEntity.getLabel());
							String[] order = calcAssessmentHeaderMasterEntity.getAssessmentId().split("-");
							Integer orderNo = Integer.valueOf(order[2]);
							calcAssessmentHeaderMasterEntity.setOrderNo(orderNo * 10);
							calcAssessmentHeaderMasterEntity.setIsActive(CommonConstants.TRUE);
							calcAssessmentHeaderMasterEntity.setCreateBy(commonRequestDto.getUserId());
							calcAssessmentHeaderMasterEntity.setCreatedDate(DateUtils.sysDate());
							calcAssessmentHeaderMasterRepository.save(calcAssessmentHeaderMasterEntity);
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("Enter into AdminServiceImpl-saveAssessmentDetails-Started", e);
			e.printStackTrace();
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "AdminServiceImpl-saveAssessmentDetails", "saveAssessmentDetails",
					"", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
			logger.error("Exception-AdminServiceImpl-saveAssessmentDetails", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setError(e.getMessage());
		}
		logger.info("Enter into AdminServiceImpl-saveAssessmentDetails-end - " + commonResponseDto.getStatus());
		return commonResponseDto;
	}

	@Override
	public DataTableDto<List<CauseOfLossDto>> searchCOLDetails(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request) {
		logger.info("Enter into AdminServiceImpl searchCOLDetails start");
		DataTableDto<List<CauseOfLossDto>> dataTableDto = new DataTableDto<List<CauseOfLossDto>>();
		List<CauseOfLossDto> dtos = new ArrayList<CauseOfLossDto>();
		try {
			JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<CauseOfLossEntity> query = builder.createQuery(CauseOfLossEntity.class);
			Root<CauseOfLossEntity> root = query.from(CauseOfLossEntity.class);
			List<Predicate> conditions = new ArrayList<>(1);
			Join<CauseOfLossEntity, ProductMasterEntity> productEntities = root.join("causeofloss", JoinType.INNER);
			Join<ProductMasterEntity, LobMasterEntity> lobEntities = productEntities.join("lobMaster", JoinType.INNER);
			List<CauseOfLossEntity> list = new ArrayList<>();
			boolean isFilter = false;
			if (commonRequestDto.getProductCode() != null && commonRequestDto.getLineOfBusiness() != null
					&& StringUtils.isNotBlank(commonRequestDto.getLineOfBusiness())
					&& StringUtils.isNotBlank(commonRequestDto.getProductCode())) {
				isFilter = true;
				conditions.add(builder.equal(productEntities.get("code"), commonRequestDto.getProductCode()));
				conditions.add(builder.equal(lobEntities.get("code"), commonRequestDto.getLineOfBusiness()));
			} else if (commonRequestDto.getProductCode() != null
					&& StringUtils.isNotBlank(commonRequestDto.getProductCode())) {
				isFilter = true;
				conditions.add(builder.equal(productEntities.get("code"), commonRequestDto.getProductCode()));
			} else if (commonRequestDto.getLineOfBusiness() != null
					&& StringUtils.isNotBlank(commonRequestDto.getLineOfBusiness())) {
				isFilter = true;
				conditions.add(builder.equal(lobEntities.get("code"), commonRequestDto.getLineOfBusiness()));
			}

			query.select(root).where(conditions.toArray(new Predicate[] {}));
			Integer pageCount = NumericUtils.convertStringToInteger(page);
			Integer limit = NumericUtils.convertStringToInteger(per_page);
			Integer offset = CommonUtils.calculateOffset(pageCount, limit);
			List<CauseOfLossEntity> resultList = new ArrayList<>();
			if (isFilter) {
				query.orderBy(builder.asc(root.get("modifiedDate")));
				list = entityManager.createQuery(query).setFirstResult(offset).setMaxResults(limit).getResultList();
				resultList = entityManager.createQuery(query).getResultList();
			}

			if (list != null && !list.isEmpty()) {
				for (CauseOfLossEntity entity : list) {
					CauseOfLossDto dto = new CauseOfLossDto();
					BeanUtils.copyProperties(entity, dto);
					dto.setModifiedDate(DateUtils.convertDateTimeToStringWithPeriodMMM(entity.getModifiedDate()));
					dto.setProductCode(entity.getCauseofloss() != null ? entity.getCauseofloss().getCode() : null);
					dto.setStatus(CommonConstants.TRUE.equals(entity.getIsActive()) ? CommonConstants.ENABLED
							: CommonConstants.DISABLED);
					dto.setModifiedBy(commonRequestDto.getUserId());
					dtos.add(dto);
				}
			}
			dataTableDto.setLast_page("0");
			dataTableDto.setTotal("0");
			if (resultList != null && !resultList.isEmpty()) {
				Integer lastReminder = (resultList.size() % limit);
				Integer last = (resultList.size() / limit);
				if (lastReminder == 0) {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
				} else {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
				}
				dataTableDto.setTotal(NumericUtils.convertIntegerToString(resultList.size()));
			}
			dataTableDto.setCurrent_page(page);
			dataTableDto.setPer_page(per_page);
			dataTableDto.setData(dtos);
			Integer nextPage = pageCount + 1;
			Integer prevPage = pageCount - 1;
			Integer from = (pageCount * limit) - limit + 1;
			Integer to = pageCount * limit;
			dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
			dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
			String rootUrl = CommonUtils.fetchApi("CONFIGURATIONROOTURL", getProperty());
			dataTableDto.setNext_page_url(rootUrl + "/cccp/config/admin/api/searchCOLDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
			dataTableDto.setPrev_page_url(rootUrl + "/cccp/config/admin/api/searchCOLDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
			dataTableDto.setData(dtos);
			dataTableDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Enter into AdminServiceImpl searchCOLDetails Exception", e);
			e.printStackTrace();
			dataTableDto.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "AdminServiceImpl-searchCOLDetails", "searchCOLDetails", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
			dataTableDto.setError(e.getMessage());
		}
		logger.info("Enter into AdminServiceImpl searchCOLDetails end");
		return dataTableDto;
	}

	@Override
	public DataTableDto<List<SearchDataDto>> searchUserLocationDetails(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request) {
		logger.info("Enter into AdminServiceImpl searchUserLocationDetails start");
		DataTableDto<List<SearchDataDto>> dataTableDto = new DataTableDto<List<SearchDataDto>>();
		List<SearchDataDto> dtos = new ArrayList<>();
		try {
			JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<UserLocationEntity> query = builder.createQuery(UserLocationEntity.class);
			Root<UserLocationEntity> root = query.from(UserLocationEntity.class);
			List<Predicate> conditions = new ArrayList<>(1);
			Join<UserLocationEntity, LocationDetailsEntity> userLocationEntities = root.join("locationDetails",
					JoinType.INNER);
			Join<UserLocationEntity, UserEntity> userEntities = root.join("users", JoinType.INNER);
			List<UserLocationEntity> list = new ArrayList<>();
			boolean isFilter = false;
			if (commonRequestDto.getClaimLocationCode() != null
					&& StringUtils.isNotBlank(commonRequestDto.getClaimLocationCode())
					&& commonRequestDto.getUserSearchId() != null
					&& StringUtils.isNotBlank(commonRequestDto.getUserSearchId())) {
				isFilter = true;
				conditions
						.add(builder.equal(userLocationEntities.get("code"), commonRequestDto.getClaimLocationCode()));
				conditions.add(builder.equal(userEntities.get("userId"), commonRequestDto.getUserSearchId()));
			} else if (commonRequestDto.getClaimLocationCode() != null
					&& StringUtils.isNotBlank(commonRequestDto.getClaimLocationCode())) {
				isFilter = true;
				conditions
						.add(builder.equal(userLocationEntities.get("code"), commonRequestDto.getClaimLocationCode()));
			} else if (commonRequestDto.getUserSearchId() != null
					&& StringUtils.isNotBlank(commonRequestDto.getUserSearchId())) {
				isFilter = true;
				conditions.add(builder.equal(userEntities.get("userId"), commonRequestDto.getUserSearchId()));
			}
			query.select(root).where(conditions.toArray(new Predicate[] {}));
			Integer pageCount = NumericUtils.convertStringToInteger(page);
			Integer limit = NumericUtils.convertStringToInteger(per_page);
			Integer offset = CommonUtils.calculateOffset(pageCount, limit);
			List<UserLocationEntity> resultList = new ArrayList<>();
			if (CommonConstants.TRUE.equals(isFilter)) {
				query.orderBy(builder.asc(root.get("modifiedDate")));
				list = entityManager.createQuery(query).setFirstResult(offset).setMaxResults(limit).getResultList();
				resultList = entityManager.createQuery(query).getResultList();
			}
			for (UserLocationEntity entity : list) {
				SearchDataDto dto = new SearchDataDto();
				BeanUtils.copyProperties(entity, dto);
				dto.setLocationCode(entity.getLocationDetails() != null ? entity.getLocationDetails().getCode() : null);
				dto.setUserId(entity.getUsers() != null ? entity.getUsers().getUserId() : null);
				dto.setModifiedDate(DateUtils.convertDateTimeToStringWithPeriodMMM(entity.getModifiedDate()));
				dto.setStatus(CommonConstants.TRUE.equals(entity.getIsActive()) ? CommonConstants.ENABLED
						: CommonConstants.DISABLED);
				dtos.add(dto);
			}
			dataTableDto.setLast_page("0");
			dataTableDto.setTotal("0");
			if (resultList != null && !resultList.isEmpty()) {
				Integer lastReminder = (resultList.size() % limit);
				Integer last = (resultList.size() / limit);
				if (lastReminder == 0) {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
				} else {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
				}
				dataTableDto.setTotal(NumericUtils.convertIntegerToString(resultList.size()));
			}
			dataTableDto.setCurrent_page(page);
			dataTableDto.setPer_page(per_page);
			dataTableDto.setData(dtos);
			Integer nextPage = pageCount + 1;
			Integer prevPage = pageCount - 1;
			Integer from = (pageCount * limit) - limit + 1;
			Integer to = pageCount * limit;
			dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
			dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
			String rootUrl = CommonUtils.fetchApi("CONFIGURATIONROOTURL", getProperty());
			dataTableDto.setNext_page_url(
					rootUrl + "/cccp/config/admin/api/searchUserLocationDetails?payload=" + payload + "&main_filter="
							+ main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
			dataTableDto.setPrev_page_url(
					rootUrl + "/cccp/config/admin/api/searchUserLocationDetails?payload=" + payload + "&main_filter="
							+ main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
			dataTableDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Enter into AdminServiceImpl searchUserLocationDetails Exception", e);
			e.printStackTrace();
			dataTableDto.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			CommonRequestUtil.errorInfo(request, "", "AdminServiceImpl-searchUserLocationDetails",
					"searchUserLocationDetails", "", e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
			dataTableDto.setStatus(CommonConstants.ERROR);
			dataTableDto.setError(e.getMessage());
		}
		logger.info("Enter into AdminServiceImpl searchUserLocationDetails end");
		return dataTableDto;
	}

	@Override
	public CommonResponseDto<String> downloadProductDocDetials(CommonRequestDto requestDto,
			HttpServletRequest request) {
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		logger.info("Enter into AdminServiceImpl-downloadProductDocDetials Start...");

		try {
			XSSFWorkbook workbook = new XSSFWorkbook();
			// Sheet sheet =
			XSSFSheet spreadsheet = workbook.createSheet("DocumentNameEntities");

			XSSFCellStyle blueStyle = workbook.createCellStyle();
			XSSFColor blueColor = new XSSFColor(new java.awt.Color(150, 200, 230), null); // RGB for blue
			blueStyle.setFillForegroundColor(blueColor);
			blueStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

			switch (requestDto.getPageCode()) {

			case "PRODUCTDOC":
				if (requestDto.getPageCode() != null) {
					List<DocumentNameEntity> entities = documentNameRepository.findByIsActive(CommonConstants.TRUE);

					XSSFRow headerRow = spreadsheet.createRow(0);
					headerRow.createCell(1).setCellValue("Code");
					headerRow.createCell(2).setCellValue("Name");
					headerRow.createCell(3).setCellValue("Display Name");
					headerRow.createCell(4).setCellValue("Product Category");
					headerRow.createCell(5).setCellValue("Doc Type");
					headerRow.createCell(6).setCellValue("Is Active");
//				        headerRow.createCell(7).setCellValue("Is Mandatory");
					headerRow.createCell(7).setCellValue("Created Date");
					headerRow.createCell(8).setCellValue("Modified Date");
					headerRow.createCell(9).setCellValue("Workflow Type");
					headerRow.createCell(10).setCellValue("Document ID");
					// headerRow.createCell(12).setCellValue("Order No");

					for (int i = 0; i < headerRow.getLastCellNum(); i++) {
						if (headerRow.getCell(i) != null)
							headerRow.getCell(i).setCellStyle(blueStyle);
					}

					int rowNum = 1;
					for (DocumentNameEntity entity : entities) {
						XSSFRow row = spreadsheet.createRow(rowNum++);
						row.createCell(0).setCellValue(entity.getId());
						row.createCell(1).setCellValue(entity.getCode());
						row.createCell(2).setCellValue(entity.getName());
						row.createCell(3).setCellValue(entity.getDisplayName());
						row.createCell(4).setCellValue(entity.getProductCategory());
						row.createCell(5).setCellValue(entity.getDocType());
						row.createCell(6).setCellValue(
								entity.getIsActive() ? CommonConstants.ENABLED : CommonConstants.DISABLED);
						// row.createCell(7).setCellValue(entity.getIsMandatory());
						row.createCell(7).setCellValue(entity.getCreatedDate().toString());
						row.createCell(8).setCellValue(entity.getModifiedDate().toString());

						row.createCell(9).setCellValue(entity.getWorkflowType());
						row.createCell(10).setCellValue(entity.getDocumentId());
						// row.createCell(12).setCellValue(entity.getOrderNo());

					}
				}
				break;

			case "COLCONFIG":
				if (requestDto.getPageCode() != null) {
					List<CauseOfLossEntity> entities = causeOfLossRepository.findByIsActive(CommonConstants.TRUE);
					// Create Excel workbook and sheet

					// Create header row
					XSSFRow headerRow = spreadsheet.createRow(0);
					headerRow.createCell(1).setCellValue("Code");
					headerRow.createCell(2).setCellValue("Name");
					headerRow.createCell(3).setCellValue("Is Active");
					headerRow.createCell(4).setCellValue("Created Date");
					headerRow.createCell(5).setCellValue("Modified Date");
					headerRow.createCell(6).setCellValue("Workflow Type");
					headerRow.createCell(7).setCellValue("Product Id");

					for (int i = 0; i < headerRow.getLastCellNum(); i++) {
						if (headerRow.getCell(i) != null)
							headerRow.getCell(i).setCellStyle(blueStyle);
					}

					int rowNum = 1;
					for (CauseOfLossEntity entity : entities) {
						XSSFRow row = spreadsheet.createRow(rowNum++);
						row.createCell(0).setCellValue(entity.getId());
						row.createCell(1).setCellValue(entity.getCode());
						row.createCell(2).setCellValue(entity.getName());
						row.createCell(3).setCellValue(
								entity.getIsActive() ? CommonConstants.ENABLED : CommonConstants.DISABLED);
						row.createCell(4).setCellValue(entity.getCreatedDate().toString());
						row.createCell(5).setCellValue(entity.getModifiedDate().toString());
					}
				}
				break;

			case "USERLOCATION":
				if (requestDto.getPageCode() != null) {
					List<UserLocationEntity> entities = userLocationRepository.findByIsActive(CommonConstants.TRUE);
					// Create Excel workbook and sheet

					// Create header row
					XSSFRow headerRow = spreadsheet.createRow(0);
					headerRow.createCell(1).setCellValue("Location Id");
					headerRow.createCell(2).setCellValue("Role Id");
					headerRow.createCell(3).setCellValue("User Id");
					headerRow.createCell(4).setCellValue("Modified Date");
					headerRow.createCell(5).setCellValue("Is Active");
					headerRow.createCell(6).setCellValue("Modified By");
					for (int i = 0; i < headerRow.getLastCellNum(); i++) {
						if (headerRow.getCell(i) != null)
							headerRow.getCell(i).setCellStyle(blueStyle);
					}
					int rowNum = 1;
					for (UserLocationEntity entity : entities) {
						XSSFRow row = spreadsheet.createRow(rowNum++);
						row.createCell(0).setCellValue(entity.getId());
						row.createCell(6).setCellValue(entity.getModifiedBy());
						row.createCell(5).setCellValue(
								entity.getIsActive() ? CommonConstants.ENABLED : CommonConstants.DISABLED);
						row.createCell(4).setCellValue(entity.getModifiedDate().toString());
					}
				}
				break;

			case "ASSMTCOMPONENT":
				if (requestDto.getPageCode() != null) {
					List<CalcAssessmentHeaderMasterEntity> entities = calcAssessmentHeaderMasterRepository
							.findByIsActive(CommonConstants.TRUE);
					// Create Excel workbook and sheet

					// Create header row
					XSSFRow headerRow = spreadsheet.createRow(0);
					headerRow.createCell(1).setCellValue("Code");
					headerRow.createCell(2).setCellValue("Name");
					headerRow.createCell(3).setCellValue("Assessment Id");
					headerRow.createCell(4).setCellValue("Modified Date");
					headerRow.createCell(5).setCellValue("Is Active");
					headerRow.createCell(6).setCellValue("Modified By");
					headerRow.createCell(7).setCellValue("Product Id");

					for (int i = 0; i < headerRow.getLastCellNum(); i++) {
						if (headerRow.getCell(i) != null)
							headerRow.getCell(i).setCellStyle(blueStyle);
					}

					int rowNum = 1;
					for (CalcAssessmentHeaderMasterEntity entity : entities) {
						XSSFRow row = spreadsheet.createRow(rowNum++);
						row.createCell(0).setCellValue(entity.getId());
						row.createCell(1).setCellValue(entity.getCode());
						row.createCell(2).setCellValue(entity.getName());
						row.createCell(3).setCellValue(entity.getAssessmentId());
						row.createCell(6).setCellValue(entity.getModifiedBy());
						row.createCell(5).setCellValue(
								entity.getIsActive() ? CommonConstants.ENABLED : CommonConstants.DISABLED);
						row.createCell(4).setCellValue(
								entity.getModifiedDate() != null ? entity.getModifiedDate().toString() : null);
					}
				}
				break;

			case "EVENTCODECRE":
				if (requestDto.getPageCode() != null) {
					List<EventCodeListEntity> entities = eventCodeListRepository.findByIsActive(CommonConstants.TRUE);

					// Create Excel workbook and sheet

					// Create header row
					XSSFRow headerRow = spreadsheet.createRow(0);
					headerRow.createCell(1).setCellValue("Code");
					headerRow.createCell(2).setCellValue("Name");
					headerRow.createCell(3).setCellValue("Modified Date");
					headerRow.createCell(4).setCellValue("Is Active");
					headerRow.createCell(5).setCellValue("Modified By");

					for (int i = 0; i < headerRow.getLastCellNum(); i++) {
						if (headerRow.getCell(i) != null)
							headerRow.getCell(i).setCellStyle(blueStyle);
					}

					int rowNum = 1;
					for (EventCodeListEntity entity : entities) {
						XSSFRow row = spreadsheet.createRow(rowNum++);
						row.createCell(0).setCellValue(entity.getId());
						row.createCell(1).setCellValue(entity.getCode());
						row.createCell(2).setCellValue(entity.getName());
						row.createCell(3).setCellValue(
								entity.getIsActive() ? CommonConstants.ENABLED : CommonConstants.DISABLED);
						row.createCell(4).setCellValue(
								entity.getModifiedDate() != null ? entity.getModifiedDate().toString() : null);
					}
				}
				break;

			}

			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbook.write(bos);
			workbook.close();

			byte[] bytes = bos.toByteArray();
			String base64String = Base64.getEncoder().encodeToString(bytes);
			commonResponseDto.setResponseData(base64String);
			commonResponseDto.setStatus(CommonConstants.SUCCESS);

		} catch (Exception e) {
			logger.error("Enter into AdminServiceImpl-downloadProductDocDetials Exception", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto
					.setMessage(commonErrorMsg.fetchErrorMsg(ErrorCodeConstants.EXCEPTION, CommonConstants.TRUE));
			e.printStackTrace();
			CommonRequestUtil.errorInfo(request, "", "AdminServiceImpl", "downloadProductDocDetials", "",
					e.getMessage(), CommonUtils.getStackTrace(e), "", "", "", "");
		}
		logger.info("Enter into AdminServiceImpl-downloadProductDocDetials End...");
		return commonResponseDto;
	}

	@Override
	public DataTableDto<List<EventCodeListDto>> searchEventCodeDetails(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request) {
		logger.info("AdminServiceImpl-searchEventCodeDetails-start");
		DataTableDto<List<EventCodeListDto>> dataTableDto = new DataTableDto<>();
		List<EventCodeListDto> searchEventCodeListDto = new ArrayList<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {

			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<EventCodeListEntity> query = builder.createQuery(EventCodeListEntity.class);
			Root<EventCodeListEntity> root = query.from(EventCodeListEntity.class);
			List<EventCodeListEntity> list = new ArrayList<>();
			List<Predicate> conditions = new ArrayList<>(1);
			Predicate regDate = builder.between(root.get("createdDate"),
					DateUtils.convertStringToDateTime(commonRequestDto.getFromDate() + " 00:00:00"),
					DateUtils.convertStringToDateTime(commonRequestDto.getToDate() + " 23:59:59"));
//			conditions.add(regDate);
			Predicate isActive = builder.isTrue(root.get("isActive"));
			Predicate predicate = builder.and(regDate, isActive);
			conditions.add(predicate);
			query.orderBy(builder.desc(root.get("modifiedDate")));

			query.select(root).where(conditions.toArray(new Predicate[] {}));
			Integer pageCount = NumericUtils.convertStringToInteger(page);
			Integer limit = NumericUtils.convertStringToInteger(per_page);
			Integer offset = CommonUtils.calculateOffset(pageCount, limit);

			list = entityManager.createQuery(query).setFirstResult(offset).setMaxResults(limit).getResultList();
			List<EventCodeListEntity> resultList = entityManager.createQuery(query).getResultList();
			List<EventCodeListDto> evenCodeListDto = new ArrayList<>();

			for (EventCodeListEntity eventCodeListEntity : list) {
				if (eventCodeListEntity != null) {
					EventCodeListDto dto = new EventCodeListDto();
					BeanUtils.copyProperties(eventCodeListEntity, dto);
					dto.setCreatedDate(DateUtils.convertDateTimeToString(eventCodeListEntity.getCreatedDate()));
					dto.setStartDate(DateUtils.convertDateTimeToString(eventCodeListEntity.getStartDate()));
					dto.setEndDate(DateUtils.convertDateTimeToString(eventCodeListEntity.getEndDate()));
					dto.setModifiedDate(DateUtils.convertDateTimeToString(eventCodeListEntity.getModifiedDate()));
					dto.setModifiedBy(eventCodeListEntity.getModifiedBy());
					dto.setStatus(
							CommonConstants.TRUE.equals(eventCodeListEntity.getIsActive()) ? CommonConstants.ENABLED
									: CommonConstants.DISABLED);
					searchEventCodeListDto.add(dto);
					evenCodeListDto.add(dto);
				}
			}
			dataTableDto.setLast_page("0");
			dataTableDto.setTotal("0");
			if (resultList != null && !resultList.isEmpty()) {
				Integer lastReminder = (resultList.size() % limit);
				Integer last = (resultList.size() / limit);
				if (lastReminder == 0) {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
				} else {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
				}
				dataTableDto.setTotal(NumericUtils.convertIntegerToString(resultList.size()));
			}

			dataTableDto.setCurrent_page(page);
			dataTableDto.setPer_page(per_page);
			dataTableDto.setData(evenCodeListDto);
			Integer nextPage = pageCount + 1;
			Integer prevPage = pageCount - 1;
			Integer from = (pageCount * limit) - limit + 1;
			Integer to = pageCount * limit;
			dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
			dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
			String rootUrl = CommonUtils.fetchApi("CONFIGURATIONROOTURL", getProperty());
			dataTableDto.setNext_page_url(rootUrl + "/cccp/config/admin/api/searchEventCodeDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
			dataTableDto.setPrev_page_url(rootUrl + "/cccp/config/admin/api/searchEventCodeDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
			dataTableDto.setStatus(CommonConstants.SUCCESS);

		} catch (Exception e) {
			logger.error("Enter into AdminServiceImpl-searchEventCodeDetails Exception", e);
			dataTableDto.setStatus(CommonConstants.ERROR);
			dataTableDto.setMessage(CommonUtils.getStackTrace(e));
		}

		return dataTableDto;
	}

	@Override
	public DataTableDto<List<DeficiencyReasonDetailsDto>> searchDeficiencyDetails(String payload, String main_filter,
			String sort, String page, String per_page, HttpServletRequest request) {
		DataTableDto<List<DeficiencyReasonDetailsDto>> dataTableDto = new DataTableDto<>();
		List<DeficiencyReasonDetailsDto> deficiencyReasonDetailsDtos = new ArrayList<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();

		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<DeficiencyReasonDetailsEntity> query = builder
					.createQuery(DeficiencyReasonDetailsEntity.class);
			Root<DeficiencyReasonDetailsEntity> root = query.from(DeficiencyReasonDetailsEntity.class);
			List<DeficiencyReasonDetailsEntity> list = new ArrayList<>();
			List<Predicate> conditions = new ArrayList<>(1);
			Predicate code = builder.equal(root.get("code"), commonRequestDto.getCode());
			Predicate name = builder.equal(root.get("name"), commonRequestDto.getName());
			Predicate isActive = builder.isTrue(root.get("isActive"));
			Predicate predicate = builder.and(code, name, isActive);
			conditions.add(predicate);
			query.orderBy(builder.asc(root.get("id")));

			query.select(root).where(conditions.toArray(new Predicate[] {}));
			Integer pageCount = NumericUtils.convertStringToInteger(page);
			Integer limit = NumericUtils.convertStringToInteger(per_page);
			Integer offset = CommonUtils.calculateOffset(pageCount, limit);
			List<DeficiencyReasonDetailsEntity> resultList = entityManager.createQuery(query).getResultList();
			list = entityManager.createQuery(query).setFirstResult(offset).setMaxResults(limit).getResultList();
			List<DeficiencyReasonDetailsDto> deficiencyReasonDtos = new ArrayList<>();
			for (DeficiencyReasonDetailsEntity deficiencyReasonDetails : list) {
				DeficiencyReasonDetailsDto dto = new DeficiencyReasonDetailsDto();
				BeanUtils.copyProperties(deficiencyReasonDetails, dto);
				dto.setCode(deficiencyReasonDetails.getCode());
				dto.setName(deficiencyReasonDetails.getName());
				dto.setModifiedBy(deficiencyReasonDetails.getModifiedBy());
				dto.setModifiedDate(DateUtils
						.convertDateTimeDDMMMYyyyToStringWithPeriod(deficiencyReasonDetails.getModifiedDate()));
				deficiencyReasonDetailsDtos.add(dto);
				dto.setStatus(deficiencyReasonDetails.getStatus());
				dto.setRemarks(deficiencyReasonDetails.getRemarks());
				deficiencyReasonDtos.add(dto);
			}

			dataTableDto.setLast_page("0");
			dataTableDto.setTotal("0");
			if (resultList != null && !resultList.isEmpty()) {
				Integer lastReminder = (resultList.size() % limit);
				Integer last = (resultList.size() / limit);
				if (lastReminder == 0) {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
				} else {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
				}
				dataTableDto.setTotal(NumericUtils.convertIntegerToString(resultList.size()));
			}

			dataTableDto.setCurrent_page(page);
			dataTableDto.setPer_page(per_page);
			dataTableDto.setData(deficiencyReasonDtos);
			Integer nextPage = pageCount + 1;
			Integer prevPage = pageCount - 1;
			Integer from = (pageCount * limit) - limit + 1;
			Integer to = pageCount * limit;
			dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
			dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
			String rootUrl = CommonUtils.fetchApi("CONFIGURATIONROOTURL", getProperty());
			dataTableDto.setNext_page_url(rootUrl + "/cccp/config/admin/api/searchDeficiencyDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
			dataTableDto.setPrev_page_url(rootUrl + "/cccp/config/admin/api/searchDeficiencyDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
			dataTableDto.setStatus(CommonConstants.SUCCESS);

		} catch (Exception e) {
			logger.error("Enter into AdminServiceImpl-searchDeficiencyDetails Exception", e);
			dataTableDto.setStatus(CommonConstants.ERROR);
			dataTableDto.setMessage(CommonUtils.getStackTrace(e));

		}
		return dataTableDto;
	}

	@Override
	public DataTableDto<List<DeficiencyReasonDetailsDto>> searchPrdWfConfig(String payload, String main_filter,
			String sort, String page, String per_page, HttpServletRequest request) {
		DataTableDto<List<DeficiencyReasonDetailsDto>> dataTableDto = new DataTableDto<>();
		List<DeficiencyReasonDetailsDto> deficiencyReasonDtos = new ArrayList<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();

		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<DeficiencyReasonDetailsEntity> query = builder
					.createQuery(DeficiencyReasonDetailsEntity.class);
			Root<DeficiencyReasonDetailsEntity> root = query.from(DeficiencyReasonDetailsEntity.class);
			List<DeficiencyReasonDetailsEntity> list = new ArrayList<>();
			List<Predicate> conditions = new ArrayList<>(1);
			Predicate code = builder.equal(root.get("subStatusCode"), commonRequestDto.getSubStatusCode());
			Predicate isActive = builder.isTrue(root.get("isActive"));
			Predicate predicate = builder.and(code, isActive);
			conditions.add(predicate);
			query.orderBy(builder.asc(root.get("id")));

			query.select(root).where(conditions.toArray(new Predicate[] {}));
			Integer pageCount = NumericUtils.convertStringToInteger(page);
			Integer limit = NumericUtils.convertStringToInteger(per_page);
			Integer offset = CommonUtils.calculateOffset(pageCount, limit);

			list = entityManager.createQuery(query).setFirstResult(offset).setMaxResults(limit).getResultList();
			List<DeficiencyReasonDetailsEntity> resultList = entityManager.createQuery(query).getResultList();
			for (DeficiencyReasonDetailsEntity deficiencyReasonDetails : list) {
				DeficiencyReasonDetailsDto dtos = new DeficiencyReasonDetailsDto();
				dtos.setSubStatusCode(deficiencyReasonDetails.getSubStatusCode());
				dtos.setName(deficiencyReasonDetails.getName());
				dtos.setModifiedDate(DateUtils.convertDateTimeToString(deficiencyReasonDetails.getModifiedDate()));
				dtos.setModifiedBy(deficiencyReasonDetails.getModifiedBy());
				dtos.setStatus(deficiencyReasonDetails.getStatus());
				dtos.setCode(deficiencyReasonDetails.getCode());
				deficiencyReasonDtos.add(dtos);
			}

			dataTableDto.setLast_page("0");
			dataTableDto.setTotal("0");
			if (resultList != null && !resultList.isEmpty()) {
				Integer lastReminder = (resultList.size() % limit);
				Integer last = (resultList.size() / limit);
				if (lastReminder == 0) {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
				} else {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
				}
				dataTableDto.setTotal(NumericUtils.convertIntegerToString(resultList.size()));
			}

			dataTableDto.setCurrent_page(page);
			dataTableDto.setPer_page(per_page);
			dataTableDto.setData(deficiencyReasonDtos);
			Integer nextPage = pageCount + 1;
			Integer prevPage = pageCount - 1;
			Integer from = (pageCount * limit) - limit + 1;
			Integer to = pageCount * limit;
			dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
			dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
			String rootUrl = CommonUtils.fetchApi("CONFIGURATIONROOTURL", getProperty());
			dataTableDto.setNext_page_url(rootUrl + "/cccp/config/admin/api/searchPrdWfConfig?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
			dataTableDto.setPrev_page_url(rootUrl + "/cccp/config/admin/api/searchPrdWfConfig?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
			dataTableDto.setStatus(CommonConstants.SUCCESS);

		} catch (Exception e) {
			logger.error("Enter into AdminServiceImpl-searchPrdWfConfig Exception", e);
			dataTableDto.setStatus(CommonConstants.ERROR);
			dataTableDto.setMessage(CommonUtils.getStackTrace(e));
		}
		return dataTableDto;

	}

	@Override
	public DataTableDto<List<SubStatusDto>> searchSubStatusDetails(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request) {
		logger.info("Enter into AdminServiceImpl searchSubStatusDetails start");
		DataTableDto<List<SubStatusDto>> dataTableDto = new DataTableDto<>();
		List<SubStatusDto> dtos = new ArrayList<>();
		try {
			JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<SubStatusMasterEntity> query = builder.createQuery(SubStatusMasterEntity.class);
			Root<SubStatusMasterEntity> root = query.from(SubStatusMasterEntity.class);
			List<SubStatusMasterEntity> list = new ArrayList<>();
			List<Predicate> conditions = new ArrayList<>(1);
			if (commonRequestDto.getCode() != null && StringUtils.isNotBlank(commonRequestDto.getCode())) {
				conditions.add(builder.equal(root.get("code"), commonRequestDto.getCode()));
			}
			if (commonRequestDto.getName() != null && StringUtils.isNotBlank(commonRequestDto.getName())) {
				conditions.add(builder.equal(root.get("name"), commonRequestDto.getName()));
			}

			if (commonRequestDto.getFromDate() != null && commonRequestDto.getToDate() != null
					&& StringUtils.isNotBlank(commonRequestDto.getFromDate())
					&& StringUtils.isNotBlank(commonRequestDto.getToDate())) {
				Predicate regDate = builder.between(root.get("modifiedDate"),
						DateUtils.convertStringToDateTime(commonRequestDto.getFromDate() + " 00:00:00"),
						DateUtils.convertStringToDateTime(commonRequestDto.getToDate() + " 23:59:59"));
				Predicate predicate = builder.and(regDate);
				conditions.add(predicate);
			}
			query.orderBy(builder.asc(root.get("id")));
			query.select(root).where(conditions.toArray(new Predicate[] {}));
			Integer pageCount = NumericUtils.convertStringToInteger(page);
			Integer limit = NumericUtils.convertStringToInteger(per_page);
			Integer offset = CommonUtils.calculateOffset(pageCount, limit);

			list = entityManager.createQuery(query).setFirstResult(offset).setMaxResults(limit).getResultList();
			for (SubStatusMasterEntity subStatusMasterEntity : list) {
				SubStatusDto subStatusDto = new SubStatusDto();
				BeanUtils.copyProperties(subStatusMasterEntity, subStatusDto);
				subStatusDto.setCode(subStatusMasterEntity.getCode());
				subStatusDto.setName(subStatusMasterEntity.getName());
				subStatusDto.setUserId(subStatusMasterEntity.getModifiedBy());
				subStatusDto
						.setModifiedDate(DateUtils.dateToStringDDMMYYYYWith(subStatusMasterEntity.getModifiedDate()));
				dtos.add(subStatusDto);
			}
			dataTableDto.setCurrent_page(page);
			dataTableDto.setPer_page(per_page);
			dataTableDto.setData(dtos);
			Integer nextPage = pageCount + 1;
			Integer prevPage = pageCount - 1;
			Integer from = (pageCount * limit) - limit + 1;
			Integer to = pageCount * limit;
			dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
			dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
			String rootUrl = CommonUtils.fetchApi("CONFIGURATIONROOTURL", getProperty());
			dataTableDto.setNext_page_url(rootUrl + "/cccp/config/admin/api/searchSubStatusDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
			dataTableDto.setPrev_page_url(rootUrl + "/cccp/config/admin/api/searchSubStatusDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
			dataTableDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Enter into AdminServiceImpl-searchSubStatusDetails Exception", e);
			dataTableDto.setStatus(CommonConstants.ERROR);
			dataTableDto.setMessage(CommonUtils.getStackTrace(e));
		}
		logger.info("Eneter into AdminServiceImpl searchSubStatusDetails end");
		return dataTableDto;
	}

	@Override
	public DataTableDto<List<SubStatusDto>> searchUserProfileDetails(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request) {
		logger.info("Enter into AdminServiceImpl searchUserProfileDetails start");
		DataTableDto<List<SubStatusDto>> dataTableDto = new DataTableDto<>();
		List<SubStatusDto> dtos = new ArrayList<>();
		try {
			JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<MenuPageEntity> query = builder.createQuery(MenuPageEntity.class);
			Root<MenuPageEntity> root = query.from(MenuPageEntity.class);
			List<MenuPageEntity> list = new ArrayList<>();
			List<Predicate> conditions = new ArrayList<>(1);
			conditions.add(builder.equal(root.get("source"), CommonConstants.RCS));
			if (commonRequestDto.getUserCode() != null && StringUtils.isNotBlank(commonRequestDto.getUserCode())) {
				RoleEntity roleEntity = roleRepository.findByNameAndIsActive(commonRequestDto.getUserCode(),
						CommonConstants.TRUE);
				if (roleEntity != null) {
					conditions.add(builder.like(root.get("visibleRoles"), "%" + roleEntity.getCode() + "%"));
				}
			} else if (commonRequestDto.getClaimHandler() != null
					&& StringUtils.isNotBlank(commonRequestDto.getClaimHandler())) {
				UserEntity userEntity = userRepository.findByUserIdAndIsActiveTrue(commonRequestDto.getClaimHandler());
				if (userEntity != null) {
					if (userEntity.getRoles() != null && !userEntity.getRoles().isEmpty()) {
						List<RoleEntity> roleList = new ArrayList<>(userEntity.getRoles());
						roleList.sort(Comparator.comparing(RoleEntity::getPriority));
						Optional<RoleEntity> findFirst = roleList.stream().findFirst();
						if (findFirst.isPresent()) {
							RoleEntity rolesEntity = findFirst.get();
							conditions.add(builder.like(root.get("visibleRoles"), "%" + rolesEntity.getCode() + "%"));
						}
					}
				}
			}
			query.orderBy(builder.asc(root.get("id")));
			query.select(root).where(conditions.toArray(new Predicate[] {}));
			Integer pageCount = NumericUtils.convertStringToInteger(page);
			Integer limit = NumericUtils.convertStringToInteger(per_page);
			Integer offset = CommonUtils.calculateOffset(pageCount, limit);

			list = entityManager.createQuery(query).setFirstResult(offset).setMaxResults(limit).getResultList();
			for (MenuPageEntity menuPageEntity : list) {
				SubStatusDto subStatusDto = new SubStatusDto();
				BeanUtils.copyProperties(menuPageEntity, subStatusDto);
				subStatusDto.setCode(menuPageEntity.getCode());
				subStatusDto.setName(menuPageEntity.getName());
				subStatusDto.setUserId(menuPageEntity.getModifiedBy());
				subStatusDto.setModifiedDate(DateUtils.dateToStringDDMMYYYYWith(menuPageEntity.getModifiedDate()));
				dtos.add(subStatusDto);
			}
			dataTableDto.setCurrent_page(page);
			dataTableDto.setPer_page(per_page);
			dataTableDto.setData(dtos);
			Integer nextPage = pageCount + 1;
			Integer prevPage = pageCount - 1;
			Integer from = (pageCount * limit) - limit + 1;
			Integer to = pageCount * limit;
			dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
			dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
			String rootUrl = CommonUtils.fetchApi("CONFIGURATIONROOTURL", getProperty());
			dataTableDto.setNext_page_url(rootUrl + "/cccp/config/admin/api/searchUserProfileDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
			dataTableDto.setPrev_page_url(rootUrl + "/cccp/config/admin/api/searchUserProfileDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
			dataTableDto.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Enter into AdminServiceImpl-searchUserProfileDetails Exception", e);
			dataTableDto.setStatus(CommonConstants.ERROR);
			dataTableDto.setMessage(CommonUtils.getStackTrace(e));
		}
		logger.info("Eneter into AdminServiceImpl searchUserProfileDetails end");
		return dataTableDto;
	}

//	@Override
//	public DataTableDto<List<ErrorLogDto>> searchLogDetails(String payload, String main_filter, String sort,
//			String page, String per_page, HttpServletRequest request) {
//		
//		   DataTableDto<List<ErrorLogDto>> dataTableDto = new DataTableDto<>();
//		    List<ErrorLogDto> dtos = new ArrayList<>();
//		    try {
//		    	JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
//		        CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
//		        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
//		        CriteriaQuery<ProductDocStagingDetailsEntity> query = builder.createQuery(ProductDocStagingDetailsEntity.class);
//		        Root<ProductDocStagingDetailsEntity> root = query.from(ProductDocStagingDetailsEntity.class);
//		        List<ProductDocStagingDetailsEntity> list = new ArrayList<>();
//		        List<Predicate> conditions = new ArrayList<>();
//
//		        if (commonRequestDto.getStatus() != null && StringUtils.isNotBlank(commonRequestDto.getStatus())) {
//		            conditions.add(builder.equal(root.get("status"),CommonConstants.FAILURE));
//		        }
//
//		        query.orderBy(builder.asc(root.get("id")));
//		        query.select(root).where(conditions.toArray(new Predicate[0]));
//		        Integer pageCount = NumericUtils.convertStringToInteger(page);
//		        Integer limit = NumericUtils.convertStringToInteger(per_page);
//		        Integer offset = CommonUtils.calculateOffset(pageCount, limit);
//
//		        list = entityManager.createQuery(query).setFirstResult(offset).setMaxResults(limit).getResultList();
//		        for (ProductDocStagingDetailsEntity entity : list) {
//		        	ErrorLogDto errorLogDto = new ErrorLogDto();
//		            BeanUtils.copyProperties(entity, errorLogDto);
//		            errorLogDto.setLabel(entity.getLabel());
//		            errorLogDto.setStatus(entity.getStatus());
//		            dtos.add(errorLogDto);
//		        }
//
//		        dataTableDto.setCurrent_page(page);
//		        dataTableDto.setPer_page(per_page);
//		        dataTableDto.setData(dtos);
//		        Integer nextPage = pageCount + 1;
//		        Integer prevPage = pageCount - 1;
//		        Integer from = (pageCount * limit) - limit + 1;
//		        Integer to = pageCount * limit;
//		        dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
//		        dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
//		        String rootUrl = CommonUtils.fetchApi("CONFIGURATIONROOTURL", getProperty());
//		        dataTableDto.setNext_page_url(rootUrl + "/cccp/config/admin/api/searchLogDetails?payload=" + payload
//		                + "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
//		        dataTableDto.setPrev_page_url(rootUrl + "/cccp/config/admin/api/searchLogDetails?payload=" + payload
//		                + "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
//		        dataTableDto.setStatus(CommonConstants.SUCCESS);
//		    
//			} catch (Exception e) {
//				logger.error("Enter into AdminServiceImpl-searchLogDetails Exception", e);
//				dataTableDto.setStatus(CommonConstants.ERROR);
//				dataTableDto.setMessage(CommonUtils.getStackTrace(e));
//			}
//		    logger.info("Eneter into AdminServiceImpl searchLogDetails end");
//			return dataTableDto;
//	}

	@Override
	public DataTableDto<List<ErrorLogDto>> searchLogDetails(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request) {

		DataTableDto<List<ErrorLogDto>> dataTableDto = new DataTableDto<>();
		List<ErrorLogDto> dtos = new ArrayList<>();
		try {
			JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			CriteriaBuilder builder = entityManager.getCriteriaBuilder();
			CriteriaQuery<Object> query = builder.createQuery(Object.class);
			Root<?> root = null;

			switch (commonRequestDto.getMenuName()) {
			case "M16 Product Document":
				root = query.from(ProductDocStagingDetailsEntity.class);
				break;

			case "M17 COL Configuration":
				root = query.from(ColStagingDataDetailsEntity.class);
				break;

			case "M19 Assessment Component Label":
				root = query.from(AssessmentStagingDataDetailsEntity.class);
				break;

			case "M42 Event Code Creation":
				root = query.from(EventCodeStagingDataDetailsEntity.class);
				break;

			case "M18 User Location Mapping":
				root = query.from(UserLocStagingDataDetailsEntity.class);
				break;

			case "Product Workflow Configuration":
				root = query.from(WfStagingDataDetailsEntity.class);
				break;

			default:
				throw new IllegalArgumentException("Invalid main_filter: " + main_filter);
			}

			List<Predicate> conditions = new ArrayList<>();
			if (commonRequestDto.getStatus() != null) {
				conditions.add(builder.equal(root.get("status"), commonRequestDto.getStatus()));
			}

			query.orderBy(builder.desc(root.get("id")));
			query.select(root).where(conditions.toArray(new Predicate[0]));
			Integer pageCount = NumericUtils.convertStringToInteger(page);
			Integer limit = NumericUtils.convertStringToInteger(per_page);
			Integer offset = CommonUtils.calculateOffset(pageCount, limit);

			List<?> list = entityManager.createQuery(query).setFirstResult(offset).setMaxResults(limit).getResultList();
			List<Object> resultList = entityManager.createQuery(query).getResultList();
			for (Object entity : list) {
				ErrorLogDto errorLogDto = new ErrorLogDto();
				BeanUtils.copyProperties(entity, errorLogDto);

				if (entity instanceof ProductDocStagingDetailsEntity) {
					ProductDocStagingDetailsEntity productDocEntity = (ProductDocStagingDetailsEntity) entity;
					errorLogDto.setModifiedBy(productDocEntity.getModifiedBy());
					errorLogDto.setModifiedDate(
							DateUtils.convertDateTimeDDMMMYyyyToStringWithPeriod(productDocEntity.getModifiedDate()));
					errorLogDto.setReason(productDocEntity.getReason());
					errorLogDto.setRowNum(productDocEntity.getRowNum());

				} else if (entity instanceof ColStagingDataDetailsEntity) {
					ColStagingDataDetailsEntity colEntity = (ColStagingDataDetailsEntity) entity;
					errorLogDto.setModifiedBy(colEntity.getModifiedBy());
					errorLogDto.setModifiedDate(
							DateUtils.convertDateTimeDDMMMYyyyToStringWithPeriod(colEntity.getModifiedDate()));
					errorLogDto.setReason(colEntity.getReason());
					errorLogDto.setRowNum(colEntity.getRowNum());
				}

				else if (entity instanceof AssessmentStagingDataDetailsEntity) {
					AssessmentStagingDataDetailsEntity assessmentEntity = (AssessmentStagingDataDetailsEntity) entity;
					errorLogDto.setModifiedBy(assessmentEntity.getModifiedBy());
					errorLogDto.setModifiedDate(
							DateUtils.convertDateTimeDDMMMYyyyToStringWithPeriod(assessmentEntity.getModifiedDate()));

				} else if (entity instanceof EventCodeStagingDataDetailsEntity) {
					EventCodeStagingDataDetailsEntity eventCodeEntity = (EventCodeStagingDataDetailsEntity) entity;
					errorLogDto.setModifiedBy(eventCodeEntity.getModifiedBy());
					errorLogDto.setModifiedDate(
							DateUtils.convertDateTimeDDMMMYyyyToStringWithPeriod(eventCodeEntity.getModifiedDate()));
					errorLogDto.setReason(eventCodeEntity.getReason());
					errorLogDto.setRowNum(eventCodeEntity.getRowNum());

				} else if (entity instanceof UserLocStagingDataDetailsEntity) {
					UserLocStagingDataDetailsEntity userLocEntity = (UserLocStagingDataDetailsEntity) entity;
					errorLogDto.setModifiedBy(userLocEntity.getModifiedBy());
					errorLogDto.setModifiedDate(
							DateUtils.convertDateTimeDDMMMYyyyToStringWithPeriod(userLocEntity.getModifiedDate()));
					errorLogDto.setReason(userLocEntity.getReason());
					errorLogDto.setRowNum(userLocEntity.getRowNum());

				} else if (entity instanceof WfStagingDataDetailsEntity) {
					WfStagingDataDetailsEntity wfEntity = (WfStagingDataDetailsEntity) entity;
					errorLogDto.setModifiedBy(wfEntity.getModifiedBy());
					errorLogDto.setModifiedDate(
							DateUtils.convertDateTimeDDMMMYyyyToStringWithPeriod(wfEntity.getModifiedDate()));
					errorLogDto.setReason(wfEntity.getReason());
					errorLogDto.setRowNum(wfEntity.getRowNum());
				}

				dtos.add(errorLogDto);
			}

			dataTableDto.setLast_page("0");
			dataTableDto.setTotal("0");
			if (resultList != null && !resultList.isEmpty()) {
				Integer lastReminder = (resultList.size() % limit);
				Integer last = (resultList.size() / limit);
				if (lastReminder == 0) {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last));
				} else {
					dataTableDto.setLast_page(NumericUtils.convertIntegerToString(last + 1));
				}
				dataTableDto.setTotal(NumericUtils.convertIntegerToString(resultList.size()));
			}

			dataTableDto.setCurrent_page(page);
			dataTableDto.setPer_page(per_page);
			dataTableDto.setData(dtos);
			Integer nextPage = pageCount + 1;
			Integer prevPage = pageCount - 1;
			Integer from = (pageCount * limit) - limit + 1;
			Integer to = pageCount * limit;
			dataTableDto.setFrom(NumericUtils.convertIntegerToString(from));
			dataTableDto.setTo(NumericUtils.convertIntegerToString(to));
			String rootUrl = CommonUtils.fetchApi("CONFIGURATIONROOTURL", getProperty());
			dataTableDto.setNext_page_url(rootUrl + "/cccp/config/admin/api/searchLogDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + nextPage + "&per_page=" + per_page);
			dataTableDto.setPrev_page_url(rootUrl + "/cccp/config/admin/api/searchLogDetails?payload=" + payload
					+ "&main_filter=" + main_filter + "&sort=" + sort + "&page=" + prevPage + "&per_page=" + per_page);
			dataTableDto.setStatus(CommonConstants.SUCCESS);

		} catch (Exception e) {
			logger.error("Enter into AdminServiceImpl-searchLogDetails Exception", e);
			dataTableDto.setStatus(CommonConstants.ERROR);
			dataTableDto.setMessage(CommonUtils.getStackTrace(e));
		}
		logger.info("Enter into AdminServiceImpl searchLogDetails end");
		return dataTableDto;
	}

	@Override
	public CommonResponseDto<?> saveStakeDetails(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		CommonResponseDto<PartiesDto> responseDto = new CommonResponseDto<PartiesDto>();
		logger.info("AdminServiceImpl--saveStakeDetails--Start");
		PartiesDto dto = new PartiesDto();
		PartiesEntity partiesEntity = partiesRepository.findFirstBySupplierCodeAndIsActive(
				commonRequestDto.getPartyDetail().getSupplierCode(), CommonConstants.TRUE);

		try {
			if (partiesEntity == null) {
				if (commonRequestDto != null) {
					PartiesDto partiesDto = commonRequestDto.getPartyDetail();
					PartiesEntity entity = new PartiesEntity();
					entity.setOrgType(partiesDto.getOrgType());
					entity.setSupplierCode(partiesDto.getSupplierCode());
					entity.setStakeCode(partiesDto.getStakeCode());
					entity.setStakeName(partiesDto.getStakeName());
					entity.setPartyCode(partiesDto.getPartyCode());
					entity.setBusinessName(partiesDto.getBusinessName());
					entity.setCreatedDate(DateUtils.sysDate());
					entity.setIsActive(CommonConstants.TRUE);
					partiesRepository.save(entity);
					BeanUtils.copyProperties(partiesDto, dto);
				}
				responseDto.setResponseData(dto);
				responseDto.setStatus(CommonConstants.SUCCESS);
				responseDto.setMessage("Stake Code saved Successfully");
			} else {
				responseDto.setStatus(CommonConstants.ERROR);
				responseDto.setMessage(" Party already available against given 'Supplier Code'");
			}
		} catch (Exception e) {
			logger.error("AdminServiceImpl--saveStakeDetails--Error...", e);
			responseDto.setStatus(CommonConstants.ERROR);
//			responseDto.setMessage("Claim Status not Fetched");
			responseDto.setError(CommonUtils.getStackTrace(e));
		}
		return responseDto;
	}

}