package com.fa.bajajallianz.cccp.config.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.config.entity.DeficiencyReasonDetailsEntity;
@Repository
public interface DeficiencyReasonDetailsRepository extends JpaRepository<DeficiencyReasonDetailsEntity, Long> {

	List<DeficiencyReasonDetailsEntity> findByIsActive(Boolean true1);	

	List<DeficiencyReasonDetailsEntity> findBySubStatusCodeAndIsActive(String subStatusCode,
			Boolean true1);

	@Query("select dr from DeficiencyReasonDetailsEntity dr WHERE dr.isActive = ?1 and dr.csStepId = ?2 and (dr.processId is null or dr.processId  = ?3 )")
	List<DeficiencyReasonDetailsEntity> getDeficiencyByCsIdAndProcessType(Boolean true1, Long csStepId, String processType);
	
	@Query("select dr from DeficiencyReasonDetailsEntity dr WHERE dr.isActive = ?1 and dr.csStepId = ?2 and (dr.processId is null or dr.processId is not null )")
	List<DeficiencyReasonDetailsEntity> getDeficiencyByCsId(Boolean true1, Long csStepId);

}
