/**
 * 
 */
package com.fa.bajajallianz.cccp.config.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.fa.bajajallianz.cccp.common.dto.AuthorityDto;
import com.fa.bajajallianz.cccp.common.dto.ClientsFieldsConfigDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.RuntimeFields;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.DateUtils;
import com.fa.bajajallianz.cccp.common.utils.NumericUtils;
import com.fa.bajajallianz.cccp.config.dto.DeficiencyReasonDetailsDto;
import com.fa.bajajallianz.cccp.config.dto.FormPageDto;
import com.fa.bajajallianz.cccp.config.dto.FormPageFieldgroupDto;
import com.fa.bajajallianz.cccp.config.dto.FormPageFieldsDto;
import com.fa.bajajallianz.cccp.config.dto.FormPageSectionsDto;
import com.fa.bajajallianz.cccp.config.dto.FormPageSubsectionsDto;
import com.fa.bajajallianz.cccp.config.entity.DeficiencyReasonDetailsEntity;
import com.fa.bajajallianz.cccp.config.entity.FormPageEntity;
import com.fa.bajajallianz.cccp.config.entity.FormPageFieldgroupEntity;
import com.fa.bajajallianz.cccp.config.entity.FormPageFieldEntity;
import com.fa.bajajallianz.cccp.config.entity.FormPageSectionEntity;
import com.fa.bajajallianz.cccp.config.entity.FormPageSubsectionEntity;
import com.fa.bajajallianz.cccp.config.entity.ResponseMessageEntity;
import com.fa.bajajallianz.cccp.config.repository.DeficiencyReasonDetailsRepository;
import com.fa.bajajallianz.cccp.config.repository.EventCodeListRepository;
import com.fa.bajajallianz.cccp.config.repository.FormPageRepository;
import com.fa.bajajallianz.cccp.config.repository.FormPageSectionRepository;
import com.fa.bajajallianz.cccp.config.repository.ResponseMessageRepository;
import com.fa.bajajallianz.cccp.config.restservice.ConfigRestService;
import com.fa.bajajallianz.cccp.config.service.ConfigurationService;
import com.fa.bajajallianz.cccp.master.dto.EventCodeListDto;
import com.fa.bajajallianz.cccp.master.entity.AuthoritiesEntity;
import com.fa.bajajallianz.cccp.master.entity.EventCodeListEntity;
import com.fa.bajajallianz.cccp.master.entity.PageFieldRoleAuthoritiesEntity;
import com.fa.bajajallianz.cccp.master.entity.ProductMasterEntity;
import com.fa.bajajallianz.cccp.master.repository.AuthoritiesEntityRepository;
import com.fa.bajajallianz.cccp.master.repository.LookupTypeValueRepository;
import com.fa.bajajallianz.cccp.master.repository.PageFieldRoleAuthoritiesRepository;
import com.fa.bajajallianz.cccp.master.repository.ProductMasterRepository;

/**
 * @author praveen
 *
 */
@Service
public class ConfigurationServiceImpl implements ConfigurationService {

	@Autowired
	private FormPageRepository formPageRepository;

	@Autowired
	private FormPageSectionRepository formPageSectionsRepository;

	@Autowired
	private ProductMasterRepository productMasterRepo;

	@Autowired
	private ResponseMessageRepository responseMsgRepo;

	@Autowired
	private ConfigRestService configRestService;

	@Autowired
	DeficiencyReasonDetailsRepository deficiencyReasonDetailsRepository;

	@Autowired
	LookupTypeValueRepository lookupTypeValueRepository;

	@Autowired
	private EventCodeListRepository eventCodeListRepository;
	
	@Autowired
	private PageFieldRoleAuthoritiesRepository pageFieldRoleAuthoritiesRepo;
	
	@Autowired
	private AuthoritiesEntityRepository authoritiesEntityRepo;

	private static final Logger logger = LoggerFactory.getLogger(ConfigurationServiceImpl.class);

	@Override
	@Cacheable(value = "fetchFormPage", key = "{#commonRequestDto.productCode,#commonRequestDto.pageCode}", cacheManager = "twoMinsCacheManager")
	public CommonResponseDto<List<FormPageDto>> fetchFormPage(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonResponseDto<List<FormPageDto>> commonResponseDto = new CommonResponseDto<>();
		logger.info("ConfigServiceImpl--fetchFormPage--Start");
		try {
			String productCatgory = null;
			if (commonRequestDto.getProductCode() != null && !commonRequestDto.getPageCode().isEmpty()) {
				ProductMasterEntity productDetails = productMasterRepo.findByCode(commonRequestDto.getProductCode());
				productCatgory = (productDetails != null ? productDetails.getProductCategory() : null);
			}
			List<FormPageDto> dtos = new ArrayList<>();
			List<FormPageEntity> formPageEntity = formPageRepository
					.findByPageCodeAndIsActive(commonRequestDto.getPageCode(), CommonConstants.TRUE);
			if (Objects.nonNull(formPageEntity) && !formPageEntity.isEmpty()) {
				for (FormPageEntity entity : formPageEntity) {
					FormPageDto formPageDto = new FormPageDto();
					BeanUtils.copyProperties(entity, formPageDto);
					List<FormPageSectionsDto> pageSectionList = new ArrayList<>();
					if (entity.getFormPageSection() != null) {
						for (FormPageSectionEntity formPageSectionEntity : entity.getFormPageSection()) {
							if (formPageSectionEntity.getProductCategory() == null
									|| formPageSectionEntity.getProductCategory().equalsIgnoreCase(productCatgory)) {
								if (CommonConstants.TRUE.equals(formPageSectionEntity.getIsActive())) {
									FormPageSectionsDto sectionDto = new FormPageSectionsDto();
									BeanUtils.copyProperties(formPageSectionEntity, sectionDto);
									pageSectionList.add(sectionDto);
								}
							}
						}
					}
					formPageDto.setFormPageSection(pageSectionList);
					dtos.add(formPageDto);
				}
				commonResponseDto.setResponseData(dtos);
				commonResponseDto.setStatus(CommonConstants.SUCCESS);
			}
		} catch (Exception e) {
			logger.error("Exception-ConfigServiceImpl-fetchFormPage", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setError(e.getMessage());
		}
		logger.info("ConfigServiceImpl--fetchFormPage--End");
		return commonResponseDto;
	}

	@Override
	@Cacheable(value = "fetchFormPageField", key = "{#commonRequestDto.pageCode,#commonRequestDto.sectionCode,#commonRequestDto.productCode}", cacheManager = "twoMinsCacheManager")
	public CommonResponseDto<List<FormPageSubsectionsDto>> fetchFormPageFields(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonResponseDto<List<FormPageSubsectionsDto>> commonResponseDto = new CommonResponseDto<>();
		logger.info("ConfigServiceImpl--fetchFormPageFields--Start");
		try {
			String productCatgory = null;
			if (commonRequestDto.getProductCode() != null && !commonRequestDto.getPageCode().isEmpty()) {
				ProductMasterEntity productDetails = productMasterRepo.findByCode(commonRequestDto.getProductCode());
				productCatgory = (productDetails != null ? productDetails.getProductCategory() : null);
			}
			
			ClientsFieldsConfigDto runTimeFields = null;
			List<FormPageFieldsDto> formPageFieldDtoList1 = new ArrayList<>();
			if (commonRequestDto.getPolicyNumber() != null && !commonRequestDto.getPolicyNumber().isEmpty()) {
				runTimeFields = configRestService.fetchRuntimeFieldConfig(commonRequestDto.getPolicyNumber(), request);
				FormPageSectionEntity formPageSectionEntity1 = null;
				formPageSectionEntity1 = formPageSectionsRepository
						.findBySectionCodeAndIsActiveAndFormPagePageCodeAndFormPageIsActive(
								CommonConstants.CLIFIELDUPDATE, CommonConstants.TRUE, CommonConstants.CONFIGURATION,
								CommonConstants.TRUE);
				if (formPageSectionEntity1.getSubSection() != null) {
					for (FormPageSubsectionEntity formPageSubSection : formPageSectionEntity1.getSubSection()) {
						if (formPageSubSection.getFieldGroup() != null) {
							for (FormPageFieldgroupEntity formPageFielGroup : formPageSubSection.getFieldGroup()) {
								if (formPageFielGroup.getPageField() != null) {
									for (FormPageFieldEntity formPageFieldEntity : formPageFielGroup.getPageField()) {
										if (formPageFieldEntity.getProductCategory() == null || formPageFieldEntity
												.getProductCategory().equalsIgnoreCase(productCatgory)) {
											FormPageFieldsDto formPageFieldDto1 = new FormPageFieldsDto();
											BeanUtils.copyProperties(formPageFieldEntity, formPageFieldDto1);
											formPageFieldDtoList1.add(formPageFieldDto1);
										}
									}
								}
							}
						}
					}
				}
			}
			FormPageSectionEntity formPageSectionEntity = formPageSectionsRepository
					.findBySectionCodeAndIsActiveAndFormPagePageCodeAndFormPageIsActive(
							commonRequestDto.getSectionCode(), CommonConstants.TRUE, commonRequestDto.getPageCode(),
							CommonConstants.TRUE);
			if (formPageSectionEntity != null) {
				List<FormPageSubsectionsDto> formPageSubSectionDtoList = new ArrayList<>();
				if (formPageSectionEntity.getSubSection() != null) {
					for (FormPageSubsectionEntity formPageSubSection : formPageSectionEntity.getSubSection()) {
						FormPageSubsectionsDto subSectionDto = new FormPageSubsectionsDto();
						BeanUtils.copyProperties(formPageSubSection, subSectionDto);

						List<FormPageFieldgroupDto> formPageFieldGroupDtoList = new ArrayList<>();
						if (formPageSubSection.getFieldGroup() != null) {
							for (FormPageFieldgroupEntity formPageFielGroup : formPageSubSection.getFieldGroup()) {
								FormPageFieldgroupDto formPageFieldGroupDto = new FormPageFieldgroupDto();
								BeanUtils.copyProperties(formPageFielGroup, formPageFieldGroupDto);
								formPageFieldGroupDtoList.add(formPageFieldGroupDto);

								List<FormPageFieldsDto> formPageFieldDtoList = new ArrayList<>();
								if (formPageFielGroup.getPageField() != null) {
									for (FormPageFieldEntity formPageFieldEntity : formPageFielGroup.getPageField()) {
										if (CommonConstants.TRUE.equals(formPageFieldEntity.getIsActive())) {
											if (formPageFieldEntity.getProductCategory() == null || formPageFieldEntity
													.getProductCategory().equalsIgnoreCase(productCatgory)) {
												FormPageFieldsDto formPageFieldDto = new FormPageFieldsDto();
												BeanUtils.copyProperties(formPageFieldEntity, formPageFieldDto);
//												if (commonRequestDto.getProductCode() != null && !commonRequestDto.getProductCode().isEmpty()) {
//													PageFieldRoleAuthoritiesEntity pageFieldRoleAuthorities = pageFieldRoleAuthoritiesRepo
//															.findByPageIdAndSectionIdAndFieldIdAndProductCode(
//																	formPageSectionEntity.getFormPage() != null
//																			? formPageSectionEntity.getFormPage().getId() : null,
//																	formPageSectionEntity.getId(),
//																	formPageFieldEntity.getId(),commonRequestDto.getProductCode());
//													if(pageFieldRoleAuthorities != null) {
//														AuthoritiesEntity authorities = authoritiesEntityRepo.findByIdAndIsActive(
//																pageFieldRoleAuthorities.getAuthoritiesId(),
//																CommonConstants.TRUE);
//														AuthorityDto authoritieDtos = new AuthorityDto();
//														if (authorities != null) {
//															mapFormPagefieldauthorities(authorities, authoritieDtos,
//																	pageFieldRoleAuthorities.getIsActive());
//															formPageFieldDto.setAuthorities(authoritieDtos);
//														}
//													}
//												}
												formPageFieldDtoList.add(formPageFieldDto);
											}
										}
									}
									if (runTimeFields != null) {
										if (runTimeFields.getFieldDetails() != null) {
											for (RuntimeFields dto : runTimeFields.getFieldDetails()) {
												for (FormPageFieldsDto dto1 : formPageFieldDtoList1) {
													if (dto1.getFieldCode().equalsIgnoreCase(dto.getFieldCode())) {
														FormPageFieldsDto formPageFieldDto = new FormPageFieldsDto();
														formPageFieldDto.setId(dto1.getId());
														formPageFieldDto.setOrderNo(dto1.getOrderNo());
														formPageFieldDto.setAuthorityCode(dto1.getAuthorityCode());
														formPageFieldDto.setFields("runtime." + dto1.getFields());
														formPageFieldDto.setDisplayName(dto.getFieldName());
														formPageFieldDto.setFieldCode(dto1.getFieldCode());
														formPageFieldDto.setIsActive(dto.getIsActive());
														formPageFieldDto.setAttributes(dto1.getAttributes());
														formPageFieldDto.setDescription(dto.getFieldName());
														formPageFieldDto.setIsMandatory(CommonConstants.FALSE);
														formPageFieldDtoList.add(formPageFieldDto);
													}
												}

											}
										}
									}
								}
								formPageFieldGroupDto.setFormPageFields(formPageFieldDtoList);
							}
						}
						subSectionDto.setFormPageFieldGroups(formPageFieldGroupDtoList);
						formPageSubSectionDtoList.add(subSectionDto);
					}

				}
				commonResponseDto.setResponseData(formPageSubSectionDtoList);
				commonResponseDto.setStatus(CommonConstants.SUCCESS);

			} else {
				commonResponseDto.setStatus(CommonConstants.SUCCESS);
				commonResponseDto.setMessage(CommonConstants.NORECORDFOUND);
			}

		} catch (Exception e) {
			logger.error("Exception-ConfigServiceImpl-fetchFormPage", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setError(e.getMessage());
		}
		logger.info("ConfigServiceImpl--fetchFormPage--End");
		return commonResponseDto;

	}
	
//	private void mapFormPagefieldauthorities(AuthoritiesEntity authority, AuthorityDto authoritieDtos, Boolean isRequired) {
//		logger.info("ConfigurationServiceImpl-mapFormPages-end");
//		try {
//			if (CommonConstants.TRUE.equals(authority.getIsActive())) {
//				authoritieDtos.setId(authority.getId());
//				authoritieDtos.setAuthorityCode(authority.getCode());
//				authoritieDtos.setDescription(authority.getDescription());
//				authoritieDtos.setIsActive(NumericUtils.convertBooleanToString(authority.getIsActive()));
//				authoritieDtos
//						.setCreatedDate(DateUtils.dateToStringFormatYyyyMmDdHhMmSsSlash(authority.getCreatedDate()));
//				authoritieDtos
//						.setModifiedDate(DateUtils.dateToStringFormatYyyyMmDdHhMmSsSlash(authority.getModifiedDate()));
//				authoritieDtos.setCreatedBy(NumericUtils.convertLongToString(authority.getCreatedBy()));
//				authoritieDtos.setModifiedBy(NumericUtils.convertLongToString(authority.getModifiedBy()));
//				if (isRequired != null) {
//					authoritieDtos.setIsRequired(NumericUtils.convertBooleanToString(isRequired));
//				}
//			}
//		} catch (Exception e) {
//			logger.error("Exception-ConfigurationServiceImpl-mapFormPages-", e);
//		}
//		logger.info("ConfigurationServiceImpl-mapFormPages-end");
//	}

	public String responseMsg(String code) {
		ResponseMessageEntity findByCode = responseMsgRepo.findByCode(code);
		String description = null;
		if (findByCode != null) {
			description = findByCode.getDescription();
		}
		return description;
	}

	@Override
	public CommonResponseDto<List<DeficiencyReasonDetailsDto>> fetchDeficiencyReason(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		CommonResponseDto<List<DeficiencyReasonDetailsDto>> commonResponse = new CommonResponseDto<>();
		List<DeficiencyReasonDetailsDto> deficiencyList = new ArrayList<>();
		List<DeficiencyReasonDetailsDto> uniqueList = new ArrayList<>();
		try {
			if (commonRequestDto.getCurrentStepId() != null && StringUtils.isNotBlank(commonRequestDto.getCurrentStepId())) {
				List<DeficiencyReasonDetailsEntity> deficiencyReason = new ArrayList<>();
				if(commonRequestDto.getProcessType() != null && StringUtils.isNotBlank(commonRequestDto.getProcessType())) {
					deficiencyReason = deficiencyReasonDetailsRepository
							.getDeficiencyByCsIdAndProcessType(CommonConstants.TRUE,
									NumericUtils.convertStringToLong(commonRequestDto.getCurrentStepId()), commonRequestDto.getProcessType());
				}else if(commonRequestDto.getProcessType() == null && StringUtils.isBlank(commonRequestDto.getProcessType())) {
					deficiencyReason = deficiencyReasonDetailsRepository
							.getDeficiencyByCsId(CommonConstants.TRUE,
									NumericUtils.convertStringToLong(commonRequestDto.getCurrentStepId()));
				}
				if (!deficiencyReason.isEmpty()) {
					for (DeficiencyReasonDetailsEntity look : deficiencyReason) {
						DeficiencyReasonDetailsDto dto = new DeficiencyReasonDetailsDto();
						dto.setCode(look.getCode());
						dto.setId((look.getId()));
						dto.setOrderNo(look.getOrderNo());
						dto.setName(look.getName());
						deficiencyList.add(dto);
					}
				}
				commonResponse.setResponseData(deficiencyList);
				commonResponse.setStatus(CommonConstants.SUCCESS);
				return commonResponse;
			}
			
			List<DeficiencyReasonDetailsEntity> defReason = new ArrayList<>();
			if (commonRequestDto.getSubStatus() != null) {
				 defReason = deficiencyReasonDetailsRepository
						.findBySubStatusCodeAndIsActive(commonRequestDto.getSubStatus(), CommonConstants.TRUE);
			} else if (commonRequestDto.getSubStatus() == null) {
				defReason = deficiencyReasonDetailsRepository
						.findByIsActive(CommonConstants.TRUE);
			}
			if(defReason != null && !defReason.isEmpty()) {
				for (DeficiencyReasonDetailsEntity look : defReason) {
					DeficiencyReasonDetailsDto dto = new DeficiencyReasonDetailsDto();
					dto.setCode(look.getCode());
					dto.setId((look.getId()));
					dto.setOrderNo(look.getOrderNo());
					dto.setName(look.getName());
					uniqueList.add(dto);
				}
				deficiencyList.addAll(uniqueList.stream().filter(CommonUtils.distinctByKey(DeficiencyReasonDetailsDto::getCode)).collect(Collectors.toList()));
			}
			commonResponse.setResponseData(deficiencyList);
			commonResponse.setStatus(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Exception-ConfigServiceImpl-fetchDeficiencyReason", e);
			commonResponse.setStatus(CommonConstants.ERROR);
		}
		logger.info("ConfigServiceImpl--fetchDeficiencyReason--End");
		return commonResponse;
	}

	@Override
	public CommonResponseDto<List<EventCodeListDto>> fetchEventCodeList(CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("MasterServiceImpl--fetchClaimSubStatus--Start");
		CommonResponseDto<List<EventCodeListDto>> commonResponseDto = new CommonResponseDto<>();
		try {
			List<EventCodeListDto> eventCodeDtoList = new ArrayList<EventCodeListDto>();
			List<EventCodeListEntity> eventCodeEntity = eventCodeListRepository.findByIsActive(CommonConstants.TRUE);

			if (eventCodeEntity != null) {

				for (EventCodeListEntity eventEntity : eventCodeEntity) {

					EventCodeListDto eventCodeDto = new EventCodeListDto();

					eventCodeDto.setId(NumericUtils.convertLongToString(eventEntity.getId()));
					eventCodeDto.setCode(eventEntity.getCode());
					eventCodeDto.setName(eventEntity.getName());
					eventCodeDto.setIsActive(true);
					eventCodeDto.setCreatedDate(DateUtils.dateToStringDDMMYYYY(eventEntity.getCreatedDate()));
					eventCodeDto.setModifiedDate(DateUtils.dateToStringDDMMYYYY(eventEntity.getModifiedDate()));
					eventCodeDtoList.add(eventCodeDto);
				}
				commonResponseDto.setResponseData(eventCodeDtoList);
				commonResponseDto.setStatus(CommonConstants.SUCCESS);
				commonResponseDto.setMessage(" EventCode Fetched Successfully");
			}
		} catch (Exception e) {
			logger.error("MasterServiceImpl--fetchEventCodeList--Error...", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setMessage("EventCodeList not Fetched");
			commonResponseDto.setError(CommonUtils.getStackTrace(e));
		}

		return commonResponseDto;
	}

	// 20221107
//	@Override
//	public CommonResponseDto<List<FormPageSubsectionsDto>> fetchFormPageFields(CommonRequestDto commonRequestDto,
//			HttpServletRequest request) {
//		CommonResponseDto<List<FormPageSubsectionsDto>> commonResponseDto = new CommonResponseDto<>();
//		logger.info("ConfigServiceImpl--fetchFormPageFields--Start");
//		try {
//			String productCatgory = null;
//			if (commonRequestDto.getProductCode() != null && !commonRequestDto.getPageCode().isEmpty()) {
//				ProductMasterEntity productDetails = productMasterRepo.findByCode(commonRequestDto.getProductCode());
//				productCatgory = (productDetails != null ? productDetails.getProductCategory() : null);
//			}
//			ClientsFieldsConfigDto runTimeFields = null;
//			
//			if (commonRequestDto.getPolicyNumber() != null && !commonRequestDto.getPolicyNumber().isEmpty()) {
//				runTimeFields = configRestService.fetchRuntimeFieldConfig(commonRequestDto.getPolicyNumber(), request);
////				FormPageSectionEntity formPageSectionEntity1 = null;
////				System.err.println(runTimeFields.getFieldDetails());				
////				formPageSectionEntity1 = formPageSectionsRepository
////				.findBySectionCodeAndIsActiveAndFormPagePageCodeAndFormPageIsActive(
////						"CLIFIELDUPDATE", CommonConstants.TRUE, "CONFIGURATION",
////						CommonConstants.TRUE);
////				System.err.println(formPageSectionEntity1.getDisplayName());
////				System.err.println("formPageSectionEntity1 = "+formPageSectionEntity1);
//			}
//			FormPageSectionEntity formPageSectionEntity = formPageSectionsRepository
//					.findBySectionCodeAndIsActiveAndFormPagePageCodeAndFormPageIsActive(
//							commonRequestDto.getSectionCode(), CommonConstants.TRUE, commonRequestDto.getPageCode(),
//							CommonConstants.TRUE);
//			if (formPageSectionEntity != null) {
//				List<FormPageSubsectionsDto> formPageSubSectionDtoList = new ArrayList<>();
//				if (formPageSectionEntity.getSubSection() != null) {
//					for (FormPageSubsectionEntity formPageSubSection : formPageSectionEntity.getSubSection()) {
//						FormPageSubsectionsDto subSectionDto = new FormPageSubsectionsDto();
//						BeanUtils.copyProperties(formPageSubSection, subSectionDto);
//
//						List<FormPageFieldgroupDto> formPageFieldGroupDtoList = new ArrayList<>();
//						if (formPageSubSection.getFieldGroup() != null) {
//							for (FormPageFieldgroupEntity formPageFielGroup : formPageSubSection.getFieldGroup()) {
//								FormPageFieldgroupDto formPageFieldGroupDto = new FormPageFieldgroupDto();
//								BeanUtils.copyProperties(formPageFielGroup, formPageFieldGroupDto);
//								formPageFieldGroupDtoList.add(formPageFieldGroupDto);
//
//								List<FormPageFieldsDto> formPageFieldDtoList = new ArrayList<>();
//								if (formPageFielGroup.getPageField() != null) {
//									for (FormPageFieldEntity formPageFieldEntity : formPageFielGroup.getPageField()) {
//										if (formPageFieldEntity.getProductCategory() == null || formPageFieldEntity
//												.getProductCategory().equalsIgnoreCase(productCatgory)) {
//											FormPageFieldsDto formPageFieldDto = new FormPageFieldsDto();
//											BeanUtils.copyProperties(formPageFieldEntity, formPageFieldDto);
//											formPageFieldDtoList.add(formPageFieldDto);
//										}
//									}
//									if (runTimeFields != null) {
//										if (runTimeFields.getFieldDetails() != null) {
//											for (RuntimeFields dto : runTimeFields.getFieldDetails()) {
//												FormPageFieldsDto formPageFieldDto = new FormPageFieldsDto();
////											BeanUtils.copyProperties(dto, formPageFieldDto);
//												formPageFieldDto.setDisplayName(dto.getFieldName());
//												formPageFieldDto.setFieldCode(dto.getFieldCode());
//												formPageFieldDto.setIsActive(dto.getIsActive());
//												formPageFieldDto.setAttributes(dto.getFieldType());
//												formPageFieldDto.setAuthorityCode("READ");
//												formPageFieldDto.setIsMandatory(CommonConstants.FALSE);
//												formPageFieldDtoList.add(formPageFieldDto);
//											}
//										}
//									}
//								}
//								formPageFieldGroupDto.setFormPageFields(formPageFieldDtoList);
//
//							}
//						}
//						subSectionDto.setFormPageFieldGroups(formPageFieldGroupDtoList);
//						formPageSubSectionDtoList.add(subSectionDto);
//					}
//
//				}
//				commonResponseDto.setResponseData(formPageSubSectionDtoList);
//				commonResponseDto.setStatus(CommonConstants.SUCCESS);
//
//			} else {
//				commonResponseDto.setStatus(CommonConstants.SUCCESS);
//				commonResponseDto.setMessage(CommonConstants.NORECORDFOUND);
//			}
//
//		} catch (Exception e) {
//			logger.error("Exception-ConfigServiceImpl-fetchFormPage", e);
//			commonResponseDto.setStatus(CommonConstants.ERROR);
//			commonResponseDto.setError(e.getMessage());̥
//		}
//		logger.info("ConfigServiceImpl--fetchFormPage--End");
//		return commonResponseDto;
//
//	}

//	private List<FormPageSectionsDto> mapFormPageSubSection(Set<FormPageSectionEntity> formPageSectionEntity) {
//		logger.info("ConfigurationServiceImpl-mapFormPageSubSection-start");
//		List<FormPageSectionsDto> pageSectionList = new ArrayList<>();
//		try {
//
//			if (formPageSectionEntity != null) {
//				for (FormPageSectionEntity entity : formPageSectionEntity) {
//					if (entity.getIsActive()) {
//						FormPageSectionsDto sectionDto = new FormPageSectionsDto();
//						BeanUtils.copyProperties(entity, sectionDto);
//						pageSectionList.add(sectionDto);
//					}
//				}
//			}
//		} catch (Exception e) {
//			logger.error("Exception-ConfigurationServiceImpl-mapFormPageSubSection", e);
//			e.printStackTrace();
//		}
//		logger.info("ConfigurationServiceImpl-mapFormPageSubSection-end");
//		return pageSectionList;
//	}
}
