package com.fa.bajajallianz.cccp.config.admin.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.dto.DocumentDto;
import com.fa.bajajallianz.cccp.config.dto.DeficiencyReasonDetailsDto;
import com.fa.bajajallianz.cccp.master.dto.EventCodeListDto;
import com.fa.bajajallianz.cccp.master.dto.SubStatusMasterDto;
import com.fa.bajajallianz.cccp.rcs.admin.common.dto.ErrorLogDto;
import com.fa.bajajallianz.cccp.rcs.admin.common.dto.SearchDataDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.SubStatusDto;
import com.fa.bajajallianz.cccp.surveyor.common.dto.CauseOfLossDto;

public interface AdminService {

	DataTableDto<List<SearchDataDto>> searchAssessmentDetails(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request);

	CommonResponseDto<?> saveAssessmentDetails(CommonRequestDto commonRequestDto, HttpServletRequest request);

	DataTableDto<List<CauseOfLossDto>> searchCOLDetails(String payload, String main_filter, String sort, String page,
			String per_page, HttpServletRequest request);

	DataTableDto<List<SearchDataDto>> searchUserLocationDetails(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request);

	CommonResponseDto<?> saveProductDocument(CommonRequestDto commonRequestDto, HttpServletRequest request);

	DataTableDto<List<DocumentDto>> searchProductDocument(String payload, String main_filter, String sort, String page,
			String per_page, HttpServletRequest request);

	CommonResponseDto<String> downloadProductDocDetials(CommonRequestDto requestDto, HttpServletRequest request);

	DataTableDto<List<EventCodeListDto>> searchEventCodeDetails(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request);

	DataTableDto<List<DeficiencyReasonDetailsDto>> searchDeficiencyDetails(String payload, String main_filter,
			String sort, String page, String per_page, HttpServletRequest request);

	DataTableDto<List<DeficiencyReasonDetailsDto>> searchPrdWfConfig(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request);

	DataTableDto<List<SubStatusDto>> searchSubStatusDetails(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request);

	DataTableDto<List<SubStatusDto>> searchUserProfileDetails(String payload, String main_filter, String sort,
			String page, String per_page, HttpServletRequest request);

	DataTableDto<List<ErrorLogDto>> searchLogDetails(String payload, String main_filter, String sort, String page,
			String per_page, HttpServletRequest request);

	CommonResponseDto<?> saveStakeDetails(CommonRequestDto commonRequestDto, HttpServletRequest request);

}
