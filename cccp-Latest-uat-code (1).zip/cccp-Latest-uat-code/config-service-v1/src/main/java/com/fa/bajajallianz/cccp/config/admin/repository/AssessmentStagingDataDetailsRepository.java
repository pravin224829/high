package com.fa.bajajallianz.cccp.config.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.config.admin.entity.AssessmentStagingDataDetailsEntity;

@Repository
public interface AssessmentStagingDataDetailsRepository
		extends JpaRepository<AssessmentStagingDataDetailsEntity, Long> {

	List<AssessmentStagingDataDetailsEntity> findByFileIdAndStatus(String fileId, String success);

}
