package com.fa.bajajallianz.cccp.config.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fa.bajajallianz.cccp.config.entity.FormPageEntity;

public interface FormPageRepository extends JpaRepository<FormPageEntity, Long> {

	public List<FormPageEntity> findByPageCodeAndIsActive(String pageCode, Boolean true1);
}
