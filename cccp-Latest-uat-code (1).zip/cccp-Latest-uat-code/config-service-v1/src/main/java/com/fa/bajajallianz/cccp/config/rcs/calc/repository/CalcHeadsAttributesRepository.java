package com.fa.bajajallianz.cccp.config.rcs.calc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fa.bajajallianz.cccp.master.entity.CalcHeadsAttributesEntity;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcHeadsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcTypeDto;

public interface CalcHeadsAttributesRepository extends JpaRepository<CalcHeadsAttributesEntity, Long> {

	CalcHeadsAttributesEntity findByCodeAndIsActive(String code, Boolean true1);


//	CalcHeadsAttributesEntity findByCalcheadsCodeAndIsActive(String id, Boolean true1);

}
