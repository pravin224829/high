package com.fa.bajajallianz.cccp.config.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.config.admin.entity.MasterHistoryLogEntity;

@Repository
public interface MasterHistoryLogRepository extends JpaRepository<MasterHistoryLogEntity, Long> {

}
