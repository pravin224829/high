package com.fa.bajajallianz.cccp.config.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.config.dto.FormPageDto;
import com.fa.bajajallianz.cccp.config.dto.FormPageSubsectionsDto;
import com.fa.bajajallianz.cccp.config.service.ConfigurationService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/config/api/" })
public class ConfigurationController {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	public ConfigurationService configService;

	@GetMapping(value = { "healthCheck" })
	public String healthCheck() {
		logger.info("CommonController-healthCheck-started");
		return CommonConstants.CONFIGHEALTHCHECK;
	}

	@GetMapping("fetchFormPage")
	public ResponseEntity<?> fetchFormPages(@RequestParam String payload, HttpServletRequest request) {
		logger.info("ConfigurationController-fetchFormPage-start");
		CommonResponseDto<List<FormPageDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = configService.fetchFormPage(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
			logger.error("Exception-ConfigServiceImpl-fetchFormPages", e);
		}
		logger.info("ConfigurationController-fetchFormPage-end");

		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchFormPageField")
	public ResponseEntity<?> fetchFormPageField(@RequestParam String payload, HttpServletRequest request) {
		logger.info("ConfigurationController-fetchFormPageField-start");
		CommonResponseDto<List<FormPageSubsectionsDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = configService.fetchFormPageFields(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
			logger.error("Exception-ConfigurationController-fetchFormPageField", e);
		}
		logger.info("ConfigurationController-fetchFormPageField-end");
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}
}
