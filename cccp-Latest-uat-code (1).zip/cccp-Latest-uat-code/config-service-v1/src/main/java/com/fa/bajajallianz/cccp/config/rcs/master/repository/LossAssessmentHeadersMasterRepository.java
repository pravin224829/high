package com.fa.bajajallianz.cccp.config.rcs.master.repository;
 
import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;
 
import com.fa.bajajallianz.cccp.config.rcs.master.entity.LossAssessmentHeadersMasterEntity;
 
public interface LossAssessmentHeadersMasterRepository extends JpaRepository<LossAssessmentHeadersMasterEntity, Long> {
 
	List<LossAssessmentHeadersMasterEntity> findByProductCodeAndIsActiveTrueAndCauseOfLossOrCauseOfLossIsNull(
			String productCode, String causeOfLoss);
 
}