package com.fa.bajajallianz.cccp.config.entity;

/**
 * @author praveen
 *
 */

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "form_page_field_group")
public class FormPageFieldgroupEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", length = 20, nullable = false)
	private Long id;

	@Column(name = "additional_info", length = 5000)
	private String additionalInfo;
	
	@Column(name = "attributes", length = 5000)
	private String attributes;

	@Column(name = "description", length = 5000)
	private String description;

	@Column(name = "display_name", length = 300)
	private String displayName;

	@Column(name = "field_group_code", length = 20, unique = true, nullable = true)
	private String fieldGroupCode;

	@Column(name = "is_active", nullable = false)
	private Boolean isActive;

	@Column(name = "model", length = 5000)
	private String model;

	@Column(name = "order_no", length = 10)
	private Integer orderNo;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_date")
	private Date modifiedDate;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, targetEntity = FormPageSubsectionEntity.class)
	@JoinColumn(name = "subsection_id")
	private FormPageSubsectionEntity formPageSubsection;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "formPageFieldgroup")
	private Set<FormPageFieldEntity> pageField;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}
	
	public String getAttributes() {
		return attributes;
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getFieldGroupCode() {
		return fieldGroupCode;
	}

	public void setFieldGroupCode(String fieldGroupCode) {
		this.fieldGroupCode = fieldGroupCode;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Integer getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public FormPageSubsectionEntity getFormPageSubsection() {
		return formPageSubsection;
	}

	public void setFormPageSubsection(FormPageSubsectionEntity formPageSubsection) {
		this.formPageSubsection = formPageSubsection;
	}

	public Set<FormPageFieldEntity> getPageField() {
		return pageField;
	}

	public void setPageField(Set<FormPageFieldEntity> pageField) {
		this.pageField = pageField;
	}

}
