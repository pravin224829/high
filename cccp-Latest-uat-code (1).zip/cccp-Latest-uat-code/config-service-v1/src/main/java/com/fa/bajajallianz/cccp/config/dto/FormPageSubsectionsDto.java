package com.fa.bajajallianz.cccp.config.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class FormPageSubsectionsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	private String additionalInfo;
	private String authorityCode;
	private String description;
	private String displayName;
	private Boolean isActive;
	private Integer orderNo;
	private String objName;
	private String subSectionCode;
	private Date createdDate;
	private Date modifiedDate;
	private List<FormPageFieldgroupDto> formPageFieldGroups;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public String getAuthorityCode() {
		return authorityCode;
	}

	public void setAuthorityCode(String authorityCode) {
		this.authorityCode = authorityCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}

	public String getSubSectionCode() {
		return subSectionCode;
	}

	public void setSubSectionCode(String subSectionCode) {
		this.subSectionCode = subSectionCode;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public List<FormPageFieldgroupDto> getFormPageFieldGroups() {
		return formPageFieldGroups;
	}

	public void setFormPageFieldGroups(List<FormPageFieldgroupDto> formPageFieldGroups) {
		this.formPageFieldGroups = formPageFieldGroups;
	}

}
