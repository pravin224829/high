package com.fa.bajajallianz.cccp.config.rcs.calc.serviceimpl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.NumericUtils;
import com.fa.bajajallianz.cccp.config.rcs.calc.repository.CalcHeadsAttributesRepository;
import com.fa.bajajallianz.cccp.config.rcs.calc.repository.CalcHeadsRepository;
import com.fa.bajajallianz.cccp.config.rcs.calc.repository.CalcTypeRepository;
import com.fa.bajajallianz.cccp.config.rcs.calc.repository.SubCalcTypeRepository;
import com.fa.bajajallianz.cccp.config.rcs.calc.service.RcscalcService;
import com.fa.bajajallianz.cccp.config.rcs.master.service.RcsMasterService;
import com.fa.bajajallianz.cccp.master.entity.CalcAssessmentHeaderMasterEntity;
import com.fa.bajajallianz.cccp.master.entity.CalcHeadsAttributesEntity;
import com.fa.bajajallianz.cccp.master.entity.CalcHeadsEntity;
import com.fa.bajajallianz.cccp.master.entity.CalcSubHeadsEntity;
import com.fa.bajajallianz.cccp.master.entity.CalcTypeEntity;
import com.fa.bajajallianz.cccp.master.entity.ProductMasterEntity;
import com.fa.bajajallianz.cccp.master.entity.SubCalcTypeEntity;
import com.fa.bajajallianz.cccp.master.repository.CalcAssessmentHeaderMasterRepository;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcHeadsAttributesDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcHeadsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcSubHeadsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcSubTypeDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcTypeDto;

@Service
public class RcsCalcServiceImpl implements RcscalcService {
	@Autowired
	CalcHeadsRepository calcHeadsRepository;

	@Autowired
	CalcHeadsAttributesRepository calcHeadsAttributesRepository;

	@Autowired
	SubCalcTypeRepository subCalcTypeRepository;

	@Autowired
	CalcTypeRepository calcTypeRepository;

	@Autowired
	RcsMasterService rcsMasterService;

	@Autowired
	CalcAssessmentHeaderMasterRepository calcAssessmentHeaderMasterRepository;

	@Override
	public CommonResponseDto<?> fetchCalcFields(CommonRequestDto commonRequestDto, HttpServletRequest request) {
		CommonResponseDto<List<CalcHeadsDto>> responseDto = new CommonResponseDto<>();
		List<CalcHeadsDto> calcHeadsDtoList = new ArrayList<>();
		List<String> propertyCodeList = new ArrayList<String>();
//		List<String> propertyCodeList1 = new ArrayList<String>();

		try {
//			
			if (commonRequestDto.getPageCode() != null && !commonRequestDto.getPageCode().isBlank()) {
				if (commonRequestDto.getSectionCode() != null && !commonRequestDto.getSectionCode().isBlank()) {
					CalcTypeEntity calcType = calcTypeRepository.findByCodeAndIsActive(commonRequestDto.getPageCode(),
							CommonConstants.TRUE);
					List<CalcAssessmentHeaderMasterEntity> calcAssessmentHeaders = null;
					if (calcType.getCode().equals(CommonConstants.LOSSASSESSMENT)) {
						calcAssessmentHeaders = calcAssessmentHeaderMasterRepository
								.findByIsActiveAndProductCodeOrderByOrderNoAsc(CommonConstants.TRUE,
										commonRequestDto.getProductCode());
						if (calcAssessmentHeaders != null && calcAssessmentHeaders.size() > 25) {
							calcAssessmentHeaders = calcAssessmentHeaders.stream()
									.filter(h -> StringUtils.isNotBlank(h.getCauseOfLoss()))
									.filter(h -> h.getCauseOfLoss().equals(commonRequestDto.getCauseOfLoss()))
									.collect(Collectors.toList());
						}

						propertyCodeList = calcAssessmentHeaderMasterRepository.findPropertyCodes();

						List<String> propertyHeaderCodes = calcAssessmentHeaderMasterRepository
								.findPropertyHeaderCodes();

						if (propertyCodeList != null && propertyCodeList.contains(commonRequestDto.getProductCode())) {
							calcAssessmentHeaders = calcAssessmentHeaders.stream().filter(h -> {
								String code1 = h.getCode();
								return !(propertyHeaderCodes.contains(code1));

							}).collect(Collectors.toList());

						}

//						List<String> propertyHeaderCodes1 = calcAssessmentHeaderMasterRepository
//								.findPropertyHeaderCodes1();
//
//						propertyCodeList1 = calcAssessmentHeaderMasterRepository.findPropertyCodes1();
//
//						if (propertyCodeList1 != null
//								&& propertyCodeList1.contains(commonRequestDto.getProductCode())) {
//							calcAssessmentHeaders = calcAssessmentHeaders.stream().filter(h -> {
//								String code1 = h.getCode();
//								return !(propertyHeaderCodes1.contains(code1));
//
//							}).collect(Collectors.toList());
//
//						}
//						calcAssessmentHeaders = calcAssessmentHeaders.stream()
//								.sorted(Comparator.comparingInt(h -> h.getOrderNo())).collect(Collectors.toList());
					}
					List<SubCalcTypeEntity> subCalcTypeList = calcType.getSubCalcType();
//					List<CalcSubTypeDto> calcSubTypeDtoList = new ArrayList<>();
//					CalcTypeDto calcTypeDto = new CalcTypeDto();
//					BeanUtils.copyProperties(calcType, calcTypeDto);
					for (SubCalcTypeEntity subCalcType : subCalcTypeList) {
						if (CommonConstants.TRUE.equals(subCalcType.getIsActive())) {
							int i = 0;

//						CalcSubTypeDto calcSubTypeDto = new CalcSubTypeDto();
//						BeanUtils.copyProperties(subCalcType, calcSubTypeDto);
							List<String> propertyHeaderCodes = calcAssessmentHeaderMasterRepository
									.findPropertyHeaderCodes();

							List<CalcHeadsEntity> calcHeadsList = subCalcType.getCalcHeads();
							if (propertyCodeList != null
									&& propertyCodeList.contains(commonRequestDto.getProductCode())) {
								calcHeadsList = calcHeadsList.stream().filter(h -> {
									String code1 = h.getCalcSubHeads().get(0).getCode();
									System.out.println(code1);
									return !(propertyHeaderCodes.contains(code1));

								}).collect(Collectors.toList());

							}

//							List<String> propertyHeaderCodes1 = calcAssessmentHeaderMasterRepository
//									.findPropertyHeaderCodes1();
//
//							if (propertyCodeList1 != null
//									&& propertyCodeList1.contains(commonRequestDto.getProductCode())) {
//								calcHeadsList = calcHeadsList.stream().filter(h -> {
//									String code1 = h.getCode();
//									System.out.println(code1);
//									return !(code1.equals("ASMT12")||(code1.equals("ASMT13")));
//
//								}).collect(Collectors.toList());
//
//							}

							for (CalcHeadsEntity calcHeadsEntity : calcHeadsList) {
								if (CommonConstants.TRUE.equals(calcHeadsEntity.getIsActive())) {
									List<CalcSubHeadsDto> calcSubHeadsList = new ArrayList<>();
									CalcHeadsDto calcHeadsDto = new CalcHeadsDto();
									BeanUtils.copyProperties(calcHeadsEntity, calcHeadsDto);
									List<CalcSubHeadsEntity> calcSubHeadsEntityList = calcHeadsEntity.getCalcSubHeads();
									if (calcSubHeadsEntityList != null && !calcSubHeadsEntityList.isEmpty()) {
										for (CalcSubHeadsEntity calcSubHeadsEntity : calcSubHeadsEntityList) {
											if (CommonConstants.TRUE.equals(calcSubHeadsEntity.getIsActive())) {
												CalcSubHeadsDto calcSubHeadsDto = new CalcSubHeadsDto();
												BeanUtils.copyProperties(calcSubHeadsEntity, calcSubHeadsDto);
												List<CalcHeadsAttributesDto> attributesList = new ArrayList<>();
												if (calcType.getCode().equals(CommonConstants.LOSSASSESSMENT)) {
													if (calcAssessmentHeaders != null)
														calcSubHeadsDto
																.setName(calcAssessmentHeaders.get(i++).getName());
													if (StringUtils.isNotBlank(calcSubHeadsDto.getName())
															&& calcSubHeadsDto.getName().equals("-")) {
														calcSubHeadsDto.setAuthorityCode("READ_WRITE");
													} else {
														calcSubHeadsDto.setAuthorityCode("READ");
													}

												} else {
													calcSubHeadsDto.setId(NumericUtils
															.convertLongToString(calcSubHeadsEntity.getId()));
													calcSubHeadsDto.setCode(calcSubHeadsEntity.getCode());
													calcSubHeadsDto.setName(calcSubHeadsEntity.getName());
													calcSubHeadsDto.setObjName(calcSubHeadsEntity.getObjName());
													calcSubHeadsDto
															.setAuthorityCode(calcSubHeadsEntity.getAuthorityCode());
													calcSubHeadsDto.setSubCalcType(subCalcType.getCode());
												}
												List<CalcHeadsAttributesEntity> calcHeadsAttributesList = calcSubHeadsEntity
														.getCalcHeadsAttributes();

												for (CalcHeadsAttributesEntity calcHeadsAttributesEntity : calcHeadsAttributesList) {
													if (CommonConstants.TRUE
															.equals(calcHeadsAttributesEntity.getIsActive())) {
														CalcHeadsAttributesDto calcHeadsAttributesDto = new CalcHeadsAttributesDto();

														calcHeadsAttributesDto.setAuthorityCode(
																calcHeadsAttributesEntity.getAuthorityCode());
														BeanUtils.copyProperties(calcHeadsAttributesEntity,
																calcHeadsAttributesDto);
														if (StringUtils.isNotBlank(calcSubHeadsDto.getName())
																&& calcSubHeadsDto.getName()
																		.equals("Total_Deductible_Amount")
																&& calcHeadsAttributesDto.getCode().equals("AMT24")) {
															calcHeadsAttributesDto.setCode("AMT26");
														} else {
															calcHeadsAttributesDto
																	.setCode(calcHeadsAttributesEntity.getCode());
														}
														calcHeadsAttributesDto
																.setName(calcHeadsAttributesEntity.getName());
														calcHeadsAttributesDto
																.setOrderNo(NumericUtils.convertIntegerToString(
																		calcHeadsAttributesEntity.getOrderNo()));
														calcHeadsAttributesDto.setAttributes(
																calcHeadsAttributesEntity.getAttributes());
														calcHeadsAttributesDto
																.setObjName(calcHeadsAttributesEntity.getObjName());
														calcHeadsAttributesDto.setBoldString(
																calcHeadsAttributesEntity.getBoldString());
														calcHeadsAttributesDto.setCalcHeads(calcHeadsEntity.getCode());
//									calcHeadsAttributesDto
//											.setCalcHeadsFormula(formulaMap.get(calcH̥eadsAttributesEntity.getCode()));
														attributesList.add(calcHeadsAttributesDto);
													}
													attributesList = attributesList.stream()
															.sorted(Comparator.comparingInt(a -> NumericUtils
																	.convertStringToInteger(a.getOrderNo())))
															.collect(Collectors.toList());
													calcSubHeadsDto.setCalcHeadsAttributes(attributesList);
												}
												calcSubHeadsList.add(calcSubHeadsDto);
											}
										}
									}
									calcHeadsDto.setCalcSubHeads(calcSubHeadsList);
									calcHeadsDtoList.add(calcHeadsDto);
								}
							}
						}
					}
				}
			}
			responseDto.setResponseData(calcHeadsDtoList);
			responseDto.setStatus(CommonConstants.SUCCESS);
			// responseDto.setMessage("SUCESS");

		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
			responseDto.setStatus(CommonConstants.ERROR);
			responseDto.setMessage("Headers Not Configured for Product");

		} catch (Exception e) {

			e.printStackTrace();
			responseDto.setStatus(CommonConstants.ERROR);
			responseDto.setMessage(CommonUtils.getStackTrace(e));
		}

		return responseDto;
	}

}
