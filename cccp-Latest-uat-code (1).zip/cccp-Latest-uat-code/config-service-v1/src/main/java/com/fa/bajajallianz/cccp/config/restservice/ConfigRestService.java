package com.fa.bajajallianz.cccp.config.restservice;

import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.common.dto.ClientsFieldsConfigDto;

/**
 * @author Santhosh
 *
 */
public interface ConfigRestService {

	ClientsFieldsConfigDto fetchRuntimeFieldConfig(String policyNumber, HttpServletRequest request);

	
	
}
