package com.fa.bajajallianz.cccp.config.rcs.calc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.master.entity.CalcTypeEntity;
@Repository
public interface CalcTypeRepository extends JpaRepository<CalcTypeEntity,Long> {

	CalcTypeEntity findByCodeAndIsActive(String calcType, Boolean true1);

}
