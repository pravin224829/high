package com.fa.bajajallianz.cccp.master.dto;

import java.io.Serializable;
import java.util.List;

/**
 * @author Santhosh
 *
 */
public class LookupTypeDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long id;
	private String code;
	private String name;
	private List<LookupTypeValuesDto> lookupTypeValues;
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

		public List<LookupTypeValuesDto> getLookupTypeValues() {
		return lookupTypeValues;
	}

	public void setLookupTypeValues(List<LookupTypeValuesDto> lookupTypeValues) {
		this.lookupTypeValues = lookupTypeValues;
	}

}
