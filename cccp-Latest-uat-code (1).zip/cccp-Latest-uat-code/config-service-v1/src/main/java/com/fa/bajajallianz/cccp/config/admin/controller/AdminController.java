package com.fa.bajajallianz.cccp.config.admin.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.common.dto.DocumentDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.ErrorCodeConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.config.admin.service.AdminService;
import com.fa.bajajallianz.cccp.config.dto.DeficiencyReasonDetailsDto;
import com.fa.bajajallianz.cccp.master.dto.EventCodeListDto;
import com.fa.bajajallianz.cccp.rcs.admin.common.dto.ErrorLogDto;
import com.fa.bajajallianz.cccp.rcs.admin.common.dto.SearchDataDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.SubStatusDto;
import com.fa.bajajallianz.cccp.surveyor.common.dto.CauseOfLossDto;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/config/admin/api/" })
public class AdminController {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	AdminService adminService;

	@GetMapping("searchProductDocument")
	public ResponseEntity<?> searchProductDocument(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("AdminController-searchProductDocument-start");
		DataTableDto<List<DocumentDto>> dataTableDto = new DataTableDto<>();
		try {
			dataTableDto = adminService.searchProductDocument(payload, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			e.printStackTrace();
			dataTableDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("AdminController-searchProductDocument-End");
		return new ResponseEntity<DataTableDto<List<DocumentDto>>>(dataTableDto, HttpStatus.OK);
	}

	@PostMapping("saveProductDocument")
	public ResponseEntity<?> saveProductDocument(@RequestBody CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("Enter into AdminController -saveProductDocument - Start");
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = adminService.saveProductDocument(commonRequestDto, request);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Enter into AdminController -saveProductDocument", e);
		}
		logger.info("Enter into AdminController -saveProductDocument - End");
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("searchAssessmentDetails")
	public ResponseEntity<?> searchAssessmentDetails(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("AdminController-searchAssessmentDetails-start");
		DataTableDto<List<SearchDataDto>> dataTableDto = new DataTableDto<List<SearchDataDto>>();
		try {
			dataTableDto = adminService.searchAssessmentDetails(payload, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			dataTableDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("AdminController-searchAssessmentDetails - " + dataTableDto.getStatus());
		return new ResponseEntity<DataTableDto<List<SearchDataDto>>>(dataTableDto, HttpStatus.OK);
	}

	@PostMapping("saveAssessmentDetails")
	public ResponseEntity<?> saveAssessmentDetails(@RequestBody CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("AdminController-saveAssessmentDetails-start");
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = adminService.saveAssessmentDetails(commonRequestDto, request);
		} catch (Exception e) {
			commonRequestDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("AdminController-saveAssessmentDetails - " + commonRequestDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("searchCOLDetails")
	public ResponseEntity<?> searchCOLDetails(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("AdminController-searchCOLDetails-start");
		DataTableDto<List<CauseOfLossDto>> dataTableDto = new DataTableDto<List<CauseOfLossDto>>();
		try {
			dataTableDto = adminService.searchCOLDetails(payload, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Enter into AdminController -searchCOLDetails", e);
			dataTableDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("AdminController-searchCOLDetails - " + dataTableDto.getStatus());
		return new ResponseEntity<DataTableDto<List<CauseOfLossDto>>>(dataTableDto, HttpStatus.OK);
	}

	@GetMapping("searchUserLocationDetails")
	public ResponseEntity<?> searchUserLocationDetails(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("Enter into AdminController-searchUserLocationDetails-start");
		DataTableDto<List<SearchDataDto>> dataTableDto = new DataTableDto<List<SearchDataDto>>();
		try {
			dataTableDto = adminService.searchUserLocationDetails(payload, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			dataTableDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("AdminController-searchUserLocationDetails - " + dataTableDto.getStatus());
		return new ResponseEntity<DataTableDto<List<SearchDataDto>>>(dataTableDto, HttpStatus.OK);
	}

	@GetMapping("downloadProductDocDetials")
	public ResponseEntity<?> downloadProductDocDetials(@RequestParam String payload, HttpServletRequest request) {
		logger.info("AdminController-downloadProductDocDetials-start");
		CommonResponseDto<String> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto requestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = adminService.downloadProductDocDetials(requestDto, request);
		} catch (Exception e) {
			logger.error("Exception-AdminController-downloadProductDocDetials", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setErrorCode(ErrorCodeConstants.ERROR1);
		}
		return new ResponseEntity<>(commonResponseDto, HttpStatus.OK);
	}

//	@GetMapping("/searchSubStatusDetails")
//	public ResponseEntity<?> searchSubStatusDetails(@RequestParam String payload, @RequestParam String main_filter,
//			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
//			HttpServletRequest request) {
//		logger.info("AdminController-searchSubStatusDetails-start");
//		DataTableDto<List<DocumentDto>> dataTableDto = new DataTableDto<>();
//		try {
//			dataTableDto = adminService.searchSubStatusDetails(payload, main_filter, sort, page, per_page, request);
//		} catch (Exception e) {
//			e.printStackTrace();
//			dataTableDto.setStatus(CommonConstants.ERROR);
//		}
//		logger.info("AdminController-searchSubStatusDetails-End");
//		return new ResponseEntity<DataTableDto<List<DocumentDto>>>(dataTableDto, HttpStatus.OK);
//
//	}

	@GetMapping("searchEventCodeDetails")
	public ResponseEntity<?> searchEventCodeDetails(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("AdminController-searchEventCodeDetails-start");
		DataTableDto<List<EventCodeListDto>> dataTableDto = new DataTableDto<>();
		try {
			dataTableDto = adminService.searchEventCodeDetails(payload, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			e.printStackTrace();
			dataTableDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("AdminController-searchEventCodeDetails-End");
		return new ResponseEntity<DataTableDto<List<EventCodeListDto>>>(dataTableDto, HttpStatus.OK);
	}

	@GetMapping("searchDeficiencyDetails")
	public ResponseEntity<?> searchDeficiencyDetails(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("AdminController-searchProductDocument-start");
		DataTableDto<List<DeficiencyReasonDetailsDto>> dataTableDto = new DataTableDto<>();
		try {
			dataTableDto = adminService.searchDeficiencyDetails(payload, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			e.printStackTrace();
			dataTableDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("AdminController-searchProductDocument-End");
		return new ResponseEntity<DataTableDto<List<DeficiencyReasonDetailsDto>>>(dataTableDto, HttpStatus.OK);
	}

	@GetMapping("searchPrdWfConfig")
	public ResponseEntity<?> searchPrdWfConfig(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("AdminController-searchPrdWfConfig-start");
		DataTableDto<List<DeficiencyReasonDetailsDto>> dataTableDto = new DataTableDto<>();
		try {
			dataTableDto = adminService.searchPrdWfConfig(payload, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			e.printStackTrace();
			dataTableDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("AdminController-searchProductDocument-End");
		return new ResponseEntity<DataTableDto<List<DeficiencyReasonDetailsDto>>>(dataTableDto, HttpStatus.OK);
	}

	@GetMapping("searchSubStatusDetails")
	public ResponseEntity<?> searchSubStatusDetails(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("AdminController-searchSubStatusDetails-start");
		DataTableDto<List<SubStatusDto>> dataTableDto = new DataTableDto<>();
		try {
			dataTableDto = adminService.searchSubStatusDetails(payload, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			e.printStackTrace();
			dataTableDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("AdminController-searchSubStatusDetails-End");
		return new ResponseEntity<DataTableDto<List<SubStatusDto>>>(dataTableDto, HttpStatus.OK);
	}
	
	@GetMapping("searchUserProfileDetails")
	public ResponseEntity<?> searchUserProfileDetails(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("AdminController-searchUserProfileDetails-start");
		DataTableDto<List<SubStatusDto>> dataTableDto = new DataTableDto<>();
		try {
			dataTableDto = adminService.searchUserProfileDetails(payload, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			e.printStackTrace();
			dataTableDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("AdminController-searchUserProfileDetails-End");
		return new ResponseEntity<DataTableDto<List<SubStatusDto>>>(dataTableDto, HttpStatus.OK);
	}
	
	@GetMapping("searchLogDetails")
	public ResponseEntity<?> searchLogDetails(@RequestParam String payload, @RequestParam String main_filter,
			@RequestParam String sort, @RequestParam String page, @RequestParam String per_page,
			HttpServletRequest request) {
		logger.info("AdminController-searchLogDetails-start");
		DataTableDto<List<ErrorLogDto>> dataTableDto = new DataTableDto<>();
		try {
			dataTableDto = adminService.searchLogDetails(payload, main_filter, sort, page, per_page, request);
		} catch (Exception e) {
			e.printStackTrace();
			dataTableDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("AdminController-searchLogDetails-End");
		return new ResponseEntity<DataTableDto<List<ErrorLogDto>>>(dataTableDto, HttpStatus.OK);
	}
	
	@PostMapping("saveStakeDetails")
	public ResponseEntity<?> saveStakeDetails(@RequestBody CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("AdminController-saveStakeDetails-start");
		CommonResponseDto<?> commonDto = new CommonResponseDto<>();

		try {
			commonDto = adminService.saveStakeDetails(commonRequestDto, request);
		} catch (Exception e) {
			logger.error("Exception-AdminController-saveStakeDetails-error", e);
			commonDto.setStatus(CommonConstants.ERROR);
			commonDto.setError(CommonUtils.getStackTrace(e));
		}
		logger.info("AdminController-saveStakeDetails-end");
		return new ResponseEntity<CommonResponseDto<?>>(commonDto, HttpStatus.OK);
	}
}
