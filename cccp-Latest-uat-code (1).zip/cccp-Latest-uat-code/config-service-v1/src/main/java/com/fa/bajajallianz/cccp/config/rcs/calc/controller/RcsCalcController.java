package com.fa.bajajallianz.cccp.config.rcs.calc.controller;


import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.config.rcs.calc.service.RcscalcService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/config/rcs/calc/api/" })
public class RcsCalcController {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	RcscalcService rcscalcService;
	

	@GetMapping("fetchCalcFields")
	public ResponseEntity<?> fetchCalcFields(@RequestParam String payload, HttpServletRequest request) {
		logger.info("RcsCalcController-fetchCalcFields-start");
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = rcscalcService.fetchCalcFields(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
			e.printStackTrace();
			}
		logger.info("RcsCalcController-fetchCalcFields-end");

		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

}
