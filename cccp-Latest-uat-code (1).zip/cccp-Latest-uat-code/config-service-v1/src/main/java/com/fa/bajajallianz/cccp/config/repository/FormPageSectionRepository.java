package com.fa.bajajallianz.cccp.config.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.config.entity.FormPageSectionEntity;

@Repository
public interface FormPageSectionRepository extends JpaRepository<FormPageSectionEntity, Long> {

	FormPageSectionEntity findBySectionCodeAndIsActiveAndFormPagePageCodeAndFormPageIsActive(String sectionCode,
			Boolean true1, String pageCode, Boolean true2);
}
