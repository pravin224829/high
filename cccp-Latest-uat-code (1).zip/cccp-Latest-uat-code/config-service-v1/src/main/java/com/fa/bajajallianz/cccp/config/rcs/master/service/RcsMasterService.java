package com.fa.bajajallianz.cccp.config.rcs.master.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.common.dto.ClaimMileStonesDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.PartiesDto;
import com.fa.bajajallianz.cccp.master.dto.LookupTypeDto;
import com.fa.bajajallianz.cccp.master.dto.MasterDto;
import com.fa.bajajallianz.cccp.master.dto.StatusMasterDto;
import com.fa.bajajallianz.cccp.master.dto.SubStatusMasterDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcConditionsDto;
import com.fa.bajajallianz.cccp.rcs.common.dto.CalcFormulaDto;

public interface RcsMasterService {

	CommonResponseDto<?> fetchClaimMileStone(CommonRequestDto commonRequestDto, HttpServletRequest request);

	Map<String, ClaimMileStonesDto> getClaimMileStone(HttpServletRequest request);

	CommonResponseDto<List<StatusMasterDto>> fetchClaimStatus(CommonRequestDto commonRequestDto,
			HttpServletRequest request);

	CommonResponseDto<List<SubStatusMasterDto>> fetchClaimSubStatus(CommonRequestDto commonRequestDto,
			HttpServletRequest request);

	CommonResponseDto<?> savePartyDetails(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonResponseDto<Map<String, List<CalcFormulaDto>>> getCalcFormula(String calcType, HttpServletRequest request);

	CommonResponseDto<?> fetchPendingAgeBand(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonResponseDto<Map<String, List<CalcConditionsDto>>> getCalcConditions(String calcType,
			HttpServletRequest request);

	CommonResponseDto<List<MasterDto>> fetchClosingReason(CommonRequestDto commonRequestDto,
			HttpServletRequest request);

	CommonResponseDto<List<MasterDto>> fetchMarineVoyages(CommonRequestDto commonRequestDto,
			HttpServletRequest request);

	CommonResponseDto<List<MasterDto>> fetchPortNames(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonResponseDto<List<MasterDto>> fetchLossAssessmentHeaders(CommonRequestDto commonRequestDto,
	HttpServletRequest request);

}
