package com.fa.bajajallianz.cccp.config.rcs.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.master.entity.PendingAgeMasterEntity;

@Repository
public interface PendingAgeBandRepository extends JpaRepository<PendingAgeMasterEntity,Long> {

	List<PendingAgeMasterEntity> findByIsActive(Boolean true1);

}
