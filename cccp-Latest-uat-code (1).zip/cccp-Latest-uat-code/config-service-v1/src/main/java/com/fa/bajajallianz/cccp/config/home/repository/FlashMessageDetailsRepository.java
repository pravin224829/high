package com.fa.bajajallianz.cccp.config.home.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fa.bajajallianz.cccp.config.home.entity.FlashMessageDetailsEntity;

@Repository
public interface FlashMessageDetailsRepository extends JpaRepository<FlashMessageDetailsEntity, Long> {

	FlashMessageDetailsEntity findByMsgId(String msgId);

	List<FlashMessageDetailsEntity> findTop5ByUserIdAndIsActiveOrderByCreatedDateDesc(String searchUserId,
			Boolean true1);
}
	