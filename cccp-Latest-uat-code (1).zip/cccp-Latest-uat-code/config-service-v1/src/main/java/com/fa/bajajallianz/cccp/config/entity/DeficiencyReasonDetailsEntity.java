package com.fa.bajajallianz.cccp.config.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "deficiency_reason_details")
public class DeficiencyReasonDetailsEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", length = 20, nullable = false)
	private Long id;

	@Column(name = "name", length = 100)
	private String name;

	@Column(name = "code", length = 30)
	private String code;

	@Column(name = "product_code", length = 30)
	private String productCode;

	@Column(name = "sub_status_code", length = 30)
	private String subStatusCode;

	@Column(name = "is_active")
	private Boolean isActive;
	
	@Column(name = "remarks")
	private String remarks;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "is_action_required")
	private Boolean isActionRequired;
	
	@Column(name = "action_id")
	private Long actionId;
	
	@Column(name = "cs_step_id")
	private Long csStepId;
	
	@Column(name = "ns_step_id")
	private Long nsStepId;
	
	@Column(name = "process_id", length = 20)
	private String processId;
	
	@Column(name = "is_default")
	private Boolean isDefault;
	
	@Column(name = "order_no", length = 10)
	private Integer orderNo;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "created_by", length = 100)
	private String createdBy;

	@Column(name = "modified_date")
	private Date modifiedDate;

	@Column(name = "modified_by", length = 100)
	private String modifiedBy;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getSubStatusCode() {
		return subStatusCode;
	}

	public void setSubStatusCode(String subStatusCode) {
		this.subStatusCode = subStatusCode;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Boolean getIsActionRequired() {
		return isActionRequired;
	}

	public void setIsActionRequired(Boolean isActionRequired) {
		this.isActionRequired = isActionRequired;
	}

	public Long getActionId() {
		return actionId;
	}

	public void setActionId(Long actionId) {
		this.actionId = actionId;
	}

	public Long getCsStepId() {
		return csStepId;
	}

	public void setCsStepId(Long csStepId) {
		this.csStepId = csStepId;
	}

	public Long getNsStepId() {
		return nsStepId;
	}

	public void setNsStepId(Long nsStepId) {
		this.nsStepId = nsStepId;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	public Boolean getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}

	public Integer getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
}
