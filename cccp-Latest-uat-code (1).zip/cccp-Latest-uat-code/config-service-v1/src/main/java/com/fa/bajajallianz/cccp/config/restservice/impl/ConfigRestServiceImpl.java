/**
 * 
 */
package com.fa.bajajallianz.cccp.config.restservice.impl;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.fa.bajajallianz.cccp.common.dto.ClientsFieldsConfigDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.DateUtils;
import com.fa.bajajallianz.cccp.common.utils.NumericUtils;
import com.fa.bajajallianz.cccp.config.restservice.ConfigRestService;
import com.fa.bajajallianz.cccp.config.utils.CommonRequestUtil;

/**
 * @author santhosh
 *
 */

@Service
public class ConfigRestServiceImpl implements ConfigRestService {

	private static final Logger logger = LoggerFactory.getLogger(ConfigRestServiceImpl.class);

	@Autowired
	private Environment environment;

	@Autowired
	private RestTemplate restTemplate;

	public String getProperty() {
		return environment.getProperty("CONFIG_API_URL");
	}

	@Override
	public ClientsFieldsConfigDto fetchRuntimeFieldConfig(String policyNumber, HttpServletRequest request) {
		logger.info("RestTemplateServiceImpl-fetchRuntimeFieldConfig-start");
		ClientsFieldsConfigDto responseDto = new ClientsFieldsConfigDto();
		String url = null;
		String message = null;
		String errorMessage = null;
		HttpHeaders headers = new HttpHeaders();
		try {
			url = CommonUtils.fetchApi("FETCHRUNTIMFIELDS", getProperty());
			System.err.println("policyNumber=" + policyNumber);
			url = url + "?policyNumber=" + policyNumber;
//			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			//headers.set(CommonConstants.AUTHORIZATION, request.getHeader(CommonConstants.AUTHORIZATION));
			headers.add(CommonConstants.BUSINESSCORELATIONID, "B-" + DateUtils.uniqueNoMilli());
			headers.add(CommonConstants.CORELATIONID, "C-" + DateUtils.uniqueNoMilli());
			logger.info("API => " + url);
			CommonResponseDto<ClientsFieldsConfigDto> response = restTemplate.exchange(url, HttpMethod.GET, null,
					new ParameterizedTypeReference<CommonResponseDto<ClientsFieldsConfigDto>>() {
					}, headers).getBody();
			if (response != null) {
				responseDto = response.getResponseData();
			} else {
				logger.error("Rest Template Responce => ", response);
			}

		} catch (HttpClientErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-RestTemplateServiceImpl-fetchRuntimeFieldConfig-HttpClientErrorException", e);
		} catch (HttpServerErrorException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-RestTemplateServiceImpl-fetchRuntimeFieldConfig-HttpServerErrorException", e);
		} catch (ResourceAccessException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-RestTemplateServiceImpl-fetchRuntimeFieldConfig-ResourceAccessException", e);
		} catch (JSONException e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-RestTemplateServiceImpl-fetchRuntimeFieldConfig-JSONException", e);
		} catch (Exception e) {
			message = e.getMessage();
			errorMessage = CommonUtils.getStackTrace(e);
			logger.error("Exception-RestTemplateServiceImpl-fetchRuntimeFieldConfig-Exception-end", e);
		} finally {
			CommonRequestUtil.saveApiLog(request, policyNumber,
					"fetchRuntimeFieldConfig", "fetchRuntimeFieldConfig", "fetchRuntimeFieldConfig", message, errorMessage,
					"", "", NumericUtils.convertPojoClassToString(responseDto), "", url, headers);
		}
		logger.info("RestTemplateServiceImpl-fetchRuntimeFieldConfig-end");
		return responseDto;
	}

}
