package com.fa.bajajallianz.cccp.config.home.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.DataTableDto;
import com.fa.bajajallianz.cccp.config.home.dto.FlashMessageDetailsDto;

public interface HomeService {

	CommonResponseDto<List<FlashMessageDetailsDto>> fetchFlashMessageDetails(CommonRequestDto commonRequestDto,
			HttpServletRequest request);
	
	CommonResponseDto<DataTableDto<List<FlashMessageDetailsDto>>> fetchFalshMessageList(CommonRequestDto commonRequestDto, HttpServletRequest request);

	CommonResponseDto<FlashMessageDetailsDto> saveFlashMessageDetails(FlashMessageDetailsDto dto,
			HttpServletRequest request);

}
