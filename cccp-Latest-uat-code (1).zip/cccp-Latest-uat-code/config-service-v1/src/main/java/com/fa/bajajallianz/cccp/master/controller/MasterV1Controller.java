/**
 * 
 */
package com.fa.bajajallianz.cccp.master.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.dto.MobileAppVersionDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;
import com.fa.bajajallianz.cccp.master.dto.MenuPagesDto;
import com.fa.bajajallianz.cccp.master.dto.SubMenuPagesDto;
import com.fa.bajajallianz.cccp.master.service.MasterService;
import com.fa.bajajallianz.cccp.surveyor.common.dto.NotifyConfigDto;

/**
 * @author praveen
 *
 */

@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/config/m/master/api/" })
public class MasterV1Controller {
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	public MasterService masterService;

	@GetMapping("v1/fetchWidgets")
	public ResponseEntity<?> fetchWidgets(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterV1Controller-fetchWidgets-start");
		CommonResponseDto<List<SubMenuPagesDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchWidgets(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);

		}
		logger.info("fetchWidgets" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("v1/fetchMenuPages")
	public ResponseEntity<?> fetchMenuPagesByRole(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterV1Controller-fetchWidgets-start");
		CommonResponseDto<List<MenuPagesDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.fetchMenuPagesByRole(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);

		}
		logger.info("fetchMenuPages" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}
	
	@GetMapping("v1/getNotifyConfig")
	public ResponseEntity<?> getNotifyConfig(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterV1Controller-getNotifyConfig-start");
		CommonResponseDto<NotifyConfigDto> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = masterService.getNotifyConfig(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);

		}
		logger.info("getNotifyConfig" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}
	
	@GetMapping("v1/fetchMobileAppVersion")
	public ResponseEntity<?> fetchMobileAppVersion(HttpServletRequest request) {
		logger.info("MasterV1Controller-fetchMobileAppVersion-start");
		CommonResponseDto<MobileAppVersionDto> commonResponseDto = new CommonResponseDto<>();
		try {
			commonResponseDto = masterService.fetchMobileAppVersion(request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("fetchMobileAppVersion" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}
}