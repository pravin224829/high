package com.fa.bajajallianz.cccp.config.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fa.bajajallianz.cccp.config.rcs.master.entity.ClosingReasonMasterEntity;

public interface ClosingReasonRepository extends JpaRepository<ClosingReasonMasterEntity, Long>{

	List<ClosingReasonMasterEntity> findByIsActive(Boolean true1);

}
