package com.fa.bajajallianz.cccp.config.rcs.master.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fa.bajajallianz.cccp.common.dto.ClaimMileStonesDto;
import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;
import com.fa.bajajallianz.cccp.common.utils.CommonConstants;
import com.fa.bajajallianz.cccp.common.utils.CommonUtils;
import com.fa.bajajallianz.cccp.common.utils.JsonRequest;

import com.fa.bajajallianz.cccp.config.rcs.master.service.RcsMasterService;
import com.fa.bajajallianz.cccp.config.utils.CommonErrorMsg;
import com.fa.bajajallianz.cccp.master.dto.LookupTypeDto;
import com.fa.bajajallianz.cccp.master.dto.LookupTypeValuesDto;
import com.fa.bajajallianz.cccp.master.dto.MasterDto;
import com.fa.bajajallianz.cccp.master.dto.StatusMasterDto;
import com.fa.bajajallianz.cccp.master.dto.SubStatusMasterDto;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping({ "/cccp/config/rcs/master/api/" })
public class RcsMasterController {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private RcsMasterService rcsMasterService;

	@Autowired
	CommonErrorMsg commonErrorMsg;

	@GetMapping("fetchClaimMileStone")
	public ResponseEntity<?> fetchClaimMileStone(@RequestParam String payload, HttpServletRequest request) {
		logger.info("RcsMasterController-fetchClaimMileStone-start");
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = rcsMasterService.fetchClaimMileStone(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
		}
		logger.info("RcsMasterController-fetchClaimMileStone-end");

		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("getClaimMileStone")
	public Map<String, ClaimMileStonesDto> getClaimMileStone(HttpServletRequest request) {
		logger.info("RcsMasterController-getClaimMileStone-start");
		Map<String, ClaimMileStonesDto> response = new HashMap<>();
		try {
			response = rcsMasterService.getClaimMileStone(request);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("RcsMasterController-getClaimMileStone-" + e);

		}
		logger.info("RcsMasterController-getClaimMileStone-end");
		return response;
	}

	@GetMapping("fetchClaimStatus")
	public ResponseEntity<?> fetchClaimStatus(@RequestParam String payload, HttpServletRequest request) {
		logger.info("RcsMasterController-fetchClaimStatus-start");
		CommonResponseDto<List<StatusMasterDto>> commonDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonDto = rcsMasterService.fetchClaimStatus(commonRequestDto, request);
		} catch (Exception e) {
			logger.error("Exception-MasterController-fetchClaimStatus-error", e);
			commonDto.setStatus(CommonConstants.ERROR);
			commonDto.setMessage("Claim Not Fetched");
			commonDto.setError(CommonUtils.getStackTrace(e));
		}
		logger.info("RcsMasterController-fetchClaimStatus-end");
		return new ResponseEntity<CommonResponseDto<?>>(commonDto, HttpStatus.OK);

	}

	@GetMapping("fetchClaimSubStatus")
	public ResponseEntity<?> fetchClaimSubStatus(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchClaimStatusMaster-start");
		CommonResponseDto<List<SubStatusMasterDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = rcsMasterService.fetchClaimSubStatus(commonRequestDto, request);
		} catch (Exception e) {
			logger.error("MasterController-fetchClaimStatusMaster-error", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setMessage("Claim Sub Status not fetched");
		}
		logger.info("MasterController-fetchClaimStatusMaster-end");
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@RequestMapping(value = { "savePartyDetails" }, method = { RequestMethod.POST, RequestMethod.GET })
	public ResponseEntity<?> savePartyDetails(@RequestBody CommonRequestDto commonRequestDto,
			HttpServletRequest request) {
		logger.info("RcsMasterController-fetchClaimStatus-start");
		CommonResponseDto<?> commonDto = new CommonResponseDto<>();

		try {
			commonDto = rcsMasterService.savePartyDetails(commonRequestDto, request);
		} catch (Exception e) {
			logger.error("Exception-MasterController-fetchClaimStatus-error", e);
			commonDto.setStatus(CommonConstants.ERROR);
			commonDto.setMessage("Claim Not Fetched");
			commonDto.setError(CommonUtils.getStackTrace(e));
		}
		logger.info("RcsMasterController-fetchClaimStatus-end");
		return new ResponseEntity<CommonResponseDto<?>>(commonDto, HttpStatus.OK);
	}

	@GetMapping("getCalcFormula")
	public ResponseEntity<?> getCalcFormula(@RequestParam String calcType, HttpServletRequest request) {
		logger.info("RcsMasterController-getCalcFormula-start");
		CommonResponseDto<?> commonDto = new CommonResponseDto<>();
		try {
			commonDto = rcsMasterService.getCalcFormula(calcType, request);
		} catch (Exception e) {
			logger.error("Exception-MasterController-getCalcFormula-error", e);
			commonDto.setStatus(CommonConstants.ERROR);
			commonDto.setError(CommonUtils.getStackTrace(e));
		}
		logger.info("RcsMasterController-getCalcFormula-end");
		return new ResponseEntity<CommonResponseDto<?>>(commonDto, HttpStatus.OK);
	}

	@GetMapping("fetchPendingAgeBand")
	public ResponseEntity<?> fetchPendingAgeBand(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchClaimStatusMaster-start");
		CommonResponseDto<?> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = rcsMasterService.fetchPendingAgeBand(commonRequestDto, request);
		} catch (Exception e) {
			logger.error("MasterController-fetchPendingAgeBand-error", e);
			commonResponseDto.setStatus(CommonConstants.ERROR);
			commonResponseDto.setMessage("PendingAgeBand not fetched");
		}
		logger.info("MasterController-fetchPendingAgeBand-end");
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("getCalcConditions")
	public ResponseEntity<?> getCalcConditions(@RequestParam String calcType, HttpServletRequest request) {
		logger.info("RcsMasterController-getCalcFormula-start");
		CommonResponseDto<?> commonDto = new CommonResponseDto<>();
		try {
			commonDto = rcsMasterService.getCalcConditions(calcType, request);
		} catch (Exception e) {
			logger.error("Exception-MasterController-getCalcConditions-error", e);
			commonDto.setStatus(CommonConstants.ERROR);
			commonDto.setError(CommonUtils.getStackTrace(e));
		}
		logger.info("RcsMasterController-getCalcConditions-end");
		return new ResponseEntity<CommonResponseDto<?>>(commonDto, HttpStatus.OK);
	}

	@GetMapping("fetchClosingReason")
	public ResponseEntity<?> fetchClosingReason(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchClosingReason-start");
		CommonResponseDto<List<MasterDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = rcsMasterService.fetchClosingReason(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);

		}
		logger.info("fetchClosingReason" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchPortNames")
	public ResponseEntity<?> fetchPortNames(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchPortNames-start");
		CommonResponseDto<List<MasterDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = rcsMasterService.fetchPortNames(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);

		}
		logger.info("fetchPortNames" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

	@GetMapping("fetchMarineVoyages")
	public ResponseEntity<?> fetchMarineVoyages(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchMarineVoyages-start");
		CommonResponseDto<List<MasterDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = rcsMasterService.fetchMarineVoyages(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);

		}
		logger.info("fetchMarineVoyages" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}
	

	@GetMapping("fetchLossAssessmentHeaders")
	public ResponseEntity<?> fetchLossAssessmentHeaders(@RequestParam String payload, HttpServletRequest request) {
		logger.info("MasterController-fetchLossAssessmentHeaders-start");
		CommonResponseDto<List<MasterDto>> commonResponseDto = new CommonResponseDto<>();
		JsonRequest<CommonRequestDto> jsonRequest = new JsonRequest<>();
		try {
			CommonRequestDto commonRequestDto = jsonRequest.readEncoded(payload, CommonRequestDto.class);
			commonResponseDto = rcsMasterService.fetchLossAssessmentHeaders(commonRequestDto, request);
		} catch (Exception e) {
			commonResponseDto.setStatus(CommonConstants.ERROR);
			logger.error("RcsMasterController - fetchLossAssessmentHeaders ", e);
		}
		logger.info("fetchMarineVoyages" + commonResponseDto.getStatus());
		return new ResponseEntity<CommonResponseDto<?>>(commonResponseDto, HttpStatus.OK);
	}

}
