package com.fa.bajajallianz.cccp.master.dto;

import java.io.Serializable;

/**
 * @author Santhosh
 *
 */
public class LookupTypeValuesDto implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long id;
	private String code;
	private String value;
	private Integer orderNo;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Integer getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}

}
