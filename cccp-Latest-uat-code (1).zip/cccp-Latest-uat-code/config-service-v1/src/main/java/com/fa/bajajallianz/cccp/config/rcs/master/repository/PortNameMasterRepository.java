package com.fa.bajajallianz.cccp.config.rcs.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fa.bajajallianz.cccp.config.rcs.master.entity.PortNameMasterEntity;

public interface PortNameMasterRepository extends JpaRepository<PortNameMasterEntity, Long> {

	List<PortNameMasterEntity> findByIsActive(Boolean true1);

}
