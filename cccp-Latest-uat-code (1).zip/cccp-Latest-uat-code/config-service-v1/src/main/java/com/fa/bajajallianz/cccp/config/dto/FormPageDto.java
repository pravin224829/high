package com.fa.bajajallianz.cccp.config.dto;

import java.io.Serializable;
import java.util.List;

public class FormPageDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long id;
	private String additionalInfo;
	private String description;
	private String displayName;
	private Boolean isActive;
	private String objName;
	private String pageCode;
	private String orderNo;
	private String pageType;
	private List<FormPageSectionsDto> formPageSection;
	private String authorities;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getPageCode() {
		return pageCode;
	}

	public void setPageCode(String pageCode) {
		this.pageCode = pageCode;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getPageType() {
		return pageType;
	}

	public void setPageType(String pageType) {
		this.pageType = pageType;
	}

	public List<FormPageSectionsDto> getFormPageSection() {
		return formPageSection;
	}

	public void setFormPageSection(List<FormPageSectionsDto> formPageSection) {
		this.formPageSection = formPageSection;
	}

	public String getAuthorities() {
		return authorities;
	}

	public void setAuthorities(String authorities) {
		this.authorities = authorities;
	}
}
