package com.fa.bajajallianz.cccp.config.rcs.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fa.bajajallianz.cccp.config.rcs.master.entity.MarineVoyageMasterEntity;

public interface MarineVoyageMasterRepository extends JpaRepository<MarineVoyageMasterEntity, Long> {

	List<MarineVoyageMasterEntity> findByIsActive(Boolean true1);

}
