package com.fa.bajajallianz.cccp.config.rcs.calc.service;

import javax.servlet.http.HttpServletRequest;

import com.fa.bajajallianz.cccp.common.dto.CommonRequestDto;
import com.fa.bajajallianz.cccp.common.dto.CommonResponseDto;

public interface RcscalcService {

	CommonResponseDto<?> fetchCalcFields(CommonRequestDto commonRequestDto, HttpServletRequest request);

}
