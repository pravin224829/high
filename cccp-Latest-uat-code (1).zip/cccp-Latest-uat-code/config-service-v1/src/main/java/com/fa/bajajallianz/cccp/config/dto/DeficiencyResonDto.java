package com.fa.bajajallianz.cccp.config.dto;

import java.io.Serializable;
import java.util.List;

import com.fa.bajajallianz.cccp.master.dto.LookupTypeValuesDto;

public class DeficiencyResonDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private String name;
	private String code;
	private LookupTypeValuesDto lookupValues;
	private DeficiencyReasonDetailsDto deficiencyReasonDetailsDtos;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public LookupTypeValuesDto getLookupValues() {
		return lookupValues;
	}
	public void setLookupValues(LookupTypeValuesDto lookupValues) {
		this.lookupValues = lookupValues;
	}
	public DeficiencyReasonDetailsDto getDeficiencyReasonDetailsDtos() {
		return deficiencyReasonDetailsDtos;
	}
	public void setDeficiencyReasonDetailsDtos(DeficiencyReasonDetailsDto deficiencyReasonDetailsDtos) {
		this.deficiencyReasonDetailsDtos = deficiencyReasonDetailsDtos;
	}
	
	
}
