package com.fa.bajajallianz.cccp.config.dto;

import java.io.Serializable;

public class FormPageSectionsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	private String additionalInfo;
	private String description;
	private String displayName;
	private Boolean isActive;
	private Boolean isQuestionaire;
	private String objName;
	private Integer orderNo;
	private String sectionCode;
	private String attributes;
	private Object formPageSubSections;
	private Object authorities;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean getIsQuestionaire() {
		return isQuestionaire;
	}

	public void setIsQuestionaire(Boolean isQuestionaire) {
		this.isQuestionaire = isQuestionaire;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public Integer getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}

	public String getSectionCode() {
		return sectionCode;
	}

	public void setSectionCode(String sectionCode) {
		this.sectionCode = sectionCode;
	}

	public Object getFormPageSubSections() {
		return formPageSubSections;
	}

	public void setFormPageSubSections(Object formPageSubSections) {
		this.formPageSubSections = formPageSubSections;
	}

	public Object getAuthorities() {
		return authorities;
	}

	public void setAuthorities(Object authorities) {
		this.authorities = authorities;
	}

	public String getAttributes() {
		return attributes;
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

}
