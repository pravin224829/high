<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <div class="row">
                        <div class="col-lg-6">
                            <h1 class="page-title">
                                New Claim Registration
                            </h1>
                        </div>
                        <div class="col-lg-6">
                            <ul class="breadcrumbs float-right">
                                <li><a href="#">List of Policies > ></a></li>
                                <li class="active">New Claim Registration</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="claim-details main-card cancel-step">
            <div class="row">
                <div class="col-lg-3">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Policy Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="claim-details-aside">
                                <ul class="claim-detail-item">
                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/policy-number.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Policy Number
                                                <span>OG-20-1101-4001-00000088</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/name-of-insured.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Name of Insured
                                                <span>Carrier Airconditioning</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/policy-status.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Policy Status
                                                <span><div class="badge badge-success">Active</div></span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/product.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Product
                                                <span>Marine Turnover Policy</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/financial-institute.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Name of Financial Institute
                                                <span>None</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/calendar.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Policy Start Date
                                                <span>10-01-2021</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/calendar.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Policy End Date
                                                <span>09-01-2022</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/policy-sum-insured.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Sum Insured
                                                <span>₹ 9,60,000</span>
                                            </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-9">
                    <div class="new-claim-reg-step">
                        <div class="add-policy-detail h-100">
                            <div class="policy-detail-bg">
                                <div class="steps d-flex justify-content-center flex-lg-row flex-column">
                                    <div class="step-1 active d-flex">
                                        <div class="img-ico-parent">
                                            <div class="step-img">
                                                <img src="@/assets/images/icons/cancel-1.svg" alt="Icon">
                                            </div>
                                        </div>
                                        <div class="step-detail">
                                            <p>Step 1</p>
                                            <h6>Loss Details</h6>
                                        </div>
                                    </div>
                                    <div class="step-1 d-flex">
                                        <div class="img-ico-parent">
                                            <div class="step-img">
                                                <img src="@/assets/images/icons/cancel-2.svg" alt="Icon">
                                            </div>
                                        </div>
                                        <div class="step-detail">
                                            <p>Step 2</p>
                                            <h6>Transit Details</h6>
                                        </div>
                                    </div>
                                    <div class="step-1 d-flex">
                                        <div class="img-ico-parent">
                                            <div class="step-img">
                                                <img src="@/assets/images/icons/cancel-3.svg" alt="Icon">
                                            </div>
                                        </div>
                                        <div class="step-detail">
                                            <p>Step 3</p>
                                            <h6>Contact Details for Loss Location / Place</h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="policy-input common-form">
                                   <div class="row">
                                    <div class="col-lg-3">

                                        <div class="form-group">
                                            <label>Date of Loss <span>*</span></label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="Select Date" value="10-01-2021">
                                                <div class="input-group-append">
                                                  <span class="input-group-text" id="basic-addon2">
                                                    <img src="@/assets/images/icons/calendar.svg">
                                                  </span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label>Notification Date <span>*</span></label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="Select Date" value="10-01-2021">
                                                <div class="input-group-append">
                                                  <span class="input-group-text" id="basic-addon2">
                                                    <img src="@/assets/images/icons/calendar.svg">
                                                  </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Enter Pin Code Where Loss Happened <span>*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter">
                                        </div>
                                        <div class="form-group">
                                            <label>Estimated Value of Loss <span>*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter">
                                        </div>
                                    </div>
                                    <div class="col-lg-8 offset-lg-1">
                                        <div class="row">
                                            <div class="col-lg-5">
                                                <div class="form-group">
                                                    <label>Time of Loss <span>*</span></label>
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" placeholder="hh:mm">
                                                        <div class="input-group-append">
                                                          <span class="input-group-text" id="basic-addon2">
                                                            <img src="@/assets/images/icons/clock.svg">
                                                          </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-5 offset-lg-2">
                                                <div class="form-group">
                                                    <label>Cause of Loss <span>*</span></label>
                                                    <select id="inputState" class="form-control">
                                                        <option selected>Select</option>
                                                        <option>Insured</option>
                                                      </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-lg-5">
                                                <div class="form-group">
                                                    <label>Claim Notified by <span>*</span></label>
                                                    <select id="inputState" class="form-control">
                                                        <option selected>Select</option>
                                                        <option>Insured</option>
                                                      </select>
                                                </div>
                                                <div class="form-group">
                                                    <label for="inputState">Datails of Goods Damaged <span>*</span></label>
                                                    <input type="text" class="form-control" placeholder="Enter">
                                                </div>
                                            </div>
                                            <div class="col-lg-5 offset-lg-2">
                                                <div class="form-group">
                                                    <label for="inputState">Loss Description <span>*</span></label>
                                                    <textarea class="form-control" rows="5">Lorem Ipsum is simply dummy text of the printing & typesetting industry.</textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="step-button mx-auto">
                                        <router-link to="/new-claim-registration-cancel-step-two" class="btn btn-primary">Next</router-link>
                                    </div>
                                   </div>
                                </div>  
                            </div>
                            
                        </div>
                    </div>
                </div>

                </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'NewClaimRegistrationCancelStepOne'
    }
</script>
