<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <h1 class="page-title">
                        Reports
                    </h1>
                </div>
            </div>
        </section>

        <section class="form-filter main-card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                          <h3>Filter</h3>
                        </div>
                            <div class="card-body">
                                <div class="form-filter-items">
                                    <form>
                                        <div class="form-row d-flex">
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Policy Start Date</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Select Date" value="24-12-2020">
                                                    <div class="input-group-append">
                                                      <span class="input-group-text" id="basic-addon2">
                                                        <img src="@/assets/images/icons/calendar.svg">
                                                      </span>
                                                    </div>
                                                </div>
                                            </div>
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Policy Start Date</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Select Date" value="23-01-2021">
                                                    <div class="input-group-append">
                                                      <span class="input-group-text" id="basic-addon2">
                                                        <img src="@/assets/images/icons/calendar.svg">
                                                      </span>
                                                    </div>
                                                </div>
                                            </div>
    
                                            <div class="form-group col-auto align-self-end">
                                                <button class="btn btn-primary" type="submit">Filter</button>
                                            </div>
                                            <div class="form-group col-auto align-self-end">
                                                <button class="btn btn-primary" type="submit">Reset</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                      </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="table-result table-responsive h-100">
                            <table id="example" class="table table-borderless">
                                <thead class="thead-lt-head">
                                  <tr>
                                    <th>S No.</th>
                                    <th>Document Name <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th class="text-right">Select <span><img src="@/assets/images/sort.svg"></span></th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td>01</td>
                                    <td>
                                        <div class="document-details">
                                            <div class="img-icon">
                                                <img src="@/assets/images/icons/list-of-outstanding-claims.svg">
                                            </div>
                                            <p>
                                                List of Outstanding Claims
                                                <span>281</span>
                                            </p>
                                        </div>
                                    </td>
                                    <td class="text-right">
                                        <input type="checkbox" class="checkbox-input">
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>02</td>
                                    <td>
                                        <div class="document-details">
                                            <div class="img-icon">
                                                <img src="@/assets/images/icons/list-of-settled-claims.svg">
                                            </div>
                                            <p>
                                                List of Settled Claims
                                                <span>102</span>
                                            </p>
                                        </div>
                                    </td>
                                    <td class="text-right">
                                        <input type="checkbox" checked class="checkbox-input">
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>03</td>
                                    <td>
                                        <div class="document-details">
                                            <div class="img-icon">
                                                <img src="@/assets/images/icons/detailed-information-report.svg">
                                            </div>
                                            <p>
                                                Detailed Information Report
                                                <span>130</span>
                                            </p>
                                        </div>
                                    </td>
                                    <td class="text-right">
                                        <input type="checkbox" class="checkbox-input">
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>04</td>
                                    <td>
                                        <div class="document-details">
                                            <div class="img-icon">
                                                <img src="@/assets/images/icons/claim-payment-report.svg">
                                            </div>
                                            <p>
                                                Claim Payment Report
                                                <span>88</span>
                                            </p>
                                        </div>
                                    </td>
                                    <td class="text-right">
                                        <input type="checkbox" class="checkbox-input">
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                              <div class="row">
                                <div class="col-lg-6 mx-auto text-center">
                                    <button class="btn btn-primary" type="submit">Download</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'ReportsView'
    }
</script>

<style lang="scss" scoped>

</style>