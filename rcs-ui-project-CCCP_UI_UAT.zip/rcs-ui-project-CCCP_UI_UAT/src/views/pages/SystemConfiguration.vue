<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <h1 class="page-title">
                        System Configuration
                    </h1>
                </div>
            </div>
        </section>

        <section class="form-filter main-card mb-4">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                          <h3>Filter</h3>
                        </div>
                            <div class="card-body">
                                <div class="form-filter-items">
                                    <form>
                                        <div class="form-row d-flex">
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">User ID <span>*</span></label>
                                                <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter">
                                            </div>

                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Partner ID</label>
                                                <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter">
                                            </div>
    
                                            <div class="form-group col-auto align-self-end">
                                                <button class="btn btn-primary" type="submit">Filter</button>
                                            </div>
                                            <div class="form-group col-auto align-self-end">
                                                <button class="btn btn-primary" type="submit">Reset</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                      </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="table-result h-100">
                            <div class="table-responsive">
                                <table id="example" class="table table-borderless">
                                    <thead class="thead-lt-head">
                                        <th>S No.</th>
                                        <th>User ID <span><img src="@/assets/images/sort.svg"></span></th>
                                        <th>Partner ID <span><img src="@/assets/images/sort.svg"></span></th>
                                        <th>Policy Number <span><img src="@/assets/images/sort.svg"></span></th>
                                        <th>Register Mobile Number <span><img src="@/assets/images/sort.svg"></span></th>
                                        <th>Register Email ID <span><img src="@/assets/images/sort.svg"></span></th>
                                        <th>Updated by User ID <span><img src="@/assets/images/sort.svg"></span></th>
                                        <th>Updated on Date and Time <span><img src="@/assets/images/sort.svg"></span></th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td>01</td>
                                        <td>user_0885631</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td><div class="badge badge-success w-100">Active</div></td>
                                        <td class="text-center">
                                            <a href="update-claim-details-form.html" class="update_claim_icon">
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_2229_31788)">
                                                    <path d="M19.4578 3.60871L16.3912 0.54207C15.6687 -0.180469 14.4991 -0.180586 13.7765 0.54207C13.2622 1.05648 1.95468 12.364 1.73902 12.5796C1.65378 12.6648 1.59351 12.7717 1.5648 12.8888L0.0193706 19.1825C-0.0992232 19.6656 0.339136 20.0981 0.817457 19.9806C1.14406 19.9004 6.82207 18.5061 7.11109 18.4351C7.22812 18.4064 7.33507 18.3461 7.42027 18.2609C7.64746 18.0337 18.892 6.78914 19.4578 6.22336C20.1803 5.50082 20.1805 4.33133 19.4578 3.60871ZM1.56058 18.4393L1.62355 18.183L1.81695 18.3764L1.56058 18.4393ZM3.31515 18.0085L1.99144 16.6848L2.56707 14.3407L5.65925 17.4328L3.31515 18.0085ZM6.95375 16.8613L3.13859 13.0462L12.9903 3.19437L16.8055 7.00953L6.95375 16.8613ZM18.5248 5.29031L17.7627 6.0523L13.9476 2.23715L14.7096 1.47516C14.9164 1.2684 15.2513 1.2682 15.4582 1.47516L18.5248 4.54184C18.7316 4.74867 18.7316 5.0834 18.5248 5.29031Z" fill="#B2B3C7"></path>
                                                    </g>
                                                    <defs>
                                                    <clipPath id="clip0_2229_31788">
                                                    <rect width="20" height="20" fill="white"></rect>
                                                    </clipPath>
                                                    </defs>
                                                </svg>                                                                                                                                             
                                            </a>
                                        </td>
                                      </tr>
    
                                      <tr>
                                        <td>02</td>
                                        <td>user_0885631</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td><div class="badge badge-success w-100">Active</div></td>
                                        <td class="text-center">
                                            <a href="update-claim-details-form.html" class="update_claim_icon">
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_2229_31788)">
                                                    <path d="M19.4578 3.60871L16.3912 0.54207C15.6687 -0.180469 14.4991 -0.180586 13.7765 0.54207C13.2622 1.05648 1.95468 12.364 1.73902 12.5796C1.65378 12.6648 1.59351 12.7717 1.5648 12.8888L0.0193706 19.1825C-0.0992232 19.6656 0.339136 20.0981 0.817457 19.9806C1.14406 19.9004 6.82207 18.5061 7.11109 18.4351C7.22812 18.4064 7.33507 18.3461 7.42027 18.2609C7.64746 18.0337 18.892 6.78914 19.4578 6.22336C20.1803 5.50082 20.1805 4.33133 19.4578 3.60871ZM1.56058 18.4393L1.62355 18.183L1.81695 18.3764L1.56058 18.4393ZM3.31515 18.0085L1.99144 16.6848L2.56707 14.3407L5.65925 17.4328L3.31515 18.0085ZM6.95375 16.8613L3.13859 13.0462L12.9903 3.19437L16.8055 7.00953L6.95375 16.8613ZM18.5248 5.29031L17.7627 6.0523L13.9476 2.23715L14.7096 1.47516C14.9164 1.2684 15.2513 1.2682 15.4582 1.47516L18.5248 4.54184C18.7316 4.74867 18.7316 5.0834 18.5248 5.29031Z" fill="#B2B3C7"></path>
                                                    </g>
                                                    <defs>
                                                    <clipPath id="clip0_2229_31788">
                                                    <rect width="20" height="20" fill="white"></rect>
                                                    </clipPath>
                                                    </defs>
                                                </svg>                                                                                                                                             
                                            </a>
                                        </td>
                                      </tr>
    
                                      <tr>
                                        <td>03</td>
                                        <td>user_0885631</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td><div class="badge badge-success w-100">Active</div></td>
                                        <td class="text-center">
                                            <a href="update-claim-details-form.html" class="update_claim_icon">
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_2229_31788)">
                                                    <path d="M19.4578 3.60871L16.3912 0.54207C15.6687 -0.180469 14.4991 -0.180586 13.7765 0.54207C13.2622 1.05648 1.95468 12.364 1.73902 12.5796C1.65378 12.6648 1.59351 12.7717 1.5648 12.8888L0.0193706 19.1825C-0.0992232 19.6656 0.339136 20.0981 0.817457 19.9806C1.14406 19.9004 6.82207 18.5061 7.11109 18.4351C7.22812 18.4064 7.33507 18.3461 7.42027 18.2609C7.64746 18.0337 18.892 6.78914 19.4578 6.22336C20.1803 5.50082 20.1805 4.33133 19.4578 3.60871ZM1.56058 18.4393L1.62355 18.183L1.81695 18.3764L1.56058 18.4393ZM3.31515 18.0085L1.99144 16.6848L2.56707 14.3407L5.65925 17.4328L3.31515 18.0085ZM6.95375 16.8613L3.13859 13.0462L12.9903 3.19437L16.8055 7.00953L6.95375 16.8613ZM18.5248 5.29031L17.7627 6.0523L13.9476 2.23715L14.7096 1.47516C14.9164 1.2684 15.2513 1.2682 15.4582 1.47516L18.5248 4.54184C18.7316 4.74867 18.7316 5.0834 18.5248 5.29031Z" fill="#B2B3C7"></path>
                                                    </g>
                                                    <defs>
                                                    <clipPath id="clip0_2229_31788">
                                                    <rect width="20" height="20" fill="white"></rect>
                                                    </clipPath>
                                                    </defs>
                                                </svg>                                                                                                                                             
                                            </a>
                                        </td>
                                      </tr>
    
                                      <tr>
                                        <td>04</td>
                                        <td>user_0885631</td>
                                        <td>ptr_6397123LM</td>
                                        <td>OG-20-1205-4008-00000115</td>
                                        <td>+91 89631 01263</td>
                                        <td>bradpitt@gmail.com</td>
                                        <td>user_521786</td>
                                        <td>24-11-2020 10:01 PM</td>
                                        <td><div class="badge badge-danger w-100">Deactivate</div></td>
                                        <td class="text-center">
                                            <a href="update-claim-details-form.html" class="update_claim_icon">
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_2229_31788)">
                                                    <path d="M19.4578 3.60871L16.3912 0.54207C15.6687 -0.180469 14.4991 -0.180586 13.7765 0.54207C13.2622 1.05648 1.95468 12.364 1.73902 12.5796C1.65378 12.6648 1.59351 12.7717 1.5648 12.8888L0.0193706 19.1825C-0.0992232 19.6656 0.339136 20.0981 0.817457 19.9806C1.14406 19.9004 6.82207 18.5061 7.11109 18.4351C7.22812 18.4064 7.33507 18.3461 7.42027 18.2609C7.64746 18.0337 18.892 6.78914 19.4578 6.22336C20.1803 5.50082 20.1805 4.33133 19.4578 3.60871ZM1.56058 18.4393L1.62355 18.183L1.81695 18.3764L1.56058 18.4393ZM3.31515 18.0085L1.99144 16.6848L2.56707 14.3407L5.65925 17.4328L3.31515 18.0085ZM6.95375 16.8613L3.13859 13.0462L12.9903 3.19437L16.8055 7.00953L6.95375 16.8613ZM18.5248 5.29031L17.7627 6.0523L13.9476 2.23715L14.7096 1.47516C14.9164 1.2684 15.2513 1.2682 15.4582 1.47516L18.5248 4.54184C18.7316 4.74867 18.7316 5.0834 18.5248 5.29031Z" fill="#B2B3C7"></path>
                                                    </g>
                                                    <defs>
                                                    <clipPath id="clip0_2229_31788">
                                                    <rect width="20" height="20" fill="white"></rect>
                                                    </clipPath>
                                                    </defs>
                                                </svg>                                                                                                                                             
                                            </a>
                                        </td>
                                      </tr>
    
                                      <tr>
                                        <td>04</td>
                                        <td>user_0885631</td>
                                        <td>ptr_6397123LM</td>
                                        <td>OG-20-1205-4008-00000881</td>
                                        <td>+91 99888 14725</td>
                                        <td>keanureeves@gmail.com</td>
                                        <td>user_521786</td>
                                        <td>10-11-2020 09:41 AM</td>
                                        <td><div class="badge badge-danger w-100">Deactivate</div></td>
                                        <td class="text-center">
                                            <a href="update-claim-details-form.html" class="update_claim_icon">
                                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g clip-path="url(#clip0_2229_31788)">
                                                    <path d="M19.4578 3.60871L16.3912 0.54207C15.6687 -0.180469 14.4991 -0.180586 13.7765 0.54207C13.2622 1.05648 1.95468 12.364 1.73902 12.5796C1.65378 12.6648 1.59351 12.7717 1.5648 12.8888L0.0193706 19.1825C-0.0992232 19.6656 0.339136 20.0981 0.817457 19.9806C1.14406 19.9004 6.82207 18.5061 7.11109 18.4351C7.22812 18.4064 7.33507 18.3461 7.42027 18.2609C7.64746 18.0337 18.892 6.78914 19.4578 6.22336C20.1803 5.50082 20.1805 4.33133 19.4578 3.60871ZM1.56058 18.4393L1.62355 18.183L1.81695 18.3764L1.56058 18.4393ZM3.31515 18.0085L1.99144 16.6848L2.56707 14.3407L5.65925 17.4328L3.31515 18.0085ZM6.95375 16.8613L3.13859 13.0462L12.9903 3.19437L16.8055 7.00953L6.95375 16.8613ZM18.5248 5.29031L17.7627 6.0523L13.9476 2.23715L14.7096 1.47516C14.9164 1.2684 15.2513 1.2682 15.4582 1.47516L18.5248 4.54184C18.7316 4.74867 18.7316 5.0834 18.5248 5.29031Z" fill="#B2B3C7"></path>
                                                    </g>
                                                    <defs>
                                                    <clipPath id="clip0_2229_31788">
                                                    <rect width="20" height="20" fill="white"></rect>
                                                    </clipPath>
                                                    </defs>
                                                </svg>                                                                                                                                             
                                            </a>
                                        </td>
                                      </tr>
    
                                    </tbody>
                                  </table>
                            </div>
                              <div class="row result-filters mt-4">
                                <div class="col-lg-6">
                                    <form class="form-inline">
                                        <div class="form-group">
                                            <label>Show</label>
                                            <select class="custom-select custom-count ml-2" id="exampleFormControlSelect1">
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
                                        <div class="form-group ml-3">
                                            <label class="show-result">Showing 1-10 of 18</label>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-lg-6">
                                    <nav aria-label="Page navigation example">
                                        <ul class="pagination justify-content-end">
                                          <li class="page-item disabled">
                                            <a class="page-link" href="#" tabindex="-1"><span aria-hidden="true">&#60;</span> Pre</a>
                                          </li>
                                          <li class="page-item"><a class="page-link active" href="#">1</a></li>
                                          <li class="page-item"><a class="page-link" href="#">2</a></li>
                                          <li class="page-item"><a class="page-link" href="#">3 ...</a></li>
                                          <li class="page-item"><a class="page-link" href="#">10</a></li>
                                          <li class="page-item">
                                            <a class="page-link" href="#">Next <span aria-hidden="true">&#62;</span></a>
                                          </li>
                                        </ul>
                                      </nav>
                                </div>
                            </div>
                            <hr>
                              <div class="row">
                                <div class="col-lg-6 mx-auto text-center">
                                    <div class="filter-buttons">
                                        <div class="button-item">
                                            <button class="btn btn-light-warning btn-max-50px" type="submit">
                                                <svg width="21" height="19" viewBox="0 0 21 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M20.1818 15.9773V12.6136C20.1818 12.3906 20.0932 12.1767 19.9355 12.019C19.7778 11.8613 19.5639 11.7727 19.3409 11.7727C19.1179 11.7727 18.904 11.8613 18.7463 12.019C18.5886 12.1767 18.5 12.3906 18.5 12.6136V15.9773C18.5 16.2003 18.4114 16.4142 18.2537 16.5719C18.096 16.7296 17.8821 16.8182 17.6591 16.8182H2.52273C2.2997 16.8182 2.08582 16.7296 1.92811 16.5719C1.77041 16.4142 1.68182 16.2003 1.68182 15.9773V12.6136C1.68182 12.3906 1.59322 12.1767 1.43552 12.019C1.27782 11.8613 1.06393 11.7727 0.840909 11.7727C0.617886 11.7727 0.403998 11.8613 0.246297 12.019C0.0885957 12.1767 0 12.3906 0 12.6136V15.9773C0 16.6463 0.265787 17.288 0.73889 17.7611C1.21199 18.2342 1.85366 18.5 2.52273 18.5H17.6591C18.3282 18.5 18.9698 18.2342 19.4429 17.7611C19.916 17.288 20.1818 16.6463 20.1818 15.9773ZM14.8168 11.5877L10.6123 14.9514C10.4638 15.0687 10.2801 15.1325 10.0909 15.1325C9.90169 15.1325 9.71801 15.0687 9.56954 14.9514L5.365 11.5877C5.2118 11.4431 5.11846 11.2463 5.10345 11.0361C5.08844 10.826 5.15285 10.6179 5.28394 10.453C5.41503 10.288 5.60324 10.1783 5.81135 10.1456C6.01945 10.1128 6.23228 10.1593 6.40773 10.2759L9.25 12.5464V0.840909C9.25 0.617886 9.3386 0.403998 9.4963 0.246297C9.654 0.0885957 9.86789 0 10.0909 0C10.3139 0 10.5278 0.0885957 10.6855 0.246297C10.8432 0.403998 10.9318 0.617886 10.9318 0.840909V12.5464L13.7741 10.2759C13.8588 10.196 13.9591 10.1345 14.0688 10.0954C14.1785 10.0563 14.2951 10.0403 14.4112 10.0486C14.5274 10.0569 14.6405 10.0893 14.7435 10.1436C14.8465 10.1979 14.9371 10.273 15.0096 10.3642C15.0821 10.4553 15.1348 10.5605 15.1645 10.6731C15.1941 10.7857 15.2001 10.9033 15.182 11.0183C15.1639 11.1333 15.122 11.2433 15.0592 11.3413C14.9963 11.4394 14.9138 11.5233 14.8168 11.5877Z" fill="#F39C12"/>
                                                </svg>                                                    
                                            </button>
                                        </div>
                                        <div class="button-item">
                                            <button class="btn btn-primary" type="submit">Partner Mapping Loader</button>
                                        </div>
                                        <div class="button-item">
                                            <button class="btn btn-success" type="submit">Upload Loader</button>
                                        </div>      
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>

        <section class="form-filter main-card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                          <h3>Filter</h3>
                        </div>
                            <div class="card-body">
                                <div class="form-filter-items">
                                    <form>
                                        <div class="form-row d-flex">
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">User ID <span>*</span></label>
                                                <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter" value="user_0885631">
                                            </div>
    
                                            <div class="form-group col-auto align-self-end">
                                                <button class="btn btn-primary" type="submit">Filter</button>
                                            </div>
                                            <div class="form-group col-auto align-self-end">
                                                <button class="btn btn-primary" type="submit">Reset</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                      </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="table-result h-100">
                            <div class="table-responsive">
                                <table id="example" class="table table-borderless text-center">
                                    <thead class="thead-lt-head">
                                        <th>S No.</th>
                                        <th>User ID <span><img src="@/assets/images/sort.svg"></span></th>
                                        <th>Dashboard</th>
                                        <th>New Claim Registration</th>
                                        <th>Claim Document Submissions</th>
                                        <th>Check Claims Status</th>
                                        <th>Download Reports</th>
                                        <th>Update Claim Details</th>
                                        <th>System Configuration</th>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td>01</td>
                                        <td>user_0885631</td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                      </tr>
    
                                      <tr>
                                        <td>02</td>
                                        <td>user_0885632</td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>03</td>
                                        <td>user_0885633</td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                      </tr>
    
                                      <tr>
                                        <td>04</td>
                                        <td>user_0885634</td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td>05</td>
                                        <td>user_0885635</td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                      </tr>
    
                                    </tbody>
                                  </table>
                            </div>
                              <div class="row result-filters mt-4">
                                <div class="col-lg-6">
                                    <form class="form-inline">
                                        <div class="form-group">
                                            <label>Show</label>
                                            <select class="custom-select custom-count ml-2" id="exampleFormControlSelect1">
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
                                        <div class="form-group ml-3">
                                            <label class="show-result">Showing 1-10 of 18</label>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-lg-6">
                                    <nav aria-label="Page navigation example">
                                        <ul class="pagination justify-content-end">
                                          <li class="page-item disabled">
                                            <a class="page-link" href="#" tabindex="-1"><span aria-hidden="true">&#60;</span> Pre</a>
                                          </li>
                                          <li class="page-item"><a class="page-link active" href="#">1</a></li>
                                          <li class="page-item"><a class="page-link" href="#">2</a></li>
                                          <li class="page-item"><a class="page-link" href="#">3 ...</a></li>
                                          <li class="page-item"><a class="page-link" href="#">10</a></li>
                                          <li class="page-item">
                                            <a class="page-link" href="#">Next <span aria-hidden="true">&#62;</span></a>
                                          </li>
                                        </ul>
                                      </nav>
                                </div>
                            </div>
                            <hr>
                              <div class="row">
                                <div class="col-lg-6 mx-auto text-center">
                                    <div class="filter-buttons">
                                        <div class="button-item">
                                            <button class="btn btn-light-warning btn-max-50px" type="submit">
                                                <svg width="21" height="19" viewBox="0 0 21 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M20.1818 15.9773V12.6136C20.1818 12.3906 20.0932 12.1767 19.9355 12.019C19.7778 11.8613 19.5639 11.7727 19.3409 11.7727C19.1179 11.7727 18.904 11.8613 18.7463 12.019C18.5886 12.1767 18.5 12.3906 18.5 12.6136V15.9773C18.5 16.2003 18.4114 16.4142 18.2537 16.5719C18.096 16.7296 17.8821 16.8182 17.6591 16.8182H2.52273C2.2997 16.8182 2.08582 16.7296 1.92811 16.5719C1.77041 16.4142 1.68182 16.2003 1.68182 15.9773V12.6136C1.68182 12.3906 1.59322 12.1767 1.43552 12.019C1.27782 11.8613 1.06393 11.7727 0.840909 11.7727C0.617886 11.7727 0.403998 11.8613 0.246297 12.019C0.0885957 12.1767 0 12.3906 0 12.6136V15.9773C0 16.6463 0.265787 17.288 0.73889 17.7611C1.21199 18.2342 1.85366 18.5 2.52273 18.5H17.6591C18.3282 18.5 18.9698 18.2342 19.4429 17.7611C19.916 17.288 20.1818 16.6463 20.1818 15.9773ZM14.8168 11.5877L10.6123 14.9514C10.4638 15.0687 10.2801 15.1325 10.0909 15.1325C9.90169 15.1325 9.71801 15.0687 9.56954 14.9514L5.365 11.5877C5.2118 11.4431 5.11846 11.2463 5.10345 11.0361C5.08844 10.826 5.15285 10.6179 5.28394 10.453C5.41503 10.288 5.60324 10.1783 5.81135 10.1456C6.01945 10.1128 6.23228 10.1593 6.40773 10.2759L9.25 12.5464V0.840909C9.25 0.617886 9.3386 0.403998 9.4963 0.246297C9.654 0.0885957 9.86789 0 10.0909 0C10.3139 0 10.5278 0.0885957 10.6855 0.246297C10.8432 0.403998 10.9318 0.617886 10.9318 0.840909V12.5464L13.7741 10.2759C13.8588 10.196 13.9591 10.1345 14.0688 10.0954C14.1785 10.0563 14.2951 10.0403 14.4112 10.0486C14.5274 10.0569 14.6405 10.0893 14.7435 10.1436C14.8465 10.1979 14.9371 10.273 15.0096 10.3642C15.0821 10.4553 15.1348 10.5605 15.1645 10.6731C15.1941 10.7857 15.2001 10.9033 15.182 11.0183C15.1639 11.1333 15.122 11.2433 15.0592 11.3413C14.9963 11.4394 14.9138 11.5233 14.8168 11.5877Z" fill="#F39C12"/>
                                                </svg>                                                    
                                            </button>
                                        </div>
                                        <div class="button-item">
                                            <button class="btn btn-primary" type="submit">Access Loader Mapping</button>
                                        </div>
                                        <div class="button-item">
                                            <button class="btn btn-success" type="submit">Upload Loader</button>
                                        </div>      
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'SystemConfiguration'
    }
</script>
