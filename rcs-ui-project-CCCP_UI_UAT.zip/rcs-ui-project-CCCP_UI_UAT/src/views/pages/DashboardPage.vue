<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <h1 class="page-title">
                        Overview
                    </h1>
                </div>
            </div>
        </section>

        <section class="dashboard main-card">
            <div class="row">
                <div class="col-lg-7 col-md-12 col-sm-12 mb-20">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Claim Summary</h3>
                        </div>
                            <div class="card-body pt-5">
                                    <div class="row">
                                            <div class="col-lg-4 col-md-12 col-sm-12">
                                            <div class="claim-summary1">
                                                <div class="summary-arrow1 left">
                                                    <div class="card claim-summary-card1 addBorder">
                                                        <div class="card-body claim-summary-content1">
                                                            <div class="claim-icon-text1 d-flex align-items-center">
                                                                <div class="claim-icon">
                                                                    <img src="@/assets/images/claim-add.svg" alt="claim-add">
                                                                </div>
                                                                <p>Total No. of Registered Claims</p>
                                                            </div>
                                                            <div class="claim-value1 mt-3">
                                                                <h3>2188</h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12 col-sm-12">
                                            <div class="claim-summary2">
                                                <div class="summary-arrow2 left">
                                                    <div class="card claim-summary-card2 addBorder">
                                                        <div class="card-body claim-summary-content2">
                                                            <div class="claim-icon-text2 d-flex align-items-center">
                                                                <div class="claim-icon">
                                                                    <img src="@/assets/images/claim-file.svg" alt="claim-add">
                                                                </div>
                                                                <p>Total No. of Doc Uploaded Claims</p>
                                                            </div>
                                                            <div class="claim-value2 mt-3">
                                                                <h3>131</h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12 col-sm-12">
                                            <div class="claim-summary3">
                                                <div class="summary-arrow3 left">
                                                    <div class="card claim-summary-card3 addBorder">
                                                        <div class="card-body claim-summary-content3">
                                                            <div class="claim-icon-text3 d-flex align-items-center">
                                                                <div class="claim-icon">
                                                                    <img src="@/assets/images/claim-document.svg" alt="claim-add">
                                                                </div>
                                                                <p>Total No. of Updated Claims</p>
                                                            </div>
                                                            <div class="claim-value3 mt-3">
                                                                <h3>26</h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                    </div>
                </div>
                <div class="col-lg-5 col-md-12 col-sm-12 mb-20">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>User</h3>
                        </div>
                            <div class="card-body pt-5">
                                <div class="row">
                                    <div class="col-lg-5 col-md-12 col-sm-12">
                                        <div class="user-count">
                                            <div class="card user-count-card">
                                                <div class="card-body">
                                                    <div class="semi-circle">
                                                        <p>Total No. of Users</p>
                                                    </div>
                                                    <div class="user-count-content">
                                                        <h3>118</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-7 col-md-12 col-sm-12">
                                        <div class="user-status">
                                            <div class="card user-status-card">
                                                <div class="card-body">
                                                    <div class="user-status-content d-flex align-items-center">
                                                        <div class="user-status-text">
                                                            <h3>98</h3>
                                                            <p>Active Users</p>
                                                        </div>
                                                        <div class="user-status-progress1">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                    <div class="user-status-content d-flex align-items-center">
                                                        <div class="user-status-text">
                                                            <h3>20</h3>
                                                            <p>Inactive Users</p>
                                                        </div>
                                                        <div class="user-status-progress2">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="reports main-card">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-sm-12 mb-20">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Reports</h3>
                        </div>
                        <div class="card-body pt-5">
                            <div class="row">
                                <div class="col-lg-6 col-md-11 col-sm-11 col-11 mx-auto">
                                    <div class="report-card report-card-bg-1">
                                        <div class="card">
                                            <div class="card-header">
                                                <div class="report-header">
                                                    <img src="@/assets/images/reports-header1.png" class="img-fluid" alt="">
                                                </div>
                                            </div>
                                            <div class="card-body report-body pt-2 pb-4">
                                                <h2>281</h2>
                                                <p>Total No. of Outstanding Claims</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">
                                    <div class="report-card report-card-bg-2">
                                        <div class="card">
                                            <div class="card-header">
                                                <div class="report-header">
                                                    <img src="@/assets/images/reports-header2.png" class="img-fluid" alt="">
                                                </div>
                                            </div>
                                            <div class="card-body report-body pt-2 pb-4">
                                                <h2>102</h2>
                                                <p>Total No. of Settled Claims</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">
                                    <div class="report-card report-card-bg-3">
                                        <div class="card">
                                            <div class="card-header">
                                                <div class="report-header">
                                                    <img src="@/assets/images/reports-header3.png" class="img-fluid" alt="">
                                                </div>
                                            </div>
                                            <div class="card-body report-body pt-2 pb-4">
                                                <h2>130</h2>
                                                <p>Total No. of Detailed Information Report</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">
                                    <div class="report-card report-card-bg-4">
                                        <div class="card">
                                            <div class="card-header">
                                                <div class="report-header">
                                                    <img src="@/assets/images/reports-header4.png" class="img-fluid" alt="">
                                                </div>
                                            </div>
                                            <div class="card-body report-body pt-2 pb-4">
                                                <h2>88</h2>
                                                <p>Total No. of Claim Payment Report</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-12 col-sm-12 mb-20">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Claim Analysis</h3>
                        </div>
                        <div class="card-body pt-3">
                            <div class="chart-header">
                                <div class="row d-flex align-items-center mb-20">
                                    <div class="col-lg-3">
                                        <div class="chart-text d-flex align-items-center">
                                            <div class="reg-legend"></div>
                                            <p>Registered Claim</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-9 align-self-end">
                                        <div class="chart-filter d-flex align-items-center justify-content-end">
                                            
                                                <div class="row align-items-center">
                                                    <div class="col-lg-8">
                                                        <div class="rounded-form">
                                                            <div class="input-group">
                                                                <div class="input-group-prepend">
                                                                <span class="input-group-text">
                                                                    <img src="@/assets/images/icons/calendar.svg">
                                                                </span>
                                                                </div>
                                                                <input type="text" class="form-control" placeholder="From" >
                                                            </div>
                                                            <img src="@/assets/images/arrow-right.svg" alt="">
                                                            <div class="input-group">
                                                                <div class="input-group-prepend">
                                                                <span class="input-group-text">
                                                                    <img src="@/assets/images/icons/calendar.svg">
                                                                </span>
                                                                </div>
                                                                <input type="text" class="form-control" placeholder="To" >
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-4">
                                                        <div class="row align-items-center">
                                                            <div class="col-lg-12">
                                                                <div class="rounded-form">
                                                                    <div class="form-group w-100">
                                                                        <select class="form-control">
                                                                        <option>All Claims</option>
                                                                        <option>Claims 1</option>
                                                                        <option>Claims 2</option>
                                                                        <option>Claims 3</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="chart"></div>
                            <div class="chart-year">
                                <span>2022</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'DashboardPage',
    }
</script>

