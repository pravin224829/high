<template>
    <div>
        <!-- Flash Message -->
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <h1 class="page-title mb-3">
                        Home
                    </h1>
                    <div class="flash-message-container">
                        <div class="flash-heading" id="flash">
                            <div class="flash-title">
                                <h3>Flash Message</h3>
                            </div>
                            <div class="flash-title-border1"></div>
                            <div class="flash-title-border2"></div>
                        </div>
                        <div class="flash-message">
                            <div><p><span>5 mins ago</span><span> - </span>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p></div>
                            <div><p><span>1 hr ago</span><span> - </span>There are many variations of passages of Lorem Ipsum available, but the majority</p></div>
                            <div><p><span>18 hrs ago</span><span> - </span>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical</p></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- User Hierarchy -->
        <section class="user-hierarchy main-card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h3>User Hierarchy</h3>
                        </div>
                        <div class="card-body">
                            <div class="user-tree-container">
                                <div class="level-group">
                                    <div class="row">
                                        <div class="col-lg-3 vertical-line top">
                                            <div class="tree-round">
                                                <div class="tree-round-inner">
                                                    <img src="assets/images/tree-icon.svg" alt="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row wrap align-items-end mb-5">
                                        <div class="col-lg-3 col-md-12 vertical-line top">
                                            <div class="dot">
                                                <div class="top-level-items top-level1 left">
                                                    <div>
                                                        <div class="level-sno">1</div>
                                                    </div>
                                                    <p>Top Management : ITC of India Limited</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Shri Dinesh Kumar Khara</p>
                                                        <p>Chairman, State Bank of India</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Shri Ashwini Kumar Tewari</p>
                                                        <p>Managing Director (IB, T &amp; S), State Bank of India</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Shri T K Kurien</p>
                                                        <p>Nominee Director of Napean Opportunities LLP</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row wrap align-items-end mb-5">
                                        <div class="col-lg-3 col-md-12 vertical-line top">
                                            <div class="dot">
                                                <div class="top-level-items top-level2 left">
                                                    <div>
                                                        <div class="level-sno">2</div>
                                                    </div>
                                                    <p>Bagic Client Relationship Team</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Smt. Saloni Narayan</p>
                                                        <p>Deputy Managing Director (Retail Business)</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Shri K. K. Mishra</p>
                                                        <p>Independent Director</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Shri Prakash Chandra Kandpal</p>
                                                        <p>Managing Director &amp; Chief Executive Officer</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row wrap align-items-end mb-5">
                                        <div class="col-lg-3 col-md-12 vertical-line top">
                                            <div class="dot">
                                                <div class="top-level-items top-level3 left">
                                                    <div>
                                                        <div class="level-sno">3</div>
                                                    </div>
                                                    <p>Bagic Zonal Claims Authorities</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Shri Mahender Kumar Garg</p>
                                                        <p>Independent Director</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Shri D. Sundaram</p>
                                                        <p>Independent Director</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Dr. Ashima Goyal</p>
                                                        <p>Independent Director</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row wrap align-items-end mb-5">
                                        <div class="col-lg-3 col-md-12 vertical-line top">
                                            <div class="dot">
                                                <div class="top-level-items top-level4 left">
                                                    <div>
                                                        <div class="level-sno">4</div>
                                                    </div>
                                                    <p>Bagic National Claims Authorities</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Smt. Saloni Narayan</p>
                                                        <p>Deputy Managing Director (Retail Business)</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Shri K. K. Mishra</p>
                                                        <p>Independent Director</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Shri Prakash Chandra Kandpal</p>
                                                        <p>Managing Director &amp; Chief Executive Officer</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row wrap align-items-end mb-5">
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="top-level-items top-level5 left">
                                                    <div>
                                                        <div class="level-sno">5</div>
                                                    </div>
                                                    <p>Proclaim Surveyors, Adjustors Team : Empanelled Surveyor</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Smt. Saloni Narayan</p>
                                                        <p>Deputy Managing Director (Retail Business)</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Shri K. K. Mishra</p>
                                                        <p>Independent Director</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-12">
                                            <div class="dot">
                                                <div class="level-user text-center">
                                                    <img src="@/assets/images/user-profile-image.png" class="te" alt="User">
                                                    <div class="user-details">
                                                        <p>Shri Prakash Chandra Kandpal</p>
                                                        <p>Managing Director &amp; Chief Executive Officer</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Service Level Agreements -->
        <section class="service-level main-card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h3>Service Level Agreements</h3>
                        </div>
                        <div class="card-body">
                            <div class="service-container">
                                <div class="row d-flex justify-content-center">
                                    <div class="col-lg-4 rt-border">
                                        <a class="service-link1" href="#">
                                            <div class="service-item1">
                                                <div class="icon-text">
                                                    <div class="service-icon">
                                                        <svg width="27" height="30" viewBox="0 0 27 30" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path
                                                                d="M5.08333 12.7167H17.9167C18.0846 12.7167 18.2457 12.6499 18.3645 12.5312C18.4833 12.4124 18.55 12.2513 18.55 12.0833C18.55 11.9154 18.4833 11.7543 18.3645 11.6355C18.2457 11.5167 18.0846 11.45 17.9167 11.45H5.08333C4.91536 11.45 4.75427 11.5167 4.6355 11.6355C4.51673 11.7543 4.45 11.9154 4.45 12.0833C4.45 12.2513 4.51673 12.4124 4.6355 12.5312C4.75427 12.6499 4.91536 12.7167 5.08333 12.7167Z"
                                                                fill="#00CEC9" stroke="#00CEC9" stroke-width="0.1" />
                                                            <path
                                                                d="M14.4167 14.366H5.08333C4.91536 14.366 4.75427 14.4327 4.6355 14.5515C4.51673 14.6703 4.45 14.8314 4.45 14.9993C4.45 15.1673 4.51673 15.3284 4.6355 15.4472C4.75427 15.566 4.91536 15.6327 5.08333 15.6327H14.4167C14.5846 15.6327 14.7457 15.566 14.8645 15.4472C14.9833 15.3284 15.05 15.1673 15.05 14.9993C15.05 14.8314 14.9833 14.6703 14.8645 14.5515C14.7457 14.4327 14.5846 14.366 14.4167 14.366Z"
                                                                fill="#00CEC9" stroke="#00CEC9" stroke-width="0.1" />
                                                            <path
                                                                d="M5.08333 9.80065H17.9167C18.0846 9.80065 18.2457 9.73393 18.3645 9.61515C18.4833 9.49638 18.55 9.33529 18.55 9.16732C18.55 8.99935 18.4833 8.83826 18.3645 8.71948C18.2457 8.60071 18.0846 8.53398 17.9167 8.53398H5.08333C4.91536 8.53398 4.75427 8.60071 4.6355 8.71948C4.51673 8.83826 4.45 8.99935 4.45 9.16732C4.45 9.33529 4.51673 9.49638 4.6355 9.61515C4.75427 9.73392 4.91536 9.80065 5.08333 9.80065Z"
                                                                fill="#00CEC9" stroke="#00CEC9" stroke-width="0.1" />
                                                            <path
                                                                d="M5.08333 6.88268H17.9167C18.0846 6.88268 18.2457 6.81596 18.3645 6.69718C18.4833 6.57841 18.55 6.41732 18.55 6.24935C18.55 6.08138 18.4833 5.92029 18.3645 5.80151C18.2457 5.68274 18.0846 5.61602 17.9167 5.61602H5.08333C4.91536 5.61602 4.75427 5.68274 4.6355 5.80151C4.51673 5.92029 4.45 6.08138 4.45 6.24935C4.45 6.41732 4.51673 6.57841 4.6355 6.69718C4.75427 6.81596 4.91536 6.88268 5.08333 6.88268Z"
                                                                fill="#00CEC9" stroke="#00CEC9" stroke-width="0.1" />
                                                            <path
                                                                d="M13.25 24.2827C13.2288 24.2827 13.203 24.2726 13.1695 24.2443C13.136 24.2161 13.1001 24.1742 13.0593 24.1203C13.0282 24.0791 12.9957 24.0328 12.9603 23.9823C12.9494 23.9668 12.9383 23.951 12.9268 23.9347C12.8784 23.8661 12.8251 23.7922 12.7654 23.718C12.5262 23.4208 12.1808 23.116 11.6167 23.116C11.0525 23.116 10.7058 23.4208 10.4651 23.7179C10.405 23.792 10.3514 23.866 10.3026 23.9346C10.2911 23.9508 10.2798 23.9667 10.2689 23.9822C10.2332 24.0326 10.2005 24.079 10.1692 24.1201C10.1282 24.1741 10.092 24.2161 10.0584 24.2443C10.0247 24.2725 9.99871 24.2827 9.9775 24.2827C9.95635 24.2827 9.9306 24.2726 9.89728 24.2444C9.86403 24.2162 9.8283 24.1744 9.78781 24.1204C9.75693 24.0792 9.72467 24.0329 9.68953 23.9825C9.67873 23.967 9.66766 23.9511 9.65628 23.9349C9.60821 23.8662 9.55526 23.7923 9.49592 23.7181C9.25811 23.4209 8.91423 23.116 8.35 23.116C7.78588 23.116 7.4391 23.4207 7.19912 23.7179C7.12497 23.8098 7.05826 23.9047 6.99948 23.9884C6.96521 24.0371 6.93363 24.0821 6.90485 24.1203C6.8642 24.1744 6.82844 24.2163 6.79534 24.2445C6.76207 24.2728 6.73685 24.2827 6.71667 24.2827C6.69651 24.2827 6.6714 24.2729 6.63831 24.2446C6.60537 24.2164 6.56981 24.1745 6.52938 24.1204C6.50093 24.0824 6.46976 24.0378 6.43593 23.9894C6.3773 23.9055 6.3107 23.8102 6.23645 23.718C5.99711 23.4207 5.65032 23.116 5.08333 23.116C4.91536 23.116 4.75427 23.1827 4.6355 23.3015C4.51673 23.4203 4.45 23.5814 4.45 23.7493C4.45 23.9173 4.51673 24.0784 4.6355 24.1972C4.75427 24.316 4.91536 24.3827 5.08333 24.3827C5.10449 24.3827 5.13023 24.3928 5.16357 24.421C5.19683 24.4491 5.23259 24.491 5.27313 24.545C5.30385 24.5859 5.33594 24.6319 5.37089 24.6819C5.38192 24.6978 5.39324 24.714 5.40489 24.7306C5.45306 24.7992 5.50616 24.8731 5.56569 24.9473C5.80429 25.2446 6.14963 25.5493 6.71667 25.5493C7.2837 25.5493 7.62905 25.2446 7.86764 24.9473C7.92718 24.8731 7.98027 24.7992 8.02844 24.7306C8.04009 24.714 8.05141 24.6978 8.06245 24.6819C8.09739 24.6319 8.12948 24.5859 8.16021 24.545C8.20074 24.491 8.2365 24.4491 8.26977 24.421C8.3031 24.3928 8.32885 24.3827 8.35 24.3827C8.37115 24.3827 8.3969 24.3928 8.43022 24.421C8.46347 24.4491 8.4992 24.491 8.53969 24.545C8.57057 24.5861 8.60283 24.6325 8.63797 24.6829C8.64877 24.6984 8.65984 24.7143 8.67122 24.7305C8.71929 24.7991 8.77224 24.8731 8.83158 24.9473C9.06939 25.2445 9.41328 25.5493 9.9775 25.5493C10.5416 25.5493 10.8884 25.2446 11.1291 24.9475C11.1891 24.8733 11.2428 24.7994 11.2916 24.7308C11.3031 24.7145 11.3143 24.6987 11.3253 24.6832C11.3609 24.6327 11.3937 24.5864 11.425 24.5452C11.466 24.4912 11.5022 24.4493 11.5358 24.4211C11.5695 24.3928 11.5955 24.3827 11.6167 24.3827C11.6378 24.3827 11.6636 24.3928 11.6969 24.421C11.7302 24.4491 11.7659 24.491 11.8065 24.545C11.8372 24.5859 11.8693 24.6319 11.9042 24.6819C11.9153 24.6978 11.9266 24.714 11.9382 24.7306C11.9864 24.7992 12.0395 24.8731 12.099 24.9473C12.3376 25.2446 12.683 25.5493 13.25 25.5493C13.418 25.5493 13.5791 25.4826 13.6978 25.3639C13.8166 25.2451 13.8833 25.084 13.8833 24.916C13.8833 24.748 13.8166 24.587 13.6978 24.4682C13.5791 24.3494 13.418 24.2827 13.25 24.2827Z"
                                                                fill="#00CEC9" stroke="#00CEC9" stroke-width="0.1" />
                                                            <path
                                                                d="M15.9709 24.2778L15.9709 24.2778L16.6042 24.8992V24.9492H16.6043H16.6044C16.6689 24.9492 16.7165 24.9492 16.7953 24.9155C16.8693 24.8839 16.9723 24.8221 17.1542 24.7041C17.28 24.6225 17.4453 24.5128 17.6671 24.3656C17.7678 24.2988 17.8802 24.2242 18.0058 24.1411C18.4083 23.8745 18.9474 23.5191 19.6764 23.0453L19.6765 23.0452C19.6792 23.0435 19.6818 23.0418 19.6844 23.0401C19.7184 23.0179 19.7473 22.9991 19.7824 22.9582C19.8183 22.9164 19.8608 22.8518 19.9299 22.7349C20.0105 22.5987 20.1302 22.3868 20.3213 22.048C20.4397 21.8383 20.5854 21.58 20.7663 21.261L20.7832 27.7833H2.21667V3.91667C2.21667 3.4658 2.39577 3.0334 2.71459 2.71459C3.0334 2.39577 3.4658 2.21667 3.91667 2.21667H21.316C21.145 2.44404 21.0215 2.63082 20.9358 2.90028C20.8409 3.19886 20.7932 3.59614 20.771 4.26135C20.7459 5.01131 20.753 6.10917 20.764 7.80242C20.7725 9.10996 20.7833 10.7725 20.7833 12.9041L16.2519 20.7555C16.2518 20.7556 16.2518 20.7557 16.2517 20.7558C16.2489 20.7607 16.2461 20.7654 16.2433 20.77C16.2227 20.8043 16.2054 20.8333 16.1918 20.8964C16.1774 20.9631 16.1663 21.0709 16.1518 21.2783C16.1376 21.4805 16.12 21.7812 16.0933 22.2372C16.065 22.7203 16.0264 23.3779 15.9709 24.2778ZM25.34 10.845L25.34 10.845L24.636 12.0672L23.234 11.2424L23.91 10.02C23.91 10.0199 23.9101 10.0198 23.9102 10.0197C24.0196 9.83019 24.1998 9.69191 24.4111 9.63521C24.6225 9.57848 24.8479 9.60807 25.0375 9.71748C25.2272 9.82688 25.3656 10.0071 25.4223 10.2186C25.479 10.43 25.4494 10.6554 25.34 10.845ZM26.0833 6.88333C26.2513 6.88333 26.4124 6.81661 26.5312 6.69783C26.6499 6.57906 26.7167 6.41797 26.7167 6.25V3.91667C26.7167 3.12986 26.4041 2.37527 25.8478 1.81892C25.2914 1.26256 24.5368 0.95 23.75 0.95H3.91667C3.12986 0.95 2.37527 1.26256 1.81892 1.81892C1.26256 2.37527 0.95 3.12986 0.95 3.91667V28.4167C0.95 28.5846 1.01673 28.7457 1.1355 28.8645C1.25427 28.9833 1.41536 29.05 1.58333 29.05H21.4167C21.5846 29.05 21.7457 28.9833 21.8645 28.8645C21.9833 28.7457 22.05 28.5846 22.05 28.4167V19.0968L26.4352 11.526C26.4353 11.5258 26.4354 11.5257 26.4355 11.5255C26.5803 11.2876 26.6762 11.023 26.7174 10.7475C26.7586 10.4718 26.7443 10.1907 26.6753 9.92057C26.6063 9.65047 26.4841 9.39688 26.3157 9.17471C26.1473 8.95255 25.9362 8.76628 25.6948 8.62686C25.4534 8.48743 25.1866 8.39767 24.91 8.36285C24.6334 8.32802 24.3527 8.34884 24.0842 8.42407C23.8158 8.49929 23.5651 8.62742 23.3469 8.80091C23.1289 8.97425 22.9478 9.18936 22.814 9.43365C22.8139 9.43388 22.8138 9.43411 22.8136 9.43434L22.05 10.733V6.88333H26.0833ZM25.45 3.91667V5.61667H22.05V3.91667C22.05 3.4658 22.2291 3.0334 22.5479 2.71459C22.8667 2.39577 23.2991 2.21667 23.75 2.21667C24.2009 2.21667 24.6333 2.39577 24.9521 2.71459C25.2709 3.0334 25.45 3.4658 25.45 3.91667ZM17.2901 23.099L17.3799 21.6148C17.8303 21.6934 18.2384 21.9293 18.5314 22.2803L17.2901 23.099ZM23.9791 13.1866L19.3064 21.253C18.9104 20.8572 18.4172 20.5727 17.8763 20.428L22.5491 12.3616L23.9791 13.1866Z"
                                                                fill="#00CEC9" stroke="#00CEC9" stroke-width="0.1" />
                                                        </svg>
                                                    </div>
                                                    <h3>Service Level Agreement</h3>
                                                </div>
                                            </div>
                                            <div class="ribbon">
                                                <div class="text">
                                                    <p class="bold">Download</p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4 rt-border">
                                        <a class="service-link2" href="#">
                                            <div class="service-item2">
                                                <div class="icon-text">
                                                    <div class="service-icon">
                                                        <svg width="30" height="30" viewBox="0 0 30 30" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path
                                                                d="M13.9636 17.4302C17.2454 15.1835 18.1311 10.6317 15.942 7.26363C13.753 3.89539 9.31787 2.98638 6.03624 5.23308C2.75461 7.47978 1.86871 12.0316 4.05778 15.3996C4.58045 16.2037 5.25285 16.8938 6.03624 17.4302C2.50176 18.2976 0.00641956 21.5372 0 25.267C0 25.6718 0.319735 26 0.714227 26H19.2856C19.6801 26 20 25.6718 20 25.267C19.9934 21.5372 17.498 18.2976 13.9636 17.4302ZM4.28577 11.3383C4.28577 8.09931 6.84407 5.47367 10 5.47367C13.1557 5.47367 15.7142 8.09931 15.7142 11.3383C15.7142 14.5771 13.1559 17.203 10 17.203C6.84552 17.1994 4.28909 14.5759 4.28577 11.3383ZM1.46759 24.5337C1.83578 21.1963 4.58459 18.6733 7.85711 18.6691H12.1427C15.4154 18.6733 18.1642 21.1963 18.5322 24.5337H1.46759Z"
                                                                fill="#0984E3" />
                                                            <path
                                                                d="M23.474 12.6455H29.2109C29.6469 12.6455 30.0003 12.2921 30.0003 11.856C30.0003 11.42 29.6469 11.0664 29.2109 11.0664H23.474C23.038 11.0664 22.6846 11.42 22.6846 11.856C22.6846 12.2921 23.038 12.6455 23.474 12.6455Z"
                                                                fill="#0984E3" />
                                                            <path
                                                                d="M29.2109 14.2246H23.474C23.038 14.2246 22.6846 14.578 22.6846 15.014C22.6846 15.45 23.038 15.8034 23.474 15.8034H29.2109C29.6469 15.8034 30.0003 15.45 30.0003 15.014C30.0003 14.578 29.6469 14.2246 29.2109 14.2246Z"
                                                                fill="#0984E3" />
                                                            <path
                                                                d="M29.2109 17.3828H23.474C23.038 17.3828 22.6846 17.7362 22.6846 18.1722C22.6846 18.6082 23.038 18.9616 23.474 18.9616H29.2109C29.6469 18.9616 30.0003 18.6082 30.0003 18.1722C30.0003 17.7362 29.6469 17.3828 29.2109 17.3828Z"
                                                                fill="#0984E3" />
                                                        </svg>
                                                    </div>
                                                    <h3>Service Level Agreement</h3>
                                                </div>
                                            </div>
                                            <div class="ribbon">
                                                <div class="text">
                                                    <p class="bold">Download</p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4">
                                        <a class="service-link3" href="#">
                                            <div class="service-item3">
                                                <div class="icon-text">
                                                    <div class="service-icon">
                                                        <svg width="30" height="30" viewBox="0 0 30 30" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path
                                                                d="M9.61719 24.6992V20.1289C9.61719 19.7082 9.27614 19.3672 8.85547 19.3672C8.4348 19.3672 8.09375 19.7082 8.09375 20.1289V24.6992C8.09375 25.1199 8.4348 25.4609 8.85547 25.4609C9.27614 25.4609 9.61719 25.1199 9.61719 24.6992Z"
                                                                fill="#D63031" />
                                                            <path
                                                                d="M8.85547 18.3516C9.27615 18.3516 9.61719 18.0105 9.61719 17.5898C9.61719 17.1692 9.27615 16.8281 8.85547 16.8281C8.43478 16.8281 8.09375 17.1692 8.09375 17.5898C8.09375 18.0105 8.43478 18.3516 8.85547 18.3516Z"
                                                                fill="#D63031" />
                                                            <path
                                                                d="M27.6754 7.30136L22.5974 2.22313C22.4546 2.08023 22.2608 2 22.0588 2H10.3789C9.11887 2 8.09375 3.02512 8.09375 4.28516V14.3316C4.67079 14.7118 2 17.6219 2 21.1445C2 24.9246 5.07536 28 8.85547 28H25.6133C26.8733 28 27.8984 26.9749 27.8984 25.7148V7.84C27.8984 7.63794 27.8182 7.44426 27.6754 7.30136ZM22.8203 4.60066L25.2977 7.07812H22.8203V4.60066ZM3.52344 21.1445C3.52344 18.2044 5.91539 15.8125 8.85547 15.8125C11.7956 15.8125 14.1875 18.2044 14.1875 21.1445C14.1875 24.0846 11.7956 26.4766 8.85547 26.4766C5.91539 26.4766 3.52344 24.0846 3.52344 21.1445ZM25.6133 26.4766H13.1591C14.5283 25.3693 15.464 23.7466 15.6684 21.9062H23.582C24.0027 21.9062 24.3438 21.5652 24.3438 21.1445C24.3438 20.7239 24.0027 20.3828 23.582 20.3828H15.6684C15.5442 19.2646 15.1502 18.2267 14.5528 17.3359H23.582C24.0027 17.3359 24.3438 16.9949 24.3438 16.5742C24.3438 16.1535 24.0027 15.8125 23.582 15.8125H13.1591C12.1678 15.0109 10.9496 14.4796 9.61719 14.3316V4.28516C9.61719 3.86514 9.95889 3.52344 10.3789 3.52344H21.2969V7.83984C21.2969 8.26052 21.6379 8.60156 22.0586 8.60156H26.375V25.7148C26.375 26.1349 26.0333 26.4766 25.6133 26.4766Z"
                                                                fill="#D63031" />
                                                            <path
                                                                d="M23.582 11.2422H12.4102C11.9895 11.2422 11.6484 11.5832 11.6484 12.0039C11.6484 12.4246 11.9895 12.7656 12.4102 12.7656H23.582C24.0027 12.7656 24.3438 12.4246 24.3438 12.0039C24.3438 11.5832 24.0027 11.2422 23.582 11.2422Z"
                                                                fill="#D63031" />
                                                        </svg>
                                                    </div>
                                                    <h3>Service Level Agreement</h3>
                                                </div>
                                            </div>
                                            <div class="ribbon">
                                                <div class="text">
                                                    <p class="bold">Download</p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        
        
    </div>
</template>

<script>
    export default {
        name: 'HomePage'
    }
</script>