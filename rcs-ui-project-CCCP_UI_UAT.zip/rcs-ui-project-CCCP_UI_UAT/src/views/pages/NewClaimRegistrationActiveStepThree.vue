<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <div class="row">
                        <div class="col-lg-6">
                            <h1 class="page-title">
                                New Claim Registration
                            </h1>
                        </div>
                        <div class="col-lg-6">
                            <ul class="breadcrumbs float-right">
                                <li><a href="#">List of Policies > ></a></li>
                                <li class="active">New Claim Registration</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="claim-details main-card">
            <div class="row">
                <div class="col-lg-3">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Policy Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="claim-details-aside">
                                <ul class="claim-detail-item">
                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/policy-holder-name.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Policy Holder Name
                                                <span>Arnold Schwarzenegger</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/policy-number.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Policy Number
                                                <span>OG-20-1101-4001-00000088</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/policy-status.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Policy Status
                                                <span><div class="badge badge-success">Active</div></span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/calendar.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Inception Date
                                                <span>11-01-2020</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/calendar.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Expiry Date
                                                <span>10-01-2021</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/policy-description.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Product Description
                                                <span>Lorem Ipsum is simply dummy text of the
                                                    printing & typesetting industry. Lorem Ipsum
                                                    has been the standard dummy text ever.</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/policy-imd-channel.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                IMD Channel
                                                <span>IMD1023</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/policy-sum-insured.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Sum Insured
                                                <span>₹ 9,60,000</span>
                                            </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-9">
                    <div class="new-claim-reg-step">
                        <div class="add-policy-detail h-100">
                            <div class="policy-detail-bg">
                                <div class="steps d-flex justify-content-center flex-lg-row flex-column">
                                    <div class="step-1 completed d-flex">
                                        <div class="img-ico-parent">
                                            <div class="step-img">
                                                <img src="@/assets/images/icons/tick.svg" alt="Icon">
                                            </div>
                                        </div>
                                        <div class="step-detail">
                                            <p>Step 1</p>
                                            <h6>Insured Details</h6>
                                        </div>
                                    </div>
                                    <div class="step-1 completed d-flex">
                                        <div class="img-ico-parent">
                                            <div class="step-img">
                                                <img src="@/assets/images/icons/tick.svg" alt="Icon">
                                            </div>
                                        </div>
                                        <div class="step-detail">
                                            <p>Step 2</p>
                                            <h6>Claim Details</h6>
                                        </div>
                                    </div>
                                    <div class="step-1 active d-flex">
                                        <div class="img-ico-parent">
                                            <div class="step-img">
                                                <img src="@/assets/images/icons/step-3-white.svg" alt="Icon">
                                            </div>
                                        </div>
                                        <div class="step-detail">
                                            <p>Step 3</p>
                                            <h6>Claimant Details</h6>
                                        </div>
                                    </div>
                                </div>
                        <div class="policy-input step-3 common-form">
                            <form>
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Name</label>
                                            <input type="text" class="form-control" placeholder="Enter" value="Robert De Niro">
                                        </div>
                                    </div>

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Mobile Number</label>
                                            <input type="text" class="form-control" placeholder="Enter">
                                        </div>
                                    </div>

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Email ID</label>
                                            <input type="text" class="form-control" placeholder="Enter">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-group check w-100">
                                            <div class="row align-items-center">
                                                <input class="form-check-input" type="checkbox" id="sameAsInsured">
                                                <label class="form-check-label insured-label" for="sameAsInsured">Same as Insured’s Details</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="disclamier mb-5 form-filter">
                                    <div class="row">
                                        <label class="switch">
                                            <input type="checkbox">
                                            <span class="slider round"></span> 
                                        </label>
                                        <p class="disclamier-p">Disclamier</p>
                                     </div>
                                     <p>I have understood the claim process and all the information being provided with the claim intimation is true / correct. I shall comply to claim process as stipulated by the company and submit all
                                        required documents in support of the claim.</p>
                                </div>
                                
                                 
                            </form>
                                <div class="step-button mx-auto">
                                    <router-link to="/new-claim-registration-active-step-two" class="btn btn-primary mr-2">Previous</router-link>
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#newClaimModal">
                                        Submit
                                    </button>
                                </div>
                                <!-- New claim Registration Modal -->
                                <div class="modal fade bd-example-modal-lg" id="newClaimModal" tabindex="-1" role="dialog" aria-labelledby="newClaimModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                                    <div class="modal-content common-modal">
                                        <div class="modal-body text-center">
                                            <img src="@/assets/images/modal-check.svg" alt="check">
                                            <h1>Commercial Claim Intimation Completed</h1>
                                            <p class="modal-para mb-4">Thank You, <span> Medico Electrodes International Limited</span>, your claim has been intimated successfully,</p>
                                            <div class="model-ref-num mb-4">
                                                <p>Your reference number <span class="ref-num">OC-22-1501-1018-00000088</span> <small>Please use this reference number for further communication</small></p> 
                                            </div>
                                            <router-link to="/dashboard" class="btn btn-primary mr-3">Home</router-link>
                                            <router-link to="/claim-document-upload-list" class="btn btn-primary">Upload Document</router-link>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                        </div>
                        </div>
                        </div>
                    </div>
                </div>

                </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'NewClaimRegistrationActiveStepThree'
    }
</script>
