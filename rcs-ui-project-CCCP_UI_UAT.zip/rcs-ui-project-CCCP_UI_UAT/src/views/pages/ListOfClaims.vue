<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <div class="row">
                        <div class="col-lg-6">
                            <h1 class="page-title">
                                List of Claims
                            </h1>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="form-filter main-card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                          <h3>Filter</h3>
                        </div>
                            <div class="card-body">
                                <div class="form-filter-items">
                                    <form>
                                        <div class="form-row">
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                              <label for="PolicyNumber">Claim Number</label>
                                              <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter">
                                            </div>

                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Policy Number</label>
                                                <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter">
                                            </div>
    
                                            
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="inputState">Claim Status</label>
                                                <select id="inputState" class="form-control">
                                                  <option>Select</option>
                                                  <option selected>All</option>
                                                </select>
                                            </div>
                                            
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Claim Registration Date From</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Select Date" value="24-12-2020">
                                                    <div class="input-group-append">
                                                      <span class="input-group-text" id="basic-addon2">
                                                        <img src="@/assets/images/icons/calendar.svg">
                                                      </span>
                                                    </div>
                                                </div>
                                            </div>
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Claim Registration Date To</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Select Date" value="23-01-2021">
                                                    <div class="input-group-append">
                                                      <span class="input-group-text" id="basic-addon2">
                                                        <img src="@/assets/images/icons/calendar.svg">
                                                      </span>
                                                    </div>
                                                </div>
                                            </div>
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Claim Handler</label>
                                                <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter">
                                            </div>
                                        </div>
                                        <div class="row mt-4">
                                            <div class="col-lg-6 mx-auto text-center">
                                                <div class="filter-buttons">
                                                    <div class="button-item">
                                                        <button class="btn btn-default" type="submit">RCS Home</button>
                                                    </div>
                                                    <div class="button-item">
                                                        <button class="btn btn-primary" type="submit">Reset</button>
                                                    </div>
                                                    <div class="button-item">
                                                        <button class="btn btn-primary" type="submit">Filter</button>
                                                    </div>         
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                      </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="table-result table-responsive">
                            <table id="example" class="table table-borderless">
                                <thead class="thead-lt-head">
                                  <tr>
                                    <th>S No.</th>
                                    <th>Claim Number <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Insured Name <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Policy Number <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Date of Loss <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Loss Descriptions <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Place of Loss <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>IMD Channel <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th class="text-center">Actions</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td>01</td>
                                    <td>OC-22-1101-4008-00000008</td>
                                    <td>Johnny Depp</td>
                                    <td>OG-20-1205-4008-00000115</td>
                                    <td>11-01-2020</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing...</td>
                                    <td>Edinburgh</td>
                                    <td>IM</td>
                                    <td class="text-center">
                                        <router-link to="claim-document-upload" class="upload_doc_icon">
                                            <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M10.2924 3.75649L8.38515 5.66487C7.82942 6.2206 7.27331 6.77614 6.71682 7.33149C6.39255 7.65404 5.97833 7.67524 5.6913 7.38878C5.40427 7.10232 5.42489 6.68695 5.74859 6.36326C7.30922 4.80149 8.87041 3.24029 10.4322 1.67966C10.7857 1.32675 11.169 1.32274 11.5207 1.67279C13.0867 3.23876 14.6527 4.80473 16.2186 6.3707C16.532 6.68466 16.5515 7.09659 16.2731 7.38133C15.9946 7.66607 15.5684 7.65805 15.2481 7.33779C14.1206 6.21182 12.9939 5.08508 11.8679 3.95758C11.8141 3.90373 11.7579 3.85274 11.6662 3.76623V4.05268C11.6662 7.91796 11.6662 11.7832 11.6662 15.6485C11.671 15.7484 11.6668 15.8485 11.6536 15.9476C11.6202 16.1107 11.5286 16.2561 11.3961 16.3568C11.2635 16.4575 11.0989 16.5067 10.9328 16.4952C10.7667 16.4837 10.6104 16.4124 10.4929 16.2944C10.3755 16.1764 10.3048 16.0198 10.2941 15.8536C10.2901 15.7826 10.2941 15.711 10.2941 15.6393V3.75649H10.2924Z" fill="#B2B3C7"/>
                                                <path d="M2.74474 19.247H19.2126V19.0178C19.2126 18.2108 19.2126 17.4033 19.2126 16.5955C19.2126 16.1372 19.4894 15.8284 19.895 15.8267C20.3006 15.8249 20.5825 16.136 20.5825 16.5892C20.5825 17.4612 20.5854 18.3326 20.5825 19.2046C20.579 20.0347 19.993 20.6277 19.1674 20.6283C13.7079 20.6283 8.24893 20.6283 2.79057 20.6283C1.965 20.626 1.37489 20.0359 1.37489 19.2074C1.37146 18.329 1.37146 17.4505 1.37489 16.572C1.37489 16.1338 1.66135 15.8272 2.05895 15.8272C2.45656 15.8272 2.74645 16.1349 2.74645 16.572C2.74588 17.4532 2.74474 18.3383 2.74474 19.247Z" fill="#B2B3C7"/>
                                            </svg>                                                                                              
                                        </router-link>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>02</td>
                                    <td>OC-22-1101-4008-00000099</td>
                                    <td>Al Pacino</td>
                                    <td>OG-20-1205-4008-00000116</td>
                                    <td>11-01-2020</td>
                                    <td>Lorem Ipsum is simply dummy of the printing...</td>
                                    <td>Manchester</td>
                                    <td>IM</td>
                                    <td class="text-center">
                                        <router-link to="claim-document-upload" class="upload_doc_icon">
                                            <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M10.2924 3.75649L8.38515 5.66487C7.82942 6.2206 7.27331 6.77614 6.71682 7.33149C6.39255 7.65404 5.97833 7.67524 5.6913 7.38878C5.40427 7.10232 5.42489 6.68695 5.74859 6.36326C7.30922 4.80149 8.87041 3.24029 10.4322 1.67966C10.7857 1.32675 11.169 1.32274 11.5207 1.67279C13.0867 3.23876 14.6527 4.80473 16.2186 6.3707C16.532 6.68466 16.5515 7.09659 16.2731 7.38133C15.9946 7.66607 15.5684 7.65805 15.2481 7.33779C14.1206 6.21182 12.9939 5.08508 11.8679 3.95758C11.8141 3.90373 11.7579 3.85274 11.6662 3.76623V4.05268C11.6662 7.91796 11.6662 11.7832 11.6662 15.6485C11.671 15.7484 11.6668 15.8485 11.6536 15.9476C11.6202 16.1107 11.5286 16.2561 11.3961 16.3568C11.2635 16.4575 11.0989 16.5067 10.9328 16.4952C10.7667 16.4837 10.6104 16.4124 10.4929 16.2944C10.3755 16.1764 10.3048 16.0198 10.2941 15.8536C10.2901 15.7826 10.2941 15.711 10.2941 15.6393V3.75649H10.2924Z" fill="#B2B3C7"/>
                                                <path d="M2.74474 19.247H19.2126V19.0178C19.2126 18.2108 19.2126 17.4033 19.2126 16.5955C19.2126 16.1372 19.4894 15.8284 19.895 15.8267C20.3006 15.8249 20.5825 16.136 20.5825 16.5892C20.5825 17.4612 20.5854 18.3326 20.5825 19.2046C20.579 20.0347 19.993 20.6277 19.1674 20.6283C13.7079 20.6283 8.24893 20.6283 2.79057 20.6283C1.965 20.626 1.37489 20.0359 1.37489 19.2074C1.37146 18.329 1.37146 17.4505 1.37489 16.572C1.37489 16.1338 1.66135 15.8272 2.05895 15.8272C2.45656 15.8272 2.74645 16.1349 2.74645 16.572C2.74588 17.4532 2.74474 18.3383 2.74474 19.247Z" fill="#B2B3C7"/>
                                            </svg>                                                                                              
                                        </router-link>
                                    </td>
                                  </tr>
                                  
                                </tbody>
                              </table>
                              <div class="row result-filters">
                                <div class="col-lg-6">
                                    <form class="form-inline">
                                        <div class="form-group">
                                            <label>Show</label>
                                            <select class="custom-select custom-count ml-2" id="exampleFormControlSelect1">
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
                                        <div class="form-group ml-3">
                                            <label class="show-result">Showing 1-10 of 18</label>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-lg-6">
                                    <nav aria-label="Page navigation example">
                                        <ul class="pagination justify-content-end">
                                          <li class="page-item disabled">
                                            <a class="page-link" href="#" tabindex="-1"><span aria-hidden="true">&#60;</span> Pre</a>
                                          </li>
                                          <li class="page-item"><a class="page-link active" href="#">1</a></li>
                                          <li class="page-item"><a class="page-link" href="#">2</a></li>
                                          <li class="page-item"><a class="page-link" href="#">3 ...</a></li>
                                          <li class="page-item"><a class="page-link" href="#">10</a></li>
                                          <li class="page-item">
                                            <a class="page-link" href="#">Next <span aria-hidden="true">&#62;</span></a>
                                          </li>
                                        </ul>
                                      </nav>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'ListOfClaims'
    }
</script>