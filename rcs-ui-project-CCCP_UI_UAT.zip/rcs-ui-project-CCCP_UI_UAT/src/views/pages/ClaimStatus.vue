<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <h1 class="page-title">
                        List of Claims
                    </h1>
                </div>
            </div>
        </section>

        <section class="form-filter main-card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                          <h3>Filter</h3>
                        </div>
                            <div class="card-body">
                                <div class="form-filter-items">
                                    <form>
                                        <div class="form-row">
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                              <label for="PolicyNumber">Claim Number</label>
                                              <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter">
                                            </div>

                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Policy Number</label>
                                                <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter">
                                            </div>
    
                                            
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="inputState">Claim Status</label>
                                                <select id="inputState" class="form-control">
                                                  <option>Select</option>
                                                  <option selected>All</option>
                                                </select>
                                            </div>
                                            
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Claim Registration Date From</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Select Date" value="24-12-2020">
                                                    <div class="input-group-append">
                                                      <span class="input-group-text" id="basic-addon2">
                                                        <img src="@/assets/images/icons/calendar.svg">
                                                      </span>
                                                    </div>
                                                </div>
                                            </div>
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Claim Registration Date To</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Select Date" value="23-01-2021">
                                                    <div class="input-group-append">
                                                      <span class="input-group-text" id="basic-addon2">
                                                        <img src="@/assets/images/icons/calendar.svg">
                                                      </span>
                                                    </div>
                                                </div>
                                            </div>
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Claim Handler</label>
                                                <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter">
                                            </div>
                                        </div>
                                        <div class="row mt-4">
                                            <div class="col-lg-6 mx-auto text-center">
                                                <div class="filter-buttons">
                                                    <div class="button-item">
                                                        <button class="btn btn-default" type="submit">RCS Home</button>
                                                    </div>
                                                    <div class="button-item">
                                                        <button class="btn btn-primary" type="submit">Reset</button>
                                                    </div>
                                                    <div class="button-item">
                                                        <button class="btn btn-primary" type="submit">Filter</button>
                                                    </div>         
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                      </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="table-result table-responsive">
                            <table id="example" class="table table-borderless">
                                <thead class="thead-lt-head">
                                  <tr>
                                    <th>S No.</th>
                                    <th>Claim Number <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Insured Name <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Policy Number <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Date of Loss <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Loss Descriptions <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Place of Loss <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>IMD Channel <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th class="text-center">Actions</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td>01</td>
                                    <td>OC-22-1101-4008-00000008</td>
                                    <td>Johnny Depp</td>
                                    <td>OG-20-1205-4008-00000115</td>
                                    <td>11-01-2020</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing...</td>
                                    <td>Edinburgh</td>
                                    <td>IMD1023</td>
                                    <td class="text-center">
                                        <router-link to="claims-status-detail" class="view_claim_icon">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M23.9111 11.716C23.7221 11.441 19.18 4.99988 11.9999 4.99988C5.83883 4.99988 0.348744 11.404 0.11774 11.677C-0.0392467 11.863 -0.0392467 12.136 0.11774 12.323C0.348744 12.596 5.83883 19.0001 11.9999 19.0001C18.1611 19.0001 23.6511 12.596 23.8821 12.323C24.0271 12.151 24.0401 11.902 23.9111 11.716ZM11.9999 18.0001C7.06088 18.0001 2.36478 13.29 1.17179 12C2.36281 10.709 7.0539 5.99992 11.9999 5.99992C17.779 5.99992 21.8581 10.703 22.8541 11.973C21.7041 13.222 16.981 18.0001 11.9999 18.0001Z" fill="#9092AD"/>
                                                <path d="M12 7.99988C9.79403 7.99988 8 9.79391 8 11.9999C8 14.2059 9.79403 16 12 16C14.2061 16 16.0001 14.2059 16.0001 11.9999C16.0001 9.79391 14.2061 7.99988 12 7.99988ZM12 15C10.346 15 9 13.654 9 12C9 10.346 10.346 8.99992 12 8.99992C13.6541 8.99992 15.0001 10.346 15.0001 12C15.0001 13.654 13.6541 15 12 15Z" fill="#9092AD"/>
                                            </svg>                                                                                              
                                        </router-link>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>02</td>
                                    <td>OC-22-1101-4008-00000099</td>
                                    <td>Al Pacino</td>
                                    <td>OG-20-1205-4008-00000116</td>
                                    <td>11-01-2020</td>
                                    <td>Lorem Ipsum is simply dummy of the printing...</td>
                                    <td>Manchester</td>
                                    <td>IMD1024</td>
                                    <td class="text-center">
                                        <router-link to="claims-status-detail" class="view_claim_icon">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M23.9111 11.716C23.7221 11.441 19.18 4.99988 11.9999 4.99988C5.83883 4.99988 0.348744 11.404 0.11774 11.677C-0.0392467 11.863 -0.0392467 12.136 0.11774 12.323C0.348744 12.596 5.83883 19.0001 11.9999 19.0001C18.1611 19.0001 23.6511 12.596 23.8821 12.323C24.0271 12.151 24.0401 11.902 23.9111 11.716ZM11.9999 18.0001C7.06088 18.0001 2.36478 13.29 1.17179 12C2.36281 10.709 7.0539 5.99992 11.9999 5.99992C17.779 5.99992 21.8581 10.703 22.8541 11.973C21.7041 13.222 16.981 18.0001 11.9999 18.0001Z" fill="#9092AD"/>
                                                <path d="M12 7.99988C9.79403 7.99988 8 9.79391 8 11.9999C8 14.2059 9.79403 16 12 16C14.2061 16 16.0001 14.2059 16.0001 11.9999C16.0001 9.79391 14.2061 7.99988 12 7.99988ZM12 15C10.346 15 9 13.654 9 12C9 10.346 10.346 8.99992 12 8.99992C13.6541 8.99992 15.0001 10.346 15.0001 12C15.0001 13.654 13.6541 15 12 15Z" fill="#9092AD"/>
                                            </svg>                                                                                              
                                        </router-link>
                                    </td>
                                  </tr>
                                  
                                </tbody>
                              </table>
                              <div class="row result-filters">
                                <div class="col-lg-6">
                                    <form class="form-inline">
                                        <div class="form-group">
                                            <label>Show</label>
                                            <select class="custom-select custom-count ml-2" id="exampleFormControlSelect1">
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
                                        <div class="form-group ml-3">
                                            <label class="show-result">Showing 1-10 of 18</label>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-lg-6">
                                    <nav aria-label="Page navigation example">
                                        <ul class="pagination justify-content-end">
                                          <li class="page-item disabled">
                                            <a class="page-link" href="#" tabindex="-1"><span aria-hidden="true">&#60;</span> Pre</a>
                                          </li>
                                          <li class="page-item"><a class="page-link active" href="#">1</a></li>
                                          <li class="page-item"><a class="page-link" href="#">2</a></li>
                                          <li class="page-item"><a class="page-link" href="#">3 ...</a></li>
                                          <li class="page-item"><a class="page-link" href="#">10</a></li>
                                          <li class="page-item">
                                            <a class="page-link" href="#">Next <span aria-hidden="true">&#62;</span></a>
                                          </li>
                                        </ul>
                                      </nav>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'ClaimStatus'
    }
</script>
