<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <h1 class="page-title">
                        Clients Fields Configuration
                    </h1>
                </div>
            </div>
        </section>

        <section class="form-filter main-card mb-4">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                          <h3>Filter</h3>
                        </div>
                            <div class="card-body">
                                <div class="form-filter-items">
                                    <form>
                                        <div class="form-row d-flex">
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Policy Number</label>
                                                <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter" value="OG-20-1205-4008-00000115">
                                            </div>

                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Partner ID</label>
                                                <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter" value="ptr_6397123LM">
                                            </div>
    
                                            <div class="form-group col-auto align-self-end">
                                                <button class="btn btn-primary" type="submit">Filter</button>
                                            </div>
                                            <div class="form-group col-auto align-self-end">
                                                <button class="btn btn-primary" type="submit">Reset</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
                
            <div class="row">
                <div class="col-lg-12 pr-0">
                    <div class="table-result h-100">
                        <div class="table-responsive">
                            <table class="table table-striped table-borderless clients-fields-table">
                                <thead>
                                  <th>S No.</th>
                                  <th>Policy Number <span><img src="assets/images/sort.svg"></span></th>
                                  <th>Partner ID <span><img src="assets/images/sort.svg"></span></th>
                                  <th>Effective Date <span><img src="assets/images/sort.svg"></span></th>
                                  <th>Display Label</th>
                                  <th>FLID_01</th>
                                  <th>Display Label</th>
                                  <th>FLID_02</th>
                                  <th>Display Label</th>
                                  <th>FLID_03</th>
                                  <th>Display Label</th>
                                  <th>FLID_04</th>
                                  <th>Display Label</th>
                                  <th>FLID_05</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>01</td>
                                        <td>OG-20-1205-4008-00000115</td>
                                        <td>ptr_6397123LM</td> 
                                        <td>01/01/2022</td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Division Name"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Store Manager Name"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Rank"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="ITC Branch"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" placeholder="Enter"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>02</td>
                                        <td>OG-20-1205-4008-00000808</td>
                                        <td>ptr_6397123LM</td> 
                                        <td>21/12/2021</td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Division Name"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Store Manager Name"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Rank"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="ITC Branch"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" placeholder="Enter"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>03</td>
                                        <td>OG-20-1205-4008-00000963</td>
                                        <td>ptr_6397123LM</td> 
                                        <td>18/12/2021</td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Division Name"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Store Manager Name"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Rank"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="ITC Branch"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" placeholder="Enter"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>04</td>
                                        <td>OG-20-1205-4008-00000147</td>
                                        <td>ptr_6397123LM</td> 
                                        <td>01/12/2021</td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Division Name"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Store Manager Name"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Rank"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="ITC Branch"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" placeholder="Enter"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>05</td>
                                        <td>OG-20-1205-4008-00000203</td>
                                        <td>ptr_6397123LM</td> 
                                        <td>27/11/2021</td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Division Name"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Store Manager Name"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox">
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="Rank"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" value="ITC Branch"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                        <td><input type="text" class="form-control" id="PolicyNumber" placeholder="Enter"></td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" checked>
                                                <span class="slider round"></span> 
                                            </label>
                                        </td>
                                    </tr>
                                </tbody>
                              </table>
                        </div>
                        <div class="row result-filters mt-4">
                            <div class="col-lg-6">
                                <form class="form-inline">
                                    <div class="form-group">
                                        <label>Show</label>
                                        <select class="custom-select custom-count ml-2" id="exampleFormControlSelect1">
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                        </select>
                                    </div>
                                    <div class="form-group ml-3">
                                        <label class="show-result">Showing 1-10 of 18</label>
                                    </div>
                                </form>
                            </div>
                            <div class="col-lg-6">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination justify-content-end">
                                      <li class="page-item disabled">
                                        <a class="page-link" href="#" tabindex="-1"><span aria-hidden="true">&#60;</span> Pre</a>
                                      </li>
                                      <li class="page-item"><a class="page-link active" href="#">1</a></li>
                                      <li class="page-item"><a class="page-link" href="#">2</a></li>
                                      <li class="page-item"><a class="page-link" href="#">3 ...</a></li>
                                      <li class="page-item"><a class="page-link" href="#">10</a></li>
                                      <li class="page-item">
                                        <a class="page-link" href="#">Next <span aria-hidden="true">&#62;</span></a>
                                      </li>
                                    </ul>
                                  </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-lg-6 mx-auto text-center">
                  <div class="filter-buttons">
                      <div class="button-item">
                          <button class="btn btn-light-warning btn-max-50px" type="submit">
                              <svg width="21" height="19" viewBox="0 0 21 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M20.1818 15.9773V12.6136C20.1818 12.3906 20.0932 12.1767 19.9355 12.019C19.7778 11.8613 19.5639 11.7727 19.3409 11.7727C19.1179 11.7727 18.904 11.8613 18.7463 12.019C18.5886 12.1767 18.5 12.3906 18.5 12.6136V15.9773C18.5 16.2003 18.4114 16.4142 18.2537 16.5719C18.096 16.7296 17.8821 16.8182 17.6591 16.8182H2.52273C2.2997 16.8182 2.08582 16.7296 1.92811 16.5719C1.77041 16.4142 1.68182 16.2003 1.68182 15.9773V12.6136C1.68182 12.3906 1.59322 12.1767 1.43552 12.019C1.27782 11.8613 1.06393 11.7727 0.840909 11.7727C0.617886 11.7727 0.403998 11.8613 0.246297 12.019C0.0885957 12.1767 0 12.3906 0 12.6136V15.9773C0 16.6463 0.265787 17.288 0.73889 17.7611C1.21199 18.2342 1.85366 18.5 2.52273 18.5H17.6591C18.3282 18.5 18.9698 18.2342 19.4429 17.7611C19.916 17.288 20.1818 16.6463 20.1818 15.9773ZM14.8168 11.5877L10.6123 14.9514C10.4638 15.0687 10.2801 15.1325 10.0909 15.1325C9.90169 15.1325 9.71801 15.0687 9.56954 14.9514L5.365 11.5877C5.2118 11.4431 5.11846 11.2463 5.10345 11.0361C5.08844 10.826 5.15285 10.6179 5.28394 10.453C5.41503 10.288 5.60324 10.1783 5.81135 10.1456C6.01945 10.1128 6.23228 10.1593 6.40773 10.2759L9.25 12.5464V0.840909C9.25 0.617886 9.3386 0.403998 9.4963 0.246297C9.654 0.0885957 9.86789 0 10.0909 0C10.3139 0 10.5278 0.0885957 10.6855 0.246297C10.8432 0.403998 10.9318 0.617886 10.9318 0.840909V12.5464L13.7741 10.2759C13.8588 10.196 13.9591 10.1345 14.0688 10.0954C14.1785 10.0563 14.2951 10.0403 14.4112 10.0486C14.5274 10.0569 14.6405 10.0893 14.7435 10.1436C14.8465 10.1979 14.9371 10.273 15.0096 10.3642C15.0821 10.4553 15.1348 10.5605 15.1645 10.6731C15.1941 10.7857 15.2001 10.9033 15.182 11.0183C15.1639 11.1333 15.122 11.2433 15.0592 11.3413C14.9963 11.4394 14.9138 11.5233 14.8168 11.5877Z" fill="#F39C12"/>
                              </svg>                                                    
                          </button>
                      </div>
                      <div class="button-item">
                          <button class="btn btn-primary" type="submit">Download Loader Format</button>
                      </div>
                      <div class="button-item">
                          <button class="btn btn-success" type="submit">Upload Loader</button>
                      </div>      
                  </div>
              </div>
          </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'ClientsFieldsConfiguration'
    }
</script>

