<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <div class="row">
                        <div class="col-lg-6">
                            <h1 class="page-title">
                                Claim Document Upload
                            </h1>
                        </div>
                        <div class="col-lg-6">
                            <ul class="breadcrumbs float-right">
                                <li><a href="/claim-document-upload">List of Claims ></a></li>
                                <li class="active">Claim Document Upload</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="claim-details main-card">
            <div class="row">
                <div class="col-lg-3">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Claim Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="claim-details-aside">
                                <ul class="claim-detail-item">
                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/hash.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Claim Number
                                                <span>OC-22-1101-4008-00000008</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/hash.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Policy Number
                                                <span>OG-20-1205-4008-00000105</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/claim-status.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Claim Status
                                                <span><div class="badge badge-active">Surveyor Appointed</div></span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/insured-name.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Insured Name
                                                <span>INTAS PHARMACEUTICALS LTD.</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/pending-age.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Pending Age
                                                <span>55 Days</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/claim-handler.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Claim Handler
                                                <span>russellcrowe@gmail.com</span>
                                            </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-9">
                    <div class="card">
                        <div class="card-header">
                          <h3>Claim Details</h3>
                        </div>
                        <div class="card-body">

                            <div class="claim-file-upload">
                                <input type="file" multiple>
                                
                                <p>
                                    <img src="@/assets/images/file-upload-icon.svg" class="text-center">
                                    Drop the claim related document here or
                                   <span>click to browse</span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="row form-filter">
                        <div class="col-lg-12">
                            <div class="table-result table-responsive h-100">
                                <table id="example" class="table table-borderless">
                                    <thead class="thead-lt-head">
                                      <tr>
                                        <th>S No.</th>
                                        <th>Select <span><img src="@/assets/images/sort.svg"></span></th>
                                        <th>Document Name <span><img src="@/assets/images/sort.svg"></span></th>
                                        <th>Uploaded Date <span><img src="@/assets/images/sort.svg"></span></th>
                                        <th class="text-center">Upload Status <span><img src="@/assets/images/sort.svg"></span></th>
                                        <th class="text-center">Actions <span><img src="@/assets/images/sort.svg"></span></th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td>01</td>
                                        <td>
                                            <input type="checkbox" class="checkbox-input">
                                        </td>
                                        <td>
                                            <div class="document-details">
                                                <div class="img-icon">
                                                    <img src="@/assets/images/pdf-icon.png" alt="jpg icon">
                                                </div>
                                                <p>
                                                    Copy of the cover note.pdf
                                                    <span>1.8 MB</span>
                                                </p>
                                            </div>
                                        </td>
                                        <td>11-01-2020 02:17 PM</td>
                                        <td>
                                          <div class="badge badge-success w-100">Success</div>
                                        </td>
                                        <td class="text-center">
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/view_claim.svg" alt="view">
                                            </a>
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/delete-icon.svg" alt="delete">
                                            </a>
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/download-icon.svg" alt="download">
                                            </a>
                                        </td>
                                      </tr>

                                      <tr>
                                        <td>02</td>
                                        <td>
                                            <input type="checkbox" checked class="checkbox-input">
                                        </td>
                                        <td>
                                            <div class="document-details">
                                                <div class="img-icon">
                                                    <img src="@/assets/images/doc-icon.png" alt="jpg icon">
                                                </div>
                                                <p>
                                                    A valid claim intimation form.doc
                                                    <span>813 KB</span>
                                                </p>
                                            </div>
                                        </td>
                                        <td>11-01-2020 02:17 PM</td>
                                        <td>
                                          <div class="badge badge-warning w-100">Pending</div>
                                        </td>
                                        <td class="text-center">
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/view_claim.svg" alt="view">
                                            </a>
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/delete-icon.svg" alt="delete">
                                            </a>
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/download-icon.svg" alt="download">
                                            </a>
                                        </td>
                                      </tr>

                                      <tr>
                                        <td>03</td>
                                        <td>
                                            <input type="checkbox" class="checkbox-input">
                                        </td>
                                        <td>
                                            <div class="document-details">
                                                <div class="img-icon">
                                                    <img src="@/assets/images/xls-icon.png" alt="jpg icon">
                                                </div>
                                                <p>
                                                    Receipt of payment.xls
                                                    <span>2.1 MB</span>
                                                </p>
                                            </div>
                                        </td>
                                        <td>11-01-2020 02:17 PM</td>
                                        <td>
                                          <div class="badge badge-danger w-100">Error</div>
                                        </td>
                                        <td class="text-center">
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/view_claim.svg" alt="view">
                                            </a>
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/delete-icon.svg" alt="delete">
                                            </a>
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/download-icon.svg" alt="download">
                                            </a>
                                        </td>
                                      </tr>

                                      <tr>
                                        <td>04</td>
                                        <td>
                                            <input type="checkbox" class="checkbox-input">
                                        </td>
                                        <td>
                                            <div class="document-details">
                                                <div class="img-icon">
                                                    <img src="@/assets/images/jpg-icon.png" alt="jpg icon">
                                                </div>
                                                <p>
                                                    A valid canceled cheque.jpg
                                                    <span>621 KB</span>
                                                </p>
                                            </div>
                                        </td>
                                        <td>11-01-2020 02:17 PM</td>
                                        <td>
                                            <div class="badge badge-danger w-100">Error</div>
                                        </td>
                                        <td class="text-center">
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/view_claim.svg" alt="view">
                                            </a>
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/delete-icon.svg" alt="delete">
                                            </a>
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/download-icon.svg" alt="download">
                                            </a>
                                        </td>
                                      </tr>

                                      <tr>
                                        <td>05</td>
                                        <td>
                                            <input type="checkbox" class="checkbox-input">
                                        </td>
                                        <td>
                                            <div class="document-details">
                                                <div class="img-icon">
                                                    <img src="@/assets/images/xlsx-icon.png" alt="jpg icon">
                                                </div>
                                                <p>
                                                    A police FIR copy.xlsx
                                                    <span>2.1 MB</span>
                                                </p>
                                            </div>
                                        </td>
                                        <td>11-01-2020 02:17 PM</td>
                                        <td>
                                          <div class="badge badge-success w-100">Success</div>
                                        </td>
                                        <td class="text-center">
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/view_claim.svg" alt="view">
                                            </a>
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/delete-icon.svg" alt="delete">
                                            </a>
                                            <a href="#" class="action-icon">
                                                <img src="@/assets/images/download-icon.svg" alt="download">
                                            </a>
                                        </td>
                                      </tr>
                                      
                                    </tbody>
                                  </table>
                                  <div class="row result-filters">
                                    <div class="col-lg-6">
                                        <form class="form-inline">
                                            <div class="form-group">
                                                <label>Show</label>
                                                <select class="custom-select custom-count ml-2" id="exampleFormControlSelect1">
                                                    <option>1</option>
                                                    <option>2</option>
                                                    <option>3</option>
                                                    <option>4</option>
                                                    <option>5</option>
                                                </select>
                                            </div>
                                            <div class="form-group ml-3">
                                                <label class="show-result">Showing 1-10 of 18</label>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-lg-6">
                                        <nav aria-label="Page navigation example">
                                            <ul class="pagination justify-content-end">
                                              <li class="page-item disabled">
                                                <a class="page-link" href="#" tabindex="-1"><span aria-hidden="true">&#60;</span> Pre</a>
                                              </li>
                                              <li class="page-item"><a class="page-link active" href="#">1</a></li>
                                              <li class="page-item"><a class="page-link" href="#">2</a></li>
                                              <li class="page-item"><a class="page-link" href="#">3 ...</a></li>
                                              <li class="page-item"><a class="page-link" href="#">10</a></li>
                                              <li class="page-item">
                                                <a class="page-link" href="#">Next <span aria-hidden="true">&#62;</span></a>
                                              </li>
                                            </ul>
                                          </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'ClaimDocumentUpload'
    }
</script>