<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <h1 class="page-title">
                        List of Claims
                    </h1>
                </div>
            </div>
        </section>

        <section class="form-filter main-card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                          <h3>Filter</h3>
                        </div>
                            <div class="card-body">
                                <div class="form-filter-items">
                                    <form>
                                        <div class="form-row">
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                              <label for="PolicyNumber">Claim Number</label>
                                              <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter">
                                            </div>

                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Policy Number</label>
                                                <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter">
                                            </div>
    
                                            
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="inputState">Claim Status</label>
                                                <select id="inputState" class="form-control">
                                                  <option>Select</option>
                                                  <option selected>All</option>
                                                </select>
                                            </div>
                                            
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Claim Registration Date From</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Select Date" value="24-12-2020">
                                                    <div class="input-group-append">
                                                      <span class="input-group-text" id="basic-addon2">
                                                        <img src="@/assets/images/icons/calendar.svg">
                                                      </span>
                                                    </div>
                                                </div>
                                            </div>
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Claim Registration Date To</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Select Date" value="23-01-2021">
                                                    <div class="input-group-append">
                                                      <span class="input-group-text" id="basic-addon2">
                                                        <img src="@/assets/images/icons/calendar.svg">
                                                      </span>
                                                    </div>
                                                </div>
                                            </div>
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Claim Handler</label>
                                                <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter">
                                            </div>
                                        </div>
                                        <div class="row mt-4">
                                            <div class="col-lg-6 mx-auto text-center">
                                                <div class="filter-buttons">
                                                    <div class="button-item">
                                                        <button class="btn btn-default" type="submit">RCS Home</button>
                                                    </div>
                                                    <div class="button-item">
                                                        <button class="btn btn-primary" type="submit">Reset</button>
                                                    </div>
                                                    <div class="button-item">
                                                        <button class="btn btn-primary" type="submit">Filter</button>
                                                    </div>         
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                      </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="table-result table-responsive">
                            <table id="example" class="table table-borderless">
                                <thead class="thead-lt-head">
                                  <tr>
                                    <th>S No.</th>
                                    <th>Claim Number <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Insured Name <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Policy Number <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Date of Loss <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Loss Descriptions <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Place of Loss <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>IMD Channel <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th class="text-center">Actions</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td>01</td>
                                    <td>OC-22-1101-4008-00000008</td>
                                    <td>Johnny Depp</td>
                                    <td>OG-20-1205-4008-00000115</td>
                                    <td>11-01-2020</td>
                                    <td>Lorem Ipsum is simply dummy text of the printing...</td>
                                    <td>Edinburgh</td>
                                    <td>IMD1023</td>
                                    <td class="text-center">
                                        <router-link to="/update-claim-details-form" class="update_claim_icon">
                                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <g clip-path="url(#clip0_2229_31788)">
                                                <path d="M19.4578 3.60871L16.3912 0.54207C15.6687 -0.180469 14.4991 -0.180586 13.7765 0.54207C13.2622 1.05648 1.95468 12.364 1.73902 12.5796C1.65378 12.6648 1.59351 12.7717 1.5648 12.8888L0.0193706 19.1825C-0.0992232 19.6656 0.339136 20.0981 0.817457 19.9806C1.14406 19.9004 6.82207 18.5061 7.11109 18.4351C7.22812 18.4064 7.33507 18.3461 7.42027 18.2609C7.64746 18.0337 18.892 6.78914 19.4578 6.22336C20.1803 5.50082 20.1805 4.33133 19.4578 3.60871ZM1.56058 18.4393L1.62355 18.183L1.81695 18.3764L1.56058 18.4393ZM3.31515 18.0085L1.99144 16.6848L2.56707 14.3407L5.65925 17.4328L3.31515 18.0085ZM6.95375 16.8613L3.13859 13.0462L12.9903 3.19437L16.8055 7.00953L6.95375 16.8613ZM18.5248 5.29031L17.7627 6.0523L13.9476 2.23715L14.7096 1.47516C14.9164 1.2684 15.2513 1.2682 15.4582 1.47516L18.5248 4.54184C18.7316 4.74867 18.7316 5.0834 18.5248 5.29031Z" fill="#B2B3C7"/>
                                                </g>
                                                <defs>
                                                <clipPath id="clip0_2229_31788">
                                                <rect width="20" height="20" fill="white"/>
                                                </clipPath>
                                                </defs>
                                            </svg>                                                                                                                                             
                                        </router-link>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>02</td>
                                    <td>OC-22-1101-4008-00000099</td>
                                    <td>Al Pacino</td>
                                    <td>OG-20-1205-4008-00000116</td>
                                    <td>11-01-2020</td>
                                    <td>Lorem Ipsum is simply dummy of the printing...</td>
                                    <td>Manchester</td>
                                    <td>IMD1024</td>
                                    <td class="text-center">
                                        <router-link to="/update-claim-details-form" class="update_claim_icon">
                                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <g clip-path="url(#clip0_2229_31788)">
                                                <path d="M19.4578 3.60871L16.3912 0.54207C15.6687 -0.180469 14.4991 -0.180586 13.7765 0.54207C13.2622 1.05648 1.95468 12.364 1.73902 12.5796C1.65378 12.6648 1.59351 12.7717 1.5648 12.8888L0.0193706 19.1825C-0.0992232 19.6656 0.339136 20.0981 0.817457 19.9806C1.14406 19.9004 6.82207 18.5061 7.11109 18.4351C7.22812 18.4064 7.33507 18.3461 7.42027 18.2609C7.64746 18.0337 18.892 6.78914 19.4578 6.22336C20.1803 5.50082 20.1805 4.33133 19.4578 3.60871ZM1.56058 18.4393L1.62355 18.183L1.81695 18.3764L1.56058 18.4393ZM3.31515 18.0085L1.99144 16.6848L2.56707 14.3407L5.65925 17.4328L3.31515 18.0085ZM6.95375 16.8613L3.13859 13.0462L12.9903 3.19437L16.8055 7.00953L6.95375 16.8613ZM18.5248 5.29031L17.7627 6.0523L13.9476 2.23715L14.7096 1.47516C14.9164 1.2684 15.2513 1.2682 15.4582 1.47516L18.5248 4.54184C18.7316 4.74867 18.7316 5.0834 18.5248 5.29031Z" fill="#B2B3C7"/>
                                                </g>
                                                <defs>
                                                <clipPath id="clip0_2229_31788">
                                                <rect width="20" height="20" fill="white"/>
                                                </clipPath>
                                                </defs>
                                            </svg>                                                                                                                                             
                                        </router-link>
                                    </td>
                                  </tr>
                                  
                                </tbody>
                              </table>
                              <div class="row result-filters">
                                <div class="col-lg-6">
                                    <form class="form-inline">
                                        <div class="form-group">
                                            <label>Show</label>
                                            <select class="custom-select custom-count ml-2" id="exampleFormControlSelect1">
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
                                        <div class="form-group ml-3">
                                            <label class="show-result">Showing 1-10 of 18</label>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-lg-6">
                                    <nav aria-label="Page navigation example">
                                        <ul class="pagination justify-content-end">
                                          <li class="page-item disabled">
                                            <a class="page-link" href="#" tabindex="-1"><span aria-hidden="true">&#60;</span> Pre</a>
                                          </li>
                                          <li class="page-item"><a class="page-link active" href="#">1</a></li>
                                          <li class="page-item"><a class="page-link" href="#">2</a></li>
                                          <li class="page-item"><a class="page-link" href="#">3 ...</a></li>
                                          <li class="page-item"><a class="page-link" href="#">10</a></li>
                                          <li class="page-item">
                                            <a class="page-link" href="#">Next <span aria-hidden="true">&#62;</span></a>
                                          </li>
                                        </ul>
                                      </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'UpdateClaimDetails'
    }
</script>
