<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <div class="row">
                        <div class="col-lg-6">
                            <h1 class="page-title">
                                New Claim Registration
                            </h1>
                        </div>
                        <div class="col-lg-6">
                            <ul class="breadcrumbs float-right">
                                <li><a href="#">List of Policies > ></a></li>
                                <li class="active">New Claim Registration</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="claim-details main-card cancel-step">
            <div class="row">
                <div class="col-lg-3">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Policy Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="claim-details-aside">
                                <ul class="claim-detail-item">
                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/policy-number.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Policy Number
                                                <span>OG-20-1101-4001-00000088</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/name-of-insured.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Name of Insured
                                                <span>Carrier Airconditioning</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/policy-status.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Policy Status
                                                <span><div class="badge badge-success">Active</div></span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/product.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Product
                                                <span>Marine Turnover Policy</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/financial-institute.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Name of Financial Institute
                                                <span>None</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/calendar.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Policy Start Date
                                                <span>10-01-2021</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/calendar.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Policy End Date
                                                <span>09-01-2022</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/icons/policy-sum-insured.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Sum Insured
                                                <span>₹ 9,60,000</span>
                                            </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-9">
                    <div class="new-claim-reg-step">
                        <div class="add-policy-detail h-100">
                            <div class="policy-detail-bg">
                                <div class="steps d-flex justify-content-center flex-lg-row flex-column">
                                    <div class="step-1 completed d-flex">
                                        <div class="img-ico-parent">
                                            <div class="step-img">
                                                <img src="@/assets/images/icons/tick.svg" alt="Icon">
                                            </div>
                                        </div>
                                        <div class="step-detail">
                                            <p>Step 1</p>
                                            <h6>Loss Details</h6>
                                        </div>
                                    </div>
                                    <div class="step-1 completed d-flex">
                                        <div class="img-ico-parent">
                                            <div class="step-img">
                                                <img src="@/assets/images/icons/tick.svg" alt="Icon">
                                            </div>
                                        </div>
                                        <div class="step-detail">
                                            <p>Step 2</p>
                                            <h6>Transit Details</h6>
                                        </div>
                                    </div>
                                    <div class="step-1 active d-flex">
                                        <div class="img-ico-parent">
                                            <div class="step-img">
                                                <img src="@/assets/images/icons/cancel-3-white.svg" alt="Icon">
                                            </div>
                                        </div>
                                        <div class="step-detail">
                                            <p>Step 3</p>
                                            <h6>Contact Details for Loss Location / Place</h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="policy-input common-form">
                                   <div class="row">
                                    <div class="col-lg-3">

                                        <div class="form-group">
                                            <label>Name of Person <span>*</span></label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" value="Russell Crowe">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Mobile Number <span>*</span></label>
                                            <input type="text" class="form-control" value="+91 89536 74123">
                                        </div>
                                        <div class="cancel-3-email">
                                            <div class="form-group">
                                                <label>Email ID <span>*</span></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control pb-4 pt-4" value="russellcrowe@gmail.com">
                                                    <div class="input-group-append">
                                                      <span class="input-group-text">
                                                        <img src="@/assets/images/icons/plus.svg">
                                                      </span>
                                                    </div>
                                                </div>
                                                <!-- <div class="input-group">
                                                    <input type="text" class="form-control" value="russellcrowe@gmail.com">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text" id="basic-addon2">
                                                          <img src="@/assets/images/icons/plus.svg">
                                                        </span>
                                                    </div>
                                                </div> -->
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="col-lg-8 offset-lg-1">
                                        <div class="row">
                                            <div class="col-lg-5">
                                                <div class="form-group">
                                                    <label>Identification Number</label>
                                                    <input type="text" class="form-control" placeholder="Enter">
                                                </div>
                                            </div>
                                            <div class="col-lg-5 offset-lg-2">
                                                <div class="form-group">
                                                    <label>Telephone Number</label>
                                                    <input type="text" class="form-control" placeholder="Enter">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <label>Any Special Remarks</label>
                                                    <textarea class="form-control" rows="6" placeholder="Enter"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="step-button mx-auto">
                                        <router-link to="/new-claim-registration-cancel-step-two" class="btn btn-primary mr-2">Previous</router-link>
                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#newClaimModal">
                                            Submit
                                        </button>
                                    </div>
                                    <!-- New claim Registration Modal -->
                                    <div class="modal fade bd-example-modal-lg" id="newClaimModal" tabindex="-1" role="dialog" aria-labelledby="newClaimModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                                        <div class="modal-content common-modal">
                                            <div class="modal-body text-center">
                                                <img src="@/assets/images/modal-check.svg" alt="check">
                                                <h1>Commercial Claim Intimation Completed</h1>
                                                <p class="modal-para mb-4">Thank You, <span> Medico Electrodes International Limited</span>, your claim has been intimated successfully,</p>
                                                <div class="model-ref-num mb-4">
                                                    <p>Your reference number <span class="ref-num">OC-22-1501-1018-00000088</span> <small>Please use this reference number for further communication</small></p> 
                                                </div>
                                                <router-link to="/dashboard" class="btn btn-primary mr-3">Home</router-link>
                                                <router-link to="/claim-document-upload-list" class="btn btn-primary">Upload Document</router-link>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                   </div>
                                </div>  
                            </div>
                            
                        </div>
                    </div>
                </div>

                </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'NewClaimRegistrationCancelStepThree'
    }
</script>
