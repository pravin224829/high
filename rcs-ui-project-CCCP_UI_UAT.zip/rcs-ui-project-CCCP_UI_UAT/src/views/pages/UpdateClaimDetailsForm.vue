<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <div class="row">
                        <div class="col-lg-6">
                            <h1 class="page-title">
                                Update Claim Details
                            </h1>
                        </div>
                        <div class="col-lg-6">
                            <ul class="breadcrumbs float-right">
                                <li><a href="#">List of Claims ></a></li>
                                <li class="active">Update Claim Details</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="claim-details main-card">
            <div class="row">
                <div class="col-lg-3">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Claim Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="claim-details-aside">
                                <ul class="claim-detail-item">
                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/hash.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Claim Number
                                                <span>OC-22-1101-4008-00000008</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/hash.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Policy Number
                                                <span>OG-20-1205-4008-00000105</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/claim-status.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Claim Status
                                                <span><div class="badge badge-active">Surveyor Appointed</div></span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/insured-name.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Insured Name
                                                <span>INTAS PHARMACEUTICALS LTD.</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/pending-age.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Pending Age
                                                <span>55 Days</span>
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="claim-details-icon">
                                            <img src="@/assets/images/claim-handler.svg" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                Claim Handler
                                                <span>russellcrowe@gmail.com</span>
                                            </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-9">
                    <div class="card">
                        <div class="card-header">
                          <h3>Update Additional Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="update-claim-form common-form">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Client Identification Number</label>
                                            <input type="text" class="form-control" placeholder="Enter">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Client Identification Number</label>
                                            <input type="text" class="form-control" placeholder="Enter">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Client Identification Number</label>
                                            <input type="text" class="form-control" value="Denzel Washington">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Surveyor Contact Number</label>
                                            <input type="text" class="form-control" value="+91 89631 01263">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="inputState">Claim Status</label>
                                            <select id="inputState" class="form-control">
                                              <option>Select</option>
                                              <option selected>All</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="inputState">Claim Type</label>
                                            <select id="inputState" class="form-control">
                                              <option>Select</option>
                                              <option selected>All</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="inputState">Policy Type</label>
                                            <select id="inputState" class="form-control">
                                              <option>Select</option>
                                              <option selected>All</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Financial Year</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="Select Date" value="2021">
                                                <div class="input-group-append">
                                                  <span class="input-group-text" id="basic-addon2">
                                                    <img src="@/assets/images/icons/calendar.svg">
                                                  </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Client Division Name</label>
                                            <input type="text" class="form-control" placeholder="Enter">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Client District Name</label>
                                            <input type="text" class="form-control" placeholder="Enter">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Total Consignment Value</label>
                                            <input type="text" class="form-control" placeholder="Enter">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Transport Vehicle Number</label>
                                            <input type="text" class="form-control" placeholder="Enter" value="TN 08 MN 7889">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Transporter Name</label>
                                            <input type="text" class="form-control" placeholder="Enter" value="Leonardo DiCaprio">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="inputState">Consignment / Cargo Type</label>
                                            <select id="inputState" class="form-control">
                                              <option>Select</option>
                                              <option selected>All</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="inputState">K2 / K3</label>
                                            <select id="inputState" class="form-control">
                                              <option>Select</option>
                                              <option selected>All</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">JIR Date</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="Select Date" value="11-01-2020">
                                                <div class="input-group-append">
                                                  <span class="input-group-text" id="basic-addon2">
                                                    <img src="@/assets/images/icons/calendar.svg">
                                                  </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Claim Approved Amount</label>
                                            <input type="text" class="form-control" placeholder="Enter" value="₹ 3,60,000">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Surveyor Fees Paid Amount</label>
                                            <input type="text" class="form-control" placeholder="Enter" value="₹ 88,000">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">Claim Payment UTR Number</label>
                                            <input type="text" class="form-control" placeholder="Enter">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="PolicyNumber">UTR Date</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="Select Date" value="11-01-2020">
                                                <div class="input-group-append">
                                                  <span class="input-group-text" id="basic-addon2">
                                                    <img src="@/assets/images/icons/calendar.svg">
                                                  </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 text-center mt-4">
                                        <button class="btn btn-primary mr-3">Reset</button>
                                        <button class="btn btn-primary" data-toggle="modal" data-target="#updateModal">Update</button>
                                    </div>
                                    <!-- Update Modal -->
                                    <div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="updateModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content common-modal">
                                            <div class="modal-body text-center">
                                                <img src="@/assets/images/modal-check.svg" alt="check">
                                                <h1>Successfully Updated !</h1>
                                                <p class="mb-4">Dear user, the claim has been updated successfully.</p>
                                                <button type="button" class="btn btn-primary" data-dismiss="modal">Okay</button>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'UpdateClaimDetailsForm'
    }
</script>
