<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <div class="row">
                        <div class="col-lg-6">
                            <h1 class="page-title">
                                Claims Status
                            </h1>
                        </div>
                        <div class="col-lg-6">
                            <ul class="breadcrumbs float-right">
                                <li><a href="#">List of Claims ></a></li>
                                <li class="active">Claim Status</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="claim-details-view main-card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                          <h3>Claim Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-3 col-md-4 col-sm-6">
                                    <div class="claim-details-item">
                                        <p>
                                            Claim Number <span>OC-22-1101-4008-00000008</span>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-6">
                                    <div class="claim-details-item">
                                        <p>
                                            Policy Number 
                                            <span>OC-22-1101-4008-00000008</span>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-6">
                                    <div class="claim-details-item">
                                        <p>
                                            Claim Status 
                                            <span><div class="badge badge-active">Surveyor Appointed</div></span>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-6">
                                    <div class="claim-details-item">
                                        <p>
                                            Insured Name 
                                            <span>INTAS PHARMACEUTICALS LTD.</span>
                                        </p>
                                    </div>
                                </div>

                                <div class="col-lg-3 col-md-4 col-sm-6">
                                    <div class="claim-details-item">
                                        <p>
                                            Pending Age
                                            <span>55 Days</span>
                                        </p>
                                    </div>
                                </div>

                                <div class="col-lg-3 col-md-4 col-sm-6">
                                    <div class="claim-details-item">
                                        <p>
                                            Claim Handler 
                                            <span>russellcrowe@gmail.com</span>
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-5">
                                <div class="col-lg-12">
                                    <div class="survey-progress">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <div class="survey-user">
                                                    <img src="@/assets/images/survey-user-icon.svg" alt="survey-user">
                                                </div>
                                            </div>
                                            <div>
                                                <h3>
                                                    Claim Status
                                                    <span>Surveyor Appointed - Survey Under Progress</span>
                                                </h3>
                                            </div>
                                            <div class="ml-auto">
                                                <div class="survey-btn">
                                                    <a href="claims-status.html" class="btn btn-primary pull-right">Back</a>
                                                </div>
                                            </div>
                                          </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </section>
    </div>
</template>

<script>
    export default {
      name: 'ClaimStatusDetail'  
    }
</script>
