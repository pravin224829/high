<template>
    <div>
        <section class="login">
            <div class="container-fluid">
                <div class="row vh-100 vh-100-md align-items-center d-flex justify-content-center">
                    <div class="col-lg-8">
                        <div class="login-logo align-items-center d-flex text-center">
                            <img src="@/assets/images/bajajlogo.png" alt="Bajaj">
                        </div>
                        <div class="login-bg">
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="login-content">
                            <h3>Commercial Line Claims Portal Login</h3>
                            <p>Please enter your user name and password for log into your account</p>
                            <form class="login-form">
                                <div class="form-item-parent d-flex align-items-center">
                                    <div class="form-icon p-2">
                                        <i class="material-icons prefix">person_outline</i>
                                    </div>
                                    <div class="form-item flex-grow-1">
                                        <div class="form__group p-2">
                                            <input type="text" id="username" class="form__field" placeholder="Catherine Zeta-Jones">
                                            <label for="username" class="form__label">User Name</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-item-parent1 d-flex align-items-center mt-5">
                                    <div class="form-icon1 p-2">
                                        <i class="material-icons prefix">lock_outline</i>
                                    </div>
                                    <div class="form-item flex-grow-1">
                                        <div class="form__group p-2">
                                            <input type="text" id="password" class="form__field" placeholder="Catherine Zeta-Jones">
                                            <label for="password" class="form__label">Password</label>
                                        </div>
                                    </div>
                                </div>

                                <ul class="forgot-password">
                                    <!-- <li>Don't have an Account? <a href="" class="pl-1">Sign up</a></li> -->
                                    <li><a href="#">Forgot Password ?</a></li>
                                </ul>
                                <button type="submit" class="btn btn-primary btn-block login-btn">Login </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'LoginPage'
    }
</script>
