<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <h1 class="page-title">
                        List of Policies
                    </h1>
                </div>
            </div>
        </section>

        <section class="form-filter main-card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                          <h3>Filter</h3>
                        </div>
                            <div class="card-body">
                                <div class="form-filter-items">
                                    <form>
                                        <div class="form-row">
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                              <label for="PolicyNumber">Policy Number</label>
                                              <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter">
                                            </div>
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="inputState">Line of Business</label>
                                                <select id="inputState" class="form-control">
                                                  <option selected>Select</option>
                                                  <option>...</option>
                                                </select>
                                            </div>
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="inputState">Claim Status</label>
                                                <select id="inputState" class="form-control">
                                                  <option selected>Select</option>
                                                  <option>...</option>
                                                </select>
                                            </div>
                                            
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Policy Start Date</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Select Date">
                                                    <div class="input-group-append">
                                                      <span class="input-group-text" id="basic-addon2">
                                                        <img src="@/assets/images/icons/calendar.svg">
                                                      </span>
                                                    </div>
                                                </div>
                                            </div>
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Policy Start Date</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Select Date">
                                                    <div class="input-group-append">
                                                      <span class="input-group-text" id="basic-addon2">
                                                        <img src="@/assets/images/icons/calendar.svg">
                                                      </span>
                                                    </div>
                                                </div>
                                            </div>
    
                                            <div class="form-group col-lg-2 col-md-2 col-sm-6 col-12">
                                                <label for="PolicyNumber">Claim Handler</label>
                                                <input type="text" class="form-control" id="PolicyNumber" placeholder="Enter">
                                            </div>
                                        </div>
                                        <div class="row mt-4">
                                            <div class="col-lg-6 mx-auto text-center">
                                                <div class="filter-buttons">
                                                    <div class="button-item">
                                                        <button class="btn btn-default" type="submit">RCS Home</button>
                                                    </div>
                                                    <div class="button-item">
                                                        <button class="btn btn-primary" type="submit">Reset</button>
                                                    </div>
                                                    <div class="button-item">
                                                        <button class="btn btn-primary" type="submit">Filter</button>
                                                    </div>         
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                      </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="table-result">
                          <div class="table-responsive">
                            <table id="example" class="table table-borderless">
                                <thead class="thead-lt-head">
                                  <tr>
                                    <th>S No.</th>
                                    <th>Policy Number <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Insured Name <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Inception Date <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Expiry Date <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Product Code <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Product Desc. <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>IMD Channel <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Sum Insured <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th>Policy Status <span><img src="@/assets/images/sort.svg"></span></th>
                                    <th class="text-center">Actions</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td>01</td>
                                    <td>PLY0007853</td>
                                    <td>Johnny Depp</td>
                                    <td>11-01-2020</td>
                                    <td>10-01-2021</td>
                                    <td>PRD7102</td>
                                    <td>Lorem Ipsum is a text</td>
                                    <td>IMD1023</td>
                                    <td>₹ 8,00,000</td>
                                    <td>
                                      <div class="badge badge-success w-100">Active</div>
                                    </td>
                                    <td class="text-center">
                                        <router-link to="/new-claim-registration-active-step-one">
                                            <img src="@/assets/images/action-add.svg" alt="action-add">
                                        </router-link>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>01</td>
                                    <td>PLY0004263</td>
                                    <td>Al Pacino</td>
                                    <td>11-01-2020</td>
                                    <td>10-01-2021</td>
                                    <td>PRD7102</td>
                                    <td>Lorem Ipsum is a text</td>
                                    <td>IMD1023</td>
                                    <td>₹ 5,50,000</td>
                                    <td>
                                      <div class="badge badge-danger w-100">Cancelled</div>
                                    </td>
                                    <td class="text-center">
                                        <router-link to="/new-claim-registration-cancel-step-one">
                                            <img src="@/assets/images/action-add.svg" alt="action-add">
                                        </router-link>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>01</td>
                                    <td>PLY0007853</td>
                                    <td>Johnny Depp</td>
                                    <td>11-01-2020</td>
                                    <td>10-01-2021</td>
                                    <td>PRD7102</td>
                                    <td>Lorem Ipsum is a text</td>
                                    <td>IMD1023</td>
                                    <td>₹ 8,00,000</td>
                                    <td>
                                      <div class="badge badge-success w-100">Active</div>
                                    </td>
                                    <td class="text-center">
                                        <router-link to="/new-claim-registration-active-step-one">
                                            <img src="@/assets/images/action-add.svg" alt="action-add">
                                        </router-link>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td>01</td>
                                    <td>PLY0004263</td>
                                    <td>Al Pacino</td>
                                    <td>11-01-2020</td>
                                    <td>10-01-2021</td>
                                    <td>PRD7102</td>
                                    <td>Lorem Ipsum is a text</td>
                                    <td>IMD1023</td>
                                    <td>₹ 5,50,000</td>
                                    <td>
                                      <div class="badge badge-danger w-100">Cancelled</div>
                                    </td>
                                    <td class="text-center">
                                        <router-link to="/new-claim-registration-cancel-step-one">
                                            <img src="@/assets/images/action-add.svg" alt="action-add">
                                        </router-link>
                                    </td>
                                  </tr>
                                  
                                </tbody>
                              </table>
                              </div>
                              <div class="row result-filters mt-4">
                                <div class="col-lg-6">
                                    <form class="form-inline">
                                        <div class="form-group">
                                            <label>Show</label>
                                            <select class="custom-select custom-count ml-2" id="exampleFormControlSelect1">
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
                                        <div class="form-group ml-3">
                                            <label class="show-result">Showing 1-10 of 18</label>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-lg-6">
                                    <nav aria-label="Page navigation example">
                                        <ul class="pagination justify-content-end">
                                          <li class="page-item disabled">
                                            <a class="page-link" href="#" tabindex="-1"><span aria-hidden="true">&#60;</span> Pre</a>
                                          </li>
                                          <li class="page-item"><a class="page-link active" href="#">1</a></li>
                                          <li class="page-item"><a class="page-link" href="#">2</a></li>
                                          <li class="page-item"><a class="page-link" href="#">3 ...</a></li>
                                          <li class="page-item"><a class="page-link" href="#">10</a></li>
                                          <li class="page-item">
                                            <a class="page-link" href="#">Next <span aria-hidden="true">&#62;</span></a>
                                          </li>
                                        </ul>
                                      </nav>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
        </section>
    </div>
</template>

<script>
    export default {
        name:'NewClaimRegistration'
    }
</script>
