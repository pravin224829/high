<template>
    <div>
        <header>
            <section class="top-header">
                <TopBar></TopBar>
                <MainMenu></MainMenu>
            </section>
        </header>
        <main class="main-section">
            <router-view></router-view>
        </main>
        <footer>
            <FooterSection></FooterSection>
        </footer>
    </div>
</template>

<script>
import TopBar from '@/components/common/TopBar.vue'
import MainMenu from '@/components/common/MainMenu.vue'
import FooterSection from '@/components/common/Footer.vue'
    export default {
        name: 'LayoutView',
        components:{
            TopBar,
            MainMenu,
            FooterSection
        }
    }
</script>
