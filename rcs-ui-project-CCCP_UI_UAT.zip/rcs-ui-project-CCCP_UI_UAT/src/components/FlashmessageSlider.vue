<template>
	<div  class="care-pd-slider care-horizontal">
		<div id="slider">
			<!-- <div v-if="(currentSlider!=0 && items.length>1)" class="btn btn-prev" aria-label="Previous slide" @click="moveCarousel(-1)">
				<span  class="horizontal-arrow-top">
					<svg width="10" height="18" viewBox="0 0 10 18" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M8.94238 18C8.66009 18.0017 8.38876 17.8843 8.18833 17.6737L-6.31841e-07 9.00045L8.18833 0.327124C8.60257 -0.109041 9.27157 -0.109041 9.68581 0.327124C9.88687 0.53835 10 0.825877 10 1.12583C10 1.42578 9.88687 1.71331 9.68581 1.92453L3.00557 9.00045L9.68581 16.0763C9.99078 16.3967 10.0835 16.8801 9.9208 17.3012C9.75807 17.7223 9.37192 17.9981 8.94238 18Z" fill="white"/>
					</svg>
				</span>
			</div> -->

			<div class="card-carousel">
				<div class="card-carousel--overflow-container desktop-horizontal">
					<ul class="card-carousel-cards" :style="{ transform: 'translateX(' + currentOffset + 'px' + ')'}" id="slider-main">
 						<li class="card-carousel--card info" v-for="(item, index) in items" :key="'DCM'+index" :class="updateClass(index, items)">
               <p><span>{{item.delayed_date}}</span><span> - </span>{{item.description}}</p> 
            </li>
					</ul>
				</div>
			</div>

			<!-- <div v-if="currentSlider!=items.length-1 && displayNext" class="btn btn-next" aria-label="Next slide" @click="moveCarousel(1)" id="slider-next">
				<span class="horizontal-arrow-bottom">
					<svg width="10" height="18" viewBox="0 0 10 18" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M1.05762 1.90273e-05C1.33991 -0.00169188 1.61124 0.115692 1.81167 0.326267L10 8.99955L1.81167 17.6729C1.39743 18.109 0.728428 18.109 0.314192 17.6729C0.113134 17.4616 -3.61002e-08 17.1741 -4.92115e-08 16.8742C-6.23228e-08 16.5742 0.113134 16.2867 0.314192 16.0755L6.99442 8.99955L0.314191 1.92368C0.00921437 1.60328 -0.0835332 1.11986 0.0791951 0.698793C0.241923 0.277727 0.628083 0.00194547 1.05762 1.90273e-05Z" fill="white"/>
					</svg>
				</span>
			</div> -->
		</div>
	</div>
</template>

<script>

export default {
	props: {
		mode: {
			type: String,
			default: 'desktop',
		},
    items:{
      type: Array,
    }
	},
	mounted () {
    // this.items.push({description:'sunt aut facere repellat provident occaecati excepturi optio reprehenderit'})
    console.log("flashitems", this.items)
		if(window){
			this.isMobileWidth = window.matchMedia('screen and (max-width: 48em)').matches;
		}
    this.updateSliderArrow();
    this.updateWidth();
   this.myInterval = setInterval(() => {
      if(this.displayNext && this.currentSlider!=this.items.length-1){
         this.moveCarousel(1)
      }
      else if(this.currentSlider!=0 && this.items.length>1){
        this.moveCarousel(-1)
      }
    }, 3000)
	},
   destroyed() {
    clearInterval(this.myInterval);
    },
	data() {
		return {
    currentSlider : 0,
    currentOffset : 0,
    displayNext : true,
    sliderWidth:0,
    // flashmessageitem:[
    //   {
    //     description:'Helloo'
    //   },
    //   {
    //     description:'This is Flash message'
    //   }, 
    //   {
    //     description:'sunt aut facere repellat provident occaecati excepturi optio reprehenderit'
    //   }, 
    //   {
    //     description:'qui est esse'
    //   }
    // ],
    // items: [
    //   {
    //     "userId": 1,
    //     "id": 1,
    //     "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
    //     "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 2,
    //     "title": "qui est esse",
    //     "body": "est rerum tempore vitae\nsequi sint nihil reprehenderit dolor beatae ea dolores neque\nfugiat blanditiis voluptate porro vel nihil molestiae ut reiciendis\nqui aperiam non debitis possimus qui neque nisi nulla"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 3,
    //     "title": "ea molestias quasi exercitationem repellat qui ipsa sit aut",
    //     "body": "et iusto sed quo iure\nvoluptatem occaecati omnis eligendi aut ad\nvoluptatem doloribus vel accusantium quis pariatur\nmolestiae porro eius odio et labore et velit aut"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 4,
    //     "title": "eum et est occaecati",
    //     "body": "ullam et saepe reiciendis voluptatem adipisci\nsit amet autem assumenda provident rerum culpa\nquis hic commodi nesciunt rem tenetur doloremque ipsam iure\nquis sunt voluptatem rerum illo velit"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 5,
    //     "title": "nesciunt quas odio",
    //     "body": "repudiandae veniam quaerat sunt sed\nalias aut fugiat sit autem sed est\nvoluptatem omnis possimus esse voluptatibus quis\nest aut tenetur dolor neque"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 6,
    //     "title": "dolorem eum magni eos aperiam quia",
    //     "body": "ut aspernatur corporis harum nihil quis provident sequi\nmollitia nobis aliquid molestiae\nperspiciatis et ea nemo ab reprehenderit accusantium quas\nvoluptate dolores velit et doloremque molestiae"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 7,
    //     "title": "magnam facilis autem",
    //     "body": "dolore placeat quibusdam ea quo vitae\nmagni quis enim qui quis quo nemo aut saepe\nquidem repellat excepturi ut quia\nsunt ut sequi eos ea sed quas"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 8,
    //     "title": "dolorem dolore est ipsam",
    //     "body": "dignissimos aperiam dolorem qui eum\nfacilis quibusdam animi sint suscipit qui sint possimus cum\nquaerat magni maiores excepturi\nipsam ut commodi dolor voluptatum modi aut vitae"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 5,
    //     "title": "nesciunt quas odio",
    //     "body": "repudiandae veniam quaerat sunt sed\nalias aut fugiat sit autem sed est\nvoluptatem omnis possimus esse voluptatibus quis\nest aut tenetur dolor neque"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 6,
    //     "title": "dolorem eum magni eos aperiam quia",
    //     "body": "ut aspernatur corporis harum nihil quis provident sequi\nmollitia nobis aliquid molestiae\nperspiciatis et ea nemo ab reprehenderit accusantium quas\nvoluptate dolores velit et doloremque molestiae"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 7,
    //     "title": "magnam facilis autem",
    //     "body": "dolore placeat quibusdam ea quo vitae\nmagni quis enim qui quis quo nemo aut saepe\nquidem repellat excepturi ut quia\nsunt ut sequi eos ea sed quas"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 8,
    //     "title": "dolorem dolore est ipsam",
    //     "body": "dignissimos aperiam dolorem qui eum\nfacilis quibusdam animi sint suscipit qui sint possimus cum\nquaerat magni maiores excepturi\nipsam ut commodi dolor voluptatum modi aut vitae"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 5,
    //     "title": "nesciunt quas odio",
    //     "body": "repudiandae veniam quaerat sunt sed\nalias aut fugiat sit autem sed est\nvoluptatem omnis possimus esse voluptatibus quis\nest aut tenetur dolor neque"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 6,
    //     "title": "dolorem eum magni eos aperiam quia",
    //     "body": "ut aspernatur corporis harum nihil quis provident sequi\nmollitia nobis aliquid molestiae\nperspiciatis et ea nemo ab reprehenderit accusantium quas\nvoluptate dolores velit et doloremque molestiae"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 7,
    //     "title": "magnam facilis autem",
    //     "body": "dolore placeat quibusdam ea quo vitae\nmagni quis enim qui quis quo nemo aut saepe\nquidem repellat excepturi ut quia\nsunt ut sequi eos ea sed quas"
    //   },
    //   {
    //     "userId": 1,
    //     "id": 8,
    //     "title": "dolorem dolore est ipsam",
    //     "body": "dignissimos aperiam dolorem qui eum\nfacilis quibusdam animi sint suscipit qui sint possimus cum\nquaerat magni maiores excepturi\nipsam ut commodi dolor voluptatum modi aut vitae"
    //   },
    // ],
    isMobileWidth: false,
    myInterval:[]
		}
  },

	methods: {
    updateWidth(){
        let sliders = document.querySelectorAll('.slider-item');
        let sliderWidth = 0;
        Array.from(sliders).forEach((list)=>{
            let sliderDetails = list.getBoundingClientRect();
            sliderWidth+= sliderDetails.width
            list.dataset.width = sliderDetails.width
        });
        document.getElementById('slider-main').style.width=sliderWidth+'px';
        if(sliderWidth < document.getElementById('slider').offsetWidth){
          this.displayNext = false
        }
       
    },

    updateSliderArrow(){
        let getSliderHolderDetails = document.getElementById('slider').getBoundingClientRect();
        let sliders = document.querySelectorAll('.slider-item');
        let sliderItemWidth = 0;
        Array.from(sliders).forEach((list)=>{
          let sliderDetails = list.getBoundingClientRect();
          sliderItemWidth += sliderDetails.width
        });
        if((Math.floor(sliderItemWidth) < getSliderHolderDetails.width) || (Math.floor(sliderItemWidth) < getSliderHolderDetails.width)){
            this.atEndOfList = false
        }
    },



		updateClass(index, items){
			let sldierclass = `slider-item`;
			let sliderMainClass = ((index==0) ? 'first-item-slider' : ((items.length == index+1) ?  'last-item-slider' : ''));
			return sldierclass+' '+sliderMainClass;
		},

    updateNextButton(currentSlider){
        let sliders = document.querySelectorAll('.slider-item');
        let totalWidth = 0
        for(let checkSlider = currentSlider; checkSlider<this.items.length; checkSlider++){
          totalWidth += parseFloat(sliders[checkSlider].dataset.width)
        }
        if(document.getElementById('slider-main')){
          if(((document.getElementById('slider').offsetWidth) > (totalWidth))){
              this.displayNext = false
          }
          else{
              this.displayNext = true
          }
        }
    },

		moveCarousel(direction) {
      let sliders = document.querySelectorAll('.slider-item');
      if (direction === 1) {
        this.currentOffset-= parseFloat(sliders[this.currentSlider].dataset.width)
        this.currentSlider += 1
        console.log('this.currentOffset 1', this.currentOffset)
      }
      else if (direction === -1) {
          this.currentSlider -= 1
          this.currentOffset += parseFloat(sliders[this.currentSlider].dataset.width)
      }  
      this.updateNextButton(this.currentSlider)    
		},
	},
};
</script>

<style lang="scss">
body{
  margin:0px;
}
.care-horizontal {
	font-family: Source Sans Pro,Verdana,sans-serif;
  max-width:1000px;
  margin:0px auto;
	.featured-txt {
		padding: 18px;
	}

	#slider {
		width: 100%;
		position: relative;
	}

	.horizontal-arrow-top{
		position: relative;
		top:2px;
		left:-2px;
	}

	.horizontal-arrow-bottom{
		position: relative;
		top:2px;
		left:2px;
	}


	.btn {
		z-index: 10;
		cursor: pointer;
		display: flex;
		justify-content: center;
		align-items: center;
		width: 32px;
		height: 40px;
		position: absolute;
    right: 0;
		color: white;
		top: 0%;
		left: 1%;
		transition: transform 0.3s ease-in-out;
    position: sticky;
    padding: 20px;

	}

	.btn-next {
		left: auto;
		// right: 59px;
		background-color: #1D3957;
    position: sticky;
	}

	.btn-prev {
		background-color: #1D3957;
		left: 0;
	}

	.main-button-holder{
		margin-top:17px;
	}

  .card-carousel-card-container{
      position: relative;
      display: inline-block;
      p{
        margin:0px;
        padding:10px;
      }
      &:after {
          content: '';
          height: 100%;
          width: 1px;
          position: absolute;
          right: 0;
          top: 0px;
          background-color: #C8EDED;;
      }
  }


	
	.card-carousel {
		max-height: 180px;
		&--overflow-container {
			overflow: hidden;
		}

    .card-carousel-cards {
        display: -webkit-box;
        transition: 0.3s ease-in-out;
        -webkit-transition: 0.3s ease-in-out;
        list-style: none;
        padding:0px;
        margin:0px;
        .card-carousel--card {
            padding:2px 24px;
             h4{
                margin-top:0px;
            }
        }
    }
    .card-carousel-cards .card-carousel--card{
        background: #FFFFFF;
        color: #5B5D88;
        margin-right: 10px;
        white-space: wrap;
        min-width: 300px;
      }
    .card-carousel-cards .card-carousel--card{
      @media(max-width: 1245px){
        right: 100px;
      }
    }

    .card-carousel--overflow-container{
          @media(max-width:767px){
            overflow-x: scroll;
            scroll-behavior: smooth;
          }
          &::-webkit-scrollbar-thumb {
              background:#0078bf;
          }

          &::-webkit-scrollbar-track {
              background: #c8eded;
          }
          &::-webkit-scrollbar {
              height:3px;
              background: transparent; /* make scrollbar transparent */
          }
      }
    
      .card-carousel--overflow-container::-webkit-scrollbar {
          height:1px;
          background: transparent; /* make scrollbar transparent */
        }
  }

    .last-item-slider{
            &:after{
                display:none;
            }
    }
    .btn-prev, .btn-next{
        @media(max-width:767px){
            display: none !important;
        }
    }

}
#slider{
  display: flex;
  justify-content: space-between;
}
</style>