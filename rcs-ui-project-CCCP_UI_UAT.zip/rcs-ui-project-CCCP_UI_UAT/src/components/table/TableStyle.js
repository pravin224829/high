export default {
    table: {
      tableClass: 'table ',
      sortableIcon: 'fa fa-sort',
      ascendingIcon: 'fa fa-sort-up',
      descendingIcon: 'fa fa-sort-down',
      handleIcon: 'glyphicon glyphicon-menu-hamburger',
      renderIcon: function(classes) {
        return `<span class="${classes.join(' ')}"></span>`
      }
    },
    pagination: {
      infoClass: 'pull-left',
      wrapperClass: 'pull-right',
      activeClass: 'active',
      disabledClass: 'disabled',
      pageClass: 'btn',
      linkClass: 'btn',
      icons: {
        first: 'flaticon-back btn-previous',
        prev: 'flaticon-back',
        next: 'flaticon-next',
        last: 'flaticon-next btn-next',
      },
    }
  }