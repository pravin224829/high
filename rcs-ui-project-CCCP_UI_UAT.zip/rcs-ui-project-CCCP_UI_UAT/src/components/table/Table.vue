<template>
  <div class="table-responsive table-pagination">
       <template >
          <div class="table_grid_loader" v-show="display_status===true" v-bind:style="GetStyle(perPage)" >
              <vcl-table :width="'100%'" :rows="perPage" :columns="9" />  
          </div>
      </template>
       <div class="ui right aligned three wide column">
      
            <div class="settings-button" @click="showSettingsModal" >
              <div class="settings-button-inn">
                  <i class="flaticon-admin"></i>
              </div>
          </div>
        </div>
      <template>
          <settings-modal ref="settingsModal"
            :vuetable-fields="vuetableFields"
            :settingsshow="SettingsShow"
            @close_modal="close_modals"
            :track-by="this.getNewDetails()"

          ></settings-modal>
          <vuetable ref="vuetable"
              :api-url="table_date.api_url"
              :api-mode="table_date.api_mode"
              :fields="fields"
              data-path="data"
               :http-options="{
                headers:{
                  'auth':this.authDetails(),
                  'corelationid' : this.getNewDetails(),
                  'businesscorelationid' :  this.getNewDetails(),
                },
              }"
              :pagination-path="table_date.pagination_mode"
              :per-page="perPage"
              :multi-sort="multiSort"
              :table-height="tableHeight"
              :data-manager="dataManager"
              :detail-row-component="detailRow"
              :css="table_style.table"
              :sort-order="sortOrder"
              @vuetable:pagination-data="onPaginationData"
              @vuetable:initialized="onInitialized"
              @vuetable:loading="showLoader"
              @vuetable:loaded="hideLoader"

              @vuetable:scrollbar-visible="onScrollbarVisible"
              @refresh="refreshTable"
          >
            <template #SNO="{ rowIndex }">
        {{ rowIndex + 1 }}
      </template>
            <div slot="custom-actions" slot-scope="props">
              <div class="btn-group action-component dropleft bg-0">
                  <b-dropdown id="dropdown-dropleft" dropleft  variant="trans" class="m-2">
                    <b-dropdown-item href="#"   @click="GetDetails('report_submit', props.rowData, 'funcions')">Report Submit</b-dropdown-item>
                    <b-dropdown-item href="#" @click="GetDetails('case_history', props.rowData, 'funcions')">Case History</b-dropdown-item>
                  </b-dropdown>
                </div>
            </div>

            <div slot="actions" slot-scope="props">
                <div class="action-holder" @click="GetDetails('claim_details', props.rowData, 'funcions')">
                  <img src="@/assets/images/action-add.svg" alt="action-add">
                </div>
            </div>

             <div slot="uploadnhai" slot-scope="props"> 
                <div class="action-holder" @click="GetDetails('claim_details', props.rowData, 'funcions')">
                 <template v-if="$store.state.profile.role__code == 'NHAI'">
                  <img src="@/assets/images/download-icon.svg" alt="download">
                 </template>
                 <template v-else> 
                   <a href="#" class="upload_doc_icon">
                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10.2924 3.75649L8.38515 5.66487C7.82942 6.2206 7.27331 6.77614 6.71682 7.33149C6.39255 7.65404 5.97833 7.67524 5.6913 7.38878C5.40427 7.10232 5.42489 6.68695 5.74859 6.36326C7.30922 4.80149 8.87041 3.24029 10.4322 1.67966C10.7857 1.32675 11.169 1.32274 11.5207 1.67279C13.0867 3.23876 14.6527 4.80473 16.2186 6.3707C16.532 6.68466 16.5515 7.09659 16.2731 7.38133C15.9946 7.66607 15.5684 7.65805 15.2481 7.33779C14.1206 6.21182 12.9939 5.08508 11.8679 3.95758C11.8141 3.90373 11.7579 3.85274 11.6662 3.76623V4.05268C11.6662 7.91796 11.6662 11.7832 11.6662 15.6485C11.671 15.7484 11.6668 15.8485 11.6536 15.9476C11.6202 16.1107 11.5286 16.2561 11.3961 16.3568C11.2635 16.4575 11.0989 16.5067 10.9328 16.4952C10.7667 16.4837 10.6104 16.4124 10.4929 16.2944C10.3755 16.1764 10.3048 16.0198 10.2941 15.8536C10.2901 15.7826 10.2941 15.711 10.2941 15.6393V3.75649H10.2924Z" fill="#B2B3C7"></path>
                        <path d="M2.74474 19.247H19.2126V19.0178C19.2126 18.2108 19.2126 17.4033 19.2126 16.5955C19.2126 16.1372 19.4894 15.8284 19.895 15.8267C20.3006 15.8249 20.5825 16.136 20.5825 16.5892C20.5825 17.4612 20.5854 18.3326 20.5825 19.2046C20.579 20.0347 19.993 20.6277 19.1674 20.6283C13.7079 20.6283 8.24893 20.6283 2.79057 20.6283C1.965 20.626 1.37489 20.0359 1.37489 19.2074C1.37146 18.329 1.37146 17.4505 1.37489 16.572C1.37489 16.1338 1.66135 15.8272 2.05895 15.8272C2.45656 15.8272 2.74645 16.1349 2.74645 16.572C2.74588 17.4532 2.74474 18.3383 2.74474 19.247Z" fill="#B2B3C7"></path>
                    </svg>
                  </a>
                </template>  
                </div>
            </div>

             <div slot="menuSearchActions" slot-scope="props">
                <div class="action-holder" @click="GetDetails(tableHeaderObj, props.rowData, 'funcions')">
                  <img src="@/assets/images/action-add.svg" alt="action-add">
                </div>
            </div>

            <div slot="documentName" slot-scope="props">
                <div class="document-details"><div class="img-icon"><img src="@/assets/images/pdf-icon.png" alt="jpg icon" style="margin:0"></div><p> {{($route.name == 'nhai-document-upload-list' || $route.name == 'nhidcl-document-upload-list' || $route.name == 'bajaj-allianz-insurance-policy-verification') ? props.rowData.name : props.rowData.documentName}}</p></div>
            </div>

            <div slot="selectbox">
                <input type="checkbox" class="checkbox-input">
            </div>

            
            
            <div slot="claimsstatus" slot-scope="props" @click="GetDetails('claimsstatus', props.rowData, 'funcions')">
              <a class="view_claim_icon">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" >
                      <path d="M23.9111 11.716C23.7221 11.441 19.18 4.99988 11.9999 4.99988C5.83883 4.99988 0.348744 11.404 0.11774 11.677C-0.0392467 11.863 -0.0392467 12.136 0.11774 12.323C0.348744 12.596 5.83883 19.0001 11.9999 19.0001C18.1611 19.0001 23.6511 12.596 23.8821 12.323C24.0271 12.151 24.0401 11.902 23.9111 11.716ZM11.9999 18.0001C7.06088 18.0001 2.36478 13.29 1.17179 12C2.36281 10.709 7.0539 5.99992 11.9999 5.99992C17.779 5.99992 21.8581 10.703 22.8541 11.973C21.7041 13.222 16.981 18.0001 11.9999 18.0001Z" fill="#9092AD"></path>
                      <path d="M12 7.99988C9.79403 7.99988 8 9.79391 8 11.9999C8 14.2059 9.79403 16 12 16C14.2061 16 16.0001 14.2059 16.0001 11.9999C16.0001 9.79391 14.2061 7.99988 12 7.99988ZM12 15C10.346 15 9 13.654 9 12C9 10.346 10.346 8.99992 12 8.99992C13.6541 8.99992 15.0001 10.346 15.0001 12C15.0001 13.654 13.6541 15 12 15Z" fill="#9092AD"></path>
                  </svg>                                                                                              
              </a>
            </div>

            <div slot="updateclaimdetailsstatus" slot-scope="props" @click="GetDetails('updateclaimdetailsstatus', props.rowData, 'funcions')">
              <a class="view_claim_icon">
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <g clip-path="url(#clip0_2229_31788)">
                      <path d="M19.4578 3.60871L16.3912 0.54207C15.6687 -0.180469 14.4991 -0.180586 13.7765 0.54207C13.2622 1.05648 1.95468 12.364 1.73902 12.5796C1.65378 12.6648 1.59351 12.7717 1.5648 12.8888L0.0193706 19.1825C-0.0992232 19.6656 0.339136 20.0981 0.817457 19.9806C1.14406 19.9004 6.82207 18.5061 7.11109 18.4351C7.22812 18.4064 7.33507 18.3461 7.42027 18.2609C7.64746 18.0337 18.892 6.78914 19.4578 6.22336C20.1803 5.50082 20.1805 4.33133 19.4578 3.60871ZM1.56058 18.4393L1.62355 18.183L1.81695 18.3764L1.56058 18.4393ZM3.31515 18.0085L1.99144 16.6848L2.56707 14.3407L5.65925 17.4328L3.31515 18.0085ZM6.95375 16.8613L3.13859 13.0462L12.9903 3.19437L16.8055 7.00953L6.95375 16.8613ZM18.5248 5.29031L17.7627 6.0523L13.9476 2.23715L14.7096 1.47516C14.9164 1.2684 15.2513 1.2682 15.4582 1.47516L18.5248 4.54184C18.7316 4.74867 18.7316 5.0834 18.5248 5.29031Z" fill="#B2B3C7"></path>
                      </g>
                      <defs>
                      <clipPath id="clip0_2229_31788">
                      <rect width="20" height="20" fill="white"></rect>
                      </clipPath>
                      </defs>
                  </svg>                                                                                              
              </a>
            </div>

            

            <div slot="docactions" slot-scope="props">
                <div class="action-holder" @click="GetDetails('document_details', props.rowData, 'funcions')">
                  <a href="#" class="upload_doc_icon">
                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10.2924 3.75649L8.38515 5.66487C7.82942 6.2206 7.27331 6.77614 6.71682 7.33149C6.39255 7.65404 5.97833 7.67524 5.6913 7.38878C5.40427 7.10232 5.42489 6.68695 5.74859 6.36326C7.30922 4.80149 8.87041 3.24029 10.4322 1.67966C10.7857 1.32675 11.169 1.32274 11.5207 1.67279C13.0867 3.23876 14.6527 4.80473 16.2186 6.3707C16.532 6.68466 16.5515 7.09659 16.2731 7.38133C15.9946 7.66607 15.5684 7.65805 15.2481 7.33779C14.1206 6.21182 12.9939 5.08508 11.8679 3.95758C11.8141 3.90373 11.7579 3.85274 11.6662 3.76623V4.05268C11.6662 7.91796 11.6662 11.7832 11.6662 15.6485C11.671 15.7484 11.6668 15.8485 11.6536 15.9476C11.6202 16.1107 11.5286 16.2561 11.3961 16.3568C11.2635 16.4575 11.0989 16.5067 10.9328 16.4952C10.7667 16.4837 10.6104 16.4124 10.4929 16.2944C10.3755 16.1764 10.3048 16.0198 10.2941 15.8536C10.2901 15.7826 10.2941 15.711 10.2941 15.6393V3.75649H10.2924Z" fill="#B2B3C7"></path>
                        <path d="M2.74474 19.247H19.2126V19.0178C19.2126 18.2108 19.2126 17.4033 19.2126 16.5955C19.2126 16.1372 19.4894 15.8284 19.895 15.8267C20.3006 15.8249 20.5825 16.136 20.5825 16.5892C20.5825 17.4612 20.5854 18.3326 20.5825 19.2046C20.579 20.0347 19.993 20.6277 19.1674 20.6283C13.7079 20.6283 8.24893 20.6283 2.79057 20.6283C1.965 20.626 1.37489 20.0359 1.37489 19.2074C1.37146 18.329 1.37146 17.4505 1.37489 16.572C1.37489 16.1338 1.66135 15.8272 2.05895 15.8272C2.45656 15.8272 2.74645 16.1349 2.74645 16.572C2.74588 17.4532 2.74474 18.3383 2.74474 19.247Z" fill="#B2B3C7"></path>
                    </svg>
                  </a>
                </div>
            </div>

            <div slot="docdownactions" slot-scope="props">
              <a href="#" class="action-icon pointer" @click="GetDetails('download-file', props.rowData, 'funcions')"><img src="@/assets/images/download-icon.svg" alt="download"></a>
            </div>

             <div slot="exceldownactions" slot-scope="props">
              <div class="action-icon pointer" @click="GetDetails('download-excel', props.rowData, 'funcions')"><img src="@/assets/images/download-icon.svg" alt="download"></div>
            </div>

            <div slot="legalLink" slot-scope="props" class="pointer">
                <div class="btn-group action-component dropleft bg-0 case_link"><a :href="props.rowData.link" target="_blank"> Click Here</a> </div>
            </div>

             <div slot="clientFieldActions" slot-scope="props" class="pointer">
                <div class="icon-holder pointer">
                    <i class="fa fa-plus mr-4" @click="GetDetails('add-record', props.rowData, 'funcions')"> </i>
                </div>
            </div>
           
            <div slot="triggerDescription" slot-scope="props" class="pointer" @click="GetDetails('show-card', props.rowData, 'funcions')">
                {{props.rowData.triggerDescription}} 
            </div>
            <div slot="triggerCode" slot-scope="props" class="pointer" @click="GetDetails('show-card', props.rowData, 'funcions')">
                {{props.rowData.triggerCode}} 
            </div>
             <div slot="legal_address" slot-scope="props" class="pointer">
                    {{formatColumn(props.rowField,props.rowData)}}
             </div>
            <div slot="edit-details" slot-scope="props" class="pointer">
                <div class="flaticon-edit-1" @click="GetDetails('edit-details', props.rowData, 'funcions')"></div>
            </div>
            <div slot="assignedToName" slot-scope="props">
              <button type="button" class="allocate-btn" v-if="props.rowData.caseStatus=='Pending For Allocation'" @click="GetDetails('allocate', props.rowData, 'funcions')">Allocate</button>
                <div class="btn-group action-component dropleft bg-0" v-else>
                    <i class="flaticon-user"></i> {{props.rowData.assignedToName}}
                </div>
            </div>
            <div slot="case-allocate" slot-scope="props">
              <button type="button" class="allocate allocate-btn"  @click="GetDetails('case-allocate', props.rowData, 'funcions')">Allocate</button>             
            </div>
            <div slot="delete-triggers" slot-scope="props">
                <button v-if="props.rowData.status=='new'" type="button" class="allocate allocate-btn"  @click="GetDetails('delete-triggers', props.rowData, 'funcions')">Remove</button>             
            </div>

             <div slot="caseAssign" slot-scope="props">
                <button  type="button" class="allocate allocate-btn"  @click="GetDetails('assign-case', props.rowData, 'funcions')">Assign</button>             
            </div>

            
             <div slot="download-file" slot-scope="props" class="text-center">
                <i class="flaticon-download-3 download-icon" @click="GetDetails('download-file', props.rowData, 'funcions')"></i>           
            </div>
            <div slot="failed-records" slot-scope="props" class="text-center" v-show="props.rowData.failedRecords">
                <span class="result-fail">{{props.rowData.failedRecords}}</span>
                <i :class="getIconClass(props.rowData.failedRecords)" @click="GetDetails('failed-records', props.rowData, 'funcions')"></i>           
            </div>
            <div slot="successRecords" slot-scope="props" class="text-center" v-show="props.rowData.successRecords">
                <template v-if="props.rowData.fileRefNo">
                    <span class="result-pass">{{props.rowData.successRecords}}</span>
                </template>
                <template v-else>
                    <span class="result-pass pointer" @click="GetDetails('uploded-records', props.rowData, 'funcions')">{{props.rowData.successRecords}}</span>
                </template>
                    
            </div>
            <div slot="upload-report" slot-scope="props">
              <button type="button" class="upload-report-button"  @click="GetDetails('upload-report', props.rowData, 'funcions')">Upload Report</button>             
            </div>
            <div slot="caseNumber" slot-scope="props">
              <div class="btn-group action-component dropleft bg-0 case_link"  @click="GetDetails('case-details', props.rowData, 'funcions')">{{props.rowData.caseNo}}</div>             
            </div>
            <div slot="caseNumberNoLink" slot-scope="props">
              {{props.rowData.caseNo}}           
            </div>

            
            
            <div slot="view_case_upload_details" slot-scope="props" class="pointer">
                <div class="btn-group action-component dropleft bg-0 case_link" @click="GetDetails('view_case_upload_details', props.rowData, 'funcions')"> {{props.rowData.fileName}} 
                </div>
            </div>
            <div slot="view_allocate_upload_details" slot-scope="props" class="pointer">
                <div class="btn-group action-component dropleft bg-0 case_link" @click="GetDetails('view_allocate_upload_details', props.rowData, 'funcions')"> {{props.rowData.allocatedFileName}} 
                </div>
            </div>
           
            <div slot="mh_upload_report" slot-scope="props" class="text-center">
              <i class="flaticon-upload pointer" @click="GetDetails('mh_upload_report', props.rowData, 'funcions')"></i>               
            </div>
            <div slot="mh_document" slot-scope="props" class="text-center">
              <i class="flaticon-upload pointer" @click="GetDetails('mh_document', props.rowData, 'funcions')"></i>               
            </div>
            <div slot="mh_invoice" slot-scope="props" class="text-center">
              <i class="flaticon-upload pointer" @click="GetDetails('mh_invoice', props.rowData, 'funcions')"></i>               
            </div>
            <div slot="mh_invoice_download" slot-scope="props" class="text-center">
                <i class="flaticon-download-3 download-icon" @click="GetDetails('mh_invoice_download', props.rowData, 'funcions')"></i>           
            </div>
            <div slot="mh_document_download" slot-scope="props" class="text-center">
                <i class="flaticon-download-3 download-icon" @click="GetDetails('mh_document_download', props.rowData, 'funcions')"></i>           
            </div>
            <div slot="withdrawRecords" slot-scope="props" class="text-center" v-show="props.rowData.withdrawRecords">
                <span class="result-wdraw">{{props.rowData.withdrawRecords}}</span>
                <i :class="getIconClass(props.rowData.withdrawRecords)" @click="GetDetails('withdraw-records', props.rowData, 'funcions')"></i>           
            </div>
            <!-- Master Screen slots -->
            <div slot="photo" slot-scope="props">
                <i class="flaticon-edit pointer" type="button"  @click="editUser('edit-user', props.rowData, 'userMaster')"></i>             
            </div>
            <div slot="modifyRM" slot-scope="props">
                <i class="flaticon-edit pointer" type="button"  @click="editUser('edit-user', props.rowData, 'roleMaster')"></i>             
            </div>

            <div slot="evidencesProceed" slot-scope="props">
                <i class="flaticon-edit pointer" type="button"  @click="editUser('suspectAction', props.rowData, 'edit-suspect')"></i>             
                <i class="flaticon-notepad pointer" type="button"  @click="editUser('suspectAction', props.rowData, 'view-suspect')"></i>             
            </div>
            
            <div slot="modify" slot-scope="props">
                <i class="flaticon-edit pointer" type="button"  @click="editUser('edit-user', props.rowData, 'pincodeMaster')"></i>             
            </div>
            <div slot="modifyURM" slot-scope="props">
                <i class="flaticon-edit pointer" type="button"  @click="editUser('edit-user', props.rowData, 'userRoleMaster')"></i>             
            </div>
            <div :slot="`${toggle_button}`" slot-scope="props" :key="toggle_index" v-for="(toggle_button, toggle_index) in toggleButton">
                  <div v-if="props.rowData[toggle_button] == 'ACTIVE'" class="active"> {{props.rowData[toggle_button]}}</div>
                  <div v-if="props.rowData[toggle_button] == 'INACTIVE'" class="inactive"> {{props.rowData[toggle_button]}} </div>
            </div>
           
            <!-- Master Screen slots ends  -->
            <div slot="entityHeadName" slot-scope="props">
              <span class="entity-head-name">
                <span class="case_link " @click="onCellClicked(props)" > {{props.rowData.entityHeadName}}  </span>       
              </span>
            </div>
            <div slot="docListname" slot-scope="props">
              <div class="document-details">
                  <div class="img-icon">
                      <img src="@/assets/images/icons/list-of-outstanding-claims.svg">
                  </div>
                  <p>
                      {{props.rowData.name}}
                      <span>{{props.rowData.total}}</span>
                  </p>
              </div>
            </div>
            
            <div slot="icdDescription" slot-scope="props" class="wrap_text_table">
               {{props.rowData.icdDescription}}
            </div>
            <div slot="triggerDescription" slot-scope="props" class="wrap_text_table">
               {{props.rowData.triggerDescription}}
            </div>
            <div slot="benefitDetails" slot-scope="props" class="wrap_text_table">
               {{props.rowData.benefitDetails}}
            </div>
            <div slot="cptDescription" slot-scope="props" class="wrap_text_table">
               {{props.rowData.cptDescription}}
            </div>
            <div slot="denialDescription" slot-scope="props" class="wrap_text_table">
               {{props.rowData.denialDescription}}
            </div>
            <div slot="clauseDescription" slot-scope="props" class="wrap_text_table">
               {{props.rowData.clauseDescription}}
            </div>
            <div slot="repudiationRemarks" slot-scope="props" class="wrap_text_table">
               {{props.rowData.repudiationRemarks}}
            </div>

          </vuetable>
          <b-row class="text-center w-100">
              <b-col cols="12" md="6" > <div class="dataTables_info text-left" > <vuetable-pagination-info ref="paginationInfo" noDataTemplate="" :css="table_style.pagination"></vuetable-pagination-info></div></b-col>
              <b-col cols="12" md="6" > <div class="dataTables_paginate paging_simple_numbers"> <component :is="paginationComponent" ref="pagination" :css="table_style.pagination"  @vuetable-pagination:change-page="onChangePage"></component></div></b-col>
          </b-row>
      </template>
    </div>
</template>

<script>
import _ from 'lodash'
import { v4 as uuidv4 } from 'uuid';
const Vuetable = () =>import('vuetable-2/src/components/Vuetable')
const VuetableFieldSequence = () =>import('vuetable-2/src/components/VuetableFieldSequence')
const VuetablePagination = () =>import('vuetable-2/src/components/VuetablePagination')
const VuetablePaginationInfo = () =>import('vuetable-2/src/components/VuetablePaginationInfo')
const VuetableRowHeader = () =>import('vuetable-2/src/components/VuetableRowHeader')
const SettingsModal  = () =>import('@/components/table/SettingsModal')
const Loader = () =>import('@/components/common/Loader')
const MyDetailRow = () =>import('@/components/table/DetailRow')
const TabCheckbox = () => import(`@/components/common/CustomTabCheckbox`)
import {VclTable}  from 'vue-content-loading';
import TableCss from "./TableStyle"

export default {
  name: "MyVuetable",

  components: {
    Vuetable,
    VuetablePagination,
    VuetablePaginationInfo,
    VuetableRowHeader,
    Loader,
    VclTable,
    SettingsModal,
    TabCheckbox
  },


 

  props :{
      tableHeaderObj : String, 
      table_body : [Array, Object],
      table_date: Object,
      header : [Array, Object],
      pagination_mode :String,
      action_function : function() {
        return [
        {
            label: "Name"
        }
      ];
    }
  },

   data() {
    return {
    detailRow: MyDetailRow,
    //userIsActive
    toggleButton : ['dashboard', 'newClaimRegistration', 'claimDocumentUpload', 'claimstatus', 'reports', 'updateClaimDetails', 'configuration', 'userIsActive', 'isEnable', 'isActive'],
    httpOptions: {
        headers: {
          auth : ''
        }
    },
     sortOrder: [
        {
          field: "policyNumber",
          direction: "desc"
        }
      ],
      fields: [],
      paginationComponent: "vuetable-pagination",
      vuetableFields: true,
      SettingsShow : false,
      loading: "",
      multiSort: true,
      perPage: 10,
      filterRowVisible: true,
      scrollbarVisible: true,
      table_style : TableCss,
      display_status : false
    };
  },

  mounted(){
      this.ComputeFields()
  },
   beforeMount(){
      this.ComputeFields()
  },

  computed: { // opt. 2
    data :function(){
      return  (this.table_body && typeof this.table_body.data!='undefined') ? this.table_body.data : []
    }
  },

  watch: {
    perPage() {
      this.$nextTick(() => {
        (this.$refs.vuetable) ? this.$refs.vuetable.refresh() : ()=>{}; 
      });
    },

    data() {
        (this.$refs.vuetable) ? this.$refs.vuetable.refresh() : ()=>{}; 
    },

    paginationComponent() {
      this.$nextTick(() => {
        if(this.$refs.paginationInfo){
          this.$refs.pagination.setPaginationData(
            this.$refs.vuetable.tablePagination
          );
        }
      });
    },

    "table_date.header" : function(){
       this.ComputeFields()
    },
    "$store.state.isGridRefresh":function(new_val){
       if(new_val==true){
          this.$refs.vuetable.refresh()
          this.$store.state.isGridRefresh = false
       }
    }

  },

  methods: {
    refreshTable(){
         this.$refs.vuetable.refresh() 
    },
    onPaginationData(tablePagination) {
      if(tablePagination.next_page_url && tablePagination.next_page_url.includes('fetchClaimDoclist') && this.$route && this.$route.name == 'nhai-document-upload-list'){
        this.$store.state.doclist_datas = tablePagination;
      }
      this.$refs.paginationInfo.setPaginationData(tablePagination);
      this.$refs.pagination.setPaginationData(tablePagination);
    },

    getNewDetails (){
      let _temp = uuidv4();
      return _temp
    },

    authDetails(){
      let _token_details = this.$store.state.auth;
      return `${_token_details.type} ${_token_details.token}`
    },

    HeaderData(){
      let headers = {}
      let _token_details = this.$store.state.auth;
      headers['auth'] = `${_token_details.type} ${_token_details.token}`
      headers['corelationid'] =  uuidv4();
      headers['businesscorelationid'] =  uuidv4();
      return headers;
    },

    onChangePage(page) {
      this.$refs.vuetable.changePage(page);
    },

    onInitialized(fields) {
      this.vuetableFields = fields.filter(field => field.togglable);
    },

    showLoader() {
      this.display_status = true;
    },

    hideLoader() {
     this.display_status = false;
    },

    showSettingsModal() {
      this.SettingsShow = true
    },

    onCellClicked(props) {
      if ( props.rowData.entityHeadName !== this.fieldPrefix + "actions") {
        this.$refs.vuetable.toggleDetailRow(props.rowData.id);
      }
    },

    onActionClicked(action, data) {
        console.log('onActionClicked', action,data)
    },

  
    onScrollbarVisible(toggle) {
      this.scrollbarVisible = toggle;
    },

    ComputeFields(){
         let {header, perpage} = this.table_date;
        //  _.forEach(header, (list)=>{
        //     if(list.name=="SNO"){
        //         list.name = VuetableFieldSequence;
        //     }
        //     // if(list.name == "Status"){
        //     //   list.sortable = false;
        //     // }
        // })
        this.fields = header
        this.perPage = perpage
        return header
    },

    dataManager(sortOrder, pagination) {
      if (this.data.length < 1) return;
      let local = this.data;
      // sortOrder can be empty, so we have to check for that as well
      if (sortOrder.length > 0) {
        local = _.orderBy(
          local,
          sortOrder[0].sortField,
          sortOrder[0].direction
        );
      }
      pagination = this.$refs.vuetable.makePagination(
        local.length,
        this.perPage
      );
      let from = pagination.from - 1;
      let to = from + this.perPage;
      return {
        pagination: pagination,
        data: _.slice(local, from, to)
      };
    },

    GetDetails(field, value, type){
        this.$emit("GetDetails",field, value, type)
    },
    editUser(event, rowValue, place){
      //console.log(event, rowValue, place,"event, rowValue, place")
      this.$emit(event, rowValue, place)
    },

    GetStyle(page_height){
        return 'height:'+page_height *62+'px'
    },

    close_modals(values){
        this.SettingsShow = values
    },
    formatColumn(field,row){
      console.log(field,row,"field,row")
      if(field.name=="address"){
          let data = []
          let temp_obj = {
            street : row.address_street ? row.address_street : '',
            taluka : row.address_taluka? row.address_taluka : '',
            district:row.address_district? row.address_district : '',
            state : row.address_state? row.address_state : '',
            pincode : row.address_pincode? row.address_pincode : ''
          }
          for(let obj in temp_obj){
              if(temp_obj[obj]){
                  data.push(temp_obj[obj])
              }
          }
          return data.join(", ")
      }
    },
    getIconClass(value){
      if(value && parseInt(value)>0){
        return "flaticon-download-3 ml-2 download-icon"
      }else{
        return "flaticon-download-3 ml-2 download-icon-disabled"
      }
    }

  }
};
</script>

<style scoped>
.active{
  color: #2ECC71;
  background-color: rgba(46, 204, 113, 0.1);
  text-align: center;
  border-radius: 5px;
  width: 100px;
  height: 30px;
  padding: 4px 20px;
  margin: 0 auto;
}
.inactive{
  color: #D63031;
  background-color: rgba(214, 48, 49, 0.1);
  text-align: center;
  border-radius: 5px;
  width: 100px;
  height: 30px;
  padding: 4px 17px;
  margin: 0 auto;
 }

</style>