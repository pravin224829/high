<template>
      <settings-modal  v-if="settingsshow" title="Settings" :header="true" :footer="true" size="lg"  @GetDetails="GetChangeFunction" header_style="cases-title" no-close-on-backdrop no-close-on-esc> 
        <div class="content ui form">
          <div class="row">
              <div class="col-12 col-sm-8">
                <h3>Settings</h3>
              </div>
               <div class="col-12 col-sm-4">
                  <div class="close_modal" @click="CloseSettings">
                     <i class="flaticon-close-4"></i>
                  </div>
                  <div class="settings-field pull-right">
                      <select class="form-control" v-model="$parent.perPage">
                          <option :value="5">5</option>
                          <option :value="10">10</option>
                          <option :value="15">15</option>
                          <option :value="20">20</option>
                          <option :value="25">25</option>
                      </select>
                  </div>
                
              </div>
          </div>
          <div class="ui fluid card">
            <div v-if="vuetableFields" class="content">
              <b-list-group>
                <b-list-group-item v-for="(field, idx) in vuetableFields" class="field" :key="idx">
                  <div class="ui checkbox">
                    <input type="checkbox" :checked="field.visible" @change="toggleField(field)"> 
                    <label>{{ getFieldTitle(field) }}</label>
                  </div>
                </b-list-group-item>
              </b-list-group>
            </div>
          </div>
        </div>
    </settings-modal>
</template>

<script>
const SettingsModal = () => import('@/components/common/Modal')
export default {
  components :{
    SettingsModal
  },
  props: ['vuetableFields','settingsshow','close_modal'],
 
  data() {
    return {
      visible: false
    };
  },

  computed: {
    vuetable() {
      return this.$parent.$refs.vuetable
    }
  },

  methods: {
    getFieldTitle(field) {
      if (typeof field.title === "function") return field.title(true);

      let title = field.title;
      if (title !== "") return this.stripHTML(title);

      return title;
    },

    CloseSettings(){
      this.$emit('close_modal', false)
    },

    stripHTML(str) {
      return str ? str.replace(/(<([^>]+)>)/gi, "") : "";
    },

    toggleField(field, event) {
      console.log('toggleField',event )
      this.vuetable.toggleField(field.$_index);
    },

    show() {
      this.visible = true;
    },

    hide() {
      this.visible = false;
    }
  }
};
</script>

<style>
#settingsModal {
  top: 60px;
}
</style>
