<template>
    <div @click="onClick" class="sub_header_main">
      <table class="table" v-if="rowData.sub_rows && rowData.sub_rows.header">
      <thead>
        <tr class="sub_header">
          <th scope="col" v-for="(headers, index) in rowData.sub_rows.header" :key="index">{{headers.title}}</th>
        </tr>
      </thead>
      <tbody>
        <template v-if="rowData.sub_rows && rowData.sub_rows.body && rowData.sub_rows.body.length">
          <tr>
            <td v-for="(body, index) in rowData.sub_rows.body" :key="index">{{body.name}}</td>
          </tr>
        </template>
        <template v-else>
          <tr>

          </tr>
       </template>
      </tbody>
    </table>
    </div>
  </template>

  <script>
  export default {
    props: {
      rowData: {
        type: Object,
        required: true
      },
      rowIndex: {
        type: Number
      }
    },
    methods: {
      onClick (event) {
        console.log('my-detail-row: on-click', event.target)
      }
    },
  }
  </script>