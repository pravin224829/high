<template>
    <div>
        <div class="navbar navbar-expand-lg bsnav">
            <div class="container-fluid">

                <img  :src="`data:image/png;base64,${user_profile.businessLogo}`" class="img-fluid app-logo" alt="logo" v-if="user_profile.businessLogo" width="12%" style="border-radius:5px; margin-right:5px;height:80px !important">
                <a class="" style="width:11.6%;" href="#">
                    <img src="@/assets/images/bajajlogo.jpg" style="border-radius:5px;height:80px !important" class="img-fluid" alt="logo">
                </a>
                <!-- <img v-if="user_profile.role__code == 'NHAI'" src="@/assets/images/NHAI.jpg" width="175px" height="100px" style="border-radius:5px; margin-right:5px;"> -->
                
                <button class="navbar-toggler toggler-spring"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse justify-content-sm-end">
                
                <h1 class="top-bar-title d-none d-sm-block text-center ml-lg-auto">Udyam Seva Portal उद्यमसेवा पोर्टल</h1>
                <div class="flex-column ml-auto">
                    <ul class="navbar-nav navbar-mobile user-profile-header ml-lg-auto">
                       

                        <li class="nav-item dropdown user-details">
                            <a class="nav-link d-flex align-items-center" data-toggle="dropdown" href="#"  @click="showProfileMenu = !showProfileMenu"  >
                                <!-- @click="showProfileMenu = !showProfileMenu" -->
                                <img :src="`data:image/png;base64,${user_profile.profileLogo  }`" alt="user-icon">
                                <div class="user-logs">
                                    <!-- user_profile.profileLogo -->
                                    <span class="d-flex align-items-center">{{user_profile.firstName}} {{user_profile.lastName}} <i class="material-icons prefix">expand_more</i></span>
                                    <span v-if="user_profile.role__code !== 'NHAI'">{{user_profile.designation}}</span>
                                    <span v-if="user_profile.role__code === 'NHAI'">{{user_profile.role__name}}</span>
                                </div>
                            </a>
                            
                            <div class="dropdown-menu user-profile-dropdown dropdown-menu-right" :class="{'show':showProfileMenu}">
                                <div class="user-profile-links">
                                    <a href="#"   class="dropdown-item d-flex align-items-center" @click="showPopup" ><i class="material-icons prefix">person</i> Profile</a>
                                     
                                </div>
                                
                                <div class="user-profile-links">
                                    <a href="#" @click="logout" class="dropdown-item d-flex align-items-center"><i class="material-icons prefix">logout</i> Logout</a>
                                </div>
                            </div>
                            <div v-if="showProfileMenu" class="outside" @click="clickOutside()"></div>
                        </li>
                    </ul>
                </div>
                </div>
            </div>
            <profile-popup :show="popupVisible" :profileLogo="user_profile.profileLogo" :_designation="user_profile.designation" title="My Popup" @close="closePopup">
            </profile-popup>
        </div>
         
         
    </div>
   
       
     
    
</template>

<script>
import {mapState} from 'vuex'
import ProfilePopup from '@/components/common/ProfilePopup.vue'; 
    export default {
        name: 'TopBar',
        components: {
            ProfilePopup
        },
        
        data() {
            return {
                showProfileMenu: false,
                popupVisible: false,
                 
            }
        },
        computed:{
            ...mapState({
                user_profile : state => state.profile,
            })
        },
        methods:{
            async openProfile() {    
                alert("popup");
            },
            async showPopup() {
                 
                this.popupVisible = true;
                 this.showProfileMenu = false;
                
            },
             
            
            async closePopup() {
                this.popupVisible = false;
            },

            async logout() {    
                let _temp_details = this.$store.state.auth.keyclock  
                if(this.$route.path !== '/') await this.$router.push('/')
                localStorage.clear();
                sessionStorage.clear();
                _temp_details.logout()
            },
            clickOutside(){
                this.showProfileMenu = false
            },
            
        }
    }
</script>
<style scoped>
@media (min-width: 576px) { 
    .app-logo{
        height: 50px;
    }
 }

@media (min-width: 768px) { 
    .app-logo{
        height: 50px;
    }
 }
.outside {
  width: 100vw;
  height: 100vh;
  position: fixed;
  top: 0px;
  left: 0px;
}
</style>