<template>
    <div class="row align-top">
        <template  v-for="(item_list, rowIndex) in form_base" >
         <!-- <pre> {{item_list}}</pre> -->
          <ValidationProvider :vid="item_list.model" :rules="item_list.rules" :name="item_list.label"  :key="item_list.id" :class=" item_list.type == 'checkbox_text' ? 'col-lg-12' : ClassFormate(item_list) " slim v-if="item_list.check_display==='true' && item_list.field_count==null" >
            
              <template slot-scope="{ valid, errors }">
                <div v-if="item_list.sub_index!='false' && item_list.sub_index==item_list.id" class="full_width_main_dashed">
                  <h5>{{item_list.sub_label}} </h5>
                </div>
                
                 <template v-if="item_list.type==='submit_button'">
                    <div class="row">
                      <b-col sm="12">
                        <div class="form-group mb-0 mt-4 text-left from-display mr-2">
                            <label>&nbsp;</label>
                            <button @click="$emit('on-filter-search')" class="filter-button" type="submit">{{item_list.label}}</button>
                             <label>&nbsp;</label>
                            <button @click="$emit('on-clear-search')" class="reset-button" type="button">Reset</button>
                        </div>
                        
                       </b-col>
                    </div>
                 </template>
                  <template v-if="(item_list.type==='label') && (item_list.check_display==='true')">
                      <b-row class="mb-4 form-group " :class="(item_list.disbabled) ? 'default-active' : false">
                          <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                              <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label> 
                          </b-col>
                    </b-row>
                </template>
                 <template v-if="(item_list.type==='declaration') && (item_list.check_display==='true')">
                      <section class="declaration-section mt-2">
                         <p>I / we here by propose to insure the above-mentioned animals owned by me / us with Bajaj Allianz General Insurance Co. Ltd. subject to the terms &amp; conditions and exclusions of the Company’s Policy. I / we warrant that the answer to the above queries are true 
                            and that all the animal /s are correctly described and are in sound and good health and free from vice and that they are and shall be used solely for the purpose above stated. I / We declare that no information material to the insurance has been withheld and 
                            agree that this proposal shall be the basis of the contract between the Company and me/us"</p>
                             <label :for="`type-${item_list.model}`"> 
                                <input type="checkbox" :id="`type-${item_list.model}`" :name="item_list.model" v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" :disabled ="(item_list.disbabled) ? 'disabled' : false" :state="errors[0] ? false : (valid ? display_success : null)" @change="declaration_click(item_list.model, BasicForm[item_list.model])">
                                <span class="checkbox"></span>
                              <span class="text">I agree </span>
                                <div class="text-danger" v-if="errors[0]">
                                  {{ errors[0] }}
                                  </div>
                              </label>
                            
                        <hr>
                      </section>
                 </template>
                 <template v-if="(item_list.type==='checkbox_text') && (item_list.check_display==='true')">
                      <section class="declaration-section">
                         <p v-if="item_list.label == 'Disclaimer'">{{item_list.label}}</p>
                         <div style="display: flex" :class="item_list.label">
                           <label :for="`type-${item_list.model}`"> 
                                <input type="checkbox" :id="`type-${item_list.model}`" :value='item_list.model' @click="InsuredDetailsDisclaimer(item_list, item_list.model)" :name="item_list.model" v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" >
                                <div class="text-danger" v-if="errors[0]">
                                  {{ errors[0] }}
                                  </div>
                              </label>
                              <p v-if="item_list.label == 'Same As Insured Details'">{{item_list.label}}</p>
                              <p v-if="item_list.label == 'Disclaimer'">I have understood the claim process and all the information being provided with the claim intimation is true / correct. I shall comply to claim process as stipulated  by the company and submit all required documents in support of the claim.</p>
                         </div>
                      </section>
                 </template>
                 <template v-if="(item_list.type==='signature') && (item_list.check_display==='true')">
                   <div class='signature-capture'>
                      <label>{{item_list.label}}</label>
                     <VueSignaturePad width="210px" height="90px"  id="signature" ref="signaturePad"/>
                     <div class="signature-buttons">
                        <button type="button" class="save-button mt-3" @click="save(item_list.model)">Save</button>
                        <button type="button" class="clear-button mt-3" @click="un_do(item_list.model)">Clear</button>
                      </div>
                  </div>
                 </template>
                 <template v-if="(item_list.type==='display_text')">
                      <b-row class="mb-4 form-group display-text" :class="(item_list.disbabled) ? 'default-active' : false">
                          <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                              <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label> 
                        
                              <b-form-input
                                type="text"
                                v-model="BasicForm[item_list.model]"
                                :ref="item_list.model"
                                :state="errors[0] ? false : (valid ? display_success : null)"
                                :disabled ="(item_list.disbabled) ? 'disabled' : false"
                                :placeholder="item_list.placeholder"
                                @blur="handleBlur(item_list, item_list.model, BasicForm[item_list.model])"
                                @keydown.enter.prevent
                              >
                              </b-form-input>
                          
                          </b-col>
                    </b-row>
                </template>
                <template v-if="(item_list.type==='email' ) && (item_list.check_display==='true')">
                    <b-row class="mb-2 form-group " :class="(item_list.disbabled) ? 'default-active' : false">
                          <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                              <label :for="`type-${item_list.type}`">
                                <label class="switch" v-if="item_list.displayRadio=='true'">
                                      <input type="checkbox" id="work-queue-switch" name="work-queue-switch" :checked="(item_list.disbabled) ? false : true" @click="changeFieldDisplay(item_list, item_list.model, ((item_list.disbabled) ? false : true), sectionObj)">
                                      <span class="switch-slider round"></span>
                                </label>
                                {{ item_list.label }}<span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span> 
                              </label> 

                          </b-col>
                          <b-col :sm="item_list.input_value" >
                               <b-form-input
                                type="text"
                                data-vv-validate-on="blur"
                                v-model="BasicForm[item_list.model]"
                                :ref="item_list.model"
                                :data-targetField="item_list.model"
                                :state="errors[0] ? false : (valid ? display_success : null)"
                                :disabled="(item_list.disbabled) ? 'disabled' : (disable_all_fields) ? disable_all_fields : false"
                                :placeholder="item_list.placeholder"
                                :maxlength="item_list.max_length"
                                v-on:keypress="emailValidate($event, item_list.custom_validation.max_length, BasicForm[item_list.model])"
                                @keydown.enter.prevent
                                @blur="handleInputBlur(item_list, rowIndex, BasicForm[item_list.model],'blur')"
                                @input="handleInputBlur(item_list, rowIndex, BasicForm[item_list.model],'change')"
                              >
                              </b-form-input>
                            <div class="text-danger">
                              <template v-if="item_list.custom_validation && item_list.custom_validation.error_message">
                                {{item_list.custom_validation.error_message}}
                              </template>
                              <div class="text-danger" v-else-if="errors[0] && BasicForm[item_list.model] && (item_list.custom_validation.showError || show_error)">
                                {{ errors[0] }}
                              </div>
                               <div class="text-danger" v-else-if="errors[0] && show_error">
                                {{ errors[0] }}
                              </div>
                            
                            </div>
                          </b-col>
                    </b-row>
                </template>
                 <template v-if="(item_list.type==='toggle' ) && (item_list.check_display==='true')">
                    <b-row class="mb-2 form-group " :class="(item_list.disbabled) ? 'default-active' : false">
                          <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                              <label :for="`type-${item_list.type}`">
                                <label class="switch" v-if="item_list.displayRadio=='true'">
                                      <input type="checkbox" id="work-queue-switch" name="work-queue-switch" :checked="(item_list.disbabled) ? false : true" @click="changeFieldDisplay(item_list, item_list.model, ((item_list.disbabled) ? false : true), sectionObj)">
                                      <span class="switch-slider round"></span>
                                </label>
                                {{ item_list.label }}<span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span> 
                              </label> 

                          </b-col>
                          <b-col :sm="item_list.input_value" >
                            <toggle-button 
                                v-model="BasicForm[item_list.model]"
                                :value="BasicForm[item_list.model]"
                                :color="{checked:'#D9F4E1', unchecked:'#FFE5E5', disabled:'#CCCCCC'}"
                                :sync="true"
                                width="85"
                                height="28"
                                :switch-color="{checked: '#03B238', unchecked: '#FF5353'}"
                                :labels="{checked: 'ACTIVE', unchecked: 'INACTIVE'}"
                            />
                            <div class="text-danger">
                              <template v-if="item_list.custom_validation && item_list.custom_validation.error_message">
                                {{item_list.custom_validation.error_message}}
                              </template>
                              <div class="text-danger" v-else-if="errors[0] && BasicForm[item_list.model] && (item_list.custom_validation.showError || show_error)">
                                {{ errors[0] }}
                              </div>
                               <div class="text-danger" v-else-if="errors[0] && show_error">
                                {{ errors[0] }}
                              </div>
                            
                            </div>
                          </b-col>
                    </b-row>
                </template>
                 <template v-if="(item_list.type==='pancard' ) && (item_list.check_display==='true')">
                    <b-row class="mb-2 form-group " :class="(item_list.disbabled) ? 'default-active' : false">
                          <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                              <label :for="`type-${item_list.type}`">
                                <label class="switch" v-if="item_list.displayRadio=='true'">
                                      <input type="checkbox" id="work-queue-switch" name="work-queue-switch" :checked="(item_list.disbabled) ? false : true" @click="changeFieldDisplay(item_list, item_list.model, ((item_list.disbabled) ? false : true), sectionObj)">
                                      <span class="switch-slider round"></span>
                                </label>
                                {{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span> 
                              </label> 

                          </b-col>
                          <b-col :sm="item_list.input_value" >
                              <b-form-input 
                                type="text"
                                v-model="BasicForm[item_list.model]"
                                :ref="item_list.model"
                                :data-targetField="item_list.model"
                                :state="errors[0] ? false : (valid ? display_success : null)"
                                :disabled="(item_list.disbabled) ? 'disabled' : (disable_all_fields) ? disable_all_fields : false"
                                :placeholder="item_list.placeholder"
                                @keydown.enter.prevent
                                @input="handleInputBlur(item_list, rowIndex, 'change')"
                                @blur="handleInputBlur(item_list, rowIndex, 'blur')"
                              >
                            </b-form-input>
                            <div class="text-danger">
                              <template v-if="item_list.custom_validation && item_list.custom_validation.error_message">
                                {{item_list.custom_validation.error_message}}
                              </template>
                              <div class="text-danger" v-else-if="errors[0] && BasicForm[item_list.model] && (item_list.custom_validation.showError || show_error)">
                              {{ errors[0] }}
                              </div>
                              <template  v-else-if="errors[0] && item_list.display_error==true">
                                {{ errors[0] }}
                              </template>
                              <template  v-else-if="errors[0] && show_error">
                                {{ errors[0] }}
                              </template>
                            </div>
                          </b-col>
                    </b-row>
                </template>
                <template v-if="(item_list.type==='text' || item_list.type==='text_api' || item_list.type==='password' || item_list.type==='contact_number' || item_list.type==='numeric_password'   || item_list.type=='number' || item_list.type=='numeric' || item_list.type=='decimal' || item_list.type=='currency' || item_list.type=='pincode'  || item_list.type=='age' ) && (item_list.check_display==='true')">
                    <b-row class="mb-4 form-group " :class="(item_list.disbabled) ? 'default-active' : false">
                          <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                              <!-- {{item_list.disbabled}} -->
                               <label :for="`type-${item_list.type}`">
                                <label class="switch" v-if="item_list.displayRadio=='true'">
                                      <input type="checkbox" id="work-queue-switch" name="work-queue-switch" :checked="(item_list.disbabled) ? false : true" @click="changeFieldDisplay(item_list, item_list.model, ((item_list.disbabled) ? false : true), sectionObj)">
                                      <span class="switch-slider round"></span>
                                </label>
                                {{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span> 
                              </label> 

                          </b-col>
                          <b-col :sm="item_list.input_value" >
                                 <b-form-input v-if="item_list.type==='text' || item_list.type==='password'"
                                  :type="item_list.type"
                                  v-model="BasicForm[item_list.model]"
                                :ref="item_list.model"
                                  :state="errors[0] ? false : (valid ? display_success : null)"
                                  :disabled ="(item_list.disbabled) ? 'disabled' : false"
                                  :placeholder="item_list.placeholder"
                                  v-on:keypress="isAlphaNumeric($event, item_list.rules)"
                                  @keydown.enter.prevent
                                  @blur="handleBlur(item_list, item_list.model, BasicForm[item_list.model])"
                                >
                                </b-form-input>

                                <b-form-input v-if="item_list.type==='numeric_password'"
                                  type="password"
                                  v-on:keypress="isNumber($event)" @paste="onPaste($event)" 
                                  v-model="BasicForm[item_list.model]"
                                  :ref="item_list.model"
                                  :state="errors[0] ? false : (valid ? display_success : null)"
                                  :disabled ="(item_list.disbabled) ? 'disabled' : false"
                                  :placeholder="item_list.placeholder"
                                  @keydown.enter.prevent
                                  @blur="handleBlur(item_list, item_list.model, BasicForm[item_list.model])"
                                >
                                </b-form-input>
                            
                              <b-form-input v-if="item_list.type==='text_api'"
                                :type="item_list.type"
                                v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                                :state="errors[0] ? false : (valid ? display_success : null)"
                                :disabled ="(item_list.disbabled) ? 'disabled' : false"
                                :placeholder="item_list.placeholder"
                                @keydown.enter.prevent
                                @blur="handleApiCall(item_list, item_list.model, BasicForm[item_list.model])"
                              >
                              </b-form-input>

                              <b-form-input v-if="item_list.type==='decimal'"
                                type="text"
                                v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                                :state="errors[0] ? false : (valid ? display_success : null)"
                                :disabled ="(item_list.disbabled) ? 'disabled' : false"
                                :placeholder="item_list.placeholder"
                                @keydown.enter.prevent
                                @blur="handleBlur(item_list, item_list.model, BasicForm[item_list.model])"
                              >
                              </b-form-input>
                              <b-form-input v-else-if="item_list.type==='number' || item_list.type==='numeric'"
                                type="number"
                                v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                                v-on:keypress="isNumber($event)" @paste="onPaste($event)" 
                                :state="errors[0] ? false : (valid ? display_success : null)"
                                :disabled ="(item_list.disbabled) ? 'disabled' : false"
                                @keydown.enter.prevent
                                @blur="handleBlur(item_list, item_list.model, BasicForm[item_list.model])"
                                :placeholder="item_list.placeholder">
                              </b-form-input>

                              <template v-else-if="item_list.type==='contact_number'">
                                 <b-form-input 
                                type="number"
                                v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                                v-on:keypress="isMobileNumber($event, BasicForm[item_list.model])" @paste="onPaste($event)" 
                                :state="errors[0] ? false : (valid ? display_success : null)"
                                :disabled ="(item_list.disbabled) ? 'disabled' : false"
                                @keydown.enter.prevent
                                :maxlength="item_list.max_length"
                                @blur="handleBlur(item_list, item_list.model, BasicForm[item_list.model])"
                                :placeholder="item_list.placeholder">
            
                              </b-form-input>
                              </template>
                          
                              
                              <b-form-input v-else-if="item_list.type==='pincode'"
                                type="number"
                                v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                                @blur="setCityAndState(BasicForm[item_list.model],item_list.model, rowIndex)"
                                v-on:keypress="isNumber($event)" @paste="onPaste($event)" 
                                :state="errors[0] ? false : (valid ? display_success : null)"
                                :disabled ="(item_list.disbabled) ? 'disabled' : false"
                                @keydown.enter.prevent
                                :placeholder="item_list.placeholder">
                              </b-form-input>
                              <!--for accept dot and configure decimal length-->
                              <b-form-input v-else-if="item_list.type==='currency'"     
                                type="number"
                                v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                                v-on:keypress="isNumberAndDecimal($event,item_list.decimalLength)" @paste="onPaste($event)" 
                                :state="errors[0] ? false : (valid ? display_success : null)"
                                :disabled ="(item_list.disbabled) ? 'disabled' : false"
                                @keydown.enter.prevent
                                 @blur="handleBlur(item_list, item_list.model, BasicForm[item_list.model])"
                                :placeholder="item_list.placeholder">
                              </b-form-input>
                               <b-form-input v-else-if="item_list.type==='age'"     
                                type="number"
                                v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                                @change="emitAge(item_list, item_list.model, BasicForm[item_list.model])"
                                @paste="onPaste($event)" 
                                :state="errors[0] ? false : (valid ? display_success : null)"
                                :disabled ="(item_list.disbabled) ? 'disabled' : false"
                                @keydown.enter.prevent
                                :placeholder="item_list.placeholder">
                              </b-form-input>
                            <div class="text-danger" v-if="errors[0] && BasicForm[item_list.model] && (item_list.custom_validation.showError || show_error)">
                            {{ errors[0] }}
                            </div>
                            <div class="text-danger" v-else-if="errors[0] && show_error">
                              {{ errors[0] }}
                            </div>
                          </b-col>
                    </b-row>
                </template>
                
               <template v-if="(item_list.type==='auto_complete' ) && (item_list.check_display==='true')">
                  <b-row class="mb-4 form-group " :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                          <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label> 
                      </b-col>
                      <b-col :sm="item_list.input_value" >
                          <b-form-input list="my-list-id"
                          v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                          :state="errors[0] ? false : (valid ? display_success : null)"
                          :disabled ="(item_list.disbabled) ? 'disabled' : false"
                          :placeholder="item_list.placeholder">
                          </b-form-input>
                          <datalist id="my-list-id">
                            <template v-for="size in item_list.options">
                              <option :key="size.value">{{ size.value }}</option>
                            </template>
                          </datalist>
                          <div class="text-danger" v-if="errors[0]">
                              {{ errors[0] }}
                          </div>
                      </b-col>
                  </b-row>
              </template>


              <template v-if="(item_list.type==='select_check' || item_list.type==='master_select' || item_list.type==='dependent_check' || item_list.type==='normal_select' || item_list.type==='select'|| item_list.type==='qcselect') && (item_list.check_display==='true')">
                  <b-row class="mb-4 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                    <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                        <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                    </b-col>
                    <b-col :sm="item_list.input_value" class="input-slect-col">
                      <div class="select-loader" v-if="item_list.loader">
                        <b-spinner variant="primary" small="true"></b-spinner>
                      </div>
                      <!-- <b-form-select 
                        v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" 
                        :options="item_list.options"   
                        @change="emitSelectChange(item_list, item_list.model, BasicForm[item_list.model])"
                        :state="errors[0] ? false : (valid ? display_success : null)"
                        class="form-control"
                        :disabled="(item_list.disbabled) ? 'disabled' : false"
                        :placeholder="item_list.placeholder">
                      </b-form-select> -->
                      
                      <model-select 
                        :options="(item_list.options && item_list.options.length) ? item_list.options : []" 
                        v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" 
                        :isDisabled="(item_list.disbabled) ? 'disabled' : false"
                        :id="item_list.model"
                        :placeholder="`---Select---`"
                        @keydown.enter.prevent
                        @input="emitSearchSelectChange(item_list, item_list.model, BasicForm[item_list.model])"
                      ></model-select>
                      <template v-if="show_error">
                        <div class="text-danger" v-if="errors[0]" >
                          {{ errors[0] }}
                          </div>
                      </template>
                    </b-col>
                  </b-row>
              </template>

                <template v-if="(item_list.type==='nselect_check' || item_list.type==='nmaster_check' || item_list.type==='ndependent_check' || item_list.type==='nnormal_select' || item_list.type==='nselect') && (item_list.check_display==='true')">
                  <b-row class="mb-4 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                    <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                        <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                    </b-col>
                    <b-col :sm="item_list.input_value" class="input-slect-col">
                      <div class="select-loader" v-if="item_list.loader">
                        <b-spinner variant="primary" small="true"></b-spinner>
                      </div>
                      <b-form-select 
                        v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" 
                        :options="item_list.options"   
                        @change="emitSelectChange(item_list, item_list.model, BasicForm[item_list.model])"
                        :state="errors[0] ? false : (valid ? display_success : null)"
                        class="form-control"
                        :disabled="(item_list.disbabled) ? 'disabled' : false"
                        @keydown.enter.prevent
                        :placeholder="item_list.placeholder">
                      </b-form-select>
                      
                      <template v-if="show_error">
                        <div class="text-danger" v-if="errors[0]" >
                          {{ errors[0] }}
                          </div>
                      </template>
                    </b-col>
                  </b-row>
              </template>

                <template v-if="(item_list.type==='star_rating' || item_list.type==='review') &&  (item_list.check_display==='true')">
                    <b-row class="mb-4 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                       <b-col  :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                          <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                      </b-col>
                      <b-col>
                        <b-form-input 
                          :type="item_list.type"
                          v-show="item_list.type!=='star_rating' && item_list.type!=='review'"
                          v-model="BasicForm[item_list.model]"
                          :ref="item_list.model"
                          :state="errors[0] ? false : (valid ? display_success : null)"
                          :disabled ="(item_list.disbabled) ? 'disabled' : false"
                        
                          :placeholder="item_list.placeholder">
                        </b-form-input>
                          <div class="row">
                            <div class="col-12 col-sm-2">
                              <star-rating :base_model="BasicForm" :key_object="item_list.model" :current_rating="BasicForm[item_list.model]" :isReadOnly='item_list.disbabled'></star-rating>
                            </div> 
                            <div class="col-12 col-sm-10" style="padding-top: 5px;">{{item_list.weightage}}</div> 
                          </div> 
                        <div class="text-danger" v-if="errors[0]">{{ errors[0] }}</div>
                      </b-col>
                    </b-row>
                </template>

                <template v-if="(item_list.type==='select_file_upload') &&  (item_list.check_display==='true')">
                    <b-row class="mb-4 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                          <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                      </b-col>
                      <b-col :sm="item_list.input_value">
                        <b-form-select v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" :options="item_list.options"   
                          @change="emitSelectChangeFileUpload(item_list.model, BasicForm[item_list.model])"
                          :state="errors[0] ? false : (valid ? display_success : null)"
                          class="form-control"
                          :disabled="(item_list.disbabled) ? 'disabled' : false"
                          :placeholder="item_list.placeholder">
                        </b-form-select>
                      <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                            </div>
                      </b-col>
                    </b-row>
                </template>
                
                <template  v-if="item_list.type==='custom_select' &&  (item_list.check_display==='true')">
                    <b-row class="mb-4 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                          <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                      </b-col>
                      <b-col :sm="item_list.input_value">
                          <multiselect
                              v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                              :options="item_list.options"
                              :close-on-select="true"
                              :clear-on-select="false"
                              :placeholder="(item_list.label)"
                              v-validate="{'required':true}" 
                              label="text"
                              track-by="text"
                              :multiple="false" 
                              :taggable="false" 
                              :allow-empty="false"
                              @tag="addTag"
                              :disabled='item_list.disbabled'
                              deselectLabel='Selected'
                              @input="emitSelectChange(item_list, item_list.model, BasicForm[item_list.model])"
                          >
                          </multiselect>
                          <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                            </div>
                      </b-col>
                    </b-row>
                </template>

               
                <template v-if="(item_list.type==='custom_multiselect' || item_list.type==='qcselect_multiselect') && (item_list.check_display==='true')">
                   
                    <b-row class="mb-4 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                        <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                        </b-col>
                        <b-col :sm="item_list.input_value">
                          <multiselect
                              v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                              :options="item_list.options"
                              :close-on-sxelect="true"
                              :clear-on-select="false"
                              :placeholder="'Select '+(item_list.label)"
                              v-validate="{'required':true}" 
                              label="text"
                              track-by="text"
                              :multiple="true" 
                              :taggable="false" 
                              :allow-empty="true"
                              :hide-selected="true"
                              @tag="addTag"
                              :disabled='item_list.disbabled'
                              @input="emitSelectChange(item_list, item_list.model, BasicForm[item_list.model], 'all')"
                          >
                          </multiselect>
                        <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                            </div>
                        </b-col>
                    </b-row>
                </template>

                 <template v-if="item_list.type==='report_multi_select' && (item_list.check_display==='true')">
                    <b-row class="mb-4 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                        <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                        </b-col>
                        <b-col :sm="item_list.input_value">
                          <multiselect
                              v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                              :options="item_list.options"
                              :close-on-sxelect="true"
                              :clear-on-select="false"
                               :placeholder="'Select '+(item_list.label)"
                              v-validate="{'required':true}" 
                              label="text"
                              track-by="text"
                              :multiple="true" 
                              :taggable="false" 
                              :allow-empty="true"
                              :hide-selected="true"
                              @tag="addTag"
                              :disabled='item_list.disbabled'
                              @input="emitSelectChangeSelected(item_list.model, BasicForm[item_list.model],BasicForm,item_list.model,item_list.options,rowIndex, 'selected')"
                          >
                          </multiselect>
                        <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                            </div>
                        </b-col>
                    </b-row>
                </template>

                <template v-if="item_list.type==='multiselect' && (item_list.check_display==='true')">
                      <b-row class="mb-4 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                        <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                        </b-col>
                      
                        <b-col :sm="item_list.input_value">
                          <b-form-select :select-size="item_list.size" v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" :options="item_list.options" multiple ></b-form-select>
                          <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                            </div>
                        </b-col>
                      </b-row>
                </template>

                <template  v-if="item_list.type==='textarea' && (item_list.check_display==='true')">
                  <b-row class="mb-4 form-group  observation-textarea" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                          <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                      </b-col>
                      <b-col :sm="item_list.input_value">
                          <b-form-textarea
                            :id="item_list.model"
                            @keydown.enter.prevent
                            v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                            :placeholder="item_list.placeholder"
                            :rows="(item_list.rows) ? item_list.rows : ''"
                            :max-rows="(item_list.max_rows) ? item_list.max_rows : ''"
                            :disabled ="(item_list.disbabled) ? 'disabled' : false"
                             size="sm"
                          ></b-form-textarea>
                          <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                            </div>  
                      </b-col>
                  </b-row>
                </template>

                <template  v-if="item_list.type==='mh_textarea' && (item_list.check_display==='true')">
                  <b-row class="mb-4 form-group  observation-textarea" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="item_list.input_value">
                          <b-form-textarea
                            :id="item_list.model"
                            v-model="BasicForm[item_list.model]"
                            :ref="item_list.model"
                            :placeholder="item_list.placeholder"
                            :rows="(item_list.rows) ? item_list.rows : ''"
                            :max-rows="(item_list.max_rows) ? item_list.max_rows : ''"
                            :disabled ="(item_list.disbabled) ? 'disabled' : false"
                            @keydown.enter.prevent
                             size="sm"
                             class="textarea-upload"
                          ></b-form-textarea>
                          <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                            </div>  
                      </b-col>
                  </b-row>
                </template>

                <template  v-if="item_list.type==='textarea_din' && (item_list.check_display==='true')">
                  <b-row class="mb-4 form-group top-rem-top observation-textarea" :class="(item_list.disbabled) ? 'default-active' : false"> 
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                          <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                      </b-col>
                      <b-col :sm="item_list.input_value">
                          <b-form-textarea
                            id=""
                            v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                            :placeholder="item_list.placeholder"
                            :disabled ="(item_list.disbabled) ? 'disabled' : false"
                            :rows="item_list.rows"
                            @input="FileUpload(item_list.model, '',BasicForm[item_list.model])"
                            :max-rows="item_list.max_rows"
                          ></b-form-textarea>
                          <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                            </div>  
                      </b-col>
                  </b-row>
                </template>

                <template  v-if="(item_list.type==='datepicker' || item_list.type==='datetimepicker') && (item_list.check_display==='true')">
                  <b-row class="mb-4 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                      </b-col>
                       <b-col :sm="item_list.input_value"  > 
                             <datetime
                            :type="(item_list.type==='datetimepicker') ? 'datetime':'date'"
                            :id="item_list.model" 
                            :use12-hour="true"
                            :disabled="(item_list.disbabled) ? 'disabled' : false"
                            v-model="BasicForm[item_list.model]"
                            :ref="item_list.model" 
                            :format="(item_list.type==='datetimepicker') ?  'dd-MMM-yyyy hh:mm:ss a': (item_list.type==='timepicker') ? DateTimeMain.TIME_SIMPLE : 'dd-MMM-yyyy'"
                            :phrases="{ok: 'Continue', cancel: 'Exit'}"
                            input-class="form-control mb-2"
                            :min-datetime="item_list.min_date"
                            :max-datetime="item_list.max_date"
                            :placeHolder="`Select ${item_list.placeholder}`"
                            :week-start="7"
                            auto
                            @input="handleDateBlur(item_list, item_list.model, BasicForm[item_list.model])"
                          ></datetime>
                          <template v-if="show_error">
                            <div class="text-danger" v-if="errors[0]">
                              {{ errors[0] }}
                            </div>
                          </template>
                      </b-col> 

                       <!-- <b-col :sm="item_list.input_value" v-else-if="item_list.is24hrs">
                          <datetime
                            :type="(item_list.type==='datetimepicker') ? 'datetime':'date'"
                            :id="item_list.model" 
                            :disabled="(item_list.disbabled) ? 'disabled' : false"
                            v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"
                            format="MMM d, yyyy, HH:mm:ss"                            
                            :phrases="{ok: 'Continue', cancel: 'Exit'}"
                            input-class="form-control mb-2"
                            :min-datetime="item_list.min_date"
                            :week-start="7"
                            auto
                          ></datetime>
                          <template v-if="show_error">
                            <div class="text-danger" v-if="errors[0]">
                              {{ errors[0] }}
                            </div>
                          </template>
                      </b-col> -->
                     
                    </b-row>
                </template>

                 <template  v-if="(item_list.type==='timepicker') && (item_list.check_display==='true')">
                  <b-row class="mb-4 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                      </b-col>
                       <b-col :sm="item_list.input_value"  >     <!-- v-if="!item_list.is24hrs" -->
                          <datetime
                            :type="'time'"
                            :id="item_list.model" 
                            use12-hour
                            value-zone="Asia/Kolkata"
                            zone="Asia/Kolkata"
                            :disabled="(item_list.disbabled) ? 'disabled' : false"
                            v-model="BasicForm[item_list.model]"
                            :ref="item_list.model" 
                            :format="(item_list.type==='datetimepicker') ?  'dd-MMM-yyyy hh:mm:ss a': (item_list.type==='timepicker') ? DateTimeMain.TIME_SIMPLE : 'dd-MMM-yyyy'"
                            :phrases="{ok: 'Continue', cancel: 'Exit'}"
                            input-class="form-control mb-2"
                            :min-datetime="item_list.min_date"
                            :max-datetime="item_list.max_date"
                            :placeHolder="`Select ${item_list.placeholder}`"
                            :week-start="7"
                            auto
                          ></datetime>
                          <template v-if="show_error">
                            <div class="text-danger" v-if="errors[0]">
                              {{ errors[0] }}
                            </div>
                          </template>
                      </b-col> 

                     
                    </b-row>
                </template>

              
               <template  v-if="(item_list.type==='yearpicker') && (item_list.check_display==='true')">
                  <b-row class="mb-4 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                      </b-col>

                       <b-col :sm="item_list.input_value">  
                         <year-picker 
                            :disabled="(item_list.disbabled) ? true: false"
                            v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" 
                            :placeholder="item_list.placeholder"
                            :value='defaultYear'
                            format="yyyy"
                            minimum-view="year"              
                            name="datepicker"
                            id="input-id"
                            :disabled-dates="disabledYears"
                            input-class="form-control mb-2 bg-white w-100"></year-picker>
                          <template >
                            <div class="text-danger" v-if="errors[0]">
                              {{ errors[0] }}
                            </div>
                          </template>
                      </b-col> 
                    </b-row>
                </template>




                <template  v-if="item_list.type==='fileupload' && (item_list.check_display==='true')">
                  <b-row class="align-items-center">
                  <div class="col-12 col-sm-6">
                    <b-row class="mb-4 form-group no-gutters" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="(item_list.rules && item_list.rules.includes('required') || (item_list.additional_rules=='required'))" class="text-danger">*</span></label> 
                      </b-col>
                      <b-col sm="9" class="align-top">
                          <b-form-file :disabled ="(item_list.disbabled) ? 'disabled' : false" v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" @change="FileUpload(BasicForm[item_list.model], item_list.model, '')" class="mb-2" :state="errors[0] ? false : (valid ? display_success : null)"></b-form-file>
                          <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                          </div>
                      </b-col>
                      <b-col sm="3" class="align-top" >
                          <div v-if="!item_list.disbabled" @click="AddFileUpload(BasicForm[item_list.model], item_list.model, '')" class="add_button">Upload</div>
                          <button v-else type="button" class="add_button file_upload" >Upload</button>
                      </b-col>
                    </b-row>
                  </div>
                  <div class="col-12 col-sm-6">
                      <template v-if="item_list.files && item_list.files.length>0 && (item_list.disbabled==true || item_list.isFileRemove=='false')"  >
                          <span class="doc_display" v-for="(file_list) in item_list.files" :key="file_list.file_id">  <u class="download_doc" @click="DownloadFile(file_list.file_name,file_list.file_id)">{{file_list.file_name}}</u>  </span>
                      </template>
                      <template v-else-if="item_list.files && item_list.files.length>0 && item_list.disbabled==false"  >
                          <span class="doc_display" v-for="(file_list) in item_list.files" :key="file_list.file_id">  <u class="download_doc" @click="DownloadFile(file_list.file_name,file_list.file_id)">{{file_list.file_name}}</u>  <i class="flaticon-close-1 remove_icon_form" @click="DeleteFile('',file_list.file_id, {form_name: form_name, field_name: item_list.model, field_id:file_list.file_id, parent_obj : parent_obj_name})"></i></span>
                      </template>
                      <template v-else>
                        <span class="no-files">No files Uploaded</span>
                      </template>
                  </div>
                  </b-row>
                </template>

                <template  v-if="item_list.type==='multi_fileupload' && (item_list.check_display==='true')"  >
                  <b-row class="align-items-center docs-manage-dropzone">
                  <div class="col-12 col-sm-6">
                    <b-row class="mb-4 form-group no-gutters" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="(item_list.rules && item_list.rules.includes('required') || (item_list.additional_rules=='required'))" class="text-danger">*</span></label> 
                      </b-col>
                      <b-col sm="9" class="align-top">
                          <b-form-file placeholder="Drop or Select Files" multiple :file-name-formatter="formatNames" :disabled ="(item_list.disbabled) ? 'disabled' : false" v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" @change="FileUploadChange(BasicForm[item_list.model], item_list.model, '')" class="mb-2" :state="errors[0] ? false : (valid ? display_success : null)"></b-form-file>
                          <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                          </div>
                      </b-col>
                      <b-col sm="3" class="align-top" >
                          <div v-if="!item_list.disbabled" @click="AddMultiFileUpload(BasicForm[item_list.model], item_list.model, '')" class="add_button">Upload</div>
                          <button v-else type="button" class="add_button file_upload" >Upload</button>
                      </b-col>
                    </b-row>
                  </div>
                  <div class="col-12 col-sm-6">
                      <template v-if="item_list.files && item_list.files.length>0 && (item_list.disbabled==true || item_list.isFileRemove=='false')"  >
                          <span class="doc_display" v-for="(file_list) in item_list.files" :key="file_list.file_id">  <u class="download_doc" @click="DownloadFile(file_list.file_name,file_list.file_id)">{{file_list.file_name}}</u>  </span>
                      </template>
                      <template v-else-if="item_list.files && item_list.files.length>0 && item_list.disbabled==false"  >
                          <span class="doc_display" v-for="(file_list) in item_list.files" :key="file_list.file_id">  <u class="download_doc" @click="DownloadFile(file_list.file_name,file_list.file_id)">{{file_list.file_name}}</u>  <i class="flaticon-close-1 remove_icon_form" @click="DeleteFile('',file_list.file_id, {form_name: form_name, field_name: item_list.model, field_id:file_list.file_id, parent_obj : parent_obj_name})"></i></span>
                      </template>
                      <template v-else>
                        <span class="no-files">No files Uploaded</span>
                      </template>
                  </div>
                  </b-row>
                </template>

                <template  v-if="item_list.type==='multi_fileupload_row' && (item_list.check_display==='true')"  >
                  <b-row class="align-items-center docs-manage-dropzone">
                  <div class="col-12">
                    <b-row class="mb-4 form-group no-gutters" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="(item_list.rules && item_list.rules.includes('required') || (item_list.additional_rules=='required'))" class="text-danger">*</span></label> 
                      </b-col>
                      <b-col sm="12" class="align-top">
                          <b-form-file placeholder="Drop or Select Files" multiple :file-name-formatter="formatNames" :disabled ="(item_list.disbabled) ? 'disabled' : false" v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" @change="FileUploadChange(BasicForm[item_list.model], item_list.model, '')" class="mb-2" :state="errors[0] ? false : (valid ? display_success : null)"></b-form-file>
                          <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                          </div>
                      </b-col>
                      <b-col sm="12" class="align-top" >
                          <div v-if="!item_list.disbabled" @click="AddMultiFileUpload(BasicForm[item_list.model], item_list.model, '')" class="add_button">Upload</div>
                          <button v-else type="button" class="add_button file_upload" >Upload</button>
                      </b-col>
                    </b-row>
                  </div>
                  <div class="col-12 col-sm-6">
                      <template v-if="item_list.files && item_list.files.length>0 && (item_list.disbabled==true || item_list.isFileRemove=='false')"  >
                          <span class="doc_display" v-for="(file_list) in item_list.files" :key="file_list.file_id">  <u class="download_doc" @click="DownloadFile(file_list.file_name,file_list.file_id)">{{file_list.file_name}}</u>  </span>
                      </template>
                      <template v-else-if="item_list.files && item_list.files.length>0 && item_list.disbabled==false"  >
                          <span class="doc_display" v-for="(file_list) in item_list.files" :key="file_list.file_id">  <u class="download_doc" @click="DownloadFile(file_list.file_name,file_list.file_id)">{{file_list.file_name}}</u>  <i class="flaticon-close-1 remove_icon_form" @click="DeleteFile('',file_list.file_id, {form_name: form_name, field_name: item_list.model, field_id:file_list.file_id, parent_obj : parent_obj_name})"></i></span>
                      </template>
                      <template v-else>
                        <span class="no-files">No files Uploaded</span>
                      </template>
                  </div>
                  </b-row>
                </template>

                <template  v-if="item_list.type==='mh_fileupload' && (item_list.check_display==='true')">
                    <div class="form-group mb-0 icon-upload" :class="(item_list.disbabled) ? 'default-active' : false">
                      <div class="align-items-center justify-content-center d-flex">
                            <b-form-file placeholder="Drop or Select Files" :file-name-formatter="formatNames" :disabled ="(item_list.disbabled) ? 'disabled' : false" v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" @change="FileUploadChange(BasicForm[item_list.model], item_list.model)" class="input-button-upload" :state="errors[0] ? false : (valid ? display_success : null)"></b-form-file>
                            
                      </div>
                    </div>
                    <div class="row" v-if="BasicForm[item_list.model]">
                          <div class="col-12">
                              <strong>File Choosed :{{BasicForm[item_list.model].name}} </strong>
                          </div>
                      </div>
                     
                  <div class="text-danger  text-center" v-if="errors[0]" >
                    {{ errors[0] }}
                  </div>
                  <div class=" mt-10" v-if="!errors[0]">
                         <template v-if="item_list.files && item_list.files.length>0 && item_list.disbabled==true"  >
                              <span class="doc_display" v-for="(file_list) in item_list.files" :key="file_list.file_id">  <u class="download_doc" @click="DownloadFile(file_list.file_name,file_list.file_id)">{{file_list.file_name}}</u>  </span>
                          </template>
                          <template v-else-if="item_list.files && item_list.files.length>0 && item_list.disbabled==false"  class="upload-document-error">
                              <span class="doc_display upload-docs" v-for="(file_list) in item_list.files" :key="file_list.file_id">  <u class="download_doc" @click="DownloadFile(file_list.file_name,file_list.file_id)">{{file_list.file_name}}</u> <!-- <i class="flaticon-close-1 remove_icon_form" @click="DeleteFile('',file_list.file_id, {form_name: form_name, field_name: item_list.model, field_id:file_list.file_id, parent_obj : parent_obj_name})"></i> --></span>
                          </template>
                  </div>
                  
                </template>
          

                <template  v-if="item_list.type==='fileupload_full' && (item_list.check_display==='true')">
                  <b-row>
                  <div class="col-12 col-sm-12 align-top-grid align-top">
                    <!-- {{item_list}} -->
                    <b-row class="mb-4 form-group no-gutters" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="(item_list.rules && item_list.rules.includes('required'))" class="text-danger">*</span></label> 
                      </b-col>
                      <b-col sm="9">
                        
                          <b-form-file 
                          :key="rowIndex"
                          :disabled ="(item_list.disbabled) ? 'disabled' : false" v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" @change="FileUpload(BasicForm[item_list.model], item_list.model)" class="mb-2" :state="errors[0] ? false : (valid ? display_success : null)"></b-form-file>
                          <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                          </div>
                      </b-col>
                      <b-col sm="3" > 
                          <div v-if="!item_list.disbabled || !item_list.sub_fields[0].disabled_upload " @click="AddFileUpload(BasicForm[item_list.model], item_list.model, BasicForm[(item_list.model).replace('upload','').split('__')[0]])" class="add_button file_upload">Submit </div> 
                          <button v-else type="button" class="add_button file_upload" >Submit</button>
                      </b-col>
                    </b-row>
                  </div>
                  <div class="col-12 col-sm-12">
                     <b-row>
                      <b-col sm="12">
                          <template v-if="item_list.files && item_list.files.length>0 && item_list.disbabled==true"  >
                              <span class="doc_display" v-for="(file_list) in item_list.files" :key="file_list.file_id">  <u class="download_doc" @click="DownloadFile('',file_list.file_id)">{{file_list.file_name}}</u>  </span>
                          </template>
                          <template v-else-if="item_list.files && item_list.files.length>0 && item_list.disbabled==false"  >
                              <span class="doc_display" v-for="(file_list) in item_list.files" :key="file_list.file_id">  <u class="download_doc" @click="DownloadFile('',file_list.file_id)">{{file_list.file_name}}</u>  <i class="flaticon-close-1 remove_icon_form" @click="DeleteFile('',file_list.file_id, {form_name: form_name, field_name: item_list.model, field_id:file_list.file_id, parent_obj : parent_obj_name})"></i></span>
                          </template>
                          <template v-else>
                             <span class="no-files">No files Uploaded</span>
                          </template>
                      </b-col>
                    </b-row>
                  </div>
                  </b-row>
                </template>

                <template  v-if="item_list.type==='fileupload1'">
                  <b-row class="mb-4 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                      </b-col>
                      <b-col :sm="item_list.input_value">
                          <b-form-file :disabled ="(item_list.disbabled) ? 'disabled' : false" v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" @change="FileUpload(BasicForm[item_list.model], item_list.model)" class="mb-2" :state="errors[0] ? false : (valid ? display_success : null)"></b-form-file>
                          <template v-if="item_list.files && item_list.files.length">
                            Files Uploaded
                            <span class="doc_display" v-for="(file_list) in item_list.files" :key="file_list.file_id">  <u class="download_doc" @click="DownloadFile('',file_list.file_id)">{{file_list.file_name}}</u>  <i class="flaticon-close-1 remove_icon_form" @click="DeleteFile('',file_list.file_id, {form_name: form_name, field_name: item_list.model, field_id:file_list.file_id, parent_obj : parent_obj_name})"></i></span>
                          </template>
                          <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                          </div>
                      </b-col>
                    </b-row>
                </template>

                <template  v-if="item_list.type==='multi_fileupload1'">
                  <b-row class="mb-4 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                      </b-col>
                      <b-col :sm="item_list.input_value">
                          <b-form-file multiple :file-name-formatter="formatNames" :disabled ="(item_list.disbabled) ? 'disabled' : false" v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" @change="FileUploadChange(BasicForm[item_list.model], item_list.model)" class="mb-2" :state="errors[0] ? false : (valid ? display_success : null)"></b-form-file>
                          <template v-if="item_list.files && item_list.files.length">
                            Files Uploaded
                            <span class="doc_display" v-for="(file_list) in item_list.files" :key="file_list.file_id">  <u class="download_doc" @click="DownloadFile('',file_list.file_id)">{{file_list.file_name}}</u>  <i class="flaticon-close-1 remove_icon_form" @click="DeleteFile('',file_list.file_id, {form_name: form_name, field_name: item_list.model, field_id:file_list.file_id, parent_obj : parent_obj_name})"></i></span>
                          </template>
                          <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                          </div>
                      </b-col>
                    </b-row>
                </template>

                <template  v-if="(item_list.type==='radio' || item_list.type==='qcradio') && (item_list.check_display==='true')">
                  <b-row class="mb-4 form-group radio-buttons" :class="(item_list.disbabled) ? 'default-active' : false">
                      <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                      </b-col>
                      <b-col>
                          <ul class="common-radio-list">
                            <template v-for="(sub_list, index) in item_list.options">
                            <li :key="index">
                              <b-form-radio type="radio" v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" :name="item_list.name" :value="sub_list.value" @change="emitSelectChange(item_list, item_list.model, BasicForm[item_list.model])" > <span>{{sub_list.text}}</span></b-form-radio>
                            </li>
                              </template>
                          </ul>
                        <span class="text-danger d-block">{{ errors[0] }}</span>      
                      </b-col>
                    </b-row>
                </template>

                <template  v-if="(item_list.type==='checkbox' || item_list.type==='qccheckbox')  && ( item_list.check_display === 'true') ">
                  <div class="form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                    <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                    <div class="qc-checkbox">
                        <div class="qc-checkbox-inn"  v-for="(sub_list, index) in item_list.options" :key="index" >
                            <b-form-checkbox :v-model="BasicForm[item_list.model]"
                              :ref="item_list.model" :name="item_list.name" :value="sub_list.value"> <span>{{sub_list.text}}</span></b-form-checkbox>
                        </div>                                                   
                    </div>
                  </div>
                </template>

                <template  v-if="(item_list.type==='checkboxgroup' || item_list.type==='qccheckboxgroup')  && (item_list.check_display==='true')">
                   <div class="form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                    <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                    <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-6" v-for="(sub_list, index) in item_list.options" :key="index" >
                            <div class="qc-checkbox-inn"  >
                              <b-form-checkbox  :v-model="BasicForm[item_list.model]"
                              :ref="item_list.model"  :name="item_list.name" :value="sub_list.value" :checked="BasicForm[item_list.model]" @change="emitCheckChange($event, item_list.model, sub_list.value)" > <span>{{sub_list.text}}</span></b-form-checkbox>
                            </div>
                        </div>                                                
                    </div>
                  </div>
                </template>
            
              </template>
            
          </ValidationProvider>
          <div :class="ClassFormate(item_list)" slim v-if="item_list.check_display==='true' && item_list.field_count>0" :key="item_list.id">
              <template  v-if="(item_list.type==='multi_datetimepicker' || item_list.type==='multi_datepicker' )  && (item_list.check_display==='true') && (item_list.field_count!=null)" >
                      <b-row :key="k+22">
                        <b-col :sm="'12'" class="text-left"  v-if="item_list.label_display==true">
                              <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label> <!-- {{item_list.field_count}} -->
                        </b-col>
                      </b-row>
                      <template v-for="(input_list,k) in item_list.field_count" >
                      <ValidationProvider :vid="rowIndex" :rules="item_list.rules" :name="item_list.label"  :key="k+22"  slim>
                        <template slot-scope="{ valid, errors }">
                          <b-row :key="k+22">
                            <b-col :sm="9" v-if="!item_list.is24hrs" :key="k+22" class="mb-2">
                                <datetime
                                  :type="(item_list.type==='multi_datetimepicker') ? 'datetime':'date'"
                                  :id="item_list.model+k+22" 
                                  :use12-hour="true"
                                  :state="errors[0] ? false : (valid ? display_success : null)"
                                  v-model="BasicForm[item_list.model][k]"
                                  :format="(item_list.type==='multi_datetimepicker') ? DateTimeMain.DATETIME_MED_WITH_SECONDS : DateTimeMain.DATE_MED"
                                  :phrases="{ok: 'Continue', cancel: 'Exit'}"
                                  input-class="form-control mb-2"
                                  :min-datetime="item_list.min_date"
                                  :week-start="7"
                                  auto
                                ></datetime>
                                <template v-if="show_error">
                                  <div class="text-danger" v-if="errors[0]">
                                    {{ errors[0] }}
                                  </div>
                                </template>
                            </b-col> 
                            <b-col :sm="9" v-else-if="item_list.is24hrs" :key="k+22" class="mb-2">
                                <datetime
                                  :type="(item_list.type==='multi_datetimepicker') ? 'datetime':'date'"
                                  :id="item_list.model" 
                                  :state="errors[0] ? false : (valid_rules ? display_success : null)"
                                  :disabled="(item_list.disbabled) ? 'disabled' : false"
                                  v-model="BasicForm[item_list.model][k]"
                                  format="MMM d, yyyy, HH:mm:ss"                            
                                  :phrases="{ok: 'Continue', cancel: 'Exit'}"
                                  input-class="form-control mb-2"
                                  :min-datetime="item_list.min_date"
                                  :week-start="7"
                                  auto
                                ></datetime>
                                <template v-if="show_error">
                                  <div class="text-danger" v-if="errors[0]">
                                    {{ errors[0] }}
                                  </div>
                                </template>
                            </b-col>
                            <b-col :sm="3" :key="k+22" class="p-0" >
                                <span class="add-muti" @click="add_date(item_list.field_count,item_list.model, k, rowIndex)" v-if="k==0">
                                  <i class="fa fa-plus-circle icon-add"></i>
                                </span>
                                <span class="delete-muti" @click="remove_date(item_list.field_count, item_list.model, k, rowIndex)" v-else>
                                  <i class="fa fa-minus-circle icon-delete"></i>
                                </span>
                            </b-col>
                          </b-row>
                        </template>
                        </ValidationProvider>
                      </template>
              </template>
      
              <template  v-else-if="(item_list.type==='multi_select')  && (item_list.check_display==='true') && (item_list.field_count!=null)" >
                  
                  <b-row :key="k+22" >
                        <b-col :sm="'12'" class="text-left"  v-if="item_list.label_display==true">
                              <label class="popup-label" :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                        </b-col>
                      </b-row>
                        <div class="multi-pincode">
                      <template v-for="(input_list,k) in item_list.field_count" >
                      <ValidationProvider :vid="rowIndex" :rules="item_list.rules" :name="item_list.label"  :key="k+22"  slim>
                        <template slot-scope="{ valid ,errors }">
                          <b-row :key="k+22" class="mb-2">
                            <b-col :sm="9"  :key="k+22">
                               <b-form-select 
                                v-model="BasicForm[item_list.model][k]" 
                                :options="item_list.options"   
                                @change="emitSelectChange(item_list, item_list.model, BasicForm[item_list.model])"
                                :state="errors[0] ? false : (valid ? display_success : null)"
                                class="form-control"
                                :disabled="(item_list.disbabled) ? 'disabled' : false"
                                :placeholder="item_list.placeholder">
                              </b-form-select>
                              <template v-if="show_error">
                                  <div class="text-danger" v-if="errors[0]">
                                    {{ errors[0] }}
                                  </div>
                              </template>
                            </b-col> 
                            
                            <b-col :sm="3" :key="k+22" class="p-0" >
                                <span class="add-muti" @click="add_date(item_list.field_count,item_list.model, k, rowIndex)" v-if="k==0">
                                  <i class="fa fa-plus-circle icon-add"></i>
                                </span>
                                <span class="delete-muti" @click="remove_date(item_list.field_count, item_list.model, k, rowIndex)" v-else>
                                  <i class="fa fa-minus-circle icon-delete"></i>
                                </span>
                            </b-col>
                          </b-row>
                        </template>
                        </ValidationProvider>
                      </template>
                      </div>
              
              </template>
           
              <template  v-else-if="(item_list.type==='multi_text')  && (item_list.check_display==='true') && (item_list.field_count!=null)" >
                 <b-row :key="k+22" >
                        <b-col :sm="'12'" class="text-left"  v-if="item_list.label_display==true">
                              <label class="popup-label" :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                        </b-col>
                      </b-row>
                      <template v-for="(input_list,k) in item_list.field_count" >
                      <ValidationProvider :vid="rowIndex" :rules="item_list.rules" :name="item_list.label"  :key="k+22"  slim>
                        <template slot-scope="{ valid ,errors }">
                          <b-row :key="k+22" class="mb-2">
                            <b-col :sm="9"  :key="k+22">
                               <b-form-input
                                type="text"
                                v-model="BasicForm[item_list.model][k]"
                                :state="errors[0] ? false : (valid ? display_success : null)"
                                :disabled ="(item_list.disbabled) ? 'disabled' : false"
                                :placeholder="item_list.placeholder"
                              >
                              </b-form-input>
                                <template v-if="show_error">
                                  <div class="text-danger" v-if="errors[0]">
                                    {{ errors[0] }}
                                  </div>
                                </template>
                            </b-col> 
                            
                            <b-col :sm="3" :key="k+22" class="p-0" >
                                <span class="add-muti" @click="add_date(item_list.field_count,item_list.model, k, rowIndex)" v-if="k==0">
                                  <i class="fa fa-plus-circle icon-add"></i>
                                </span>
                                <span class="delete-muti" @click="remove_date(item_list.field_count, item_list.model, k, rowIndex)" v-else>
                                  <i class="fa fa-minus-circle icon-delete"></i>
                                </span>
                            </b-col>
                          </b-row>
                        </template>
                        </ValidationProvider>
                      </template>
              </template>

               <template  v-else-if="(item_list.type==='multi_textarea')  && (item_list.check_display==='true') && (item_list.field_count!=null)" >
                 <b-row :key="k+22" >
                        <b-col :sm="'12'" class="text-left"  v-if="item_list.label_display==true">
                              <label class="popup-label" :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                        </b-col>
                      </b-row>
                      <template v-for="(input_list,k) in item_list.field_count" >
                      <ValidationProvider :vid="rowIndex" :rules="item_list.rules" :name="item_list.label"  :key="k+22"  slim>
                        <template slot-scope="{ valid ,errors }">
                          <b-row :key="k+22" class="mb-2">
                            <b-col :sm="11"  :key="k+22">
                               <b-form-textarea
                                type="text"
                                v-model="BasicForm[item_list.model][k]"
                                :state="errors[0] ? false : (valid ? display_success : null)"
                                :disabled ="(item_list.disbabled) ? 'disabled' : false"
                                :placeholder="item_list.placeholder"
                              >
                              </b-form-textarea>
                               
                                  <div class="text-danger" v-if="errors[0]">
                                    {{ errors[0] }}
                                  </div>
                               
                            </b-col> 
                            
                            <b-col :sm="1" :key="k+22" class="p-0" >
                                <span  class="add-muti" @click="add_date(item_list.field_count,item_list.model, k, rowIndex)" v-if="k==0 && item_list.disbabled==false">
                                  <i class="fa fa-plus-circle icon-add"></i>
                                </span>
                                <span  class="delete-muti" @click="remove_date(item_list.field_count, item_list.model, k, rowIndex)" v-else-if="item_list.disbabled==false">
                                  <i class="fa fa-minus-circle icon-delete"></i>
                                </span>
                            </b-col>
                          </b-row>
                        </template>
                        </ValidationProvider>
                      </template>
              </template>

          </div>
      </template>
  </div>
</template>

<script>
const StarRating = () => import(`@/components/common/Rating`)
import { Datetime } from 'vue-datetime';
import { ModelSelect } from 'vue-search-select'
import Multiselect from 'vue-multiselect'
import LuTimeMain from 'luxon/src/datetime.js'
import YearPicker from 'vuejs-datepicker';
LuTimeMain.local().toISODate();
import 'vue-datetime/dist/vue-datetime.css'
import 'vue-search-select/dist/VueSearchSelect.css'
export default {
  name: "BasicForm",
  components :{
    Multiselect,
    Datetime,
    StarRating,
    YearPicker,
    ModelSelect : ModelSelect
  },
  props :{
      defaultYear:{
        type : String
      },
      disabledYears : {},
      childVariable: String,
      sectionObj: String,
      base_id : String,
      form_index : Number,
      show_error: Boolean,
      parent_obj_name: String,
      display_success : Boolean,
      form_name : String,     
      module_name : {
        type: String,
        default: ''
      },
      from_action : function(){},
      form_base : {
        type:[Array, Object],
        default: function() {
              return [
              {
                  label: "Name"
              }
        ];
      }
    }
  },

  data(){
    return {
      DateTimeMain : LuTimeMain
    }
  },
 
  computed: {
    BasicForm : {
        get(){
          if(this.module_name){  
            console.log('this.$store.state[this.module_name][this.form_name]',this.$store.state[this.module_name][this.form_name]            )
              return this.$store.state[this.module_name][this.form_name]            
          }else{
              return this.$store.state[this.form_name]
          }
          
        },
        set(values){
           if(this.module_name){
              this.$store.state[this.module_name][this.form_name] = values
          }else{
               this.$store.state[this.form_name] = values
          }
        }
    },
  },
  methods : {
    formatNames(files) {
      return files.length === 1 ? files[0].name : `${files.length} files selected`
    },
    emitSearchSelectChange(fieldobj, field, value) {
      this.$emit("onSelectChange",fieldobj, field,value, (this.form_index!=undefined && this.form_index>=0) ? this.form_index : -1);
    },

    emitSelectChange(fieldobj, field, value) {
      this.$emit("onSelectChange",fieldobj, field,value, (this.form_index!=undefined && this.form_index>=0) ? this.form_index : -1);
    },

    emitSelectChangeSelected(field, value,main_value, key_value, options,field_key,type){
       console.log('emitSelectChange_1', this.form_index)
      if(type=='all'){
          this.$emit("onSelectChange",field,value, (this.form_index!=undefined && this.form_index>=0) ? this.form_index : -1);    
      }
      else{
         let _values = value.find((list)=>list.text.toLowerCase() =='others')
         if(_values){
            main_value[key_value] = value.filter((list)=>list.text == "Others")
            this.$emit("updateOptions",true, field_key);  
         }
         else{
            this.$emit("updateOptions",false, field_key);  
         }
      }
    },
    emitSelectChangeFileUpload(field, value) {
       this.$emit("emitSelectChangeFileUpload",field,value);      
    },
    emitRadioChange(event, field, value) {      
      this.$emit("onRadioChange",event, field, value);      
    },
    emitAge(event, field, value) {      
      this.$emit("onAgeChange",event, field, value, this.module_name, this.form_name);      
    },
    FileUpload(file, name,text=""){
      if(text){
        this.$emit("onFileUpload",'',file,text);    
      }
      else if(event && event.target.files && event.target.files.length){
        this.$emit("onFileUpload",event.target.files[0],name, '');    
      }
      else if(event && event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files.length){
        this.$emit("onFileUpload",event.dataTransfer.files[0],name, '');    
      }
      else{
        this.$emit("onFileUpload",'', file, '');    
      }
       
    },
    DownloadFile(file, name){
      this.$emit("onDownloadFile",name, file);     
    },
    DeleteFile(file, name, details){
      this.$emit("onDeleteFile",name, file, details);     
    },
    AddFileUpload(file, name, text=""){
      this.$emit("onAddFileUpload",file,name, text);     
    },
    FileUploadChange(file, name){
      let files = []
      if(event && event.target && event.target.files){
         files = event.target.files
      }
      if(event && event.dataTransfer && event.dataTransfer.files){
          files =  event.dataTransfer.files
      }
      this.$emit("onMultiFileUpload",files,name, '');  
    },
    AddMultiFileUpload(file, name, text=""){
      this.$emit("AddMultiFileUpload",file,name, text);   
    },
    addTag () {
      //  newTag
    },
    updateValueAction(){
      // value
    },
    emitCheckChange(e, field, value){    
      this.$emit("onCheckBoxChange",e, field, value)
    },

    isNumber: function(evt) {
         evt = (evt) ? evt : window.event        
        var charCode = (evt.which) ? evt.which : evt.keyCode
        if ((charCode > 31 && (charCode < 48 || charCode > 57))) {    // && charCode !== 46 ==> for include (dot)
            evt.preventDefault()
        } else {
            return true
        }
    },

    isMobileNumber: function(evt, formValue) {
        evt = (evt) ? evt : window.event        
        var charCode = (evt.which) ? evt.which : evt.keyCode
        if ((charCode > 31 && (charCode < 48 || charCode > 57))) {    // && charCode !== 46 ==> for include (dot)
            evt.preventDefault()
        }
        else {
          if(formValue){
            if(formValue.length >= 10){
               evt.preventDefault()
                return false
            }
            else{
               return true
            }
          }
        }
    },
    emailValidate(e, maxlength, values){
       if(maxlength){
            if(values.length >= maxlength){
               e.preventDefault()
              return false
            }
            else{
               return true
            }
          }
     },
     isAlphaNumeric(event, rules){
        const checkValidate = rules.includes('alpha_num');
        if(checkValidate){
            var regex = new RegExp("^[a-zA-Z0-9-]+$");
             var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
            if (!regex.test(key)) {
              event.preventDefault();
              return false;
            }
        }
     },
    setCityAndState: function(event,field, rowIndex) {
        this.$emit("onPincode",event,field, rowIndex, (this.form_index!=undefined && this.form_index>=0) ? this.form_index : -1);
    },
    isNumberAndDecimal : function(evt,len){
        //for configure dot and decimals in numbers
        let stringValue = evt.target.value.toString()
        if(stringValue.includes('.')){
          let charsAfterDot = stringValue.split('.')[1].length 
          if(charsAfterDot > len-1 ) {
            evt.preventDefault()
          }
        }
        evt = (evt) ? evt : window.event        
        var charCode = (evt.which) ? evt.which : evt.keyCode
        if ((charCode > 31 && (charCode < 48 || charCode > 57 ) && charCode !== 46)) {    // && charCode !== 46 ==> for include (dot)
            evt.preventDefault()
        } 
        else {
            return true
        } 
    },
    
    onPaste(event){
      let text =  event.clipboardData.getData('text/plain')
      let isNumber = /^-?[\d.]+(?:e-?\d+)?$/.test(text);
      if(!isNumber){
          event.preventDefault()
          //event.target.value = event.clipboardData.getData('text/plain');
      }
    },

    ClassFormate(list_details){
      if(list_details.sub_index!='false' && list_details.sub_index==list_details.id){
        
        return `full_width_main ${list_details.columnClass} align-top`
      }
      else{
         return `${list_details.columnClass} align-top-grid align-top`
      }
     
    },
    save(model){
      let {isEmpty, data } = this.$refs.signaturePad[0].saveSignature();
      if(!isEmpty){
         this.BasicForm[model] = data
      }else{
         delete this.BasicForm[model]
      }
    },
    un_do(model){
      this.$refs.signaturePad[0].clearSignature();
      delete this.BasicForm[model]
    },
    declaration_click(model, value){
      if(!value){
        delete this.BasicForm[model]
      }
    },
    add_date(field_count, field_index, _field_index, filed_name,max_count) {
        this.$emit("onMultiInputbox",field_count,field_index,filed_name,'add', _field_index,max_count,(this.form_index!=undefined && this.form_index>=0) ? this.form_index : -1);    
    },
    remove_date(field_count,field_index, _field_index, filed_name, max_count) {
       this.$emit("onMultiInputbox",field_count,field_index,filed_name,'remove', _field_index,max_count,(this.form_index!=undefined && this.form_index>=0) ? this.form_index : -1);
    },
    changeFieldDisplay(fiedlobj, field, value, sectionObj){
       this.$emit("onFieldDisplay",fiedlobj,field,value,0, sectionObj);
    },
    handleBlur(fiedlobj, field, value){
        this.$emit("onInputChange",fiedlobj,field,value);
    },
    handleApiCall(fiedlobj, field, value){
        this.getAPiDatas(fiedlobj, this.BasicForm, this.module_name, this.form_name)
        this.$emit("onInputChange",fiedlobj,field,value);
    },
    handleDateBlur(fiedlobj, field, value){
      this.$emit("onDateChange",fiedlobj,field,value);
    },
    validateMobileNumber(e, formValue){
         if(formValue){
           if(formValue.length > 10){
               e.preventDefault()
              return false
           }
           else{
              return true
            }
        }
    },
    InsuredDetailsDisclaimer(fiedlobj, field){
      this.$emit("onCheckBoxDisclaimer",fiedlobj,field, this.$refs[field][0].checked);
    }
  }
};
</script>
<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
<style lang="scss">
.input-slect-col{
  position: relative;
  border-radius: 5px;
  .select-loader {
      position: absolute;
      width:calc(100% - 30px);
      text-align: center;
      background: #0000008c;
      height: 100%;
      border-radius: 5px;
      z-index: 99;
  }
}
.vdatetime-popup__header{
    background: #2579bd;
}

.vdatetime-calendar__month__day--selected > span > span, .vdatetime-calendar__month__day--selected:hover > span > span{
   background: #2579bd;
}
.vdatetime-popup__actions{
  .vdatetime-popup__actions__button{
    color: #2579bd;
  }
}

.ui.disabled.dropdown, .ui.dropdown .menu>.disabled.item{
  opacity: 0.95;
  background: #e9ecef;
}

.add-muti, .delete-muti{
    background: #2077bc;
    width: 41px;
    display: block;
    padding: 5px 0px;
    text-align: center;
    border-radius: 5px;
    color: #fff;
   
}
.ui.fluid.search.selection.dropdown, .ui.dropdown .menu>.item{
  font-size: 12px;
  border-radius:0px !important;
  padding: 12px 10px;
}
.multiselect__tags{
  font-size: 12px;
}
.input-text-box-holder{
  
  .form-group{
    .col{
        &:before{
          content: ' ';
          position: absolute;
          top: 0px;
          width: 100%;
          z-index: 9999;
          left: 0px;
          background: rgb(250 250 250 / 0%);
          height: 100%;
          color: #fafafa;
        }
    }
  }
}
</style>