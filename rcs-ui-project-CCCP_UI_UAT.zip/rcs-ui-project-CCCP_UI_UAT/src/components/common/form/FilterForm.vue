<template>
  <div :class="filter_class"> 
      <template v-if="isMainFormRequired">
        <div :class="`${item_list.columnClass} form-group-inn`" v-for="(item_list) in main_form_data" :key="item_list.id">
            <ValidationProvider :rules="item_list.rules" :name="item_list.label">
                <template slot-scope="{ errors }">
                      <template v-if="item_list.type==='text'">
                          <div :class="`form-group-select-2`">
                              <b-form-input
                                :type="item_list.type"
                                v-model="MainFilterForm[item_list.model]"  
                                :id="item_list.model"            
                                :placeholder="item_list.placeholder">                   
                              </b-form-input>      
                              <div class="text-danger" v-if="errors[0]">
                                {{ errors[0] }}
                              </div>      
                          </div>
                      </template>     
                      <template v-if="item_list.type==='select' || item_list.type==='dependent_check'">     
                          <div :class="`form-group-select`">           
                            <b-form-select :id="item_list.model"  v-model="MainFilterForm[item_list.model]" :options="item_list.options"   
                              @change="emitSelectChange(item_list.model, MainFilterForm[item_list.model])"              
                              :placeholder="item_list.placeholder">              
                              </b-form-select>
                          </div>   
                          <div class="text-danger" v-if="errors[0] && isMainFormError">
                                {{ errors[0] }}
                          </div>
                      </template>
                      <template v-if="item_list.type==='daterangepicker'" >
                          <div :class="`form-group-select`">  
                            <date-picker :dateRange='MainFilterForm[item_list.model]' :field_name="item_list.model" :model_name="main_form_name"  :locale-data="localeData" :singleDatePicker='singleDatePicker'  :onDateSelect='onDateSelect'></date-picker>             
                          </div>
                      </template> 
                      <template v-if="item_list.type==='date'" >                   
                          <div :class='`form-group-select-2`'>  

                            <datetime
                              :type="(item_list.type==='datetimepicker') ? 'datetime':'date'"
                              :id="item_list.model" 
                              :disabled="(item_list.disabled) ? 'disabled' : false"
                              v-model="MainFilterForm[item_list.model]"
                              :title="(item_list.label) ? item_list.label : ''"
                              :placeholder="item_list.placeholder"
                              :use12-hour="true"
                              :min-datetime="item_list.min_date"
                              :max-datetime="item_list.max_date"
                              :format="(item_list.type==='datetimepicker') ?  'dd-MMM-yyyy hh:mm:ss a': (item_list.type==='timepicker') ? DateTimeMain.TIME_SIMPLE : 'dd-MMM-yyyy'"
                              :phrases="{ok: 'Continue', cancel: 'Exit'}"
                              input-class="form-control"
                              :week-start="7"
                              auto
                            ></datetime>
                            <template v-if="show_error">
                            <div class="text-danger" v-if="errors[0]">
                                  {{ errors[0] }}
                                </div>    
                            </template>  
                          </div>
                      </template> 
                </template>
            </ValidationProvider>
        </div>   
      </template>
      <div :class="`${item_list.className} form-group-inn`" v-for="(item_list) in form_base" :key="item_list.id">
          <ValidationProvider :rules="item_list.rules" :name="item_list.label">
            <template slot-scope="{ errors }">
                  <template v-if="item_list.type==='text'">
                    
                      <div :class="`form-group-select-2`">
                        <b-row class="mb-0 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                          <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                          </b-col>
                            <b-col>  
                            <b-form-input
                              :type="item_list.type"
                              v-model="FilterForm[item_list.model]"  
                              :id="item_list.model"            
                              :placeholder="item_list.placeholder">                   
                            </b-form-input>      
                            <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                            </div>      
                          </b-col>
                          </b-row>
                      </div>
                  </template>     
                  <template v-if="item_list.type==='select' || item_list.type==='dependent_check'" >     
                      <div :class="`form-group-select`">     
                        <b-row class="mb-0 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                        <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                          <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                        </b-col>  
                        <b-col>    
                          <b-form-select :id="item_list.model"  v-model="FilterForm[item_list.model]" :options="item_list.options"   
                          @change="emitSelectChange(item_list.model, FilterForm[item_list.model])"              
                            :placeholder="item_list.placeholder">              
                            </b-form-select>
                        </b-col>
                        </b-row>
                      </div>   
                      <div class="text-danger" v-if="errors[0]">
                          {{ errors[0] }}
                      </div>
                  </template>
                  <template v-if="item_list.type==='daterangepicker'" >
                      <div :class="`form-group-select`">  
                        <b-row class="mb-0 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                        <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                          <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                        </b-col>
                        <b-col>
                          <date-picker :dateRange='FilterForm[item_list.model]' :field_name="item_list.model" :model_name="form_name"  :locale-data="localeData" :singleDatePicker='singleDatePicker'  :onDateSelect='onDateSelect'></date-picker>             
                        </b-col>
                        </b-row>
                      </div>
                      
                  </template> 
                  <template v-if="item_list.type==='date'" >                   
                      <div :class="`form-group-select-2`">  
                        <b-row class="mb-0 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                        <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                          <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                        </b-col>
                        <b-col>
                            <datetime
                              :type="(item_list.type==='datetimepicker') ? 'datetime':'date'"
                              :id="item_list.model" 
                              :disabled="(item_list.disabled) ? 'disabled' : false"
                              v-model="FilterForm[item_list.model]"
                              :title="(item_list.label) ? item_list.label : ''"
                              :placeholder="item_list.placeholder"
                              :use12-hour="true"
                              :min-datetime="item_list.min_date"
                              :max-datetime="item_list.max_date"
                              :format="(item_list.type==='datetimepicker') ?  'dd-MMM-yyyy hh:mm:ss a': (item_list.type==='timepicker') ? DateTimeMain.TIME_SIMPLE : 'dd-MMM-yyyy'"
                              :phrases="{ok: 'Continue', cancel: 'Exit'}"
                              input-class="form-control"
                              :week-start="7"
                              auto
                            ></datetime>
                            <template v-if="show_error">
                              <div class="text-danger" v-if="errors[0]">
                                  {{ errors[0] }}
                                </div>    
                            </template>  
                        </b-col>
                        </b-row>
                      </div>
                  </template> 

                  <template v-if="item_list.type==='custom_multi_select'">
                    <b-row class="mb-0 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                        <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                        </b-col>
                        <b-col :sm="item_list.input_value">
                        <multiselect
                              v-model="FilterForm[item_list.model]"
                              :options="item_list.options"
                              :close-on-select="true"
                              :clear-on-select="false"
                              :placeholder ="`Select ${item_list.label}`" 
                              v-validate="{'required':true}" 
                              label="text"
                              track-by="text"
                              :multiple="true" 
                              :taggable="false" 
                              :allow-empty="true"
                              :hide-selected="true"
                              @tag="addTag"
                              :disabled='item_list.disbabled'                              
                          >
                        </multiselect>
                        <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                            </div>
                        </b-col>
                    </b-row>
                </template>

                <template v-if="item_list.type==='switch'">
                    <b-row class="mb-0 form-group" :class="(item_list.disbabled) ? 'default-active' : false">
                        <b-col :sm="(item_list.label_value) ? item_list.label_value : '12'" class="text-left" v-if="item_list.label_display==true">
                            <label :for="`type-${item_list.type}`">{{ item_list.label }} <span v-if="item_list.rules && item_list.rules.includes('required')" class="text-danger">*</span></label>
                        </b-col>
                        <b-col :sm="item_list.input_value">
                          <div class="priority">
                              <div class="switch-list">
                                  <ul>
                                    
                                    <li v-for="(item_option_list, index) in item_list.options" :key="index">
                                        <div class="switch-head">
                                          <label class="switch" :class="item_option_list.value">
                                              <input type="radio"  v-model="FilterForm[item_list.model]" :value="item_option_list.value"  id="search-claim-switch" name="search-claim-switch" @click="emitSelectChange(item_list.model, FilterForm[item_list.model])"> <span class="switch-slider round" ></span>
                                          </label>
                                          <span class="work active">{{item_option_list.text}}</span>
                                      </div>
                                    </li>
                                  </ul>
                              </div>
                            </div>
                          <div class="text-danger" v-if="errors[0]">
                            {{ errors[0] }}
                            </div>
                        </b-col>
                    </b-row>
                </template>
              </template>
          </ValidationProvider>                         
      </div> 
      <template v-if="display_submit==true"> 
        <div class="form-button mt-4">
          <b-button size="sm"  class="btn submit-button mr-1" @click="emitSearchFilter()">
            Filter
          </b-button> 
          <b-button size="sm"  class="btn reset-button" @click="emitClearFilter()">
              Reset
          </b-button> 
        </div>
      </template>      
  </div>
</template>
<script> 
import { Datetime } from 'vue-datetime';
import LuTimeMain from 'luxon/src/datetime.js'
LuTimeMain.local().toISODate();
import 'vue-datetime/dist/vue-datetime.css'
const DatePicker = () => import(`@/components/common/DatePicker`)
import Multiselect from 'vue-multiselect'
export default {
  name: "FilterForm",
  props :{     
      main_form_data: {
        type:[Array, Object]     
      },
      main_form_name : String, 
      isMainFormRequired : {
        type:Boolean,
        default: false
      },
      isMainFormError : {
        type:Boolean,
        default: false
      },

      form_name : String,     
      show_error: {
        type:Boolean,
        default: false
      },
      filter_class : String,
      form_base : {
        type:[Array, Object]     
    },
    dateRange: {
          startDate: null,
          endDate: null,
     },
     localeData : Object,
     display_submit : Boolean,
     singleDatePicker : null,
    
  },
  components : {
    Multiselect,
    DatePicker ,
    Datetime
  },
  data (){
    return {      
      DateTimeMain : LuTimeMain
    }
  },
  computed: {
    MainFilterForm : {
        get(){
          return this.$store.state[this.main_form_name]
        },
        set(values){
          this.$store.state[this.main_form_name] = values
        }
    },
    FilterForm : {
        get(){
          return this.$store.state[this.form_name]
        },
        set(values){
          this.$store.state[this.form_name] = values
        }
    }
  },
  methods : {
    emitSelectChange(field, value) {    
      this.$emit('onFilterSelect',field,value);      
    },
    emitSelectChangeFileUpload(field, value) {
       this.$emit("emitSelectChangeFileUpload",field,value);      
    },
    emitSearchFilter() {      
      this.$emit('onSearchFilter');      
    },
     emitClearFilter() {      
      this.$emit('onClearFilter');      
    }
  }
};
</script>
<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>