<template>
    <div>
        <section class="footer-section">
            <div class="row">
                <div class="col-lg-12">
                    <p>© Bajaj Allianz General Insurance Co. Ltd. 2022 All Rights Reserved. Insurance is the subject matter of solicitation. IRDA Reg. No. 113 </p>
                </div>
            </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'FooterSection'
    }
</script>