<template>
    <div :class="mainClass">
        <loader :display="display_status" style_class="pannel-holder"> </loader>
        <div class="tab-component-inn" v-if='title!=""'>
            <div class="tab-component-heading">
                <h3>{{title}}</h3>
            </div>
            <div class="close_button_tigger" @click="Close">
                 <i class="flaticon-close-4"></i>
            </div>
        </div>
        <div class="tab-component-fields" v-if="tab_datas.length">
            <div class="tab-component-fields-inn">
                <div class="row no-gutter">
                    <div class="col-lg-12">
                        <div class="row">

                            <template  v-for="(case_data, index) in tab_datas">
                                <!-- //class="col-lg-2 col-md-3" -->
                                <!-- <div  :key="index" class="col-lg-12"> -->
                                <!-- {{case_data}} -->
                                <div  :key="index" :class="child_class">
                                    <ul>
                                        <li>
                                             <b-form-checkbox
                                                :id="case_data.label"
                                                v-model="checklists[case_data.calc_index]"
                                                :name="case_data.label"
                                                :value='case_data.value'
                                                :disabled="case_data.isDisabled"
                                                :unchecked-value="false"
                                                @input="sendSelected(checklists[case_data.calc_index], case_data.calc_index, case_data.valueType)"
                                            >
                                                {{case_data.label}}
                                            </b-form-checkbox>
                                        </li>
                                    </ul>
                                </div>
                            </template>
                        </div>                                    
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
const Loader = () =>import('@/components/common/Loader')
export default {
    data(){
        return {
            tabIndex :0,
            checkbox :[],
            display_status:false
        }
    },
    computed: {
        checklists : {
            get(){
                if(this.module_name){  
                    return this.$store.state[this.module_name][this.form_name]            
                }
                else{
                    return this.$store.state[this.form_name]
                }
            },
            set(values){
                if(this.module_name){
                    this.$store.state[this.module_name][this.form_name] = values
                }
                else{
                    this.$store.state[this.form_name] = values
                }
            }
        },
    },
    components:{
        Loader
    },
    props:{
        tab_datas : {
            type:Array
        },
        form_name : {
            type:String,
            default:''
        },
        module_name : {
            type:String,
            default:''
        },
        title : {
            type:String,
            default:''
        },
        child_class : {
            type:String,
            default:''
        },
        
        mainClass : {
            type:String,
            default:''
        }
    },
    methods:{
        onTabClick(value){
            this.display_status=true
            if(value=='next'){                
                this.tabIndex++
            }else{
                this.tabIndex--
            }
            this.display_status=false
        },
        Close(){
            this.$emit("clickAction",false);
        },
        sendSelected(checked, index, type){
            console.log(checked, index, type,"checked, index, type")
           this.$emit("sendSelected",checked, index, type);
        }
    }
}
</script>