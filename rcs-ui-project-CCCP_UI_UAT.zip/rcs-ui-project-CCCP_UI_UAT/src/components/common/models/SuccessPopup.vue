<template>
  <div>
   
    <b-modal 
      v-model="show" :hide-footer='true'  
      centered 
      no-close-on-backdrop
      no-close-on-esc
      :size="size"
      :hide-header='true'  :id="parentId">
      <div class="close-icon" v-if="show_doclist == true">
          <button @click="CloseModel">X</button> 
        </div>                 
        <div class="new-claim-reg-step">
            <div class="common-modal text-center">    
                <img src="@/assets/images/modal-check.svg" alt="check" v-if="error_content!=true && show_doclist != true">
                <template v-if="success_content==true">
                    <h1>Successfully Updated !</h1>
                    <p class="mb-4" v-if="success_message">{{success_message}}</p>
                    <button  class="btn btn-primary mr-3" @click="CloseModel()">Okay</button>
                </template>
                <template v-else-if="error_content==true">
                    <p class="mb-4" v-if="error_message">{{error_message}}</p>
                    <button  class="btn btn-primary mr-3" @click="CloseModel">Okay</button>
                </template>
                <template v-else-if="show_doclist == true">
                  <slot name="tablecontent"></slot>
                </template> 
                <template v-else>
                     <h1 v-if="CategoryName"> {{CategoryName}} Claim Intimation Completed</h1>
                     <h1 v-else> Home Claim Intimation Completed</h1>
                    <p class="modal-para mb-4">Thank You, your claim has been intimated successfully,</p>
                    <div class="model-ref-num mb-4 flex-column">
                        <p>Your claim number is <span @click="copyClaimNumber(claimRefNo)">{{claimRefNo}}</span></p>
                          <small>Please use this claim number for further communication. Click on the claim number to copy.</small>
                    </div>
                    <router-link to='/' class="btn btn-primary mr-3">Home</router-link>
                    <router-link to='/claim-document-upload-list' class="btn btn-primary">Upload Document</router-link>
                </template>
            </div>       
        </div>      
    </b-modal>
  </div>
</template>

<script>
  import {copyToClipboard} from "@/lib/utils";

  export default {
    props:{
      modalShow:Boolean,
      mainClass:String,
      closeButtonClass:String,
      iconClass:String,
      message:String,
      okButtonClass:String,
      showOkButton:String,
      isSuccessPopup:Boolean,
      success_content:Boolean,
      error_content:Boolean,
      success_message:Boolean,
      error_message: String,
      isInputPopup:Boolean,
      size:String,
      displayClose:Boolean,
      parentId : String,
      claimRefNo: String,
      CategoryName: String,
      show_doclist:Boolean
    },
    data() {           
      return{
        show: true,
        showModal:false
      } 
    },
    methods:{
      copyClaimNumber(claimNumber) {
        copyToClipboard(claimNumber).then(success => {
          this.$bvToast.toast(`Copied to clipboard!`, {
            autoHideDelay: 3000,
            solid: true,
            variant: "success",
            title: null
          })
        });
      },
      CloseModel(){
        this.$emit("onClosePopup")
      },
    }
  }
</script>

<style scoped>
.close-icon{
  margin: auto;
  width: 92%;
  text-align: end;
}
.close-icon button{
  border: none;
  background: transparent;
  font-size: 20px;
}
</style>