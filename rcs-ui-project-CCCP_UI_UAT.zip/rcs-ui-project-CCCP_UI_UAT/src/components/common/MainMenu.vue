<template>
    <div>
        <div class="main-menu d-flex align-items-center">
            <div class="main-menu-tab d-none d-lg-block">
                <div class="navbar navbar-expand-lg bsnav" style="justify-content: center">
                    <div class="collapse navbar-collapse navbars"  id="collapse_target2">
                        <ul class="navbar-nav navbar-mobile mx-auto mob-main-menu" v-if="menuPages && menuPages.length">
                            <!-- {{ menuPages }} -->
                            <template v-for="(menu_page, index) in menuPages">
                                 <template v-if="menu_page && menu_page.child && menu_page.child.length==0">
                                    <li class="nav-item"  :key="index">
                                        <a @click="navigateUrl(menu_page)"  class="nav-link home h-lg-100" :key="index" :class="(menu_page.id == active_page.id) ? 'active' : ''">
                                            <div class="icon-mob">
                                                 <div v-html="renderIcons(menu_page.name)"></div>
                                                <div class="link-text">{{menu_page.name}}</div>
                                            </div>
                                        </a>
                                    </li>
                                </template>
                                <template  v-else-if="menu_page && menu_page.child && menu_page.child.length>0">
                                      <li class="nav-item dropdown" :key="index">
                                        <a @click="openMenu(index, true)"  class="nav-link configuration h-lg-100" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" :key="index" :class="(menu_page.id == active_page.mainId) ? 'active' : ''">
                                            <div class="icon-mob"  @click="isOpen = !isOpen">
                                                <div v-html="renderIcons(menu_page.name)"></div>
                                               <div class="link-text d-flex align-items-center">{{menu_page.name}}<i class="material-icons prefix">expand_more</i></div>
                                            </div>
                                        </a>
                                        <div class="dropdown-menu main-menu-dropdown" :class="(isOpen && currentClickIndex == index) ? 'show' : ''" aria-labelledby="navbarDropdown" >
                                            <template v-for="(subMenuPages, sub_index) in menu_page.child"> 
                                                <a @click="navigateUrl(menu_page, subMenuPages, index), isOpen = !isOpen" class="dropdown-item" :key="sub_index" :class="(subMenuPages.id==active_page.id) ? 'active' : ''">{{subMenuPages.name}}</a>
                                            </template>
                                        </div>
                                        <div v-if="isOpen" class="outside" @click="clickOutside()"></div>
                                    </li>
                                </template>
                            </template>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="bsnav-mobile">
            <div class="bsnav-mobile-overlay"></div>
                <div class="navbar">
                </div>
        </div>
    </div>
</template>
<script>
    import {replace} from 'lodash';
    import {mapState} from 'vuex';
    import {getMenuPages} from '@/apis/ApiDatas'
    import {HeaderSVG} from '@/datas/SvgIcons/TopMenu'
    
    export default {
        name: 'MainMenu',
        data(){
            return{
                menuPages : [],
                isOpen : false,
                currentClickIndex : null
            }
        },
        computed:{
            ...mapState({
                menuPagesList : state => state.menuPages,
                active_page : state => state.active_page,
            })
        },
        watch:{
            "$route.fullPath":function(new_value){
                this.updateActiveMenu(new_value)
            },
            menuPagesList:function(new_value){
               this.menuPages = new_value
            }
        },
        async mounted(){
            setTimeout(()=>{
                 this.updateActiveMenu(this.$route.fullPath)
            }, 1000)
            await this.getMenuPages();
            if(this.$route.fullPath){
                if(this.$route.fullPath=='/'){
                    this.updateActiveMenu('/home')
                }
                else{
                    this.updateActiveMenu(this.$route.fullPath)
                }
            }
        },
        methods:{
            clickOutside(){
                this.isOpen = false
            },
            openMenu(index, open){
                let tempMenu = [...this.menuPages]
                tempMenu[index]['isOpen'] = open;
                this.menuPages = [...tempMenu]
                console.log('this.menuPages', this.menuPages)
                this.currentClickIndex = index
            },
            renderIcons(iconName){
                let altIconsName = iconName.toLowerCase().replace(/ /g,"-").toLowerCase();
                if(altIconsName){
                    (altIconsName === 'bajaj-allianz-insurance-policy-verification') ? altIconsName = 'new-claim-registration' : altIconsName;
                    let getIconName = HeaderSVG(altIconsName)
                    if(getIconName){
                        return getIconName;
                    }
                    else{
                        return null
                    }
                }
                else{
                     return null
                }
            },
            updateImagePath(imagePath){
                return require(`@/assets/images${imagePath}`)
            },
            getMenuPages : async function (){
                let userDetails = this.$store.state.profile;
                let tempDetails  = getMenuPages();
                let reqObj = {
                    "userId":userDetails.userId,
                    "roleCode":userDetails.role__code,
                    "imdCode":userDetails.imdCode,
                    "pageCode":"",
                    "sectionCode":""
                }
                tempDetails.requests = reqObj;
                await this.$store.dispatch("GetRequest", tempDetails);
            },
            navigateUrl(menu_list, sub_menu='', menu_index){
                if(sub_menu){
                    let currentUrl = '';
                    if(menu_list && menu_list.name){
                        currentUrl = `/${replace(menu_list.name.toLowerCase(),new RegExp(' ','g'),'-')}`;
                    }
                    if(currentUrl){
                        console.log('jk currentUrl', currentUrl)
                         this.$router.push({
                            name  : (currentUrl == "/configuration") ? 'ConfigurationPage' : 'OthersPage',
                            params: {page_name:sub_menu.url.replace('/', '')}
                        })
                    }
                    this.openMenu(menu_index, false);
                }
                else{
                     let currentUrl = '';
                    if(menu_list && menu_list.name){
                        currentUrl = `/${replace(menu_list.name.toLowerCase(),new RegExp(' ','g'),'-')}`;
                    }
                    if(sub_menu){
                        currentUrl += `/${replace(sub_menu.name.toLowerCase(),new RegExp(' ','g'),'-')}`;
                    }
                    if(currentUrl){
                        this.$router.push(currentUrl)
                    }
                }
            },
            createUrl(menu_list){
                let currentUrl = '';
                if(menu_list && menu_list.name){
                    currentUrl = `/${replace(menu_list.name.toLowerCase(),new RegExp(' ','g'),'-')}`;
                }
                return (currentUrl) ? currentUrl : ''
            },
            updateActiveMenu(url){
                let urlCheck  = url.split('/')
                if(urlCheck.length>=3){
                    urlCheck[1] = urlCheck[1].replace('-create', '');
                    let currentUrl = this.menuPages.find((list)=>(list.url.includes(`/${urlCheck[1]}`)));
                    if(currentUrl && currentUrl.child && currentUrl.child.length > 0){
                        let subMenu = currentUrl.child.find((list)=>(list.url.includes(`/${urlCheck[2]}`)));
                        if(subMenu){
                            this.$store.commit('UDPATE_ACTIVE_PAGE', subMenu)
                        }
                    }
                    else if(currentUrl && currentUrl.child.length==0){
                        if(currentUrl){
                            this.$store.commit('UDPATE_ACTIVE_PAGE', currentUrl)
                        }
                    }

                }
                else{
                 if(this.$route.name == 'nhai-document-upload-list' && url == '/nhai-document-upload-list') url = 'nhai';
                    let currentUrl = this.menuPages.find((list)=>(list.url.includes(url) || list.url.includes(url.split('-create')[0]) || list.url.includes(url.split('-list')[0])));
                    if(currentUrl){
                        this.$store.commit('UDPATE_ACTIVE_PAGE', currentUrl)
                    }
                }
            }
        }
    }
</script>
<style scoped>
.outside {
  width: 100vw;
  height: 100vh;
  position: fixed;
  top: 0px;
  left: 0px;
}
</style>