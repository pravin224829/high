<template>
 <div class="case-history">
     <b-modal
      v-model="show"
      centered 
      :body-class="contentClass"
      :hide-footer="footer" 
      :hide-header="header" 
      :size="size" no-close-on-backdrop no-close-on-esc>
      <template v-slot:modal-header="{ }">
        <h5 :class="header_style">{{title}}</h5>
        <button type="button" class="close m-0 p-0 cases-modal-btn" data-dismiss="modal" aria-label="Close"  @click="CloseModel">
          <i class="fa fa-close"></i> 
        </button>
      </template>
       <slot></slot>
    </b-modal>
    </div>
</template>
<script>
export default {
    data(){
      return{
        show: true,
        showModal:false
      }
    },
    props:{
      name:String,
      contentClass:String,
      title : String,
      size:String,
      header : Boolean,
      footer : Boolean,
      header_style:String,
     
    },
    methods:{
      CloseModel(){
       this.$emit("onClosePopup")
      }
    }
}
</script>