<template>
    <div v-bind:class="UpdatedClass()" v-if="(display==true)">
        <div class="loader">
            <img src="../../assets/img/loader.gif"  />
        </div>
    </div>
    
</template>
<script>
export default {    
    props :{
        display:Boolean,
        style_class : String
    },
    methods:{
        UpdatedClass(){
            if(typeof this.style_class !== 'undefined' && this.style_class){
                return  this.style_class
            }
            else{
                 return 'loader-holder'
            }
        }
    }
}
</script>
<style scoped>
.loader-holder {
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    background: hsla(219, 23%, 33%, 0.61);
    z-index: 99999;
}

.loader {
    text-align: center;
    top: 50%;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    position: relative;
}

.loader img {
    vertical-align: middle;
    border-style: none;
    margin: 0px auto;
    max-width: 50px;
}
</style>