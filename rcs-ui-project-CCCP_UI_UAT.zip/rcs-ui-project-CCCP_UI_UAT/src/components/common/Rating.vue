<template>
    <div class="star-rating">
       <star-rating 
          v-model="base_model[key_object]"
          v-bind:increment="0.5"
          v-bind:max-rating="5"
          inactive-color="#e2e2e2"
          active-color="#FFC107"
          v-bind:star-size="30" 
          :read-only="isReadOnly"
       ></star-rating>
    </div>
</template>
<script>
  import StarRating from 'vue-star-rating'
  export default {
    props : {
        base_model : null,
        current_rating : null,
        key_object : null,
        isReadOnly : {
          type: Boolean,
          default: false
        },
    },
      components: {
        StarRating
      }
  }
</script>