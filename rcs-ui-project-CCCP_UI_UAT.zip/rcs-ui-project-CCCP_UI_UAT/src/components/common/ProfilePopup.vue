<template>
  <div class="popup" v-if="show" >
      <div class="popup-content d-flex flex-row ">
            
        
      <form @submit.prevent="submitForm" class="pt-5">
        <div class="form-group">
          <label for="file">Select File:</label>
          <div class="file-input-wrapper">

          <input
            type="file"
            id="file"
            ref="fileInput"
            @change="fileSelected"
            @blur="touchedFile = true"
            accept="image/jpeg, image/png, image/gif"
            required
          />
          </div>
          <span v-if="touchedFile && !selectedFile" class="error-message">Image file is required</span>
          <span v-if="touchedFile && selectedFile && !isValidFileType" class="error-message">Invalid file type. Only image files are allowed.</span>
       
        </div>
        <div class="form-group">
          <label for="designation">Designation:</label>
          <input
            type="text"
            id="designation"
            v-model="designation"
             
          />
                  </div>
        <button type="submit" >Submit</button>
      </form>
      <button @click="closePopup" class="close-button">x</button>
    
    </div>
  </div>
    
  
</template>

<script>
import {UserProfile} from '@/apis/ApiDatas'
import {EncodeString} from '@/shared/custom'
import {UpdateUserProfile} from '@/apis/ApiDatas'
export default {
  props: {
    show: Boolean,
    profileLogo: String,
    _designation: String,
  },
  data() {
    return {
      designation: this._designation,
      selectedFile: null,
      touchedFile: false, 
      isValidFileType: true,
      showPopup: this.show
    };
  },
  methods: {
    
    closePopup() {
      this.touchedDesignation = false;
      this.touchedFile = false;
      this.$emit("close");
    },
    async submitForm() {
       
       
      let _profile = this.$store.state.profile;
      let formData = new FormData();
      formData.append("file", this.selectedFile)
      

      let userInfo = {
        "designation": this.designation,
        "userId":_profile.userId,
        "roleCode":_profile.role__code
      }
      let tempPayload = EncodeString(userInfo);
      formData.append("payload", tempPayload)
      let _temp_details =  UpdateUserProfile();
      _temp_details.requests = formData;
      this.touchedDesignation = true; 
      this.touchedFile = true; 

     
                let _details = await this.$store.dispatch("UpdateUserProfileInfo", _temp_details);
               
                if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success') { 
                  let _user_details = this.$store.state.auth;
                let _temp_details  = UserProfile();
                _temp_details.requests.userId =  _user_details.username;
                let _pdetails = await this.$store.dispatch("GetIlmRequest", _temp_details);
                  if(_pdetails.body && _pdetails.body.status && _pdetails.body.status.toLowerCase()=='success'){ 
                      this.closePopup(); 
                  }
                }
                         
       
       
      
    },
     
    fileSelected(event) {
      this.selectedFile = event.target.files[0];
      if (this.selectedFile) {
        
        const allowedFileTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (!allowedFileTypes.includes(this.selectedFile.type)) {
          this.isValidFileType = false;
        } else {
          this.isValidFileType = true;
        }
      } else {
        this.isValidFileType = true;  
      }
    },
  },
};
</script>

<style scoped>
 
.popup {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5); 
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}

.popup-content {
  background-color: #fff;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}

.form-group {
  margin-bottom: 15px;
}

label {
  display: block;
  margin-bottom: 5px;
}

input[type="text"],
input[type="file"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

button[type="submit"] {
  background-color: #007bff;
  color: #fff;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
}

button[type="submit"]:hover {
  background-color: #0056b3;
}

.error-message {
  color: red;
  font-size: 12px;
  margin-top: 5px;
}

.error-message.active {
  display: block;  
}
.close-button{
align-self: flex-start!important;
border: none;
background-color: white;
font-size:25px;
margin-bottom:20px !important;
margin-left:20px;
    
 
} 


 
.file-input-wrapper {
  width: 100%;
  height: 50px; /* Set a fixed height */
  overflow: hidden; /* Hide overflow */
  border: 1px solid #ccc;
  border-radius: 5px;
}
 
</style>
