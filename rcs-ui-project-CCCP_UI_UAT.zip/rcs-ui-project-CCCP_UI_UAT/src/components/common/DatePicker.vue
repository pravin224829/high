<template>
    <date-range-picker
        ref="picker" v-model="date_filter[field_name]" :locale-data="localeData" :ranges='false' :autoApply='false' :disabled='false' :singleDatePicker='singleDatePicker' 
        @select='onSelect'
         :dateFormat="dateFormat">
    </date-range-picker> 
</template>
<script>
import DateRangePicker from 'vue2-daterange-picker'
import 'vue2-daterange-picker/dist/vue2-daterange-picker.css'
export default {
    props :{ 
     dateRange: {
          startDate: null,
          endDate: null,
     },
     field_name :String,
     model_name : String,
     localeData : Object,
     singleDatePicker : null
  },
  components : {
      DateRangePicker
  },
  computed:{
       date_filter : {
            get(){
                return this.$store.state[this.model_name]
            },
            set(values){
                this.$store.state[this.form_name] = values
            }
        }
  },
  methods : {
      onSelect(value){
          this.$emit('onDateSelect',value)  
      },
      dateFormat(classes, date){
          console.log('date', date)
          return classes;
      }
  }
}
</script>