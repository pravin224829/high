export function CheckCustomValidation (currentMenu, currentPage, formData, fieldObj, fieldValue, fromValue){
    if(currentPage=='WBDETAILS'){
        let tempoFormData = formData
        if(fieldObj && fieldObj.check_validations=="true"){
            fieldValue = (fieldValue) ? fieldValue.toLowerCase() : '';
            console.log('fieldValue',fieldValue)
            let checkValues = fieldObj.custom_validation[fieldValue];
            if(!checkValues){
                checkValues = fieldObj.custom_validation['otherOptions'];
            }
            console.log('checkValuesMain', checkValues)
            let compareValues = (fieldObj.custom_validation && fieldObj.custom_validation.compare_value) ? fieldObj.custom_validation.compare_value : [];
            tempoFormData.forEach((listFieldsMain, fieldIndexMain)=>{
                if(listFieldsMain.body){
                    listFieldsMain.body.forEach((listFields,fieldIndex)=>{
                        if(checkValues && Array.isArray(checkValues)){    
                            let checkInnerValues = checkValues.find((list)=>list.field==listFields.model && parseInt(list.form_index)==listFieldsMain.header.id);
                            console.log('checkInnerValues', checkInnerValues,checkValues, listFields.model, listFieldsMain.header.id)
                            if(checkInnerValues){
                                if(checkInnerValues.disable){
                                    if(compareValues && compareValues.length){
                                        let exec = '';
                                        compareValues.forEach((list, index)=>{
                                            if((list.value.toLowerCase() == (fromValue[list.field] && fromValue[list.field].toLowerCase()))){
                                                exec += 'true'
                                            }
                                            else{
                                                exec += 'false'
                                            }
                                            if(index==compareValues.length-1){
                                                if(!exec.includes('false')){
                                                    if(checkInnerValues.disable == "true"){
                                                        formData[fieldIndex].disbabled = true
                                                        formData[fieldIndex].rules = '';
                                                    }
                                                    else{
                                                        formData[fieldIndex].disbabled = false
                                                        formData[fieldIndex].rules = formData[fieldIndex].initRules
                                                    }
                                                }
                                                else{
                                                
                                                    formData[fieldIndex].disbabled = false
                                                    formData[fieldIndex].rules = formData[fieldIndex].initRules
                                                    
                                                }
                                            }
                                        })
                                    }
                                    else{
                                        if(checkInnerValues.disable == "true"){
                                            formData[fieldIndex].disbabled = true
                                            formData[fieldIndex].rules = '';
                                        }
                                        else{
                                            formData[fieldIndex].disbabled = false
                                            formData[fieldIndex].rules = formData[fieldIndex].initRules
                                        }
                                    }
                                }
                                if(checkInnerValues.check_display){
                                    if(checkInnerValues.check_display == "true"){
                                        listFieldsMain.body[fieldIndex].check_display = "true";
                                        listFieldsMain.body[fieldIndex].rules = '';
                                    }
                                    else{
                                        listFieldsMain.body[fieldIndex].check_display = "false";
                                        listFieldsMain.body[fieldIndex].rules = listFieldsMain.body[fieldIndex].initRules
                                    }
                                }
                                if(checkInnerValues.check_rules){
                                    if(checkInnerValues.check_display == "true"){
                                        listFieldsMain.body[fieldIndex].check_display = "true";
                                        listFieldsMain.body[fieldIndex].rules = '';
                                    }
                                    else{
                                        listFieldsMain.body[fieldIndex].check_display = "false";
                                        listFieldsMain.body[fieldIndex].rules = listFieldsMain.body[fieldIndex].initRules
                                    }
                                }
                                if(checkInnerValues.check_mandatory){
                                    if(checkInnerValues.check_mandatory == "true"){
                                        console.log('listFieldsMain.body', listFieldsMain.body, fieldIndex)
                                        listFieldsMain.body[fieldIndex].rules = listFieldsMain.body[fieldIndex].initRules
                                    }
                                    else{
                                        listFieldsMain.body[fieldIndex].rules = ""
                                    }
                                }
                            }

                            if(fieldIndexMain+1== tempoFormData.length && fieldIndex+1==listFieldsMain.body.length){
                                formData = tempoFormData
                            }
                        }
                    })
                }
            })
        }
    }
}