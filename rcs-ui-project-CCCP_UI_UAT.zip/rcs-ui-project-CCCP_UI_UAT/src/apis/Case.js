const GetCaseList = () => {
    return {
        "url": `${process.env.VUE_APP_INVESTIGATION}investigation/api/fetchLatestInvestigationByUser`,
        "mutation": "GET_CASE_LIST",
        "notify_message": "Success",
        "encryption": "false",
        "requests": {}
    }
}

export {
    GetCaseList
}