const TatBandCount = () => {
    return {
        "url": `${process.env.VUE_APP_REPORT}report/api/fetchTatBandCount`,
        "mutation": "GET_TAT_COUNT",
        "notify_message": "Success",
        "requests": {}
    }
}
const fetchCaseReportDropdowns = () => {
    return {
        "url": `${process.env.VUE_APP_REPORT}report/api/fetchCaseReportDropdowns`,
        "mutation": "GET_CASE_DROPDOWN",
        "notify_message": "Success",
        "requests": {}
    }
}
const fetchDashboardReportDropdowns = () => {
    return {
        "url": `${process.env.VUE_APP_REPORT}report/api/fetchDashboardReportDropdowns`,
        "mutation": "GET_DASHBOARD_DROPDOWN",
        "notify_message": "Success",
        "requests": {}
    }
}
const fetchCaseReportChart = () => {
    return {
        "url": `${process.env.VUE_APP_REPORT}report/api/fetchCaseReportChart`,
        "mutation": "GET_CASE_CHART_DATA",
        "notify_message": "Success",
        "requests": {}
    }
}
const fetchDashboardReportChart = () => {
    return {
        "url": `${process.env.VUE_APP_REPORT}report/api/fetchDashboardReportChart`,
        "mutation": "GET_DASHBOARD_CHART_DATA",
        "notify_message": "Success",
        "requests": {}
    }
}

export {
    TatBandCount,
    fetchCaseReportDropdowns,
    fetchDashboardReportDropdowns,
    fetchCaseReportChart,
    fetchDashboardReportChart,
}