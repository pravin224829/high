const axios = require('axios');
const LoginJson = (apis) => {
    return axios.get(apis, { 
        method: 'GET',
        headers: {
        "Content-type": "application/json; charset=UTF-8",
    }
    }).then((response)=> { return response.data })
}

const GetToken = () =>{
    const _localitems = { ...localStorage };
    return _localitems
}



export {
    LoginJson,
    GetToken
}