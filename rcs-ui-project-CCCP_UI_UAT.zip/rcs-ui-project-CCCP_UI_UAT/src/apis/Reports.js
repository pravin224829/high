const GetCaseList = () => {
    return {
        "url": `${process.env.VUE_APP_INVESTIGATION}investigation/api/fetchLatestInvestigationByUser`,
        "mutation": "GET_CASE_LIST",
        "notify_message": "Success",
        "encryption": "false",
        "requests": {}
    }
}

const GetFetchBucketStatus = () => {
    return {
        "url": `${process.env.VUE_APP_CONFIG}configuration/master/api/fetchBucketStatus`,
        "mutation": "GET_FETCH_BUCKET_STATUS",
        "notify_message": "Success",
        "encryption": "true",
        "requests": {}
    }
}

export {
    GetCaseList,
    GetFetchBucketStatus
}