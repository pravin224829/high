import {mapState} from 'vuex'
import {convert_ddmmyy, convert_datetime24} from '@/shared/timer'
import {isDate} from '@/shared/custom'
import {DownloadDocument, GetDropDownAPIs, SaveForm, LookupByType} from '@/apis/ApiDatas.js';
export default {
    computed:{
        ...mapState({
            user_profile_details : state => state.profile,
            active_page : state => state.active_page,
            active_menu : state => state.active_menu,
            multi_section_form_data : state => state.multi_section_form_data,
            section_pages: state => state.section_pages,
        })
    },
    methods: {
        emptyFilter(){
            this.form_data = [] 
            this.$store.commit('EMPTY_FILTER', [])
        },
        updateImagePath(imagePath){
            return require(`@/assets/images${imagePath}`)
        },
        
        RemoveAllSession(){
            window.sessionStorage.clear();
        },
         RemoveSessionStorage(objectName){
            window.sessionStorage.removeItem(objectName) 
        },
        SetSessionStorage(objectName, objectValue){
            window.sessionStorage.setItem(objectName, this.EncodeString(objectValue)) 
        },
        GetSessionStorage(objectName){
           let getString =  window.sessionStorage.getItem(objectName);
           if(getString){
               return this.DeocdeString(getString)
           } 
           
        },
        
        EncodeString : function(enc_string){
            let _temp = JSON.stringify(enc_string);
            _temp  = window.btoa(_temp);
            return _temp;
        },
        DeocdeString : function(enc_string){
            let _temp = window.atob(enc_string);
            _temp  = JSON.parse(_temp);
            return _temp;
        },
        downloadDoc : async function(documentDetails){
             let downloadDc = {"documentId":"","userId":"", ...documentDetails}
            if(documentDetails){
                if(documentDetails.name){
                    downloadDc['docName'] = documentDetails.name;
                }
                downloadDc['documentId'] = (documentDetails) ? documentDetails.docId : '';
                downloadDc['userId'] = (this.user_profile_details) ? this.user_profile_details.userId : '';
                downloadDc['roleCode'] = (this.user_profile_details) ? this.user_profile_details.role__roleCode : '';
                downloadDc['imdCode'] = (this.user_profile_details) ? this.user_profile_details.imdCode : '';
                let tempPage = DownloadDocument();
                console.log('downloadDc', downloadDc)
                tempPage.requests = downloadDc
                await this.$store.dispatch('GetDownloadRequest', tempPage)
            }
        },
        commonPageRequest(passSectionCode){
            let userProfile = this.user_profile_details
            console.log('active_page', this.active_page, this.active_menu)
            let createReq = {
                "userId":userProfile.userId,
                "roleCode":userProfile.role__code,
                "imdCode":userProfile.imdCode,
                "pageCode":this.active_page.code,
                "sectionCode": this.active_page.pageCode
            }
            if(passSectionCode) createReq.sectionCode = this.active_page.sectionCode
            return createReq;
        },
       
        getDropDownValues: async function(requestDetails, code, label, type, value='', user_profile, caseDetails, model){
            requestDetails.requests.roleCode = (user_profile && user_profile.role__roleCode) ? user_profile.role__roleCode : (user_profile.role__code) ? user_profile.role__code : '',
            requestDetails.requests.imdCode = (user_profile && user_profile.imdCode) ? user_profile.imdCode : (user_profile.imdCode) ? user_profile.imdCode : '',
            requestDetails.requests.code = (value) ? value : code,
            requestDetails.requests.userId = (user_profile) ?  user_profile.userId : '';
            requestDetails.requests.caseNo = (caseDetails) ?  caseDetails.caseNo : '';
            requestDetails.requests.claimNumber = this.$store.state.multi_section_form_data?.claimNumber || this.$store.state?.claimNumber;
            if(this.polcyCode){
                requestDetails.requests.productCode = this.polcyCode;
            }
            if(model == 'claimStatus'){
                requestDetails.requests.source = 'UDYAM';
            }
            requestDetails.requests.fieldCode = code
            requestDetails.requests.fieldName = label;
            requestDetails.requests.fieldType = type;
            let _response =  await this.$store.dispatch("GetRequest", requestDetails) 
            return _response;
        },
        formatePageData(formData, mainFormData){
             let saveData = {...formData}
            if(saveData){
                for(let _list_data in saveData){
                    let _date = isDate(saveData[_list_data]);
                    if(_date && saveData[_list_data]){
                        let checkData = mainFormData.find((list)=>(list.model==_list_data&&list.type=='datepicker')) 
                        let dateTimeData = mainFormData.find((list)=>(list.model==_list_data&&list.type=='datetimepicker')) 
                        if(checkData){
                            saveData[_list_data] = convert_ddmmyy(saveData[_list_data])
                        }
                        else if(dateTimeData){                                       
                            saveData[_list_data] = moment(saveData[_list_data]).format('MM/DD/YYYY h:mm:ss')
                        }                                    

                    }
                }
            }
            return saveData;
        },
        formateInner(state_object){
            let _post_object = {};
            let _temp_key = '';
            let _temp_object = state_object
            for(let temp_object in _temp_object){
                if(typeof _temp_object[temp_object]!='object'){
                    let _temp_key_in = temp_object.split('__')
                    if(_temp_key_in.length>=2){
                        let _build_temp = {};
                        if(_post_object[_temp_key_in[0]]){
                            _build_temp = _post_object[_temp_key_in[0]]
                        }
                        else{
                            _post_object[_temp_key_in[0]] = {}
                        }
                        _temp_key = temp_object;
                        _build_temp[_temp_key_in[1]] = _temp_object[_temp_key]
                        _post_object[_temp_key_in[0]] = {..._build_temp}
                    }
                    else if(_temp_key_in.length==1){
                        _temp_key = _temp_key_in[0];
                        _post_object[_temp_key] = _temp_object[_temp_key]
                    }
                }
            }
            return _post_object;
        },
        async fetchLookUp(field, fname, ftype, fsort){    
            let _temp_details  = LookupByType()
            _temp_details.requests.code = field
            _temp_details.requests.fieldName = fname;
            _temp_details.requests.fieldType = ftype;
            _temp_details.requests.fieldSort = fsort;
            return await this.$store.dispatch("GetRequest", _temp_details)           
        },
        async mapLookUpType(pageFields){
             let _look_up_types = this.$store.state.look_by_type_lists   
            pageFields.forEach(async (field_list)=>{
                if(field_list.type=='select' || field_list.type=='master_select'){
                    let checkDropDown = GetDropDownAPIs(field_list.model)
                    if(checkDropDown){
                        let _details = await this.getDropDownValues(checkDropDown, field_list.fieldCode,field_list.label,field_list.type,'', this.user_profile_details, this.caseDetails, field_list.model)
                        if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                            _look_up_types.push({
                                name : field_list.model,
                                fields : this.$store.state.lookupby_type   
                            })
                            this.$store.state.look_by_type_lists = _look_up_types                                    
                            field_list.options = [...this.$store.state.lookupby_type] 
                            if(field_list.attributeData && field_list.attributeData.default_value){
                                if(!this.from_details[field_list.model]){
                                    this.from_details[field_list.model] = field_list.attributeData.default_value
                                }
                            }
                            field_list.loader = false
                        }
                    }
                    else{
                        let _details = await this.fetchLookUp(field_list.fieldCode,field_list.label,field_list.type, field_list.sortInput) 
                        if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){
                            _look_up_types.push({
                                name : field_list.model,
                                fields : this.$store.state.lookupby_type   
                            })
                           
                            if(field_list.attributeData && field_list.attributeData.default_value){
                                if(!this.from_details[field_list.model]){
                                    this.from_details[field_list.model] = field_list.attributeData.default_value
                                }
                            }
                            this.$store.state.look_by_type_lists = _look_up_types   
                                                             
                            field_list.options = this.$store.state.lookupby_type   
                            field_list.loader = false
                        }
                    }
                }
            })
        },

        formateSaveData(formData, mainFormData, section_type='single'){
            let saveData = {...formData}
            if(saveData){
                for(let _list_data in saveData){
                    let _date = isDate(saveData[_list_data]);
                    if(_date && section_type=='single'){
                        let checkData = mainFormData.find((list)=>(list.model==_list_data&&list.type=='datepicker')) 
                        let dateTimeData = mainFormData.find((list)=>(list.model==_list_data&&list.type=='datetimepicker')) 
                        let timeData = mainFormData.find((list)=>(list.model==_list_data&&list.type=='timepicker')) 
                        if(checkData){
                            saveData[_list_data] = (saveData[_list_data]) ? convert_ddmmyy(saveData[_list_data]) : null
                        }
                        else if(dateTimeData){                                       
                            saveData[_list_data] = (saveData[_list_data]) ? convert_ddmmyy(saveData[_list_data]): null
                        }
                        else if(timeData){                                       
                            saveData[_list_data] = (saveData[_list_data]) ? convert_datetime24(saveData[_list_data]): null
                        }  
                        
                    }
                    else{
                        let checkData = mainFormData.find((list)=>(list.model==_list_data&&list.type=='datepicker')) 
                        let dateTimeData = mainFormData.find((list)=>(list.model==_list_data&&list.type=='datetimepicker')) 
                        let timeData = mainFormData.find((list)=>(list.model==_list_data&&list.type=='timepicker')) 
                        if(checkData){
                            saveData[_list_data] = (saveData[_list_data]) ? convert_ddmmyy(saveData[_list_data]) : null
                        }
                        else if(dateTimeData){                                       
                            saveData[_list_data] = (saveData[_list_data]) ?  convert_ddmmyy(saveData[_list_data]): null
                        }                                    
                        else if(timeData){                                       
                            saveData[_list_data] = (saveData[_list_data]) ?  convert_datetime24(saveData[_list_data]): null
                        }   
                    }
                }
            }
            return saveData;
        },

        processFormSubmit(isFinal){
            console.log('processFormSubmit', this.multi_section_form_data)
            let formData = {}
            let popUpData = {}
            let multipleFormData = []
            if(this.pageFields && this.pageFields.length){
              this.pageFields.forEach(async (form_list, form_index)=>{
                    if(Object.keys(this.multi_section_form_data).length){
                        formData =  {...this.formateSaveData(this.multi_section_form_data, form_list.body, form_list.header.type), ...formData, ...popUpData}
                    }
            
                   if(this.pageFields.length == form_index+1){
                      formData = this.formateInner(formData);
                      if(formData){
                          for(let formList in formData){
                              if(typeof formData[formList]=='object'){
                                  formData[formList]['taskId'] = (this.caseDetails) ? this.caseDetails.taskId: '';
                                  formData[formList]['caseId'] = (this.caseDetails) ? this.caseDetails.caseId  : '';
                              }
                          }
                      }
                      let indexDetails = 0;
                      multipleFormData.forEach((formlist)=>{
                           if(Object.keys(formlist).length){
                              for(let form_key in formlist){
                                  if(indexDetails==0){
                                      formData[form_key] = []
                                  }
                                  formData[form_key].push(formlist[form_key])
                                  indexDetails+=1
                              }
                           }
                      })
                      if(formData){
                        console.log("this.active_page",this.active_page)
                        let formPostData = SaveForm('saveClaimDetails');
                        let initalformData = {
                            "claimRefNo": (this.claimRefNo) ? this.claimRefNo : "",
                            "claimNumber": (this.claimNumber) ? this.claimNumber : '',
                            "isFinalSubmission" : (this.claimNumber) ? false : isFinal,
                            "userId": (this.user_profile_details) ? this.user_profile_details.userId : '',
                            "roleCode": (this.user_profile_details) ? this.user_profile_details.role__code : '',
                            "imdCode": (this.user_profile_details) ? this.user_profile_details.imdCode : ''
                        }
                        if(this.active_menu.secObjName in formData){
                             if(this.active_menu.secObjName){
                                initalformData[this.active_menu.secObjName] = formData[this.active_menu.secObjName]
                            }
                            else{
                                initalformData[this.active_page.secObjName] = formData[this.active_page.secObjName]
                            }
                            
                        }
                        else{
                            if(this.active_menu.secObjName){
                                initalformData[this.active_menu.secObjName] = formData
                            }
                            else{
                                // console.log("this.active_page",this.active_page)
                                initalformData[this.active_page.secObjName] = formData
                            }
                            
                        }
                        let runtimeData = [];
                        
                        // if(formData && formData.runtime && this.$store.state.multi_section_form_data){
                        //     for(let key in formData.runtime){
                        //         let filteredValue = this.pageFields[0].body.find((element, index) => {
                        //             console.log("cuv000",this.$store.state.claim_form_data)
                        //                  return element.model.includes("runtime__"+key)
                        //             }) 
                        //             if(filteredValue){
                        //                 runtimeData.push({
                        //                     "fieldName":filteredValue.label,
                        //                     "fieldCode":filteredValue.fieldCode ,
                        //                     "fieldValue":formData.runtime[key]
                        //                 }) 
                        //             } 
                        //      }
                        //      formData.runtime = runtimeData;
                        // }
                         if(formData){
                            if(Object.keys(this.$store.state.claim_form_data)) {
                                for(let key in this.$store.state.claim_form_data){
                                    this.pageFields[0].body.forEach((element) => {
                                        if(key == element.model){
                                            runtimeData.push({
                                                "fieldName":element.label,
                                                "fieldCode":element.fieldCode ,
                                                "fieldValue": this.$store.state.claim_form_data[key],
                                                "orderNo": element.orderNo
                                            })
                                        }
                                           
                                    })
                                }     
                                formData.runtime = runtimeData;
                            }   
                           
                        }
                          formPostData.requests = initalformData;
                          let temAlter = true;
                          let execLoop = true
                          if(formData && execLoop){
                              if(temAlter){
                                  let tempRequest = await this.$store.dispatch("PostRequest", formPostData);
                                  if(tempRequest.body && tempRequest.body.status && tempRequest.body.status.toLowerCase()=='success'){
                                    this.show_error = false
                                    if(!this.GetSessionStorage('claimRefNo')){
                                        this.SetSessionStorage('claimRefNo', tempRequest.body.claimRefNo)
                                    } 

                                    if(tempRequest.body.claimNumber && isFinal){
                                        this.$store.state.claimNumber = tempRequest.body.claimNumber;
                                        this.claimNumber = tempRequest.body.claimNumber;
                                        let getCLaimNumbwer = {
                                            claimNumber : tempRequest.body.claimNumber
                                        }
                                        this.SetSessionStorage('sesssion_details', JSON.stringify(getCLaimNumbwer))
                                    }
                                    else{
                                        if(!tempRequest.body.claimNumber){
                                            this.$store.state.claimNumber=""
                                        }
                                    }

                                    this.$store.commit('UDPATE_CLAIM_REF', tempRequest.body.claimRefNo)
                                    if(this.user_action !== 'save'){
                                        this.navigatePannel('next')
                                    }
                                    else if(this.claimNumber){
                                        this.isSuccessPopup = true
                                        this.success_message = 'Claim Details Updated Successfully'
                                    }
                                    else{
                                        this.isSuccessPopup = true
                                    }
                                  }
                              }
                          }
                      }
                  }
              })
            }
        },
        
        async submitForm(processSubmit=''){
            this.formError = []
            let _details = [];
            if(this.pageFields && this.pageFields.length){
                let getFinalSheet = this.pageFields.map(async (form_list, from_index)=>{
                    console.log('form_list.header.validate', form_list.header.validate, form_list.header.type)
                    if(form_list.header.validate){
                        if(form_list.header.type=='multiple'){
                            return await this.$refs['wbmultiple'+from_index][0].validate({
                                valid: false,
                                dirty: true
                            });                      
                        }
                        else{
                            let chekResult =  await this.$refs['wbsingle'+from_index][0].validate();
                            return chekResult;
                        }
                    }
                    else if(form_list.header.type=='addTable' && this.addtableSections && this.addtableSections.length && this.addtableSections.includes(from_index)){
                        if(this.tabel_form_data[form_list.header.authorityCode] && this.tabel_form_data[form_list.header.authorityCode].length>0){
                            return true
                        }
                        else{
                            this.show_error_add[form_list.header.authorityCode] = true;
                            return await this.$refs['wbsingletable'+from_index][0].validate();
                        }
                    }
                    else{
                        return true;
                    }
                })
                let getFinalSheetRest = await Promise.all(getFinalSheet)
                console.log('processSubmit', processSubmit, getFinalSheetRest)
                if(getFinalSheetRest &&  getFinalSheetRest.length){
                    if(!getFinalSheetRest.includes(false) && processSubmit==true){
                       this.show_error = true;
                       this.processFormSubmit(processSubmit)
                    }
                    else if(!getFinalSheetRest.includes(false) ){
                        this.show_error = true;
                        this.processFormSubmit(processSubmit)
                    }
                    else if(getFinalSheetRest.includes(false)){
                        this.show_error = true
                        this.formError = _details
                    }
                    else{
                        this.show_error = false
                    }
                }
            }
        },

        async navigatePannel(direction='next'){
            let getCurrentMenu = this.active_menu;
            if(getCurrentMenu){
                let getPages = this.section_pages
                if(getPages && (getPages.length>getCurrentMenu.menuIndex+1) && direction=='next'){
                    this.navigateUrl(getPages[getCurrentMenu.menuIndex+1])  
                }
                if(getPages && (getCurrentMenu.menuIndex+1 <= getPages.length) && direction=='previous'){
                    this.navigateUrl(getPages[getCurrentMenu.menuIndex-1])  
                }
            }
        },

        navigateUrl(section_page){
            this.$router.push({
                name : 'New_Claim_Registration_Details',
                params: {page_name:section_page.url.replace('/', '')}
            }).catch((err)=>{
                console.log('activateUrl', err);
            });
            this.$store.commit('UDPATE_ACTIVE_MENU', section_page)
        },
    }
};

