<template>
    <div>
        <!-- Flash Message -->
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <h1 class="page-title mb-3">
                        Home
                    </h1>
                    <div class="flash-message-container">
                        <div class="flash-heading" id="flash">
                            <div class="flash-title">
                                <h3>Flash Message</h3>
                            </div>
                            <div class="flash-title-border1"></div>
                            <div class="flash-title-border2"></div>
                        </div>
                        <div class="flash-message" v-if="flash_message && flash_message.length">
                             <flashmessage-slider :items="flash_message"></flashmessage-slider>
                            <!-- <carousel :autoplay="true" :nav="false" :items="1.5">
                                <div v-for="(flash_list, index) in flash_message" :key="index"><p><span>{{flash_list.delayed_date}}</span><span> - </span>{{flash_list.description}}</p></div>
                            </carousel> -->
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- User Hierarchy -->
        <section class="user-hierarchy main-card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h3>User Hierarchy</h3>
                        </div>
                        <div class="card-body">
                            <div class="user-tree-container">
                                <div class="level-group">
                                    <div class="row">
                                        <div id="treeHiearcy" class="col-lg-3 vertical-line top">
                                            <div class="tree-round">
                                                <div class="tree-round-inner">
                                                    <img src="@/assets/images/tree-icon.svg" alt="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <template v-for="(dashboard_list, index) in dashboard_hiererachy">
                                        <div class="row wrap align-items-end mb-5"  :key="index" v-if="dashboard_list.userHierarchy && dashboard_list.userHierarchy.length">
                                            <div class="col-lg-3 col-md-12 vertical-line top">
                                                <div class="dot">
                                                    <div class="top-level-items top-level1 left">
                                                        <div>
                                                            <div class="level-sno">{{index+1}}</div>
                                                        </div>
                                                       
                                                        <p>{{dashboard_list.teamName}}</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-3 col-md-12" v-for="(dashboard_user, index) in dashboard_list.userHierarchy" :key="index">
                                                <div class="dot">
                                                    <div class="level-user text-center">
                                                        <img :src="`data:image/png;base64,${dashboard_user.userImg}`" class="te" alt="User" v-if="dashboard_user.userImg">
                                                        <img src="@/assets/images/user-profile-image.png" class="te" alt="User" v-else>
                                                        <div class="user-details">
                                                            <p>{{dashboard_user.name}}</p>
                                                            <p>{{dashboard_user.designation}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </template>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Service Level Agreements -->
        <section class="service-level main-card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h3>Service Level Agreements</h3>
                        </div>
                        <div class="card-body">
                            <div class="service-container">
                                <div class="row d-flex justify-content-center" v-if="dashbaord_doc_list && dashbaord_doc_list.length">
                                    <div class="col-lg-4" v-for="(dashbaord_list, index) in dashbaord_doc_list" :key="index">
                                        <a :class="(dashbaord_list) ? dashbaord_list.className : 'service-item1'" @click="downloadDoc(dashbaord_list)">
                                            <div :class="`service-item${index+1}`">
                                                <div class="icon-text">
                                                    <div class="service-icon">
                                                        <img :src="updateImagePath(`/${dashbaord_list.imgName}`)" />
                                                    </div>
                                                    <h3>{{dashbaord_list.name}}</h3>
                                                </div>
                                            </div>
                                            <div class="ribbon">
                                                <div class="text">
                                                    <p class="bold">Download</p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        
        
    </div>
</template>


<script> 

import {mapState} from 'vuex';  
// import carousel from 'vue-owl-carousel'
import {FlashMessage, fetchTemplateDocList, fetchUserHierarchy} from '@/apis/ApiDatas'
import GlobalMixin from '@/mixins/GlobalMixins.js'
// import FlashmessageSlider from '@/components/FlashmessageSlider.vue';
const Loader = () =>import('@/components/common/Loader')
const FlashmessageSlider = () => import('@/components/FlashmessageSlider.vue')
    export default {
        name: 'DashboardPage',
        mixins:[GlobalMixin],
        data(){
            return{
                renderComponent:false
            }
        },
         computed:{
            ...mapState({
                active_page : state => state.active_page,
                display_status : state => state.loader, 
                flash_message : state => state.flash_message, 
                dashbaord_doc_list : state => state.dashbaord_doc_list,
                dashboard_hiererachy: state => state.dashboard_hiererachy
            })
        },
        name: 'LayoutView',
        components:{
            Loader,
            // carousel,
            FlashmessageSlider
        },
        async mounted(){
            this.GetFlashMessage()
            this.GetDocList()
            this.UserHierarchy()
        },
        methods:{
             GetFlashMessage : async function(){
                let _user_details = this.user_profile_details;
                let tempRequest =  {
                    "userId": _user_details.userId,
                    "roleCode": _user_details.role__code,
                    "imdCode":_user_details.imdCode,
                    "pageCode":this.active_page.code,
                    "sectionCode":this.active_page.pageCode,
                }
               
                let _temp_details  = FlashMessage();
                _temp_details.requests = tempRequest;   
                let _details = await this.$store.dispatch("GetRequest", _temp_details);
                if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                    console.log('_details', _details)
                }
            },
            async GetDocList(){
                let _user_details = this.user_profile_details;
                let tempRequest = {
                    "userId": _user_details.userId,
                    "roleCode": _user_details.role__code,
                    "imdCode":_user_details.imdCode,
                    "pageCode":this.active_page.code,
                    "sectionCode":this.active_page.pageCode,
                    "templateType": "HOME"
                }
                let _temp_details  = fetchTemplateDocList();
                _temp_details.requests = tempRequest;   
                let _details = await this.$store.dispatch("GetRequest", _temp_details);
                if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                    console.log('_details', _details)
                }
            },
            async UserHierarchy(){
                let _user_details = this.user_profile_details;
                let tempRequest = {
                    "userId": _user_details.userId,
                    "roleCode": _user_details.role__code,
                    "imdCode":_user_details.imdCode,
                    "pageCode":this.active_page.code,
                    "sectionCode":this.active_page.pageCode,
                }
                let _temp_details  = fetchUserHierarchy();
                _temp_details.requests = tempRequest;   
                let _details = await this.$store.dispatch("GetRequest", _temp_details);
                if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                    console.log('_details', _details)
                }
                const userHieracydetails = (_details && _details.body && _details.body.responseData &&  _details.body.responseData.length) ? _details.body.responseData[0].userHierarchy : [];
                const treeBorder = document.getElementById('treeHiearcy');
                if(userHieracydetails  && userHieracydetails.length > 0){
                    if(treeBorder){
                        treeBorder.className ='col-lg-3 vertical-line top'
                    }
                }
                else{
                    treeBorder.className ='col-lg-3 vertical-line'
                }   
            },
            downloadDoc(doc_list){
                this.downloadDoc(doc_list);
            }
        }
    }
</script>
<style lang="scss">
.owl-dots{
    display: none;
}
</style>