<template>
    <div class="steps d-flex justify-content-center flex-lg-row flex-column" v-if="section_pages && section_pages.length">
        <div class="step-1 d-flex" v-for="(section_page, index) in section_pages" :key="index" :class="(section_page.displayName==active_menu.displayName) ? 'active' : (section_page.menuIndex < active_menu.menuIndex) ? 'completed':''">
            <div class="img-ico-parent">
                <div class="step-img">
                    <img src="@/assets/images/icons/tick.svg" alt="Icon" v-if="section_page.menuIndex < active_menu.menuIndex">
                     <img src="@/assets/images/icons/step-1.svg" alt="Icon" v-else>
                </div>
            </div>
            <div class="step-detail">
                <p>{{section_page.description}}</p>
                <h6>{{section_page.displayName}}</h6>
            </div>
        </div>
    </div>
  
</template>
<script>
import {replace} from 'lodash';
import {mapState} from 'vuex';
import {GetFormPage} from '@/apis/ApiDatas'
export default {
    name: 'MainMenu',
    props: {
        product_code : String,
    },
    computed:{
        ...mapState({
            menuPages : state => state.menuPages,
            active_page : state => state.active_page,
            active_menu : state => state.active_menu,
            section_pages : state => state.section_pages,
        })
    },
   
    async mounted(){
        await this.getMenuPages();
        this.updateActiveUrl(this.$route.params)
    },
    methods:{
        getMenuPages : async function (){
            let userDetails = this.$store.state.profile;
            let tempDetails  = GetFormPage();
            let reqObj = {
                "userId":userDetails.userId,
                "roleCode":userDetails.role__code,
                "imdCode":userDetails.imdCode,
                "pageCode":'CLAIMREG1',
                "sectionCode":"",
                "productCode" : this.product_code
            }
            tempDetails.requests = reqObj;
            await this.$store.dispatch("GetRequest", tempDetails);
        },
        navigateUrl(menu_list){
            let currentUrl = '';
            if(menu_list && menu_list.name){
                currentUrl = `/${replace(menu_list.name.toLowerCase(),new RegExp(' ','g'),'-')}`;
            }
            if(currentUrl){
                this.$router.push(currentUrl)
            }
        }, 
        updateActiveMenu(url){
            let currentUrl = this.menuPages.find((list)=>(list.url.includes(url) || list.url.includes(url.split('-create')[0])));
            if(currentUrl){
                this.$store.commit('UDPATE_ACTIVE_MENU', currentUrl)
            }
        },
        activateUrl(section_page){
            this.$router.push({
                name : 'New_Claim_Registration_Details',
                params: {page_name:section_page.url.replace('/', '')}
            }).catch((err)=>{
                console.log('activateUrl', err);
            });
            this.$store.commit('UDPATE_ACTIVE_MENU', section_page)
        },
        updateActiveUrl(routeParams){
            if(routeParams && routeParams.page_name){
                let getCurrentPage = this.section_pages.find(list=>list.url.replace('/','')==routeParams.page_name)
                if(getCurrentPage){
                    this.activateUrl(getCurrentPage)
                }
            }
        }
    }
}
</script>