<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <div class="row">
                        <div class="col-lg-6">
                            <h1 class="page-title">
                                New Claim Registration
                            </h1>
                        </div>
                        <div class="col-lg-6">
                            <ul class="breadcrumbs float-right">
                                <li><router-link to='/new-claim-registration'>List of Policies > ></router-link></li>
                                <li class="active">New Claim Registration</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="claim-details main-card">
            <div class="row">
                <div class="col-lg-3">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Policy Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="claim-details-aside">
                                <ul class="claim-detail-item" v-if="policyDetails && policyDetails.length">
                                    <li v-for="(policy_detail, index) in policyDetails" :key="index">
                                        <!-- {{policy_detail}} -->
                                        <div class="claim-details-icon">
                                            <img :src="updateImagePath(`/icons/${policy_detail.icon}`)" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                {{policy_detail.title}}
                                                <span> {{policy_detail.value}}</span>
                                            </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-9">
                    <div class="new-claim-reg-step">
                            <div class="add-policy-detail h-100">
                                <div class="policy-detail-bg">
                                    <PolicyListMenu v-if="productCode" :product_code="productCode"/>
                                    <router-view></router-view>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
    </div>
</template>

<script>
import GlobalMixin from '@/mixins/GlobalMixins.js'
import {ClaimsListHeader} from '@/datas/TableHeaders/ClaimsList'
import PolicyListMenu from '@/container/pages/NewClaimRegistration/PolicyListMenu'
export default {
    name: 'NewClaimRegistrationActiveStepOne',
    data(){
        return{
            policyDetails : [],
            productCode : '',
        }
    },
    mixins:[GlobalMixin],
    components:{
        PolicyListMenu
    },
    mounted(){
        this.upodatPolicyData();
        this.$store.state.tabel_filter_result = {}
    },
    methods:{
        upodatPolicyData(){
            let getgeaderDetails = ClaimsListHeader()
            if(getgeaderDetails){
                let getPolicyDetails = this.GetSessionStorage('sesssion_details');
                if(getPolicyDetails){
                    getPolicyDetails = JSON.parse(getPolicyDetails)
                }
                
                let temData = getgeaderDetails.filter((list)=>list.icon!='')
                temData.forEach((list)=>{
                    list.value = (getPolicyDetails && getPolicyDetails[list.name]) ? getPolicyDetails[list.name] : ''
                })
                this.productCode = getPolicyDetails.productCode;
                this.policyDetails = temData;

                let claimRefNo = this.GetSessionStorage('claimRefNo');
                if(!claimRefNo){
                    this.$store.commit('UPDATE_FROM_DATE', {
                        form_value : getPolicyDetails,
                        form_key : 'multi_section_form_data'
                    })
                }
            }
        }
    }
}
</script>
