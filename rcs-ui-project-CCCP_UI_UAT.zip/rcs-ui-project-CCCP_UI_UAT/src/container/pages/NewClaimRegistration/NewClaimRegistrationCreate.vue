<template>
    <div class="policy-input common-form" v-if="active_menu && active_menu.sectionCode">
        <Loader :display="loader" />
        <!-- {{insured_form_value}} -->
        <div class="whistle-blower-form" v-for="(page_fields, index) in pageFields" :key="index"
            :class="(page_fields.header.type == 'multiple') ? 'gray-background' : ''">
            <template v-if="page_fields && page_fields.header.type == 'single'">
                <h3 v-if="page_fields.header.displayName != 'NA'">{{ page_fields.header.displayName }}</h3>
                <!-- <h3>{{convertProductName}}</h3> -->
                <ValidationObserver v-slot="{}" :ref="'wbsingle' + index">
                    <PageFieldsFrom :form_base="page_fields.body" :show_error="show_error" :form_index="index"
                        base_id="wbsingle_main" form_name="multi_section_form_data" :display_success="null"
                        @onSelectChange="GetUpdatedSelectValues" @onInputChange="GetInputSelectValues"
                        @onDateChange="GetDateChange" @onPincode="onPincode" @onMultiInputbox="GetMultiInputbox"
                        @UpdateMultiFileUpload="UpdateMultiFileUpload" @onCheckBoxDisclaimer="onCheckBoxDisclaimer">
                    </PageFieldsFrom>
                </ValidationObserver>
            </template>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <div class="step-button mx-auto">
                    <button class="btn btn-primary mr-2" v-if="active_menu.url != section_pages[0].url"
                        @click="buttonAction('previous', false)">Previous</button>
                    <button class="btn btn-primary mr-2"
                        v-if="active_menu.url != section_pages[section_pages.length - 1].url"
                        @click="buttonAction('next', false)">Next</button>
                    <button class="btn btn-primary" v-if="active_menu.url == section_pages[section_pages.length - 1].url"
                        @click="buttonAction('save', true)">Save</button>
                </div>
            </div>
        </div>
        <success-popup v-if="isSuccessPopup" @onClosePopup='onClosePopup' :okButtonClass="'case-status-ok-btn'"
            :showOkButton='true' :isSuccessPopup='true' size='lg' :mainClass="'case-status-success'"
            :closeButtonClass="'close m-0 p-0 case-status-success-btn'" :iconClass="'flaticon-check text-center'"
            :message="'Case Allocated Successfully'" :claimRefNo="claimNumber"
            :CategoryName="convertProductName"></success-popup>
    </div>
</template>

<script>
import { findIndex } from 'lodash'
import { convert_toiso } from '@/shared/timer.js';
const PageFieldsFrom = () => import(`@/components/common/form/BasicForm`)
const SuccessPopup = () => import(`@/components/common/models/SuccessPopup`)
const Loader = () => import(`@/components/common/Loader`)
import { mapState } from 'vuex'
import GlobalMixin from '@/mixins/GlobalMixins.js'
import { GetPageFields, FetchPageData, GetPincodeCode } from '@/apis/ApiDatas'
export default {
    name: 'NewClaimRegistration',
    mixins: [GlobalMixin],
    data() {
        return {
            user_action: '',
            isFormFinalSubmit: false,
            claimRefNo: '',
            claimNumber: '',
            isSuccessPopup: false,
            tableExec: false,
            show_dialog: true,
            table_type: true,
            table_display: true,
            form_data: [],
            pagename: '',
            updated_value: [],
            pageFields: [],
            highlightFields: ['taskRefNumber'],
            priorityValue: [{ text: `Select Priority`, value: null }],
            table_data: {
                api_url: '',
                header: [],
                multi_sort: false,
                action: true,
                pagination: true,
                pagination_mode: "",
                perpage: 8,
                api_mode: "",
            },
            table_data_sent: {
                api_url: '',
                header: [],
                multi_sort: false,
                action: true,
                pagination: true,
                pagination_mode: "",
                perpage: 8,
                api_mode: "",
            },
            polcyCode: '',
            policyData: {},
        }
    },
    watch: {
        active_menu: {
            handler(new_value) {
                this.GetFormFields(new_value)
                this.GetClaimNumber()
            },
            deep: true,
        },
        claim_ref_number: function (new_value) {
            this.GetClaimNumber(new_value)
        },
    },
    components: {
        PageFieldsFrom,
        SuccessPopup,
        Loader
    },

    mounted() {
        this.GetFormFields()
        this.GetClaimNumber()
    },
    computed: {
        ...mapState({
            page_fields: state => state.multi_section_page_fields,
            from_data: state => state.multi_section_form_data,
            active_menu: state => state.active_menu,
            active_page: state => state.active_page,
            claim_ref_number: state => state.claim_ref_number,
            area_list: state => state.area_list,
            loader: state => state.loader,
            section_pages: state => state.section_pages,
            insured_form_value: state => state.insured_form_value
        }),
        convertProductName() {
            let productName = this.page_fields.datas[0].body[0].productCategory;
            if (productName) {
                return `${productName[0]}${productName.slice(1).toLowerCase()}`
            }
        }
    },
    methods: {
        async onPincode(value, field, field_index, from_index) {
            console.log('onPincode', value, field)
            let getrtempdata = GetPincodeCode();
            let forPolicy = JSON.parse(this.GetSessionStorage('sesssion_details'));
            getrtempdata.requests = {
                pincode: value,
                policyNumber: forPolicy.policyNumber
            }
            let _details = await this.$store.dispatch("GetRequest", getrtempdata);
            if (_details.body && _details.body.status && _details.body.status.toLowerCase() == 'success') {
                let getFields = this.pageFields[from_index].body
                if (getFields && getFields.length) {
                    let getArea = findIndex(getFields, (list) => list.model == 'area')
                    if (getArea >= 0) {
                        if (this.area_list?.length > 0) {
                            this.pageFields[from_index].body[getArea].options = this.area_list;
                        } else {
                            this.$toast.error("Please enter valid pincode.", {
                                content: "Please enter valid pincode."
                            });
                        }
                        this.pageFields[from_index].body[getArea].options = this.area_list;
                    }
                }
            }
        },

        async GetFormFields() {
            let forProductCode = this.GetSessionStorage('sesssion_details');
            if (forProductCode) {
                forProductCode = JSON.parse(forProductCode)
                this.polcyCode = forProductCode.productCode;
                this.policyData = forProductCode;
            }
            let tempDetails = GetPageFields();
            let createReq = {
                "userId": this.user_profile_details.userId,
                "roleCode": this.user_profile_details.role__code,
                "imdCode": this.user_profile_details.imdCode,
                "pageCode": 'CLAIMREG1',
                "sectionCode": this.active_menu.sectionCode,
                "productCode": this.polcyCode
            }
            tempDetails.requests = createReq
            let _details = await this.$store.dispatch("GetRequest", tempDetails);
            if (_details.body && _details.body.status && _details.body.status.toLowerCase() == 'success') {
                let tempFields = this.page_fields.datas;
                tempFields.forEach((list, index) => {
                    if (list.body && list.body.length) {
                        this.mapLookUpType(list.body, index, this.from_details)
                    }
                });
                this.pageFields = tempFields
                this.getPageData()
            }
        },
        updatePancard() {
            let finePincode = this.pageFields[0].body.find(list => list.model == 'pincode')
            if (finePincode) {
                if (this.from_data[finePincode.model]) {
                    this.onPincode(this.from_data[finePincode.model], '', '', 0);
                }
            }
        },
        updateDate() {
            let finePincode = findIndex(this.pageFields[0].body, list => list.model == 'lossDate')
            if (finePincode >= 0) {
                if (this.policyData.expiryDate) {
                    if (this.pageFields[0].body[finePincode].productCategory && (this.pageFields[0].body[finePincode].productCategory.toLowerCase() != 'marine')) {
                        this.pageFields[0].body[finePincode].max_date = convert_toiso(new Date(this.policyData.expiryDate));
                    }
                    else {
                        console.log(' this.pageFields[0].body[finePincode]', this.pageFields[0].body[finePincode])
                    }
                }
                if (this.policyData.inspectionDate) {
                    this.pageFields[0].body[finePincode].min_date = convert_toiso(new Date(this.policyData.inspectionDate));
                }
            }
        },
        upateInputRules() {
            let finePincode = findIndex(this.pageFields[0].body, list => list.model == 'lossEstmatedValue')
            if (finePincode < 0) {
                finePincode = findIndex(this.pageFields[0].body, list => list.model == 'lossAmount')
            }
            if (finePincode > 0 && (this.policyData.sumInsured > 0)) {
                this.pageFields[0].body[finePincode].rules += `|max_value:${this.policyData.sumInsured}`
            }
        },
        GetDateChange(fiedlobj, field, value) {
            const expiryDate = new Date(this.policyData.expiryDate);
            const inspectionDate = new Date(this.policyData.inspectionDate);
            const currentDate = new Date();

            if (field == 'lossDate') {

                if (fiedlobj.productCategory == "HOME" || fiedlobj.productCategory == "COMMERCIAL") {

                    let invoiceDate = findIndex(this.pageFields[0].body, list => list.model == 'invoiceDate')
                    if (invoiceDate > 0) {
                        let getTargetfields = this.pageFields[0].body[invoiceDate];
                        if (getTargetfields) {
                            let getDate = this.multi_section_form_data[getTargetfields.model];
                            if (getDate) {
                                this.multi_section_form_data[getTargetfields.model] = null
                            }
                            getTargetfields.max_date = convert_toiso(new Date(value));
                        }
                    }
                    if (value) {
                        const getDate2 = new Date();
                        getDate2.setDate(getDate2.getDate() - 45);
                        let month2 = getDate2.getMonth() + 1;
                        let date2 = getDate2.getDate();
                        (month2 < 10) ? month2 = '0' + month2 : month2;
                        (date2 < 10) ? date2 = '0' + date2 : date2;
                        let formatDate2 = `${getDate2.getFullYear()}-${month2}-${date2}`;

                        if (inspectionDate.getTime() < new Date(formatDate2).getTime()) {
                            fiedlobj.min_date = convert_toiso(formatDate2);
                        }
                        else {
                            fiedlobj.min_date = convert_toiso(inspectionDate);
                        }
                    }
                    else {
                        const getDate2 = new Date(new Date());
                        getDate2.setDate(getDate2.getDate() - 45);
                        let month2 = getDate2.getMonth() + 1;
                        let date2 = getDate2.getDate();
                        (month2 < 10) ? month2 = '0' + month2 : month2;
                        (date2 < 10) ? date2 = '0' + date2 : date2;
                        let formatDate2 = `${getDate2.getFullYear()}-${month2}-${date2}`;

                        if (inspectionDate.getTime() < new Date(formatDate2).getTime()) {
                            fiedlobj.min_date = convert_toiso(formatDate2);
                        }
                        else {
                            fiedlobj.min_date = convert_toiso(inspectionDate);
                        }

                    }

                    if (expiryDate.getTime() > currentDate.getTime()) {
                        fiedlobj.max_date = convert_toiso(currentDate);
                    }
                    else {
                        fiedlobj.max_date = convert_toiso(expiryDate);
                    }
                }

                if (fiedlobj.productCategory == "MARINE") {
                    let invoiceDate = findIndex(this.pageFields[0].body, list => list.model == 'invoiceDate');
                    let lorryReceiptDate = findIndex(this.pageFields[0].body, list => list.model == 'lorryReceiptDate')
                    if (invoiceDate > 0 || lorryReceiptDate > 0) {
                        let getTargetfields = this.pageFields[0].body[invoiceDate];
                        let getLorryFields = this.pageFields[0].body[lorryReceiptDate]
                        if (getTargetfields || getLorryFields) {
                            this.multi_section_form_data[getTargetfields.model];
                            this.multi_section_form_data[getLorryFields.model]
                            // if(getDate || getLorry){
                            //         this.multi_section_form_data[getTargetfields.model] = null
                            //         this.multi_section_form_data[getLorryFields.model] = null
                            // }
                            const minimizeDate = new Date(value);
                            // minimizeDate.setDate(minimizeDate.getDate()-1);
                            getTargetfields.max_date = convert_toiso(minimizeDate);
                            // getTargetfields.min_date = convert_toiso(inspectionDate);
                            getLorryFields.max_date = convert_toiso(minimizeDate);
                            getLorryFields.min_date = convert_toiso(inspectionDate);
                        }
                    }
                    if (value) {
                        const getDate = new Date();
                        getDate.setDate(getDate.getDate() - 45);
                        let month = getDate.getMonth() + 1;
                        let date = getDate.getDate();
                        (month < 10) ? month = '0' + month : month;
                        (date < 10) ? date = '0' + date : date;
                        let formatDate = `${getDate.getFullYear()}-${month}-${date}`;
                        fiedlobj.min_date = convert_toiso(formatDate);
                        fiedlobj.max_date = convert_toiso(new Date());
                    }
                    else {
                        const getDate = new Date(new Date());
                        getDate.setDate(getDate.getDate() - 45);
                        let month = getDate.getMonth() + 1;
                        let date = getDate.getDate();
                        (month < 10) ? month = '0' + month : month;
                        (date < 10) ? date = '0' + date : date;
                        let formatDate = `${getDate.getFullYear()}-${month}-${date}`;
                        fiedlobj.min_date = convert_toiso(formatDate);
                        fiedlobj.max_date = convert_toiso(new Date());
                    }
                }

            }
            if (field == 'lorryReceiptDate') {
                if (fiedlobj.productCategory == "HOME" || fiedlobj.productCategory == "COMMERCIAL") {
                    fiedlobj.min_date = convert_toiso(inspectionDate);
                    fiedlobj.max_date = convert_toiso(expiryDate);
                }
            }
        },

        GetDateForm() {
            let lossDate = this.pageFields[0].body.find((list) => list.model == 'lossDate')
            if (lossDate && lossDate.model) {
                let lossDateValue = this.$store.state.multi_section_form_data[lossDate.model];
                this.GetDateChange(lossDate, lossDate.model, (lossDateValue) ? lossDateValue : '');
            }
        },

        async getPageData() {
            let mockRequest = {
                "userId": this.user_profile_details.userId,
                "roleCode": this.user_profile_details.role__code,
                "imdCode": this.user_profile_details.imdCode,
                "pageCode": 'CLAIMREG1',
                "sectionCode": this.active_menu.sectionCode,
                "lob": "",
                "policyNumber": "",
                "claimStatus": "",
                "policyStartDate": "",
                "policyEndDate": "",
                "claimHandler": "",
                "claimRefNo": this.claimRefNo,
                "take_obj": "claimDetailsDto"
            }
            let tempDetails = FetchPageData('fetchClaimDetails');
            tempDetails.requests = mockRequest;
            let _details = await this.$store.dispatch("GetRequest", tempDetails);
            if (_details.body && _details.body.status && _details.body.status.toLowerCase() == 'success') {
                this.updatePancard();
                this.updateDate();
                this.upateInputRules();
                this.GetDateForm();
            }
        },
        buttonAction(action, finalSubmit) {
            this.user_action = action
            this.isFormFinalSubmit = finalSubmit;
            if (this.from_data && this.from_data.disclaimerCommerical == true) {
                this.submitForm(finalSubmit)
            }
            else if (action == 'next') {
                this.submitForm(finalSubmit)
            }
            else if (action == 'previous') {
                this.navigatePannel(action)
            }
            else if (action == 'reset') {
                this.$store.state.tabel_filter_result = {}
            }
            else {
                this.$store.commit('RESPONSE_SUCCESS', { title: "Disclaimer", message: 'Disclaimer is required', varient: "danger " })
            }
        },
        GetClaimNumber(claimRefNo = null) {
            if (claimRefNo != null) {
                this.claimRefNo = claimRefNo
            }
            else {
                let getclaimRefNo = this.GetSessionStorage('claimRefNo')
                if (getclaimRefNo) {
                    this.claimRefNo = getclaimRefNo
                }
            }
        },
        onCheckBoxDisclaimer(fiedlobj, field, value) {
            if (field == 'sameCommerical') {
                if (value) {
                    this.$store.state.multi_section_form_data['name'] = this.insured_form_value.insuredName
                    this.$store.state.multi_section_form_data['mobileNumber'] = this.insured_form_value.mobileNo
                    this.$store.state.multi_section_form_data['email'] = this.insured_form_value.insuredEmailId
                    this.$store.state.multi_section_form_data = { ...this.$store.state.multi_section_form_data }
                }
                else {
                    this.$store.state.multi_section_form_data = {}
                }
            }
        }
    }
}
</script>