<template>
  <div>
    <Loader :display="loader" />
    <div
      v-for="(page_fields, index) in pageFields"
      :key="index"
      :class="page_fields.header.type == 'multiple' ? 'gray-background' : ''"
    >
      <template v-if="page_fields && page_fields.header.type == 'single'">
        <div class="card-header">
          <h3 v-if="page_fields.header.displayName != 'NA'">
            {{ page_fields.header.displayName }}
          </h3>
        </div>
        <div class="card-body">
          <ValidationObserver v-slot="{}" :ref="'wbsingle' + index">
            <PageFieldsFrom
              :form_base="page_fields.body"
              :show_error="show_error"
              :form_index="index"
              base_id="wbsingle_main"
              form_name="claim_form_data"
              :display_success="null"
              @onSelectChange="GetUpdatedSelectValues"
              @onInputChange="GetInputSelectValues"
              @onMultiInputbox="GetMultiInputbox"
              @UpdateMultiFileUpload="UpdateMultiFileUpload"
            >
            </PageFieldsFrom>
          </ValidationObserver>
        </div>
      </template>
    </div>
    <div class="row">
      <div class="col-12 text-center py-4">
        <div class="step-button mx-auto">
          <button
            class="btn btn-primary mr-2"
            @click="buttonAction('previous', false)"
          >
            Reset
          </button>
          <button class="btn btn-primary" @click="buttonAction('save', true)">
            Save
          </button>
        </div>
      </div>
    </div>
    <success-popup
      v-if="isSuccessPopup"
      @onClosePopup="onClosePopup"
      :okButtonClass="'case-status-ok-btn'"
      :showOkButton="true"
      :isSuccessPopup="true"
      :success_content="true"
      :success_message="success_message"
      size="lg"
      :mainClass="'case-status-success'"
      :closeButtonClass="'close m-0 p-0 case-status-success-btn'"
      :iconClass="'flaticon-check text-center'"
      :message="'Case Allocated Successfully'"
      :claimRefNo="claimNumber"
    ></success-popup>
    <success-popup
      v-if="isShowSuccessPopup"
      @onClosePopup="onClosePopup"
      :okButtonClass="'case-status-ok-btn'"
      :showOkButton="true"
      :isSuccessPopup="true"
      :error_content="status_content"
      :error_message="message_content"
      size="lg"
      :mainClass="'case-status-success'"
      :closeButtonClass="'close m-0 p-0 case-status-success-btn'"
      :iconClass="'flaticon-check text-center'"
      :message="'Case Allocated Successfully'"
      :claimRefNo="claimRefNo"
    ></success-popup>
  </div>
</template>

<script>
const PageFieldsFrom = () => import(`@/components/common/form/BasicForm`);
const SuccessPopup = () => import(`@/components/common/models/SuccessPopup`);
const Loader = () => import(`@/components/common/Loader`);
import { mapState } from "vuex";
import GlobalMixin from "@/mixins/GlobalMixins.js";
import { GetPageFields, FetchPageData } from "@/apis/ApiDatas";
export default {
  name: "NewClaimRegistration",
  mixins: [GlobalMixin],
  data() {
    return {
      status_content: false,
      message_content: "",
      isShowSuccessPopup: false,
      docSesion: {},
      user_action: "",
      isFormFinalSubmit: false,
      claimNumber: "",
      policyNumber: "",
      isSuccessPopup: false,
      success_message: "",
      tableExec: false,
      show_dialog: true,
      table_type: true,
      table_display: true,
      form_data: [],
      pagename: "",
      updated_value: [],
      pageFields: [],
      highlightFields: ["taskRefNumber"],
      priorityValue: [{ text: `Select Priority`, value: null }],
      table_data: {
        api_url: "",
        header: [],
        multi_sort: false,
        action: true,
        pagination: true,
        pagination_mode: "",
        perpage: 8,
        api_mode: "",
      },
      table_data_sent: {
        api_url: "",
        header: [],
        multi_sort: false,
        action: true,
        pagination: true,
        pagination_mode: "",
        perpage: 8,
        api_mode: "",
      },
    };
  },

  components: {
    PageFieldsFrom,
    SuccessPopup,
    Loader,
  },
  mounted() {
    this.GetClaimDetails();
    this.GetFormFields();
  },
  computed: {
    ...mapState({
      page_fields: (state) => state.multi_section_page_fields,
      from_data: (state) => state.multi_section_form_data,
      all_page_feilds: (state) => state.all_page_feilds,
      active_page: (state) => state.active_page,
      claim_ref_number: (state) => state.claim_ref_number,
      loader: (state) => state.loader,
      runTimeFields: (state) => state.insured_form_value,
    }),
  },
  methods: {
    onClosePopup() {
      this.isSuccessPopup = false;
      this.$router.push({
        name: "updateclaimdetails",
      });
    },
    async GetFormFields() {
      let tempDetails = GetPageFields();
      let createReq = {
        userId: this.user_profile_details.userId,
        roleCode: this.user_profile_details.role__code,
        imdCode: this.user_profile_details.imdCode,
        policyNumber: this.policyNumber,
        pageCode: "UPDCLAIM",
        sectionCode: "UPDCLAIM",
      };
      tempDetails.requests = createReq;
      console.log("tempDetails", tempDetails);
      let _details = await this.$store.dispatch("GetRequest", tempDetails);
      if (
        _details.body &&
        _details.body.status &&
        _details.body.status.toLowerCase() == "success"
      ) {
        let tempFields = this.page_fields.datas;
        tempFields.forEach((list, index) => {
          if (list.body && list.body.length) {
            this.mapLookUpType(list.body, index, {});
          }
        });
        this.pageFields = tempFields;
        this.getPageData();
      }
    },
    async getPageData() {
      let mockRequest = {
        userId: this.user_profile_details.userId,
        roleCode: this.user_profile_details.role__code,
        imdCode: this.user_profile_details.imdCode,
        imdCode: this.user_profile_details.imdCode,
        claimNumber: this.claimNumber,
        pageCode: "UPDCLAIM",
        sectionCode: "UPDCLAIM",
        lob: "",
        policyNumber: this.policyNumber,
        claimStatus: "",
        policyStartDate: "",
        policyEndDate: "",
        claimHandler: "",
        take_obj: "claimDetailsDto",
      };
      let tempDetails = FetchPageData("fetchClaimDetails");
      tempDetails.requests = mockRequest;
      let _details = await this.$store.dispatch("GetRequest", tempDetails);
      if (
        _details.body &&
        _details.body.status &&
        _details.body.status.toLowerCase() == "success"
      ) {
        if (this.pageFields && this.pageFields.length) {
          if (Object.keys(this.$store.state.multi_section_form_data)) {
            for (let key in this.$store.state.multi_section_form_data) {
              this.pageFields[0].body.find((element, index) => {
                if (element.model.includes(key)) {
                  this.$store.state.claim_form_data[key] =
                    this.$store.state.multi_section_form_data[key];
                  this.$store.state.claim_form_data = {
                    ...this.$store.state.claim_form_data,
                  };
                } else if (!key.startsWith("runtime")) {
                  //  else if(!this.$store.state.claim_form_data[key].startsWith("runtime")){
                  this.$store.state.claim_form_data = {};
                }
              });
            }
          }
        }
      }
    },
    buttonAction(action, finalSubmit) {
      this.user_action = action;
      this.isFormFinalSubmit = finalSubmit;
      if (action == "save" || action == "next") {
        if (
          (this.docSesion &&
            this.docSesion.status &&
            this.docSesion.status.toLowerCase().replace(/ /g, "") ==
              "claimclosed") ||
          this.docSesion.status.toLowerCase().replace(/ /g, "") ==
            "claimrepudiated-asperinsurancepolicy-t&c" ||
          this.docSesion.status.toLowerCase().replace(/ /g, "") ==
            "claimsettledwithlosspayment" ||
          this.docSesion.status.toLowerCase().replace(/ /g, "") ==
            "claimclosed-claimwithdrawnbyinsured/withinexcess"
        ) {
          this.isShowSuccessPopup = true;
          this.status_content = true;
          this.message_content = "This claim has been closed";
        } else {
          this.submitForm(finalSubmit);
        }
      } else if (action == "previous") {
        let getTempData = this.$store.state.multi_section_form_data;
        let checkRow = this.all_page_feilds.filter(
          (list) => list.disbabled != true
        );
        if (checkRow && checkRow.length) {
          checkRow.forEach((list) => {
            getTempData[list.model] = "";
          });
        }

        this.$store.state.multi_section_form_data = { ...getTempData };
        this.$store.state.claim_form_data = {};
      } else if (action == "reset") {
        this.$store.state.tabel_filter_result = {};
      }
    },
    GetClaimDetails() {
      let getclaimDetails = this.GetSessionStorage("sesssion_details");
      console.log("getclaimDetails", getclaimDetails);
      if (getclaimDetails) {
        getclaimDetails = JSON.parse(getclaimDetails);
        if (getclaimDetails) {
          this.claimNumber = getclaimDetails.claimNumber;
          this.policyNumber = getclaimDetails.policyNumber;
          this.docSesion = getclaimDetails;
        }
      }
    },
  },
};
</script>
<style>
.card-body .form-group .form-control {
  color: #131541 !important;
  font-weight: 500 !important;
}
.card-body .form-group .form-control::placeholder {
  font-weight: normal !important;
}
</style>
