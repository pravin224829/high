<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <div class="row">
                        <div class="col-lg-6">
                            <h1 class="page-title">
                                New Claim Registration
                            </h1>
                        </div>
                        <div class="col-lg-6">
                            <ul class="breadcrumbs float-right">
                                <li><router-link to="/update-claim-details">List of Policies > ></router-link></li>
                                <li class="active">New Claim Registration</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="claim-details main-card">
            <div class="row">
                <div class="col-lg-3">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Policy Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="claim-details-aside">
                                <ul class="claim-detail-item" v-if="policyDetails && policyDetails.length">
                                    <li v-for="(policy_detail, index) in policyDetails" :key="index">
                                        <div class="claim-details-icon">
                                            <img :src="updateImagePath(`/${policy_detail.icon}`)" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                {{policy_detail.title}}
                                                <span> {{policy_detail.value}}</span>
                                            </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-9">
                    <div class="new-claim-reg-step">
                            <div class="card">
                                <router-view></router-view>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
    </div>
</template>

<script>
import {mapState} from 'vuex'
import GlobalMixin from '@/mixins/GlobalMixins.js'
import {CliamDocumentUpload} from '@/datas/TableHeaders/ClaimsList'
export default {
    name: 'NewClaimRegistrationActiveStepOne',
    data(){
        return{
            policyDetails : []
        }
    },
    mixins:[GlobalMixin],
    mounted(){
        this.upodatPolicyData();
        this.$store.state.tabel_filter_result = {}
    },
    computed:{
        ...mapState({
            from_data : state => state.multi_section_form_data_init,
        }),
    },
    watch:{
        from_data:{
            handler(new_value) { 
                    this.upodatPolicyData(new_value)
            },
            deep: true,
        },
    },
    methods:{
        upodatPolicyData(updateDetails){
            console.log('updateDetails', updateDetails)
            let getgeaderDetails = CliamDocumentUpload('', 'page', 'claim-document-upload-list')
             let temData = getgeaderDetails
            if(getgeaderDetails && updateDetails){
                temData.forEach((list)=>{
                    list.value = (updateDetails && updateDetails[list.name]) ? updateDetails[list.name] : ''
                })
                this.policyDetails = temData;
            }
        },
    }
}
</script>
