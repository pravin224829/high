<template>
    <section class="forgot-password">
         <div class="container-fluid">
            <div class="row">
               <div class="col-lg-12">
                  <img src="@/assets/images/dashboard-white-logo.png" class="img-fluid forgot-password-logo" alt="logo" style="padding:0px;">
                  <div class="card border-0">
                    <template v-if="!linkSent">
                        <!-- <a href="/#/"><i class="fa fa-window-close close-icon"></i></a> -->
                        <h3>Reset password</h3>
                        <form action="" class="text-align:left">
                            <div class="form-group">
                                <input type="text" class="form-control" v-model="UserId" placeholder="User ID" disabled="disabled">
                                <div class="text-danger" v-if="UserError">Enter User ID</div>
                            </div>
                            <div class="form-group">
                                <b-form-input type="text" :class="outlineClass" id="password" @input="PasswordStrength()" v-model="password" placeholder="Password" />
                                <div class="text-danger" v-if="PasswordError">Enter Password</div>
                                 <span v-if="showText" id="passwordmessage" :class="addClass">{{textContent}}</span>

                                <!-- <div class="text-danger" v-if="matching_password">Password And Confirm Password Must be Same</div> -->
                            </div>
                            <div class="form-group">
                                <b-form-input type="text" class="form-control" :class="outlineConfirmClass" v-model="confirm_password" @input="PasswordStrength()" placeholder="Confirm Password" />
                                <div class="text-danger" v-if="ConfirmPasswordError">Enter Confirm Password</div>
                                <div class="text-danger" v-if="matching_password">Password And Confirm Password Must be Same</div>
                                <span v-if="showConfirmText" :class="addConfirmClass">{{ConfirmtextContent}}</span>
                            </div>
                            <button type="button" class="send-button" @click="UpdatePassword" :disabled="buttonDisable">{{buttonLink}}</button>
                        </form>
                    </template>
                    <template v-else>
                        <!-- <a href="/#/"><i class="fa fa-window-close close-icon"></i></a> -->
                        <h3>Forgot password</h3>
                        <img src="@/assets/images/email.svg" class="img-fluid img-mail" alt="email">
                        <h4>Check your mail</h4>
                        <a class="resend-link" @click="linkSent=false">Resend Link</a>
                    </template>
                  </div>
                  <div class="dashboard-footer text-white footer-fixed fixed-bottom">
                     <div class="footer-inn">
                        <p>Copyright 2020 FA SOFTWARE All Rights Reserved</p>
                        <p> <a href=""> Terms and Conditions</a></p>
                        <span> <a href=""> Privacy Policy</a></span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
          <success-popup
            v-if="isSuccessPopup" 
            @onClosePopup='onClosePopup' 
            :okButtonClass="'case-status-ok-btn'" 
            :showOkButton='true' 
            :isSuccessPopup='true' 
            :success_content='success_content'
            :success_message='success_message'
            size='lg'
        
        ></success-popup>
    </section>
</template>
<script>
import axios from 'axios';
import {EncodeString} from '@/shared/custom'
const SuccessPopup = () => import(`@/components/common/models/SuccessPopup`)
export default {  
    name:"Forget Password",
    data(){
        return{
            UserId : '',
            password : '',
            confirm_password : '',
            matching_password:false,
            UserError:false,
            buttonLink: 'Reset Password',
            buttonDisable:false,
            linkSent : false,
            PasswordError : false,
            ConfirmPasswordError : false,
            infoDetails:{},
            isSuccessPopup:false,
            success_message:'',
            success_content:true,
            showText:false,
            textContent:'',
            ConfirmtextContent:'',
            outlineClass:'normal',
            addClass:"text-danger",
            addConfirmClass:"text-danger",
            capitalLetter:'',
            smallLetter: '',
            specialCharacter: '',
            oneNumber: '',
            eightLetter: '',
            commonmsg:'',
            confirmCapitalLetter:'',
            confirmSmallLetter:'',
            confirmSpecialCharacter:'',
            confirmOneNumber:'',
            confirmCommonmsg:'',
            confirmeightLetter:''
         }
    },
    components:{
        SuccessPopup
    },
    watch:{
        infoDetails: function(new_value){
            console.log('new_value', new_value)
            this.UpdateStatus(new_value)
        }
    },
    mounted(){
        this.UserId = this.$route.params.userid
     },
    methods:{
      async UpdatePassword(){
            if(this.UserId && this.password && this.confirm_password){
                if(this.password  == this.confirm_password){
                    this.PasswordError = false;
                    this.ConfirmPasswordError = false;
                    this.matching_password = false;
                    this.UserError = false;
                    this.buttonDisable = true;
                    this.buttonLink = 'Password Resetting ...';
                    let tempValue = {"userId":this.UserId,"newPassword":this.password}
                    // let tempPayload = EncodeString(tempValue)
                  await axios.post(`${process.env.VUE_APP_API_URL}/cccp/config/user/api/savePassword`, tempValue)
                        .then(response => (
                        this.infoDetails = response
                    ))
                }
                else{
                    this.matching_password = true;
                    this.ConfirmtextContent = '';
                    this.outlineConfirmClass = "weak";
                    this.PasswordError = false;
                    this.ConfirmPasswordError = false;
                }
                   
            }
            else if(this.password){
                this.ConfirmPasswordError = true;
                this.matching_password = false;
                this.PasswordError = false;
            }
            else if(this.confirm_password){
                this.matching_password = false;
                this.PasswordError = true;
                this.ConfirmPasswordError = false;
            }
            else{
                this.matching_password = false;
                this.ConfirmPasswordError = true
                this.PasswordError = true
            }
        },
        ResetPassword(){
            if(this.UserId && this.password && this.confirm_password){
                this.PasswordError = false;
                this.ConfirmPasswordError = false;
                this.UserError = false;
                this.buttonDisable = true;
                this.buttonLink = 'Sending Link ...';
                let tempPayload = EncodeString({"userId" : this.UserId})
                axios.get(`${process.env.VUE_APP_API_URL}/config/cccp/config/user/api/forgotPassword?payload=${tempPayload}`)
                    .then(response => (
                        this.infoDetails = response
                ))
            }
            else if(this.password){
                this.PasswordError = true
            }
            else if(this.confirm_password){
                this.ConfirmPasswordError = true
            }
            else{
                this.UserError = true
            }
        },
        UpdateStatus(response){
            console.log("res", response)
            if(response.status == 200 && response.data.status == 'SUCCESS'){
                this.isSuccessPopup = true;
                this.success_content = true;
                this.success_message = response.data.message;
            }
        },
        onClosePopup(){    
            window.location.href = process.env.VUE_APP_DIRECT_URL
        },
        PasswordStrength(){
             let alphabet = /[a-z]/; 
             let capitalalpha = /[A-Z]/ 
             let numbers = /[0-9]/; 
             let scharacters = /[!,@,#,$,%,^,&,*,?,_,(,),-,+,=,~]/;
            if(this.password){
                this.showText = true;
                this.PasswordError = false;
                 if(this.password.match(alphabet) || this.password.match(capitalalpha) || this.password.match(numbers) || this.password.match(scharacters)){
        
                    this.capitalLetter = !this.password.match(capitalalpha) ? " One Capital letter &" : '';
                    this.smallLetter = !this.password.match(alphabet) ? " One Small letter &" : '';
                    this.specialCharacter = !this.password.match(scharacters) ? " One Special Character &" : '';
                    this.oneNumber = !this.password.match(numbers) ? " One Number &" : '';
                    this.commonmsg = (this.password.match(capitalalpha) && this.password.match(alphabet) &&this.password.match(scharacters) && this.password.match(numbers)) ? '' : 'Must Contain Atleast'

                    this.textContent = `Password is Weak ${this.commonmsg}${this.capitalLetter}${this.smallLetter}${this.specialCharacter}${this.oneNumber}`;
                    this.textContent = this.textContent.slice(0, -1);
                    this.addClass = 'text-danger'
                    this.outlineClass = "weak"
                 }
                 if(this.password.match(alphabet) && this.password.match(numbers) && this.password.length >= 6 ){
                    
                     this.capitalLetter = !this.password.match(capitalalpha) ? this.capitalLetter = "One Capital letter &" : '';
                     this.smallLetter = !this.password.match(alphabet) ? " One Small letter &" : '';
                     this.specialCharacter = !this.password.match(scharacters) ? this.specialCharacter = "One Special Character &" : '';
                     this.oneNumber = !this.password.match(numbers) ? " One Number &" : '';
                     this.eightLetter = this.password.length <= 8 ? ' Must Contain 8 letters above &' :  ''
                     this.commonmsg = (this.password.match(capitalalpha) && this.password.match(alphabet) &&this.password.match(scharacters) && this.password.match(numbers)) ? '' : 'Must Contain Atleast'
                     this.textContent = `Password is Medium ${this.commonmsg}${this.specialCharacter}${this.capitalLetter}${this.smallLetter}${this.oneNumber}${this.eightLetter}`;

                     this.textContent = this.textContent.slice(0, -1);
                     this.outlineClass = "medium"
                     this.addClass = 'text-warning'
                 }
                if(this.password.match(alphabet) && this.password.match(capitalalpha) && this.password.match(numbers) && this.password.match(scharacters) && this.password.length >= 8){
                     this.textContent = "Password is Strong";
                     this.outlineClass = "strong"
                     this.addClass = 'text-success'
                }
            }
            if(this.confirm_password){
                this.showConfirmText = true;
                this.matching_password = false;
                this.ConfirmPasswordError = false;
                 if(this.confirm_password.match(alphabet) ||this.confirm_password.match(capitalalpha) || this.confirm_password.match(numbers) || this.confirm_password.match(scharacters)){
                    this.confirmCapitalLetter = !this.confirm_password.match(capitalalpha) ? " One Capital letter &" : '';
                    this.confirmSmallLetter = !this.confirm_password.match(alphabet) ? " One Small letter &" : '';
                    this.confirmSpecialCharacter = !this.confirm_password.match(scharacters) ? " One Special Character &" : '';
                    this.confirmOneNumber = !this.confirm_password.match(numbers) ? " One Number &" : '';
                    this.confirmCommonmsg = (this.confirm_password.match(capitalalpha) && this.confirm_password.match(alphabet) &&this.confirm_password.match(scharacters) && this.confirm_password.match(numbers)) ? '' : 'Must Contain Atleast'

                    this.ConfirmtextContent = `ConfirmPassword is weak ${this.confirmCommonmsg}${this.confirmCapitalLetter}${this.confirmSmallLetter}${this.confirmSpecialCharacter}${this.confirmOneNumber}`;
                    this.ConfirmtextContent = this.ConfirmtextContent.slice(0, -1);
                    this.addConfirmClass = 'text-danger'
                    this.outlineConfirmClass = "weak"
                 }
                 if(this.confirm_password.match(alphabet) && this.confirm_password.match(numbers) && this.confirm_password.length >= 6){
                     this.confirmCapitalLetter = !this.confirm_password.match(capitalalpha) ? this.capitalLetter = "One Capital letter &" : '';
                     this.confirmSmallLetter = !this.confirm_password.match(alphabet) ? " One Small letter &" : '';
                     this.confirmSpecialCharacter = !this.confirm_password.match(scharacters) ? this.specialCharacter = "One Special Character &" : '';
                     this.confirmOneNumber = !this.confirm_password.match(numbers) ? " One Number &" : '';
                     this.confirmeightLetter = this.confirm_password.length <= 8 ? ' Must Contain 8 letters above &' :  ''
                     this.confirmCommonmsg = (this.confirm_password.match(capitalalpha) && this.confirm_password.match(alphabet) &&this.confirm_password.match(scharacters) && this.confirm_password.match(numbers)) ? '' : 'Must Contain Atleast'
                     
                     this.ConfirmtextContent = `ConfirmPassword is medium ${this.confirmCommonmsg}${this.confirmCapitalLetter}${this.confirmSmallLetter}${this.confirmSpecialCharacter}${this.confirmOneNumber}${this.confirmeightLetter}`;
                     this.ConfirmtextContent = this.ConfirmtextContent.slice(0, -1);
                    //  this.ConfirmtextContent = "Password is medium Must Contain 8 letters above";
                     this.outlineConfirmClass = "medium"
                     this.addConfirmClass = 'text-warning'
                 }
                if(this.confirm_password.match(alphabet) && this.confirm_password.match(numbers) && this.confirm_password.match(scharacters) && this.confirm_password.length >= 8){
                     this.ConfirmtextContent = "Password is strong";
                     this.outlineConfirmClass = "strong"
                     this.addConfirmClass = 'text-success'
                }
            }
            if(this.password == ''){
                this.textContent = "";
                this.outlineClass = "normal";
            } 
            if(this.confirm_password == ''){
                this.ConfirmtextContent = "";
                this.outlineConfirmClass = "normal"
            }
        }
    }
}
</script>

<style scoped>
.weak:focus{
    box-shadow: 0 0 1pt 2pt #dc3545 ;
}
.medium:focus{
    box-shadow:  0 0 1pt 2pt #ffc107;
 }
.strong:focus{
    box-shadow:  0 0 1pt 2pt #28a745 ;
 }
.normal:focus{
    box-shadow:  0 0 1pt 2pt #c3deff ;
}


</style>
