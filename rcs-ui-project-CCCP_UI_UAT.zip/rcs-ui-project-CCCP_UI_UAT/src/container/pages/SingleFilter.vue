<template>
    <div>
        
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <h1 class="page-title">
                        {{pagename}}
                    </h1>
                </div>
            </div>
        </section>
        <section class="form-filter main-card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                       
                        <div class="card-header">
                          <h3>Filter</h3>
                        </div>
                            <div class="card-body">
                                <div class="form-filter-items">
                                    <ValidationObserver v-slot="{}" ref="filterFrom">
                                        <filter-form 
                                            filter_class="form-row"
                                            :display_submit="true" 
                                            :show_error="show_error"  
                                            :form_base="form_data"  
                                            form_name = "tabel_filter_result" 
                                            @onSelectChange="onSelectChange"
                                            @onFilterSelect="getSelectValues"
                                            @onSearchFilter='onSearchFilter' 
                                            @onClearFilter='onClearFilter'
                                            @onDateChange="onDateChange"
                                            :date-format="onDateFormat" 
                                            :singleDatePicker='singleDatePicker'>                           
                                        </filter-form>
                                    </ValidationObserver>
                                </div>
                                <div class="row mt-4">
                                    <div class="col-lg-6 mx-auto text-center">
                                        <div class="filter-buttons" v-if="($route.name == 'bajaj-allianz-insurance-policy-verification' && profile.role__code == 'NHAI')">      
                                            <div class="button-item">
                                                <button class="btn btn-primary" type="submit" @click="buttonAction('submit')">Search</button>
                                            </div>
                                            <div class="button-item">
                                                <button class="btn btn-primary" type="submit" @click="buttonAction('reset')">Reset</button>
                                            </div>         
                                        </div>
                                         <div class="filter-buttons" v-else>      
                                            <div class="button-item">
                                                <button class="btn btn-primary" type="submit" @click="buttonAction('reset')">Reset</button>
                                            </div>
                                            <div class="button-item">
                                                <button class="btn btn-primary" type="submit" @click="buttonAction('submit')">Search</button>
                                            </div>         
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                      </div>
                </div>

                <div class="row" v-if="displayTable">
                    <div class="col-lg-12">
                        <div class="table-result">
                            <TableDisplay
                                :table_date="table_data" 
                                :highlight_fields="highlightFields"
                                :priority_value="priorityValue"
                                @GetDetails="GetChangeFunction"
                            ></TableDisplay>
                        </div>
                    </div>
                </div>
        </section>
        <success-popup
            v-if="isSuccessPopup" 
            @onClosePopup='onClosePopup' 
            :okButtonClass="'case-status-ok-btn'" 
            :showOkButton='true' 
            :isSuccessPopup='true' 
            :error_content='status_content'
            :error_message='message_content'
            size='lg'
            :mainClass="'case-status-success'" 
            :closeButtonClass="'close m-0 p-0 case-status-success-btn'" 
            :iconClass="'flaticon-check text-center'" 
            :message="'Case Allocated Successfully'"
            :claimRefNo="claimRefNo"
        >
        </success-popup>

         <success-popup
            v-if="isDocSuccessPopup" 
            @onClosePopup='onCloseModalPopup' 
            :okButtonClass="'case-status-ok-btn'" 
            :showOkButton='true' 
            :show_doclist = true
            :isSuccessPopup='true' 
            size='lg'
            :mainClass="'case-status-success'" 
            :closeButtonClass="'close m-0 p-0 case-status-success-btn'" 
            :iconClass="'flaticon-check text-center'" 
            :message="'Case Allocated Successfully'"
            :claimRefNo="claimRefNo"
        >
            <template #tablecontent v-if="displaydocTableContent">
                  <div class="row form-filter">
                        <div class="col-lg-12">
                            <div class="table-result table-responsive h-100" style="padding:0 !important">
                                <TableDisplay
                                    :table_date="table_data" 
                                    :highlight_fields="highlightFields"
                                    :priority_value="priorityValue"
                                    @GetDetails="GetChangePopupFunction"
                                ></TableDisplay>
                            </div>
                        </div>
                    </div>
            </template>
        </success-popup>
    </div>
    
</template>

<script>
const FilterForm = () => import(`@/components/common/form/BasicForm`)
const TableDisplay = () => import(`@/components/table/Table`)
const SuccessPopup = () => import(`@/components/common/models/SuccessPopup`)
import {ClaimsListHeader, CliamDocumentUpload,ClaimDocumentList, CliamReport, ClaimsListPolicyVerificationHeader} from '@/datas/TableHeaders/ClaimsList'
import {mapState} from 'vuex'
import GlobalMixin from '@/mixins/GlobalMixins.js'
import {GetPageFields, DocumentTableUrl,TableUrl} from '@/apis/ApiDatas'
import { parse } from 'uuid'
export default {
    name:'SingleFilter',
        mixins:[GlobalMixin],
        data(){
            return {
                displaydocTableContent:false,
                isDocSuccessPopup:false,
                isSuccessPopup : false,
                displayTable : false,
                tableExec : false,
                show_dialog : true,
                table_type: true,
                table_display : true,
                status_content: true,
                message_content : '',
                form_data : [],
                pagename: '',
                updated_value : [],
                highlightFields : ['taskRefNumber'],
                priorityValue:[{text: `Select Priority`,value: null}],
                table_data : {
                    api_url : '' ,
                    header : ClaimsListHeader() ,
                    multi_sort : false,
                    action:true,
                    pagination:true,
                    pagination_mode: "",
                    perpage : 8,
                    api_mode : "",
                },
            }
        },
        components:{
            FilterForm,
            TableDisplay,
            SuccessPopup
        },
        mounted(){
            console.log('jk mounted 2')
            this.emptyFilter();
            this.$store.state.active_menu = {}
            this.RemoveAllSession();
            // this.GetFormFields()
           
        },
        computed:{
            ...mapState({
                page_fields : state => state.multi_section_page_fields,
                profile : state => state.profile
            }),
        },
        watch:{
            "$store.state.tabel_filter_result.name":function(new_value, old_value){
                if(new_value){
                    this.hidePolicyNumber(new_value)
                }
            },
            "$store.state.active_page":function(){
                this.emptyFilter();
                this.GetFormFields()
                this.$store.state.tabel_filter_result = {}
                this.displayTable = false
            }, immediate:true
           
        },
        methods:{
            hidePolicyNumber(new_value){
                if(this.$route.name == 'reports'){
                    this.form_data.forEach((fields) => {
                        if(new_value.replace(/ /g, '') == 'AdditionalDataFieldsReport'){
                            if(fields.model == 'policyNumber'){
                                fields.check_display = 'true';
                            }
                        }else{
                             if(fields.model == 'policyNumber'){
                                fields.check_display = 'false';
                            }
                        }
                    })
                }
            },
            onSelectChange(fiedlobj,field,value){
                if(field=='lineOfBusiness' && fiedlobj){
                  
                    let fromDate = this.form_data.find(el => el.model === 'policyStartDate');
                    if(fromDate){
                        fromDate.rules = (value) ? 'required' : ''
                    }
                
                    let toDater = this.form_data.find(el => el.model === 'policyEndDate');
                    if(toDater){
                        toDater.rules = (value) ? 'required' : ''
                    }
                }
            },
           onDateChange(fiedlobj,field,value) {
                if (!value) return;
                if (fiedlobj.custom_validation.maxDate) {
                    const obj = this.form_data.find(el => el.model === fiedlobj.custom_validation.maxDate);
                    obj.min_date = value;
                    if(this.$route.name == 'reports'){
                        const getDate = new Date(new Date(value));
                        getDate.setDate(getDate.getDate()+190);
                        let month = getDate.getMonth()+1;
                        let date = getDate.getDate();
                        (month < 10) ? month = '0'+month : month;
                        (date < 10) ? date = '0'+date : date;    
                        let formatDate =`${getDate.getFullYear()}-${month}-${date}`;
                        obj.max_date = formatDate;
                    }  
				    obj.rules = (value) ? 'required' : ''
                   
                } else if (fiedlobj.custom_validation.minDate) {
                    const obj = this.form_data.find(el => el.model === fiedlobj.custom_validation.minDate);
                    obj.max_date = value;
 				    obj.rules = (value) ? 'required' : ''

                }
            },
            resetMenditory() {
                this.form_data.forEach((list,index)=>{
                    this.form_data[index].rules = list.initRules
                })
            },

            async GetFormFields(){
                let tempDetails = GetPageFields();
                let tempReqCr = this.commonPageRequest();
                console.log('tempReqCr', tempReqCr, this.active_page, this.active_page.url,this.$route.path)
                let createReq = {
                    "userId":"admin",
                    "roleCode":"ADMIN",
                    "imdCode":this.user_profile_details.imdCode,
                    "pageCode":"CLAIMREG",
                    "sectionCode":"CLAIMREG",
                    ...tempReqCr
                }
                console.log('jk check page', createReq.pageCode, this.active_page.url, this.$route.path)
                if(createReq.pageCode || (this.active_page.url==this.$route.path)){
                    tempDetails.requests = createReq
                    let _details = await this.$store.dispatch("GetRequest", tempDetails);
                    if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                        let tempFields = this.page_fields.datas;
                        this.pagename =  tempFields[0].header.displayName;
                        tempFields.forEach((list, index)=>{
                            if(list.body && list.body.length){
                                this.mapLookUpType(list.body, index, {})
                            }
                        });
                        this.form_data = tempFields[0].body
                    }
                }
            },
            async buttonAction(action){
                if(action=='reset'){
                    this.$store.state.tabel_filter_result = {}
                    this.show_error = false;
                    this.resetMenditory();
                }
                else if(action=='submit'){
                    let validate = await this.$refs.filterFrom.validate();
                    if(validate){
                        this.show_error = false;
                        this.formateSave()
                    }
                    else{
                        this.show_error = true;
                    }
                }
            },
            onClosePopup(){
                this.isSuccessPopup = false
                this.status_content = true;
                this.message_content = '';
            },
            onCloseModalPopup(){
                this.isDocSuccessPopup = false;
                this.displaydocTableContent = false
                 this.formateSave();
                // this.displayTable =false;
            },
            GetChangeFunction(type, values){
                
                if(type=='claim_details'){

                    if(this.$route.params.page_name == 'nhai'){
                        this.SetSessionStorage('sesssion_details', JSON.stringify(values))
                        this.$router.push({
                            path : '/nhai-document-upload-list'
                        }).catch((err)=>{
                            console.log('activateUrl', err);
                        });
                    } else if(this.$route.params.page_name == 'nhidcl'){
                        this.SetSessionStorage('sesssion_details', JSON.stringify(values))
                        this.$router.push({
                            path : '/nhidcl-document-upload-list'
                        }).catch((err)=>{
                            console.log('activateUrl', err);
                        });
                    } else if(this.$route.params.page_name == 'nhlml'){
                        this.SetSessionStorage('sesssion_details', JSON.stringify(values))
                        this.$router.push({
                            path : '/nhidcl-document-upload-list'
                        }).catch((err)=>{
                            console.log('activateUrl', err);
                        });
                    }
                    else if(this.$route.name == 'bajaj-allianz-insurance-policy-verification'){
                        this.isDocSuccessPopup = true;
                        this.displaydocTableContent = true;
                        this.getDocList(false,values)
                    }
                    else if(values  && values.policyStatus && values.policyStatus.toLowerCase()=='cancelled'){
                        this.isSuccessPopup = true
                        this.status_content = true;
                        this.message_content = 'Please select active policy number'
                    }  
                    else{
                        this.SetSessionStorage('sesssion_details', JSON.stringify(values))
                        this.$router.push({
                            name : 'New_Claim_Registration_Details',
                            params: {page_name:'insured-details'}
                        }).catch((err)=>{
                            console.log('activateUrl', err);
                        });
                    }
                }
                else if(type=='document_details'){
                        this.SetSessionStorage('sesssion_details', JSON.stringify(values))
                        this.$router.push({
                            name : 'claim-document-upload-list'
                        }).catch((err)=>{
                            console.log('activateUrl', err);
                        });
                }
                else if(type=='claimsstatus'){
                    this.SetSessionStorage('sesssion_details', JSON.stringify(values))
                    this.$router.push({
                        name : 'claims-status-view'
                    }).catch((err)=>{
                        console.log('activateUrl', err);
                    });
                }
                else if(type=='updateclaimdetailsstatus'){
                        this.SetSessionStorage('sesssion_details', JSON.stringify(values))
                        this.$router.push({
                            name : 'UpdateClaimDetailCreate',
                            params: {page_name:'update-claim-detail-create'}
                        }).catch((err)=>{
                            console.log('activateUrl', err);
                        });
                }
                else if(type=='download-excel'){
                   this.$store.commit('DOWNLOAD_BASE_64_EXECL', values)
                }
            },
            GetChangePopupFunction(trigger_type, tigger_data){
                if(trigger_type=='download-file'){
                    this.downloadDoc(tigger_data);
                }
            
        },
            getDocList(reset=false, values){
                let mockRequest = {
                    "userId":  this.user_profile_details.userId,
                    "roleCode": this.user_profile_details.role__code,
                    "imdCode":this.user_profile_details.imdCode,
                    "pageCode":this.active_page.pageCode,
                    "claimNumber":(values && values.policyNumber) ? values.policyNumber : '',
                    "referenceNo":'',
                    "sectionCode": "A",
                    "lob": "",
                    "policyNumber": "",
                    "claimStatus": "",
                    "policyStartDate": "",
                    "policyEndDate": "",
                    "claimReferenceNo": "",
                    "time":new Date(),
                    "docType":this.$store.state?.active_page?.docType ? this.$store.state.active_page.docType.includes("$")? eval(this.$store.state.active_page.docType) : this.$store.state.active_page.docType : ""
                }
                
                let tempDetails = this.EncodeString({...mockRequest});
                if(reset){
                    tempDetails  = {}
                }
                this.table_data.api_url = DocumentTableUrl(tempDetails, {
                    table_url :'fetchClaimDoclist',
                    main_filter : this.user_profile_details.userId,
                    table_sort : ''
                }).url
                this.table_data.header = ClaimDocumentList();
                console.log('table_data.api_url', this.table_data.api_url)
                // this.displayTable = true;
                
        },
        
            formateSave(){
                
                let mockRequest = {
                    "userId":  this.user_profile_details.userId,
                    "roleCode": this.user_profile_details.role__code,
                    "imdCode":this.user_profile_details.imdCode,
                    "pageCode":this.active_page.code,
                    "sectionCode":this.active_page.pageCode,
                    "lob": "",
                    "policyNumber": "",
                    "claimStatus": "",
                    "policyStartDate": "",
                    "policyEndDate": "",
                    "claimHandler": ""
                }
                let getUrl = this.getTableUrl();
                if(getUrl){
                    let formDetils = this.$store.state.tabel_filter_result;
                    let finalData = this.formatePageData(formDetils, this.form_data)
                    let tempDetails = this.EncodeString({...mockRequest, ...finalData});
                    this.table_data.api_url = TableUrl(tempDetails, {
                        table_url :getUrl.url,
                        main_filter : this.user_profile_details.userId,
                        table_sort : ''
                    }, getUrl.isCommon).url
                    this.displayTable = true;
                    this.table_data.header = getUrl.header
                }
            },
            getTableUrl(){
                
                let routeName = this.$route.name != "OthersPage" ? this.$route.name : this.$route?.params?.page_name
                let checkUrl = {
                    'bajaj-allianz-insurance-policy-verification' : {
                        url : 'searchPolicyList',
                        isCommon: true,
                        header : ClaimsListPolicyVerificationHeader()
                    },
                    'nhidcl' : {
                        url : 'searchPolicyList',
                        isCommon: true,
                        header : ClaimsListHeader("NHAI")
                    },
                    'nhlml' : {
                        url : 'searchPolicyList',
                        isCommon: true,
                        header : ClaimsListHeader("NHAI")
                    },
                    'new-claim-registration' : {
                        url : 'searchPolicyList',
                        isCommon: true,
                        header : ClaimsListHeader()
                    },
                    'nhai' : {
                        url : 'searchPolicyList',
                        isCommon: true,
                        header : ClaimsListHeader("NHAI")
                    },
                    'claim-document-upload' : {
                        url : 'searchClaimList',
                        isCommon: false,
                        header : CliamDocumentUpload('docactions')
                    },
                    'updateclaimdetails': {
                        url : 'searchClaimList',
                        isCommon: false,
                        header : CliamDocumentUpload('updateclaimdetailsstatus')
                    },
                    'update-claim-details': {
                        url : 'searchClaimList',
                        isCommon: false,
                        header : CliamDocumentUpload('updateclaimdetailsstatus')
                    },
                    'claims-status': {
                        url : 'searchClaimList',
                        isCommon: false,
                        header : CliamDocumentUpload('claimsstatus')
                    },
                    'reports': {
                        url : 'getOutstandingReport',
                        isCommon: false,
                        header : CliamReport()
                    },
                    
                }
                return checkUrl[routeName];
            }
        }
}
</script>
