<template>
    <div v-if="renderComponent && $route.fullPath">
        <header>
            <section class="top-header">
                <TopBar ></TopBar> 
                <MainMenu></MainMenu>
            </section>
        </header>
        <main class="main-section" v-if="active_page && (active_page.pageCode || active_page.code)">
            <loader :display="display_status"> </loader>
            <router-view></router-view>
        </main>
        <footer>
            <FooterSection></FooterSection>
        </footer>
    </div>
</template>

<script>
import {mapState} from 'vuex';
import {UserProfile} from '@/apis/ApiDatas'
import TopBar from '@/components/common/TopBar.vue'
import MainMenu from '@/components/common/MainMenu.vue'
import FooterSection from '@/components/common/Footer.vue'
const Loader = () =>import('@/components/common/Loader')
    export default {
        data(){
            return{
                renderComponent:false,
                toastCount: 0
            }
        },
         computed:{
            ...mapState({
                active_page : state => state.active_page,
                display_status : state => state.loader, 
            })
        },
        name: 'LayoutView',
        components:{
            TopBar,
            MainMenu,
            FooterSection,
            Loader
        },
        async mounted(){
            await this.UserProfile()
        },
        watch:{
            "$store.state.request_failure.status":function(new_value){
                if(new_value!=''){
                    this.ShowErrorToast()
                }
            },
        },
        methods:{
             UserProfile : async function (){
                let _user_details = this.$store.state.auth;
                let _temp_details  = UserProfile();
                _temp_details.requests.userId =  _user_details.username;
                let _details = await this.$store.dispatch("GetIlmRequest", _temp_details);
                if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                    this.renderComponent = true 
                }
            },
           
            ShowErrorToast : function(append = false){
                let _error_details = this.$store.state.request_failure
                this.$bvToast.toast(_error_details.message, {
                    title: _error_details.title,
                    toaster: 'b-toaster-top-right',
                    solid: true,
                    noFade : false,
                    variant: _error_details.varient,
                    appendToast: append,
                    autoHideDelay: 5000,
                    noCloseButton: false
                })
                var root = this;
                setTimeout(function(){
                    root.$store.commit('RESET_REQUEST')
                }, 1000);
            },
        }
    }
</script>
