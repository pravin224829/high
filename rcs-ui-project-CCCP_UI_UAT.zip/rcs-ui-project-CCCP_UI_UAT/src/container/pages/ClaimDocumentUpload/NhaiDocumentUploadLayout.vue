<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <div class="row">
                        <div class="col-lg-6">
                            <h1 class="page-title">
                                Claim Document Upload
                            </h1>
                        </div>
                        <div class="col-lg-6">
                            <ul class="breadcrumbs float-right">
                                <li><router-link to="/claim-document-upload">List of Claims ></router-link></li>
                                <li class="active">NHAI Document Upload</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="claim-details main-card">
            <div class="row">
                <div class="col-lg-3">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Policy Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="claim-details-aside"> 
                                <ul class="claim-detail-item" v-if="policyDetails && policyDetails.length">
                                    <li v-for="(policy_detail, index) in policyDetails" :key="index">
                                        <div class="claim-details-icon">
                                            <img :src="updateImagePath(`/icons/${policy_detail.icon}`)" alt="hash">
                                        </div>
                                        <div class="claim-details-text">
                                            <p>
                                                {{policy_detail.title}}
                                                <span> {{updatedpolicyDetails[policy_detail.name]}}</span>
                                            </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="card">
                        <div class="card-header">
                          <h3>Claim Details</h3>
                           <!-- <label>Document Name: </label> &nbsp; -->
                            <!-- <b-form-select class="w-50 form-control" v-model="documentName" :options="lookuptypedata"></b-form-select> -->
                            <!-- <p v-if="errormessages" class="text-danger error_msg">{{errormessages}}</p> -->
                        </div>
                        <div class="card-body">
                            <div class="claim-file-upload">
                                <input type="file" @change="onFileChange" id="choosefile" accept=".xls,.xlsx,.jpeg,.pdf,.mp3,.jpg,.mp4,.wav,.tiff,.docx,.txt,.webm">
                                <p>
                                    <img src="assets/images/file-upload-icon.svg" class="text-center">
                                    Drop the claim related document here or 
                                   <span>click to browse</span>
                                </p>
                            </div>
                             <div class="col-xs-12 col-sm-12" v-if="fileUrl">
                                <div class="row">
                                    <div class="col-12 col-md-6 mt-4 text-center uploaded-file">
                                        <strong>File Uploaded : </strong> {{uploadedFile.name}}
                                    </div>
                                    <div class="col-12 col-md-6 mt-2">
                                        <div class="form-submit-button text-center mt-2">
                                            <button class="btn btn-primary mr-2" @click="getButtonAction('cancelupload')"  data-toggle="modal" > Cancel </button>
                                            <button class="btn btn-primary" @click="UploadFile()">Upload</button>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>

                    <div class="row form-filter">
                        <div class="col-lg-12" v-if="resetTable">
                            <div class="table-result table-responsive h-100">
                                <TableDisplay
                                    :table_date="table_data" 
                                    :highlight_fields="highlightFields"
                                    :priority_value="priorityValue"
                                    @GetDetails="GetChangeFunction"
                                ></TableDisplay>
                            </div>
                        </div>
                    </div>
                </div>

                </div>
        </section>
        <success-popup
            v-if="isSuccessPopup" 
            @onClosePopup='onClosePopup' 
            :okButtonClass="'case-status-ok-btn'" 
            :showOkButton='true' 
            :isSuccessPopup='true' 
            :error_content='status_content'
            :error_message='message_content'
            size='lg'
            :mainClass="'case-status-success'" 
            :closeButtonClass="'close m-0 p-0 case-status-success-btn'" 
            :iconClass="'flaticon-check text-center'" 
            :message="'Case Allocated Successfully'"
            :claimRefNo="claimRefNo"
        ></success-popup>
    </div>
</template>


<script>
import {mapState} from 'vuex'
const SuccessPopup = () => import(`@/components/common/models/SuccessPopup`)
const TableDisplay = () => import(`@/components/table/Table`)
import GlobalMixin from '@/mixins/GlobalMixins.js'
import {CliamDocumentUpload, ClaimDocumentList} from '@/datas/TableHeaders/ClaimsList'
import PolicyListMenu from '@/container/pages/NewClaimRegistration/PolicyListMenu';
import {DocumentTableUrl, FormUploadClaimDocument, FetchPageData} from '@/apis/ApiDatas'
import {ClaimsListHeader} from '@/datas/TableHeaders/ClaimsList'

export default {
    name: 'ClaimDocumentUploadLayout',
    data(){
        return{
            toast_info:{},
            files:{},
            isSuccessPopup:false,
            errormessages:"",
            status_content:false,
            message_content:'',
            updatedpolicyDetails: {},
            // dataDetails : [],
            docSesion: {},
            fileUrl: '',
            uploadedFile : '',
            resetTable : true,
            table_data : {
                api_url : '' ,
                header : ClaimDocumentList(),
                multi_sort : false,
                action:true,
                pagination:true,
                pagination_mode: "",
                perpage : 8,
                api_mode : "",
            },
            select_form_datas:[{
                "sub_index": "false",
                "sub_label": "Document Name",
                "label": "Document Name",
                "label_display": true,
                "label_value": "12",
                "additional_rules": "",
                "id": 0,
                "disbabled": false,
                "initDisbabled": false,
                "model": "documentName",
                "check_validations": false,
                "check_field_validations": false,
                "placeholder": "Document Name",
                "type": "select",
                "decimalLength": "",
                "columnClass": "col-lg-4 col-md-6",
                "rules": "required",
                "initRules": "required",
                "sortInput": false,
                "fieldCode": "DOCNAME",
                "options": [],
                "rows": 0.4,
                "max_rows": 8,
                "loader": false,
                "check_display": "true",
                "initCheckDisplay": "true",
                "custom_validation": {
                    "type": "select",
                    "isRequired": "true",
                    "addField": false,
                    "girdEdit": false
                },
                "api_call": false,
                "sub_fields": [],
                "name": "Document Name",
                "min_date": "",
                "max_date": "",
                "field_count": null,
                "isMandatory": false,
                "isFileRemove": "true",
                "addTable": false
            }],
            // documentName:'',
            polcyCode:'',
            policyDetails:[]
        }
    },
    mixins:[GlobalMixin],
    components:{
        PolicyListMenu,
        TableDisplay,
        SuccessPopup
    },
    async mounted(){
        
        this.upodateData();
        await this.getClaimDetails();
        this.getDocList()
        // this.updateSideBarData();
         this.upodatPolicyData()
        this.$store.state.tabel_filter_result = {}

    },
    computed:{
        ...mapState({
            from_data : state => state.multi_section_form_data,
            doclist_datas : state => state.doclist_datas,
            lookuptypedata : state => state.lookupby_type
            
    
        }),
    },
    watch:{
        from_data:{
            handler(new_value) {
                   this.updatedpolicyDetails = new_value
            },
            deep: true,  
        },
    },
    
    methods:{
        upodatPolicyData(){
            let getgeaderDetails = ClaimsListHeader()
            if(getgeaderDetails){
                let getPolicyDetails = this.GetSessionStorage('sesssion_details');
                if(getPolicyDetails){
                    getPolicyDetails = JSON.parse(getPolicyDetails)
                }
                
                let temData = getgeaderDetails.filter((list)=>list.icon!='')
                temData.forEach((list)=>{
                    list.value = (getPolicyDetails && getPolicyDetails[list.name]) ? getPolicyDetails[list.name] : ''
                })
                this.productCode = getPolicyDetails.productCode;
                this.policyDetails = temData;

                let claimRefNo = this.GetSessionStorage('claimRefNo');
                if(!claimRefNo){
                    this.$store.commit('UPDATE_FROM_DATE', {
                        form_value : getPolicyDetails,
                        form_key : 'multi_section_form_data'
                    })
                }
            }
        },
        upodateData(){
            let dataDetails = this.GetSessionStorage('sesssion_details');
            if(dataDetails){
                dataDetails = JSON.parse(dataDetails)
                this.docSesion = dataDetails
            }
        },
        updateSideBarData(){
            let getgeaderDetails = CliamDocumentUpload('', 'page', 'claim-document-upload-list')
            if(getgeaderDetails){
                let temData = getgeaderDetails.filter((list)=>list.icon!='')
                temData.forEach((list)=>{
                    list.value = (this.from_data && this.from_data[list.name]) ? this.from_data[list.name] : ''
                    console.log('list.value', list.value)
                })
                // this.dataDetails = temData;
 
                console.log('temData', temData, this.from_data)
            }
        },
        GetChangeFunction(trigger_type, tigger_data){
            if(trigger_type=='download-file'){
                this.downloadDoc(tigger_data);
            }
            
        },
        onFileChange(e) {  
            this.files = e.target.files[0];
            this.uploadedFile = e.target.files[0];
            this.fileUrl = URL.createObjectURL(this.files);
        },  
        getButtonAction() {
              let choose = document.getElementById("choosefile");
              choose.value=""
            this.uploadedFile = '';
            this.fileUrl = '';
            this.files ={}
            this.documentName="";
        },
        async UploadFile(){
            
            // if(this.documentName == ""){
            //     this.errormessages = "Please Select Document Header"
            // }
            // else{
            //     this.errormessages=""
                 if((this.docSesion  && this.docSesion.status) || this.fileUrl){
                       if((Object.keys(this.docSesion).length && this.docSesion.status) && (this.docSesion.status.toLowerCase().replace(/ /g,'') == 'claimclosed' || this.docSesion.status.toLowerCase().replace(/ /g,'') == 'claimrepudiated-asperinsurancepolicy-t&c' || this.docSesion.status.toLowerCase().replace(/ /g,'') == 'claimsettledwithlosspayment' || this.docSesion.status.toLowerCase().replace(/ /g,'') == 'claimclosed-claimwithdrawnbyinsured/withinexcess')){
                            this.isSuccessPopup = true
                            this.status_content = true;
                            this.message_content = 'This claim has been closed'
                        }
                else{
                    if(this.fileUrl && this.files.size <= 10000000 && this.doclist_datas && ((this.doclist_datas.total === undefined || this.doclist_datas.total === null) || this.doclist_datas.total <= 9)){
                        let form_uploads = new FormData()
                        let tempRequest = {
                            "userId":  this.user_profile_details.userId,
                            "roleCode": this.user_profile_details.role__code,
                            "imdCode":this.user_profile_details.imdCode,
                            "pageCode":this.active_page.pageCode,
                            "name": "",
                            "fileType": "pdf",
                            "referenceNo": this.docSesion.policyNumber, 
                            "referenceType": "claimnumber",
                            "templateType": "TMPLSLA",
                            "destination": "S3",
                            "documentName": this.documentName,
                            "docType":this.$store.state?.active_page?.docType ? this.$store.state.active_page.docType.includes("$")? eval(this.$store.state.active_page.docType) : this.$store.state.active_page.docType : ""
                        }
                        let convertedReq = this.EncodeString(tempRequest);
                        form_uploads.append("payload", convertedReq)
                        form_uploads.append("file", this.uploadedFile)
                        let _temp_details =  FormUploadClaimDocument()      
                        _temp_details.requests = form_uploads;
                        let _details = await this.$store.dispatch("FileUpload", _temp_details);
                        if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                            this.getButtonAction()
                            this.table_data.api_url = '';
                            this.resetTable = false
                            this.fileUrl = '';
                            this.uploadedFile = '';
                            this.resetTable = true
                            this.getDocList()
                            if(this.$refs.inputFile)  this.$refs.inputFile.value=null  
                        }
                    } 
                    else{
                        if(this.doclist_datas && this.doclist_datas?.total >= 10){
                            this.toast_info = {message:'Allowed 10 files to Upload', title :'Allowed Only 10 Files', varient :'danger'}
                            this.ShowErrorToast()
                        }
                        else if(this.files.size >= 10000000){
                            this.toast_info = {message:'Maximum file size up to 10 Mb', title :'File Size Exceeded', varient :'danger'}
                            this.ShowErrorToast()
                        }
                    }              
                }
            }
           
            
        },
        ShowErrorToast : function(append = false){
                let _error_details = this.toast_info;
                this.$bvToast.toast(_error_details.message, {
                    title: _error_details.title,
                    toaster: 'b-toaster-top-right',
                    solid: true,
                    noFade : false,
                    variant: _error_details.varient,
                    appendToast: append,
                    autoHideDelay: 5000,
                    noCloseButton: false
                })
            },
        onClosePopup(){
            this.isSuccessPopup = false;
            this.status_content = false;
            this.message_content = ''
            this.fileUrl = '';
        },
        getDocList(reset=false){
                let mockRequest = {
                    "userId":  this.user_profile_details.userId,
                    "roleCode": this.user_profile_details.role__code,
                    "imdCode":this.user_profile_details.imdCode,
                    "pageCode":this.active_page.pageCode,
                    "claimNumber":this.docSesion.policyNumber,
                    "sectionCode": "ABC",
                    "lob": "",
                    "policyNumber": "",
                    "claimStatus": "",
                    "policyStartDate": "",
                    "policyEndDate": "",
                    "claimReferenceNo": "",
                    "destination": "S3",
                    "time":new Date(),
                    "docType":this.$store.state?.active_page?.docType ? this.$store.state.active_page.docType.includes("$")? eval(this.$store.state.active_page.docType) : this.$store.state.active_page.docType : ""
                }
               
                let tempDetails = this.EncodeString({...mockRequest});
                if(reset){
                    tempDetails  = {}
                }
                this.table_data.api_url = DocumentTableUrl(tempDetails, {
                    table_url :'fetchClaimDoclist',
                    main_filter : this.user_profile_details.userId,
                    table_sort : ''
                }).url
                console.log('this.table_data.api_url', this.table_data.api_url)
                this.displayTable = true;
                
        },

        async getClaimDetails(){
             let mockRequest = {
                    "userId":  this.user_profile_details.userId,
                    "roleCode": this.user_profile_details.role__code,
                    "imdCode":this.user_profile_details.imdCode,
                    "claimNumber":(this.docSesion.claimNumber) ? this.docSesion.claimNumber : (this.$store.state.claimNumber) ? this.$store.state.claimNumber : '',
                    "pageCode":"UPDCLAIM",
                    "sectionCode":"UPDCLAIM",
                    "lob": "",
                    "policyNumber": "",
                    "claimStatus": "",
                    "policyStartDate": "",
                    "policyEndDate": "",
                    "claimHandler": "",
                    "take_obj":"claimDetailsDto"
                }
                let tempDetails = FetchPageData('fetchClaimDetails');
                tempDetails.requests = mockRequest;
                let _details = await this.$store.dispatch("GetRequest", tempDetails);
                if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                    this.updatedpolicyDetails  = {..._details.body.responseData};
                    const {productCode} = _details.body.responseData;
                    this.polcyCode = productCode;
                    if(this.select_form_datas){
                        this.mapLookUpType(this.select_form_datas, 0, {})
                    }
                }
                else{
                    this.mapLookUpType(this.select_form_datas, 0, {})
                }
        }
    }
}
</script>
<style lang="scss">
.uploaded-file{
    img{
        max-width:100%;
    }
}
.error_msg{
    position: absolute;
    left: 149px;
}
.claim-details-aside .claim-details-text{
    word-break: break-word;
}
</style>
