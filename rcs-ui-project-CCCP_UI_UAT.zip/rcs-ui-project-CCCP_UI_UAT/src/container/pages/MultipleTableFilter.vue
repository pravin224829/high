<template>
    <div>
        <template v-for="(form_list, index) in form_data">
            <section class="top-section" :key="index">
                <div class="top-container">
                    <div class="top-content">
                        <h1 class="page-title">
                            {{form_list.header.displayName}}
                        </h1>
                    </div>
                </div>
            </section>
           
            <section  class="form-filter main-card" :key="index">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                                <div class="card-header">
                                    <h3>Filter</h3>
                                </div>
                                <div class="card-body">
                                    <div class="form-filter-items">
                                        <ValidationObserver v-slot="{}" :ref="form_list.header.sectionObj">
                                            <filter-form 
                                                filter_class="form-row"
                                                :display_submit="true" 
                                                :show_error="show_error"  
                                                :form_base="form_list.body"  
                                                form_name = "tabel_filter_result" 
                                                @onFilterSelect="getSelectValues"
                                                @onSearchFilter='onSearchFilter' 
                                                @onClearFilter='onClearFilter' 
                                                :date-format="onDateFormat" 
                                                :singleDatePicker='singleDatePicker'>                           
                                            </filter-form>
                                        </ValidationObserver>
                                    </div>
                                    <div class="row mt-4">
                                        <div class="col-lg-6 mx-auto text-center">
                                            <div class="filter-buttons">
                                                <template v-if="form_list.header.filter_buttons">
                                                    <div class="button-item" v-for="(filter_buttons, index) in form_list.header.filter_buttons" :key="index">
                                                        <button :class="filter_buttons.className" type="submit" @click="buttonAction(filter_buttons.buttonCode, form_list.header.sectionObj, form_list)">{{filter_buttons.buttonName}}</button>
                                                    </div>
                                                </template>     
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>  
                    <div class="row" v-if="displayTableObject[form_list.header.sectionObj]['display']">
                        <div class="col-lg-12">
                            <div class="table-result">
                                <TableDisplay
                                    :table_date="displayTableObject[form_list.header.sectionObj]['tableData']" 
                                    :highlight_fields="highlightFields"
                                    :priority_value="priorityValue"
                                    @GetDetails="GetChangeFunction"
                                ></TableDisplay>
                                <div class="row mt-4">
                                    <div class="col-lg-6 mx-auto text-center">
                                        <div class="filter-buttons">
                                            <template v-if="form_list.header.table_buttons">
                                                <div class="button-item" v-for="(filter_buttons, index) in form_list.header.table_buttons" :key="index">
                                                    <button :class="filter_buttons.className" type="submit" @click="buttonAction(filter_buttons.buttonCode, form_list.header.sectionObj)">
                                                        <template v-if="filter_buttons && filter_buttons.svgImage">
                                                           <img :src="updateImagePath(`/${filter_buttons.svgImage}`)" alt="button image" class="img-fluid"/>
                                                        </template>
                                                        <template v-else>
                                                            {{filter_buttons.buttonName}}
                                                        </template>
                                                    </button>
                                                </div>
                                            </template>     
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
            </section>
        </template>
        <FormModel v-if="displayPopup" 
            :footer="true" 
            @onClosePopup='onClosePopup' 
            title="User Details"
        >
            <template v-if="formDisplay.displayFrom">
            <ValidationObserver v-slot="{}" ref="popupFrom">
                <PopupFrom 
                    :form_base="popupData"
                    :show_error="show_error" 
                    :form_index="index"       
                    base_id="wbsingle_main"
                    form_name="popup_page_data"
                    :display_success="null"
                    @onSelectChange="GetUpdatedSelectValues"
                    @onInputChange="GetInputSelectValues"
                    @onMultiInputbox="GetMultiInputbox"
                    @UpdateMultiFileUpload="UpdateMultiFileUpload" 
                /> 
                    <div class="row mt-4">
                        <div class="col-lg-12 mx-auto text-center">
                            <div class="filter-buttons" >
                                <template v-if="popupButton">
                                    <div class="button-item" style="display: inline-block;" v-for="(filter_buttons, index) in popupButton" :key="index">
                                    
                                        <button :class="filter_buttons.className" class="mr-2"  type="submit" @click="buttonAction(filter_buttons.buttonCode)">{{filter_buttons.buttonName}}</button>
                                    </div>
                                </template>     
                            </div>
                        </div>
                    </div>
                </ValidationObserver>
            </template>
            <template v-else-if="formDisplay.displayUpload">
                
                    <div class="row">
                        <div class="col-12">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                </div>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="inputGroupFile01"
                                    aria-describedby="inputGroupFileAddon01"  @change="onFileChange" ref="inputFile">
                                    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 mt-4 text-center">
                            <button type="submit" class="btn btn-success" @click="UploadFile()"> Upload </button>
                        </div>
                    
                    
                </div>
            </template>
        </FormModel>
        <success-popup
            v-if="isSuccessPopup" 
            @onClosePopup='onClosePopup' 
            :okButtonClass="'case-status-ok-btn'" 
            :showOkButton='true' 
            :isSuccessPopup='true' 
            :success_content='success_content'
            :success_message='success_message'
            size='lg'
            :mainClass="'case-status-success'" 
            :closeButtonClass="'close m-0 p-0 case-status-success-btn'" 
            :iconClass="'flaticon-check text-center'" 
            :message="'Case Allocated Successfully'"
            :claimRefNo="claimRefNo"
        ></success-popup>
    </div>
</template>

<script>
const FilterForm = () => import(`@/components/common/form/BasicForm`)
const TableDisplay = () => import(`@/components/table/Table`)
const FormModel = () => import('@/components/common/Modal')
const PopupFrom = () => import('@/components/common/form/BasicForm')
const SuccessPopup = () => import(`@/components/common/models/SuccessPopup`)
import {ClaimsListHeader} from '@/datas/TableHeaders/ClaimsList'
import {mapState} from 'vuex'
import GlobalMixin from '@/mixins/GlobalMixins.js'
import {GetPageFields, TableConfigUrl, PopUpPageFields, SaveFormDetails, FormUploadDocument} from '@/apis/ApiDatas'
 
export default {
    name:'MultipleTableFilter',
    mixins:[GlobalMixin],
    data(){
        return {
            uploadedFile : '',
            fileUrl : '',
            popupButton:{},
            isSuccessPopup : false,
            success_content : '',
            success_message : '',
            currentActionForm : {},
            displayPopup : false,
            show_error: true,
            displayTable : false,
            displayTableObject : {},
            tableExec : false,
            show_dialog : true,
            table_type: true,
            table_display : true,
            form_data : [],
            popupData : [],
            pagename: '',
            updated_value : [],
            highlightFields : ['taskRefNumber'],
            priorityValue:[{text: `Select Priority`,value: null}],
            formDisplay : {
                displayFrom: false,
                displayUpload:false,
            },
            table_data : {
                api_url : '' ,
                header : ClaimsListHeader() ,
                multi_sort : false,
                action:true,
                pagination:true,
                pagination_mode: "",
                perpage : 8,
                api_mode : "",
            },
        }
    },
    components:{
        FilterForm,
        TableDisplay,
        FormModel,
        PopupFrom,
        SuccessPopup
    },
    mounted(){
        this.GetFormFields()
    },
    computed:{
        ...mapState({
            page_fields : state => state.multi_section_page_fields,
            popup_page_data : state => state.popup_page_data_details,
        }),
    },
    watch:{
        "$store.state.active_page":function(){
            this.GetFormFields()
            this.displayTable = false
        }
    },
    methods:{
        onClosePopup(){
            this.togglePopup('close')
            this.isSuccessPopup = false;
        },
        onFileChange(e) {
            const file = e.target.files[0];
            this.uploadedFile = e.target.files[0];
            this.fileUrl = URL.createObjectURL(file); 
        },
        async UploadFile(){
            if(this.fileUrl){
                let form_uploads = new FormData()
                let tempRequest = {
                    "userId":  this.user_profile_details.userId,
                    "roleCode": this.user_profile_details.role__code,
                    "imdCode":this.user_profile_details.imdCode,
                }
                let convertedReq = this.EncodeString(tempRequest);
                form_uploads.append("payload", convertedReq)
                form_uploads.append("file", this.uploadedFile)
                let _temp_details =  FormUploadDocument('uploadParnterDetails')      
                _temp_details.requests = form_uploads;
                let _details = await this.$store.dispatch("FileUpload", _temp_details);
                if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                    this.fileUrl = '';
                    this.uploadedFile = '';
                    this.$refs.inputFile.value=null 
                    this.togglePopup('close');
                    this.isSuccessPopup = true;
                    this.success_content = true
                    this.success_message = 'User Details has been upload successfully.'
                }
            }
        },
        
        async GetFormFields(){
            let tempDetails = GetPageFields();
            let tempReqCr = this.commonPageRequest();
            console.log('tempReqCr', tempReqCr)
            let createReq = {
                "userId":"admin",
                "roleCode":"ADMIN",
                "imdCode":this.user_profile_details.imdCode,
                "pageCode":"CLAIMREG",
                "sectionCode":"CLAIMREG",
                ...tempReqCr
            }
            tempDetails.requests = createReq
            let _details = await this.$store.dispatch("GetRequest", tempDetails);
            if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                let tempFields = this.page_fields.datas;
                tempFields.forEach((list, index)=>{
                    if(list.body && list.body.length){
                        console.log('list.header.sectionObj', list.header.sectionObj)
                        this.displayTableObject[list.header.sectionObj] = {
                            display : false,
                            tableData : []
                        }
                        this.mapLookUpType(list.body, index, {})
                    }
                });
                
                this.form_data = tempFields
            }
        },
        async buttonAction(action, sectionCode, sectionDetails){
            console.log('action', action, sectionCode)
            if(action=='reset'){
                this.$store.state.tabel_filter_result = {}
            }
            else if(action=='downloadExcel'){
                let tempDoc = this.currentActionForm
                this.downloadDoc({
                    "pageCode": "",
                    "sectionCode": "",
                    "docId": "",
                    "docName": "user-partner-config.xlsx",
                    "templateType":tempDoc.header.template_type
                })
            }
            else if(action=='uploadLoader'){
                this.togglePopup('open','displayUpload');
            }
            else if(action=='addFlashMesg'){
                this.currentActionForm = sectionDetails
                this.displayTogglepopup()
            }
            else if(action=='submit'){
                let validate = await this.$refs[sectionCode][0].validate();
                if(validate){
                    this.formateSave(sectionCode)
                }
            }
            else if(action=='updateUser'){
                let validate = await this.$refs.popupFrom.validate();
                if(validate){
                    this.savePopup()
                }
            }
        },
        async savePopup(){
            let finalRequest = SaveFormDetails('saveUserDetails', this.$route.params.page_name)
            finalRequest.requests = {
                ...this.popup_page_data,
                "userName": this.popup_page_data.userId,
                "userId":  this.user_profile_details.userId,
                "roleCode": this.user_profile_details.role__code,
                "imdCode":this.user_profile_details.imdCode,
                "pageCode":this.active_page.code,
                "sectionCode":this.active_page.pageCode,
            }
            console.log('finalRequest', finalRequest)
            let tempRequest = await this.$store.dispatch("PostRequest", finalRequest);
            if(tempRequest.body && tempRequest.body.status && tempRequest.body.status.toLowerCase()=='success'){
                this.togglePopup('close');
                this.isSuccessPopup = true 
                this.success_content = true
                this.success_message = 'User Details has been updated successfully.'
            }
            
        },

        async  displayTogglepopup(){
            this.togglePopup('open','displayFrom');
            let currentForm = this.currentActionForm
            console.log('currentForm',currentForm)
            let tempReq = PopUpPageFields();
            tempReq.requests = {
                "userId":  this.user_profile_details.userId,
                "roleCode": this.user_profile_details.role__code,
                "imdCode":this.user_profile_details.imdCode,
                "pageCode":this.active_page.code,
                "sectionCode":currentForm.header.popup_code
            }
            let _details = await this.$store.dispatch("GetRequest", tempReq);
            if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                let tempFields = this.page_fields.datas;
                this.popupTitle =  tempFields[0].header.displayName;
                tempFields.forEach((list, index)=>{
                    if(list.body && list.body.length){
                        this.mapLookUpType(list.body, index, {})
                    }
                });
                this.popupData = tempFields[0].body
                this.$store.state.popup_page_data_details = {...values}
                let popupButton = currentForm.header.popup_button;
                if(popupButton){
                    this.popupButton = popupButton
                }
            }
        },
        async GetChangeFunction(type, values){
            if(type=='claim_details'){
                this.displayTogglepopup()
            }
        },
        formateSave(sectionHeaderCode){
            let mockRequest = {
                "userId":  this.user_profile_details.userId,
                "roleCode": this.user_profile_details.role__code,
                "imdCode":this.user_profile_details.imdCode,
                "pageCode":this.active_page.pageCode,
                "sectionCode": "",
                "lob": "",
                "policyNumber": "",
                "claimStatus": "",
                "policyStartDate": "",
                "policyEndDate": "",
                "claimHandler": ""
            }
            let getUrl = this.getTableUrl(sectionHeaderCode);
            if(getUrl){
                let getTableDetails = this.form_data.find(list=>list.header.sectionObj==sectionHeaderCode)
                console.log('getTableDetails', getTableDetails)
                if(getTableDetails){
                    let table_data = {
                        api_url : '' ,
                        header : '',
                        multi_sort : false,
                        action:true,
                        pagination:true,
                        pagination_mode: "",
                        perpage : 8,
                        api_mode : "",
                    };
                    let formDetils = this.$store.state.tabel_filter_result;
                    let finalData = this.formatePageData(formDetils, getTableDetails.body)
                    let tempDetails = this.EncodeString({...mockRequest, ...finalData});
                    table_data.api_url = TableConfigUrl(tempDetails, {
                        table_url :getUrl.url,
                        main_filter : this.user_profile_details.userId,
                        table_sort : ''
                    },getUrl.inter).url
                    this.displayTable = true;
                    table_data.header = getUrl.header
                    this.displayTableObject[sectionHeaderCode]['tableData'] = table_data;
                }
            }
        },
        getTableUrl(sectionHeaderCode){
            let getFilterHeader = this.form_data.find(list=>list.header.sectionObj==sectionHeaderCode)
            this.currentActionForm = getFilterHeader
            let routeName = this.$route.params.page_name
            let checkUrl = {
                'system-configuration' : {
                    url : 'userSearch',
                    isCommon: true,
                    inter : '',
                    header : getFilterHeader.header.table_header
                },
                'clients-fields-configuration' : {
                    url : 'searchRuntimeFieldsConfig',
                    isCommon: true,
                    inter : '',
                },
                'userSearch' : {
                    url : 'userSearch',
                    isCommon: true,
                    inter : '',
                    header : getFilterHeader.header.table_header
                },
                'flashMesgSearch' : {
                    url : 'fetchFalshMessageList',
                    inter : 'home',
                    isCommon: true,
                    header : getFilterHeader.header.table_header
                },
            }
            let updateTableDisplay = {...this.displayTableObject}
            updateTableDisplay[sectionHeaderCode]['display'] = true;
            this.displayTableObject = updateTableDisplay
            
            let checkData = checkUrl[routeName];
            if(!checkData){
                checkData = checkUrl[getFilterHeader.header.sectionObj];
            }
            return checkData;
        },
        togglePopup(popUpAction='open', targetPopup){
            if(popUpAction=='open'){
                this.isSuccessPopup = false;
            }
            else{
                this.displayPopup = false 
            }
            
            for(let subform in this.formDisplay){
                this.formDisplay[subform] = false;
            }
            if(popUpAction=='close'){
                this.displayPopup = false;
            }
            else{
                this.displayPopup = true;
                this.formDisplay[targetPopup] = true
            }
        },
    }
}
</script>
<style scoped>
.close-button-holder{
    position: absolute;
    right :0px;
}
</style>