<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <h1 class="page-title">
                        Overview
                    </h1>
                </div>
            </div>
        </section>
        <section class="dashboard main-card">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 mb-20">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Claim Summary</h3>
                        </div>
                            <div class="card-body pt-5">
                                    <div class="row">
                                            <div class="col-lg-4 col-md-12 col-sm-12">
                                            <div class="claim-summary1">
                                                <div class="summary-arrow1 left">
                                                    <div class="card claim-summary-card1 addBorder">
                                                        <div class="card-body claim-summary-content1">
                                                            <div class="claim-icon-text1 d-flex align-items-center">
                                                                <div class="claim-icon">
                                                                    <img src="@/assets/images/claim-add.svg" alt="claim-add">
                                                                </div>
                                                                <p>Total No. of Registered Claims</p>
                                                            </div>
                                                            <div class="claim-value1 mt-3">
                                                                <h3>
                                                                    <number
                                                                        ref="number1"
                                                                        :from="1"
                                                                        :to="summary_details.noOfClaimRegsitered"
                                                                        :duration="2"
                                                                        :delay="0"
                                                                        easing="Power1.easeOut"
                                                                    />
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12 col-sm-12">
                                            <div class="claim-summary2">
                                                <div class="summary-arrow2 left">
                                                    <div class="card claim-summary-card2 addBorder">
                                                        <div class="card-body claim-summary-content2">
                                                            <div class="claim-icon-text2 d-flex align-items-center">
                                                                <div class="claim-icon">
                                                                    <img src="@/assets/images/claim-file.svg" alt="claim-add">
                                                                </div>
                                                                <p>Total No. of Closed Claims</p>
                                                            </div>
                                                            <div class="claim-value2 mt-3">
                                                                 <h3>
                                                                    <number
                                                                        ref="number1"
                                                                        :from="1"
                                                                        :to="summary_details.noOfClaimUploaded"
                                                                        :duration="2"
                                                                        :delay="0"
                                                                        easing="Power1.easeOut"
                                                                    />
                                                                 </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12 col-sm-12">
                                            <div class="claim-summary3">
                                                <div class="summary-arrow3 left">
                                                    <div class="card claim-summary-card3 addBorder">
                                                        <div class="card-body claim-summary-content3">
                                                            <div class="claim-icon-text3 d-flex align-items-center">
                                                                <div class="claim-icon">
                                                                    <img src="@/assets/images/claim-document.svg" alt="claim-add">
                                                                </div>
                                                                <p>Total No. of Outstanding Claims</p>
                                                            </div>
                                                            <div class="claim-value3 mt-3">
                                                                <h3>
                                                                    <number
                                                                        ref="number1"
                                                                        :from="1"
                                                                        :to="summary_details.noOfClaimUpdated"
                                                                        :duration="2"
                                                                        :delay="0"
                                                                        easing="Power1.easeOut"
                                                                    />
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                    </div>
                </div>
                <!-- <div class="col-lg-5 col-md-12 col-sm-12 mb-20">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>User</h3>
                        </div>
                            <div class="card-body pt-5">
                                <div class="row">
                                    <div class="col-lg-5 col-md-12 col-sm-12">
                                        <div class="user-count">
                                            <div class="card user-count-card">
                                                <div class="card-body">
                                                    <div class="semi-circle">
                                                        <p>Total No. of Users</p>
                                                    </div>
                                                    <div class="user-count-content">
                                                        <h3>
                                                            <number
                                                                ref="number1"
                                                                :from="1"
                                                                :to="user_details.totalUser"
                                                                :duration="2"
                                                                :delay="0"
                                                                easing="Power1.easeOut"
                                                            />
                                                        </h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-7 col-md-12 col-sm-12">
                                        <div class="user-status">
                                            <div class="card user-status-card">
                                                <div class="card-body">
                                                    <div class="user-status-content d-flex align-items-center">
                                                        <div class="user-status-text">
                                                            <h3>
                                                                <number
                                                                    ref="number1"
                                                                    :from="1"
                                                                    :to="user_details.activeUser"
                                                                    :duration="5"
                                                                    :delay="0"
                                                                    easing="Power1.easeOut"
                                                                />
                                                            </h3>
                                                            <p>Active Users</p>
                                                        </div>
                                                        <div class="user-status-progress1">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                    <div class="user-status-content d-flex align-items-center">
                                                        <div class="user-status-text">
                                                            <h3>
                                                                <number
                                                                    ref="number1"
                                                                    :from="1"
                                                                    :to="user_details.inActiveUser"
                                                                    :duration="5"
                                                                    :delay="0"
                                                                    easing="Power1.easeOut"
                                                                />
                                                               </h3>
                                                            <p>Inactive Users</p>
                                                        </div>
                                                        <div class="user-status-progress2">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div> -->
            </div>
        </section>

        <section class="reports main-card">
            <div class="row">
                <!-- <div class="col-lg-4 col-md-12 col-sm-12 mb-20">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Reports</h3>
                        </div>
                        <div class="card-body pt-5">
                            <div class="row">
                                <div class="col-lg-6 col-md-11 col-sm-11 col-11 mx-auto">
                                    <div class="report-card report-card-bg-1">
                                        <div class="card">
                                            <div class="card-header">
                                                <div class="report-header">
                                                    <img src="@/assets/images/reports-header1.png" class="img-fluid" alt="">
                                                </div>
                                            </div>
                                            <div class="card-body report-body pt-2 pb-4">
                                                <h2>281</h2>
                                                <p>Total No. of Outstanding Claims</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">
                                    <div class="report-card report-card-bg-2">
                                        <div class="card">
                                            <div class="card-header">
                                                <div class="report-header">
                                                    <img src="@/assets/images/reports-header2.png" class="img-fluid" alt="">
                                                </div>
                                            </div>
                                            <div class="card-body report-body pt-2 pb-4">
                                                <h2>102</h2>
                                                <p>Total No. of Settled Claims</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">
                                    <div class="report-card report-card-bg-3">
                                        <div class="card">
                                            <div class="card-header">
                                                <div class="report-header">
                                                    <img src="@/assets/images/reports-header3.png" class="img-fluid" alt="">
                                                </div>
                                            </div>
                                            <div class="card-body report-body pt-2 pb-4">
                                                <h2>130</h2>
                                                <p>Total No. of Detailed Information Report</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">
                                    <div class="report-card report-card-bg-4">
                                        <div class="card">
                                            <div class="card-header">
                                                <div class="report-header">
                                                    <img src="@/assets/images/reports-header4.png" class="img-fluid" alt="">
                                                </div>
                                            </div>
                                            <div class="card-body report-body pt-2 pb-4">
                                                <h2>88</h2>
                                                <p>Total No. of Claim Payment Report</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->
                <div class="col-lg-12 col-md-12 col-sm-12 mb-20">
                    <div class="card h-100">
                        <div class="card-header">
                          <h3>Claim Analysis</h3>
                        </div>
                        <div class="card-body pt-3">
                            <div class="chart-header">
                                <div class="row d-flex align-items-center mb-20">
                                    <div class="col-lg-3">
                                        <div class="chart-text d-flex align-items-center">
                                            <div class="reg-legend"></div>
                                            <p>Registered Claim</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-9 align-self-end">
                                        <div class="chart-filter align-items-center justify-content-end">
                                            
                                                <div class="row align-items-center">
                                                    <div class="col-lg-8">
                                                        <div class="rounded-form">
                                                            <div class="input-group">
                                                                <div class="input-group-prepend">
                                                                <span class="input-group-text">
                                                                    <img src="@/assets/images/icons/calendar.svg">
                                                                </span>
                                                                </div>
                                                               <datetime
                                                                type="date"
                                                                id="fromData" 
                                                                :use12-hour="true"
                                                                v-model="fromDate"
                                                                :format="'dd-MMM-yyyy'"
                                                                :phrases="{ok: 'Continue', cancel: 'Exit'}"
                                                                input-class="form-control"
                                                                :max-datetime="toDate"
                                                                :placeHolder="`Select From Date`"
                                                                :week-start="7"
                                                                @input="GetChangeDate(fromDate)"
                                                                auto
                                                            ></datetime>
                                                            </div>
                                                            <img src="@/assets/images/arrow-right.svg" alt="">
                                                            <div class="input-group">
                                                                <div class="input-group-prepend">
                                                                <span class="input-group-text">
                                                                    <img src="@/assets/images/icons/calendar.svg">
                                                                </span>
                                                                </div>
                                                                 <datetime
                                                                    type="date"
                                                                    id="toData" 
                                                                    :use12-hour="true"
                                                                    v-model="toDate"
                                                                    :format="'dd-MMM-yyyy'"
                                                                    :phrases="{ok: 'Continue', cancel: 'Exit'}"
                                                                    input-class="form-control"
                                                                    :min-datetime="fromDate"
                                                                    :max-datetime="maximumDateSet"
                                                                    :placeHolder="`Select To Date`"
                                                                    :week-start="7"
                                                                    auto
                                                            ></datetime>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-4">
                                                        <div class="row align-items-center">
                                                            <div class="col-lg-12">
                                                                <button class="btn btn-primary btn-small" @click="fetchDashboardChartData">Submit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                   
                                                </div>
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <apexchart type="bar" height="350" :options="chartOptions" :series="series" v-if="displayChart"></apexchart>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>
<script>
import {mapState} from 'vuex';
import { Datetime } from 'vue-datetime';
import {convert_ddmmyy} from  '@/shared/timer.js';
import {UserCount, UserSummaryCount, FetchDashboardChartData} from '@/apis/ApiDatas'
import GlobalMixin from '@/mixins/GlobalMixins.js'
import 'vue-datetime/dist/vue-datetime.css'
import 'vue-search-select/dist/VueSearchSelect.css'
const Loader = () =>import('@/components/common/Loader')
    export default {
        name: 'DashboardPage',
        mixins:[GlobalMixin],
        data(){
            return{
                fromDate : '',
                toDate : '',
                maximumDateSet:'',
                renderComponent:false,
                displayChart:false,
                series: [{
                    data: []
                }],
                chartOptions: {
                    chart: {
                    type: 'bar',
                        height: 350
                    },
                    plotOptions: {
                        bar: {
                            borderRadius: 4,
                            columnWidth: '15%',
                        }
                    },
                    dataLabels: {
                        enabled: false
                    },
                    xaxis: {
                        labels: {
                            show: true,
                            rotate: -90,
                            rotateAlways: true,
                        },
                        categories: [],      
                    },
                },
            }
        },
        computed:{
            ...mapState({
                active_page : state => state.active_page,
                display_status : state => state.loader, 
                user_details : state => state.user_details, 
                summary_details : state => state.summary_details,
                chart_data : state => state.dashbaord_data,
                
            })
        },
        name: 'LayoutView',
        components:{
            Loader,
            Datetime
        },
        async mounted(){
            this.GetUserCount()
            this.GetSummaryCount()
        },
        methods:{
            updateChart(){

            },
            GetUserCount : async function(){
                let _user_details = this.user_profile_details;
                let tempRequest = {
                    "userId":_user_details.userId,
                    "roleCode":_user_details.role__code,
                    "imdCode":_user_details.imdCode,
                    "corporateId":_user_details.corporateId
                }
                let _temp_details  = UserCount();
                _temp_details.requests = tempRequest;   
                await this.$store.dispatch("GetRequest", _temp_details);
                
            },
            async GetSummaryCount(){
                let _user_details = this.user_profile_details;
                let tempRequest = {
                    "userId":_user_details.userId,
                    "roleCode":_user_details.role__code,
                    "imdCode":_user_details.imdCode,
                    "corporateId":_user_details.corporateId
                }
                let _temp_details  = UserSummaryCount();
                _temp_details.requests = tempRequest;   
                await this.$store.dispatch("GetRequest", _temp_details);
            },
            async fetchDashboardChartData(){
                this.displayChart = false;
                if(this.fromDate && this.toDate){
                    let _user_details = this.user_profile_details;
                    let tempRequest = {
                        "userId":_user_details.userId,
                        "roleCode":_user_details.role__code,
                        "imdCode":_user_details.imdCode,
                        "corporateId":_user_details.corporateId,
                        "fromDate":convert_ddmmyy(this.fromDate),
                        "toDate":convert_ddmmyy(this.toDate)
                    }
                    let _temp_details  = FetchDashboardChartData();
                    _temp_details.requests = tempRequest;   
                    let _details = await this.$store.dispatch("GetRequest", _temp_details);
                    if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                        this.updateDashbaordData();
                        this.displayChart = true
                    }
                }
            },
            updateDashbaordData(){
                this.series[0].data = this.chart_data.data;
                this.chartOptions.xaxis.categories = this.chart_data.label;
                console.log("chartdata",this.chart_data)
                this.displayChart = true;
            },
            GetChangeDate(value){
                    const getDate = new Date(value);
                    getDate.setDate(getDate.getDate()+90);
                    let month = getDate.getMonth()+1;
                    let date = getDate.getDate();
                    (month < 10) ? month = '0'+month : month;
                    (date < 10) ? date = '0'+date : date;    
                    let formatDate =`${getDate.getFullYear()}-${month}-${date}T00:00:00.000Z`;
                    this.maximumDateSet = formatDate;
                    // this.toDate = formatDate;
             }
        },
        watch:{
            fromDate(){
                this.toDate = ''
            }
        }
    }
</script>

