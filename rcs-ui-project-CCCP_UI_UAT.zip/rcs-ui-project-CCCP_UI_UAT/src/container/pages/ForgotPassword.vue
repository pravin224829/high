<template>
    <section class="forgot-password">
         <div class="container-fluid">
            <div class="row">
               <div class="col-lg-12">
                  <img src="@/assets/images/dashboard-white-logo.png" class="img-fluid forgot-password-logo" alt="logo">
                  <div class="card border-0">
                    <template v-if="!linkSent">
                        <!-- <a href="/#/"><i class="fa fa-window-close close-icon"></i></a> -->
                        <h3>Forgot password</h3>
                        <p>Enter your User ID below and we 'll send you link to reset password</p>
                        <form action="">
                            <div class="form-group">
                            <input type="text" class="form-control" v-model="UserId">
                            <div class="text-danger" v-if="UserError">Enter User ID</div>
                            <div class="text-danger" v-if="userCheck">Enter Correct UserName</div>
                            </div>
                            <button type="button" class="send-button" @click="ResetPassword" :disabled="buttonDisable">{{buttonLink}}</button>
                        </form>
                    </template>
                    <template v-else>
                         <!-- <a href="/#/"><i class="fa fa-window-close close-icon"></i></a> -->
                        <h3>Forgot password</h3>
                      <img src="@/assets/images/email.svg" class="img-fluid img-mail" alt="email">
                        <h4>Check your mail</h4>
                        <a class="resend-link" @click="linkSent=false">Resend Link</a>
                    </template>
                  </div>
                  <div class="dashboard-footer text-white footer-fixed fixed-bottom">
                     <div class="footer-inn">
                        <p>Copyright 2020 FA SOFTWARE All Rights Reserved</p>
                        <p> <a href=""> Terms and Conditions</a></p>
                        <span> <a href=""> Privacy Policy</a></span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
    </section>
</template>
<script>
import axios from 'axios';
import {EncodeString} from '@/shared/custom'
export default {  
    name:"Forget Password",
    data(){
        return{
            UserId : '',
            UserError:false,
            buttonLink: 'Send link',
            buttonDisable:false,
            linkSent : false,
            userCheck: false
        }
    },
    created(){
        console.log("route", this.$route)
    },
    methods:{
        async ResetPassword(){
            if(this.UserId){
                this.UserError = false;
                this.buttonLink = 'Sending Link ...';
                let tempPayload = EncodeString({"userId" : this.UserId})
               await axios.get(`${process.env.VUE_APP_API_URL}/cccp/config/user/api/forgotPassword?payload=${tempPayload}`)
                    .then(response => {
                        this.info = response
                        console.log('this.info', this.info)
                          if(response.status == 200 && response.data.status == 'SUCCESS'){
                                this.userCheck = false;
                                setTimeout(() => {
                                    this.buttonDisable = true;
                                    this.buttonDisable = false;
                                    this.buttonLink = 'Sending Link ...';
                                    this.linkSent = true
                                },300)
                              
                            }
                            else{
                                this.buttonLink = 'Send link';
                                this.userCheck = true;
                            }
                    })
            }
            else{
                this.userCheck = false;
                this.UserError = true
            }
        }
    }
}
</script>
