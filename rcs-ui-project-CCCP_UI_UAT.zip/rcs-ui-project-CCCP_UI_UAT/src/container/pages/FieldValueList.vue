<template>
    <div>
        <section class="top-section">
            <div class="top-container">
                <div class="top-content">
                    <div class="row">
                        <div class="col-lg-6">
                            <h1 class="page-title">
                                {{pagename}}
                            </h1>
                        </div>
                        <div class="col-lg-6">
                            <ul class="breadcrumbs float-right">
                                <li><router-link to="/claims-status">List of Claims ></router-link></li>
                                <li class="active">Claim Status</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="claim-details-view main-card">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                          <h3>Claim Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-3 col-md-4 col-sm-6" v-for="(field_list, index) in form_data" :key="index">
                                    <div class="claim-details-item">
                                        <p>
                                            {{field_list.label}} <span>{{(multi_section_form_data && multi_section_form_data[field_list.model]!=null) ? multi_section_form_data[field_list.model] : '-'}}</span>
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-2 d-flex">
                              <div class="survey-btn">
                                <a href="#" class="btn btn-primary pull-right" @click="navigateUrl">Back</a>
                              </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </section>
    </div>
</template>

<script>
const FilterForm = () => import(`@/components/common/form/BasicForm`)
const TableDisplay = () => import(`@/components/table/Table`)
import {ClaimsListHeader} from '@/datas/TableHeaders/ClaimsList'
import {mapState} from 'vuex'
import GlobalMixin from '@/mixins/GlobalMixins.js'
import {GetPageFields, FetchPageData} from '@/apis/ApiDatas'
export default {
    name:'SingleFilter',
        mixins:[GlobalMixin],
        data(){
            return {
                displayTable : false,
                sesionData : {},
                tableExec : false,
                show_dialog : true,
                table_type: true,
                table_display : true,
                form_data : [],
                pagename: '',
                updated_value : [],
                highlightFields : ['taskRefNumber'],
                priorityValue:[{text: `Select Priority`,value: null}],
                table_data : {
                    api_url : '' ,
                    header : ClaimsListHeader() ,
                    multi_sort : false,
                    action:true,
                    pagination:true,
                    pagination_mode: "",
                    perpage : 8,
                    api_mode : "",
                },
            }
        },
        components:{
            FilterForm,
            TableDisplay
        },
        mounted(){
            this.upodateData();
            this.GetFormFields()
        },
        computed:{
            ...mapState({
                page_fields : state => state.multi_section_page_fields,
                multi_section_form_data : state => state.multi_section_form_data,
            }),
        },
        watch:{
            "$store.state.active_page":function(){
                this.GetFormFields()
                this.displayTable = false
            }
        },
        methods:{
            navigateUrl(){
                this.$router.push({
                    name : 'claims-status'
                })
            },
            async GetFormFields(){
                let tempDetails = GetPageFields();
                const passSectionCode = true;
                let tempReqCr = this.commonPageRequest(passSectionCode);
                let createReq = {
                    ...tempReqCr
                }
                console.log('createReq', createReq)
                tempDetails.requests = createReq
                let _details = await this.$store.dispatch("GetRequest", tempDetails);
                if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                    let tempFields = this.page_fields.datas;
                    this.pagename =  tempFields[0].header.displayName;
                    tempFields.forEach((list, index)=>{
                        if(list.body && list.body.length){
                            this.mapLookUpType(list.body, index)
                        }
                    });
                    this.form_data = tempFields[0].body
                    if(this.form_data && this.form_data.length){
                        this.getPageData();
                    }
                }
            },
            upodateData(){
                let dataDetails = this.GetSessionStorage('sesssion_details');
                if(dataDetails){
                    dataDetails = JSON.parse(dataDetails)
                    this.sesionData = dataDetails
                }
            },
            async getPageData(){
                let mockRequest = {
                    "userId":  this.user_profile_details.userId,
                    "roleCode": this.user_profile_details.role__code,
                    "imdCode":this.user_profile_details.imdCode,
                    "pageCode":this.active_page.pageCode,
                    "sectionCode": this.active_menu.sectionCode,
                    "claimNumber":this.sesionData.claimNumber,
                    "lob": "",
                    "policyNumber": "",
                    "claimStatus": "",
                    "policyStartDate": "",
                    "policyEndDate": "",
                    "claimHandler": "",
                    "take_obj":"claimDetailsDto"
                }
                let tempDetails = FetchPageData('fetchClaimDetails');
                tempDetails.requests = mockRequest;
                let _details = await this.$store.dispatch("GetRequest", tempDetails);
                if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                    console.log('_details', _details)
                }
            },
            async buttonAction(action){
                if(action=='reset'){
                    this.$store.state.tabel_filter_result = {}
                }
                else if(action=='submit'){
                    let validate = await this.$refs.filterFrom.validate();
                    if(validate){
                        this.formateSave()
                    }
                }
            },
        }
}
</script>