<template>
    <div>
          <div v-for="(form_list, index) in form_data" :key="index">
             <section class="top-section" >
                <div class="top-container" v-if="form_list.header.type!='table'">
                    <div class="top-content">
                        <h1 class="page-title">
                            {{form_list.header.description}}
                        </h1>
                    </div>
                </div>
            </section>

           
            <section  class="form-filter main-card" :key="index">
                <div class="row">
                    <div class="col-lg-12" v-if="form_list.header.type!='table' && form_list.header.attributes.tableType!='staticTable'">
                        <div class="card">
                           
                                <div class="card-header">
                                    <h3>{{form_list.header.displayName}}</h3>
                                </div>
                                <div class="card-body">
                                    <div class="form-filter-items" >
                                        <ValidationObserver v-slot="{}" :ref="form_list.header.sectionObj">
                                            <filter-form 
                                                filter_class="form-row"
                                                :display_submit="true" 
                                                :show_error="show_error"  
                                                :form_base="form_list.body"  
                                                form_name = "tabel_filter_result" 
                                                @onFilterSelect="getSelectValues"
                                                @onSearchFilter='onSearchFilter' 
                                                @onClearFilter='onClearFilter' 
                                                :date-format="onDateFormat" 
                                                :singleDatePicker='singleDatePicker'>                           
                                            </filter-form>
                                        </ValidationObserver>
                                    </div>
                                    <div class="row mt-4">
                                        <div class="col-lg-6 mx-auto text-center">
                                            <div class="filter-buttons">
                                                 <template v-if="form_list.header.filter_buttons">
                                                     <div class="button-item" v-for="(filter_buttons, index) in form_list.header.filter_buttons" :key="index">
                                                         <button :class="filter_buttons.className" type="submit" @click="buttonAction(filter_buttons.buttonCode, form_list.header.sectionObj, form_list)">{{filter_buttons.buttonName}}</button>
                                                    </div>
                                                </template>     
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>  
                   
                    <div class="row" v-if="form_list.header.attributes.tableType && (displayTableObject && displayTableObject[form_list.header.sectionObj] && displayTableObject[form_list.header.sectionObj]['display'])">
                         <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header" v-if="form_list.header.displayName">
                                    <h3>{{form_list.header.displayName}}</h3>
                                </div>
                                <div class="card-body">
                                    <template v-if="form_list.header.attributes.tableType=='serverTable'">
                                           <TableDisplay
                                            :tableHeaderObj="form_list.header.sectionObj"
                                            :table_date="displayTableObject[form_list.header.sectionObj]['tableData']" 
                                            :highlight_fields="highlightFields"
                                            :priority_value="priorityValue"
                                            @GetDetails="GetChangeFunction"
                                        ></TableDisplay>
                                    </template>
                                    <template v-if="form_list.header.attributes.tableType=='staticTable'">
                                        <template>
                                            <b-container fluid>
                                                <b-row>
                                                       <b-col lg="6" class="my-1 mb-4" >
                                                           <b-form-input  v-if="form_list.header.sectionObj== 'clientManagement'"
                                                            id="filter-input"
                                                            v-model="displayTableObject[form_list.header.sectionObj]['filter']"
                                                            @input="updateTextData(form_list.header.sectionObj, displayTableObject[form_list.header.sectionObj]['filter'])"
                                                            type="search"
                                                            placeholder="Type to Search"
                                                        ></b-form-input>
                                                    </b-col>
                                                    <b-col lg="6" class="my-1 mb-4 text-right">
                                                         <button class="btn btn-primary btn-sm" v-if="form_list.header.displayName != 'User Details'" type="submit" @click="buttonAction('staticSubmit',form_list.header.sectionObj, form_list)">Add {{form_list.header.displayName}}</button>
                                                    </b-col>
                                                </b-row>
                                                <div class="table-responsive">

                                                <b-table
                                                    :items="displayTableObject[form_list.header.sectionObj]['tableData']"
                                                    :fields="displayTableObject[form_list.header.sectionObj]['tableHeader']"
                                                    :current-page="displayTableObject[form_list.header.sectionObj]['currentPage']"
                                                    :per-page="displayTableObject[form_list.header.sectionObj]['perPage']"
                                                    :filter="displayTableObject[form_list.header.sectionObj]['filter']"
                                                    :sort-by.sync="displayTableObject[form_list.header.sectionObj]['sortBy']"
                                                    :sort-desc.sync="displayTableObject[form_list.header.sectionObj]['sortDesc']"
                                                    :sort-direction="displayTableObject[form_list.header.sectionObj]['sortDirection']"
                                                    stacked="md"
                                                    show-empty
                                                    
                                                    @filtered="onFiltered"
                                                >

                                                    <template #cell(sno)="row">
                                                        {{ row.index+1 }}
                                                    </template>
                                                    
                                                    <template v-slot:[gomycell(toggle_button)]="row" v-for="(toggle_button, toggle_index) in toggleButton">
                                                        <div :key="toggle_index">
                                                            <div v-if="row.item[toggle_button] == 'ACTIVE'" class="table-active"> {{row.item[toggle_button]}} </div>
                                                            <div v-if="row.item[toggle_button] == 'INACTIVE'" class="table-inactive"> {{row.item[toggle_button]}} </div>
                                                        </div>
                                                    </template>
                                                    <template v-slot:cell(file)="row">
                                                        <img :src="`data:image/png;base64,${row.item.userImg}`" class="te" alt="User" v-if="row.item.userImg" style="max-width:100px">
                                                        <img src="@/assets/images/user-profile-image.png" class="te" alt="User" v-else style="max-width:100px">
                                                    </template>
                                                    <template v-slot:cell(actions)="row">
                                                       <div class="icon-holder" @click="buttonAction('staticSubmit',form_list.header.sectionObj, form_list, row.item)">
                                                            <i class="fa fa-pencil"> </i>
                                                       </div>
                                                    </template>
                                                </b-table>
                                                </div>
                                                <b-row v-if="(displayTableObject[form_list.header.sectionObj]['tableData'] && form_list.header.sectionObj !== 'flashMessage'&& (displayTableObject[form_list.header.sectionObj]['tableData'].length >= displayTableObject[form_list.header.sectionObj]['perPage']))">
                                                    <b-col sm="1" md="1" class="my-1">
                                                        <b-form-group
                                                            class="mb-0"
                                                        >
                                                        <b-form-select
                                                            id="per-page-select"
                                                            v-model="displayTableObject[form_list.header.sectionObj]['perPage']"
                                                            @change="updateFilerData(form_list.header.sectionObj, displayTableObject[form_list.header.sectionObj]['perPage'])"
                                                            :options="displayTableObject[form_list.header.sectionObj]['pageOptions']"
                                                            size="sm"
                                                        ></b-form-select>
                                                        </b-form-group>
                                                    </b-col>
                                                    <b-col sm="3" md="3" class="my-1 float-right">
                                                        <b-pagination 
                                                            v-model="displayTableObject[form_list.header.sectionObj]['currentPage']"
                                                            :total-rows="displayTableObject[form_list.header.sectionObj]['totalRows']"
                                                            :per-page="displayTableObject[form_list.header.sectionObj]['perPage']"
                                                            align="fill"
                                                            size="sm"
                                                            class="my-0"
                                                        ></b-pagination>
                                                    </b-col>
                                                </b-row>
                                                <b-row v-if="form_list.header.sectionObj=='userTable'">
                                                    <b-col sm="12" md="12" class="text-center">
                                                        <div class="form-row align-items-center">
                                                            <div class="col-lg-4 col-md-4 col-sm-6 col-12 text-right">
                                                                <label for="PolicyNumber">Replicate User</label>
                                                            </div>
                                                            <div class="col-lg-4 col-md-2 col-sm-6 col-12">
                                                                <input type="text" class="form-control" placeholder="Enter User ID to Replicate" v-model="userIdReplicate">
                                                            </div>
                                                            <div class="col-auto align-self-end">
                                                                <button class="btn btn-success" type="submit" @click="replicateUser()">Submit</button>
                                                            </div>
                                                        </div>
                                                        <div class="form-row align-items-center" v-if="useridError">
                                                            <div class="col-lg-4 col-md-4 col-sm-6 col-12 text-right">
                                                            </div>
                                                            <div class="col-lg-4 col-md-2 col-sm-6 col-12">
                                                                <div class="text-danger text-left" >{{useridError}}</div>
                                                            </div>
                                                            <div class="form-group col-auto align-self-end">
                                                            </div>
                                                        </div>

                                                         
                                                    </b-col>
                                                </b-row>
                                            </b-container>
                                        </template>
                                    </template>
                                    <div class="row mt-4">
                                        <div class="col-lg-6 mx-auto text-center">
                                            <div class="filter-buttons">
                                                <template v-if="form_list.header.table_buttons">
                                                     <div class="button-item" v-for="(filter_buttons, index) in form_list.header.table_buttons" :key="index">
                                                        <button :class="filter_buttons.className" type="submit" @click="buttonAction(filter_buttons.buttonCode, form_list.header.sectionObj)">
                                                            <template v-if="filter_buttons && filter_buttons.svgImage">
                                                             <img :src="updateImagePath(`/${filter_buttons.svgImage}`)" alt="button image" class="img-fluid"/>
                                                            </template>
                                                            <template v-else>
                                                                {{filter_buttons.buttonName}}
                                                            </template>
                                                        </button>
                                                    </div>
                                                </template>     
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                    
            </section>
        </div>
        <FormModel v-if="displayPopup" 
            :footer="true" 
            @onClosePopup='onClosePopup' 
            :contentClass="(popupData && popupData.length && popupData.length>20) ? 'model-content-holder' : ''" 
            size="xl"
            title="User Details"
        >
            <template v-if="formDisplay.displayFrom">
            <ValidationObserver v-slot="{}" ref="popupFrom">
                <PopupFrom 
                    :form_base="popupData"
                    :show_error="show_error" 
                    :form_index="index"       
                    base_id="wbsingle_main"
                    form_name="popup_page_data_details"
                    :display_success="null"
                    @onSelectChange="GetUpdatedSelectValues"
                    @onInputChange="GetInputSelectValues"
                    @onMultiInputbox="GetMultiInputbox"
                    @onMultiFileUpload="onFileChangeFrom" 
                /> 
                    <div class="row mt-4">
                        <div class="col-lg-12 mx-auto text-center">
                            <div class="filter-buttons" >
                                <template v-if="popupButton">
                                    <div class="button-item" style="display: inline-block;" v-for="(filter_buttons, index) in popupButton" :key="index">
                                    
                                        <button :class="filter_buttons.className" class="mr-2"  type="submit" @click="buttonAction(filter_buttons.buttonCode)">{{filter_buttons.buttonName}}</button>
                                    </div>
                                </template>     
                            </div>
                        </div>
                    </div>
                </ValidationObserver>
            </template>
           
            <template v-else-if="formDisplay.displayUpload">
                     <div class="row">
                        <div class="col-12">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                </div>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="inputGroupFile01"
                                    aria-describedby="inputGroupFileAddon01"  @change="onFileChange" ref="inputFile">
                                    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                </div>
                            </div>
                                <!-- {{JSON.stringify(uploadedFile)}} - {{uploadedFile.name}} -->
                            <div class="row" v-if="uploadedFile && uploadedFile.name && showFileName">
                                <div class="col-12">
                                    <div class="upload-file">
                                        Choosed File : {{uploadedFile.name}}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 mt-4 text-center">
                            <button type="submit" class="btn btn-success" @click="UploadFile()"> Upload </button>
                        </div>
                    
                    
                </div>
            </template>
        </FormModel>
        <success-popup
            v-if="isSuccessPopup" 
            @onClosePopup='onClosePopup' 
            :okButtonClass="'case-status-ok-btn'" 
            :showOkButton='true' 
            :isSuccessPopup='true' 
            :success_content='success_content'
            :success_message='success_message'
            size='lg'
            :mainClass="'case-status-success'" 
            :closeButtonClass="'close m-0 p-0 case-status-success-btn'" 
            :iconClass="'flaticon-check text-center'" 
            :message="'Case Allocated Successfully'"
            :claimRefNo="claimRefNo"
        ></success-popup>
    </div>
</template>

<script>
const FilterForm = () => import(`@/components/common/form/BasicForm`)
const TableDisplay = () => import(`@/components/table/Table`)
const FormModel = () => import('@/components/common/Modal');
const PopupFrom = () => import('@/components/common/form/BasicForm')
const SuccessPopup = () => import(`@/components/common/models/SuccessPopup`)
import {ClaimsListHeader} from '@/datas/TableHeaders/ClaimsList'
import {mapState} from 'vuex'
import GlobalMixin from '@/mixins/GlobalMixins.js'
import {GetPageFields, TableConfigUrl, PopUpPageFields, SaveFormDetails, FormUploadDocument, GetTablePageData, ReplicateUser, SaveFlashMessage,SaveHierarchyPreference, SaveHierarchyUserDetails, SaveMenuAccess, SaveClientConfiguration} from '@/apis/ApiDatas'
 
export default {
    name:'MultipleFilter',
    mixins:[GlobalMixin],
    data(){
        
        return {
            currentUpload : '',
            currentSectionCode:'',
            getDataTableValues : {},
            uploadedFile : '',
            showFileName:false,
            toggleButton : ['dashboard', 'newClaimRegistration', 'claimDocumentUpload', 'claimStatus', 'reports', 'updateClaimDetails', 'configuration', 'isEnable', 'userIsActive', 'isActive'],
            useridError : '',
            userIdReplicate : '',
            fileUrl : '',
            editSection : {},
            popupButton:{},
            isSuccessPopup : false,
            success_content : '',
            success_message : '',
            currentActionForm : {},
            displayPopup : false,
            show_error: true,
            displayTable : false,
            displayTableObject : {},
            tableExec : false,
            show_dialog : true,
            table_type: true,
            table_display : true,
            form_data : [],
            popupData : [],
            pagename: '',
            updated_value : [],
            highlightFields : ['taskRefNumber'],
            priorityValue:[{text: `Select Priority`,value: null}],
            formDisplay : {
                displayFrom: false,
                displayUpload:false,
            },
            table_data : {
                api_url : '' ,
                header : ClaimsListHeader() ,
                multi_sort : false,
                action:true,
                pagination:true,
                pagination_mode: "",
                perpage : 8,
                api_mode : "",
            },
        items: [
          { isActive: true, age: 40, name: { first: 'Dickerson', last: 'Macdonald' } },
          { isActive: false, age: 21, name: { first: 'Larsen', last: 'Shaw' } },
          {
            isActive: false,
            age: 9,
            name: { first: 'Mini', last: 'Navarro' },
            _rowVariant: 'success'
          },
          { isActive: false, age: 89, name: { first: 'Geneva', last: 'Wilson' } },
          { isActive: true, age: 38, name: { first: 'Jami', last: 'Carney' } },
          { isActive: false, age: 27, name: { first: 'Essie', last: 'Dunlap' } },
          { isActive: true, age: 40, name: { first: 'Thor', last: 'Macdonald' } },
          {
            isActive: true,
            age: 87,
            name: { first: 'Larsen', last: 'Shaw' },
            _cellVariants: { age: 'danger', isActive: 'warning' }
          },
          { isActive: false, age: 26, name: { first: 'Mitzi', last: 'Navarro' } },
          { isActive: false, age: 22, name: { first: 'Genevieve', last: 'Wilson' } },
          { isActive: true, age: 38, name: { first: 'John', last: 'Carney' } },
          { isActive: false, age: 29, name: { first: 'Dick', last: 'Dunlap' } }
        ],
        fields: [
          { key: 'name', label: 'Person full name', sortable: true, sortDirection: 'desc' },
          { key: 'age', label: 'Person age', sortable: true, class: 'text-center' },
          {
            key: 'isActive',
            label: 'Is Active',
            formatter: (value, key, item) => {
              return value ? 'Yes' : 'No'
            },
            sortable: true,
            sortByFormatted: true,
            filterByFormatted: true
          },
          { key: 'actions', label: 'Actions' }
        ],
        currentPage: 1,
        perPage: 5,
        pageOptions: [5, 10, 15, { value: 100, text: "Show a lot" }],
        sortBy: '',
        testAction: ''
      }
        
    },
    components:{
        FilterForm,
        TableDisplay,
        FormModel,
        PopupFrom,
        SuccessPopup
    },
    mounted(){
        console.log('jk mounted')
        this.emptyFilter();
        // this.GetFormFields()

    },
    computed:{
        ...mapState({
            page_fields : state => state.multi_section_page_fields,
            popup_page_data : state => state.popup_page_data_details,
            table_page_data: state => state.table_data,
        }),
        sortOptions() {
            return this.fields
            .filter(f => f.sortable)
            .map(f => {
                return { text: f.label, value: f.key }
            })
        }
    },
    watch:{
        
        "$store.state.request_failure.upload":function(newValue){
            if(newValue){
                this.onClosePopup()
            }
        },
        "$store.state.active_page":function(){
            this.emptyFilter();
            this.show_error = false
            this.GetFormFields()
            this.displayTable = false
        },immediate: true
    },
    methods:{
        gomycell(key) {
            return `cell(${key})`; // simple string interpolation
        },
        async replicateUser(){
            if(this.userIdReplicate){
                this.useridError = ''
                let tempData = {
                    "userId":  this.user_profile_details.userId,
                    "roleCode": this.user_profile_details.role__code,
                    "imdCode": this.user_profile_details.imdCode,
                    "pageCode": "CLAIMREG",
                    "sectionCode": "CLAIMREG",
                    "fromUserId": this.$store.state.tabel_filter_result.searchUserId,
                    "replicateUserId": this.userIdReplicate
                }
                this.$store.state.tabel_filter_result.searchUserId
                let finalRequest = ReplicateUser();
                finalRequest.requests = tempData
                let tempRequest = await this.$store.dispatch("PostRequest", finalRequest);
                if(tempRequest.body && tempRequest.body.status && tempRequest.body.status.toLowerCase()=='success'){
                    this.togglePopup('close');
                    this.isSuccessPopup = true 
                    this.success_content = true
                    this.success_message = 'User Details has been Replicated successfully.'
                }
            }
            else{
                this.useridError = 'Enter User ID to Replicate'
            }
        },
        updateFilerData(sectionObj, value){
            let tempData = {...this.displayTableObject}
            tempData[sectionObj]['perPage'] = value
            this.displayTableObject = {...tempData}
        },
        updateTextData(sectionObj, value){
            let tempData = {...this.displayTableObject}
            tempData[sectionObj]['filter'] = value
            this.displayTableObject = {...tempData}
        },
        onFiltered(filteredItems, filteredCheck) {
             console.log('onFiltered', filteredItems, filteredCheck)
            // this.totalRows = filteredItems.length
            this.currentPage = 1
        },
        onClosePopup(){
            this.togglePopup('close')
            this.showFileName = false;
            this.isSuccessPopup = false;
                 if(this.currentSectionCode === "userSearch"){
                    this.displayTableObject.userSearch.display = false;
                    setTimeout(() => {
                        this.displayTableObject.userSearch.display = true;
                    },500)
                }
                else if(this.currentSectionCode === "menuSearch"){
                    this.displayTableObject.menuSearch.display = false;
                    setTimeout(() => {
                        this.displayTableObject.menuSearch.display = true;
                    },500)
                }
                else if(this.currentSectionCode === "clientFields"){
                    this.displayTableObject.clientFields.display = false;
                    setTimeout(() => {
                        this.displayTableObject.clientFields.display = true;
                    },500)
                }
                
         },
        onFileChange(e) {
            console.log('onFileChange', e)
            const file = e.target.files[0];
            this.uploadedFile = e.target.files[0];
            this.fileUrl = URL.createObjectURL(file);
            this.showFileName = true; 
        },
        onFileChangeFrom(e, model) {
            console.log('onFileChangeFrom',  e, model)
            const file = e[0];
            this.uploadedFile = e[0];
            console.log('this.uploadedFile', this.uploadedFile)
            this.fileUrl = URL.createObjectURL(file); 
        },
        async UploadFile(){
             if(this.fileUrl){
                this.$store.state.request_failure.upload = false;
                let form_uploads = new FormData()
                let tempRequest = {
                    "userId":  this.user_profile_details.userId,
                    "roleCode": this.user_profile_details.role__code,
                    "imdCode":this.user_profile_details.imdCode,
                    "pageCode":this.active_page.code,
                    "sectionCode":this.active_page.pageCode,
                }
                let convertedReq = this.EncodeString(tempRequest);
                form_uploads.append("payload", convertedReq)
                form_uploads.append("file", this.uploadedFile)
                 let _temp_details =  FormUploadDocument('uploadParnterDetails');
                 console.log("this.currentUpload", this.currentUpload)
                if(this.currentUpload == "uploadClientFields"){
                    _temp_details =  FormUploadDocument('uploadRunTimeFieldsConfig');
                }
                if(this.currentUpload == 'uploadUserAccess'){ 
                     _temp_details =  FormUploadDocument('uploadUserMenuAccess'); 
                }
                
                _temp_details.requests = form_uploads;
                let _details = await this.$store.dispatch("FileUpload", _temp_details);
                if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                    this.fileUrl = '';
                    this.uploadedFile = '';
                    this.$refs.inputFile.value=null 
                    this.togglePopup('close');
                    this.isSuccessPopup = true;
                    this.success_content = true
                    if(this.currentUpload=='uploadUserAccess'){ 
                         this.success_message = 'Menu Access has been upload successfully.'
                         this.re_render_table = 'menuSearch';
                    }
                    else if(this.currentUpload=='uploadClientFields'){ 
                        this.success_message = 'Client Fields Configuration has been upload successfully.'
                    }
                    else{
                        this.success_message = 'User Details has been upload successfully.'
                        this.re_render_table = 'userSearch';
                    }
                    
                }
                else {
                   this.onClosePopup()
                }
            }
        },
        
        async GetFormFields(displayTable=null){
            let tempDetails = GetPageFields();
            let tempReqCr = this.commonPageRequest();
            let createReq = {
                "userId":"admin",
                "roleCode":"ADMIN",
                "imdCode":this.user_profile_details.imdCode,
                "pageCode":"CLAIMREG",
                "sectionCode":"CLAIMREG",
                ...tempReqCr
            }
            tempDetails.requests = createReq
            console.log('jk123', tempDetails)
            let _details = await this.$store.dispatch("GetRequest", tempDetails);
            console.log('page_fields', _details)
            if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                let tempFields = this.page_fields.datas;
                let loopexe = 0;
                for (const list in  tempFields) {
                    let getUrl = GetTablePageData(tempFields[list].header.sectionObj);
                    console.log('getUrlHelp', getUrl, tempFields[list].header.sectionObj)
                    getUrl.requests = {
                        "userName": this.user_profile_details.userId,
                        "userId":  this.user_profile_details.userId,
                        "roleCode": this.user_profile_details.role__code,
                        "imdCode":this.user_profile_details.imdCode,
                        "pageCode":this.active_page.code,
                        "sectionCode":this.active_page.pageCode,
                        "partnerId": this.user_profile_details.partnerId,
                        "searchUserId": this.$store.state.tabel_filter_result.searchUserId,
                        "corporateUserId": ""
                    }
                    if(getUrl && getUrl.url){
                        
                        let tempRequest = await this.$store.dispatch("GetRequest", getUrl);
                        if(tempRequest.body && tempRequest.body.status && tempRequest.body.status.toLowerCase()=='success'){
                            if(tempFields[list].body && tempFields[list].body.length>=0){
                                let getLength = JSON.parse(JSON.stringify(this.table_page_data))
                                 this.displayTableObject[tempFields[list].header.sectionObj] = {
                                    display : (displayTable==null) ? tempFields[list].header.tableDisplay : true,
                                    tableData : getLength,
                                    tableHeader : tempFields[list].header.tabelHeader,
                                    currentPage : 1,
                                    perPage : 5,
                                    pageOptions: [5, 10, 15],
                                    sortBy: '',
                                    sortDesc: false,
                                    sortDirection: 'asc',
                                    filter: null,
                                    totalRows : getLength.length,
                                    api_url : '' ,
                                    header : tempFields[list].header.tabelHeader,
                                    multi_sort : false,
                                    action:true,
                                    pagination:true,
                                    pagination_mode: "",
                                    api_mode : "",
                                }
                                this.mapLookUpType(tempFields[list].body, loopexe)
                            }
                        }
                    }
                    else{
                          if(tempFields[list].body && tempFields[list].body.length){
                            let getLength = JSON.parse(JSON.stringify(this.table_page_data))
                            this.displayTableObject[tempFields[list].header.sectionObj] = {
                                display : tempFields[list].header.tableDisplay,
                                tableData : getLength,
                                tableHeader : tempFields[list].header.tabelHeader,
                                currentPage : 1,
                                perPage : 5,
                                pageOptions: [5, 10, 15, { value: 100, text: "Show a lot" }],
                                sortBy: '',
                                sortDesc: false,
                                sortDirection: 'asc',
                                filter: null,
                                totalRows : getLength.length,
                                header : tempFields[list].header.tabelHeader,
                            }
                            this.mapLookUpType(tempFields[list].body, loopexe)
                        }
                    }
                    loopexe+=1
                }
                this.form_data = tempFields
            }
        },
        async buttonAction(action, sectionCode, sectionDetails, sectionData){
             console.log('buttonAction', action, sectionCode, sectionDetails, sectionData)
            if(action=='reset'){
                this.$store.state.tabel_filter_result = {}
            }
            else if(action=='popupreset'){
                this.$store.state.popup_page_data_details = {}
            }
            else if(action=='downloadExcel'){
                let tempDoc = this.currentActionForm
                let docName = '';
                if(sectionCode == "userSearch"){
                    docName = "user-partner-config.xlsx";
                }else if(sectionCode == "menuSearch"){
                     docName = "user_menu_config.xlsx";
                }else{
                    docName = "client_fields_configuration.xlsx";
                }
                this.downloadDoc({
                    "pageCode":this.active_page.code,
                    "sectionCode":this.active_page.pageCode,
                    "docId": "",
                    "docName": (docName) ? docName : '',
                    "templateType":tempDoc.header.template_type
                })
            }
            else if(action=='uploadLoader' || action=='uploadUserAccess' || action=='uploadClientFields'){
                this.currentUpload = action;
                this.currentSectionCode = sectionCode;
                this.togglePopup('open','displayUpload');
            }
            else if(action=='updateclientField'){
              this.updateClientFieldConfiguration(sectionData)
            }
            else if(action=='addFlashMesg'){
                this.currentActionForm = sectionDetails
                this.displayTogglepopup()
            }
            else if(action=='submit'){
                 this.show_error = true
                let validate = await this.$refs[sectionCode][0].validate();
                if(validate){
                    this.formateSave(sectionCode, sectionDetails.header)
                    // this.displayTableObject.userSearch.tableHeader[8].sortable = false;
                }
            }
           
            else if(action=='staticSubmit'){
                if(sectionDetails && sectionDetails.header && sectionDetails.header.tabelHeader){
                    this.popup_page_data = {};
                    this.$store.state.popup_page_data_details =  {};
                    this.displayToggleStaticpopup(sectionDetails.header, sectionDetails, sectionData)
                }
            }
            else if(action=='updateUser'){
                let validate = await this.$refs.popupFrom.validate();
                if(validate){
                    this.savePopup()
                }
            }
             else if(action=='updateMenuAccess'){
                let validate =  await this.$refs.popupFrom.validate();
                if(validate){
                    this.saveMenuAccess()
                }
            }
            else if(action=='updateFlashMesg'){
                let validate = await this.$refs.popupFrom.validate();
                if(validate){
                    this.saveFlashMessage()
                }
            }

            else if(action=='updateUserHierarchy'){
                let validate = await this.$refs.popupFrom.validate();
                if(validate){
                    this.saveHierarchyPreference()
                }
            }

            else if(action=='updateClientManagement'){
                let validate = await this.$refs.popupFrom.validate();
                if(validate){
                    this.saveClaimManagament()
                }
            }
        },
        async savePopup(){
            let finalRequest = SaveFormDetails('saveUserDetails', this.$route.params.page_name)
            finalRequest.requests = {
                ...this.popup_page_data,
                "userName": this.popup_page_data.userId,
                "userId":  this.user_profile_details.userId,
                "roleCode": this.user_profile_details.role__code,
                "imdCode":this.user_profile_details.imdCode,
                "pageCode":this.active_page.code,
                "sectionCode":this.active_page.pageCode,
            }
            let tempRequest = await this.$store.dispatch("PostRequest", finalRequest);
            if(tempRequest.body && tempRequest.body.status && tempRequest.body.status.toLowerCase()=='success'){
                this.togglePopup('close');
                this.isSuccessPopup = true 
                this.success_content = true
                this.success_message = 'User Details has been updated successfully.'
                this.GetFormFields(true)
            }
        },

        async saveMenuAccess(){
            let finalRequest = SaveMenuAccess()
            finalRequest.requests = {
                ...this.popup_page_data,
                "userName": this.popup_page_data.userId,
                "userId":  this.user_profile_details.userId,
                "roleCode": this.user_profile_details.role__code,
                "imdCode":this.user_profile_details.imdCode,
                "pageCode":this.active_page.code,
                "sectionCode":this.active_page.pageCode,
            }
            let tempRequest = await this.$store.dispatch("PostRequest", finalRequest);
            if(tempRequest.body && tempRequest.body.status && tempRequest.body.status.toLowerCase()=='success'){
                this.togglePopup('close');
                this.isSuccessPopup = true 
                this.success_content = true
                this.success_message = 'User Details has been updated successfully.'
                this.GetFormFields(true)
            }
        },
        async updateClientFieldConfiguration(){
            let getPopupData = this.popup_page_data;
            let sectionDataDetails = this.getDataTableValues
            let createLoop = []
            let createData = {
                policyNumber:sectionDataDetails.policyNumber,
                partnerId:sectionDataDetails.partnerId,
                effectiveFromDate:sectionDataDetails.effectiveFromDate,
            }
            for(let exec = 0; exec<=19; exec++){
                let fieldData = this.popupData[exec*2]
                if(fieldData && fieldData.fieldCode){
                    createLoop[exec] = {
                        "fieldCode":(fieldData) ? fieldData.fieldCode : '',
                        "fieldType":(fieldData) ? fieldData.type : '',
                        "fieldName":(getPopupData && getPopupData[`display${exec+1}`]) ? getPopupData[`display${exec+1}`] :'',
                        "isActive":(getPopupData && getPopupData[`isActive${exec+1}`]) ? getPopupData[`isActive${exec+1}`] :false,
                        "orderNo":(fieldData) ? fieldData.orderNo : '',
                    }
                }
            }
            createData['fieldDetails'] = createLoop;
            let tempData = SaveClientConfiguration();
            tempData.requests = createData;
            let _details = await this.$store.dispatch("PostRequest", tempData);
            if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                this.togglePopup('close');
                this.isSuccessPopup = true 
                this.success_content = true
                this.$store.state.popup_page_data_details = {}
                this.success_message = 'Clients Fields Configuration has been successfully.'
                this.GetFormFields(true)
            }
           
        },
        async displayTogglepopup(values, type=''){
            this.togglePopup('open','displayFrom');
            let currentForm = this.currentActionForm
            if(type=='menuSearch'){
                let getTableDetails = this.form_data.find((list)=>list.header.sectionObj==type)
                console.log('getTableDetails', getTableDetails)
                if(getTableDetails){
                    this.popupTitle =  getTableDetails.header.displayName;
                    let tempFields = getTableDetails.body.filter(list=>list.filter_display==true);
                    tempFields.forEach((list, index)=>{
                        if(list.body && list.body.length){
                            this.mapLookUpType(list.body, index)
                        }
                    });
                    this.popupData = tempFields
                    let popupButton = getTableDetails.header.popup_button;
                    if(popupButton){
                        this.popupButton = popupButton
                    }
                    this.$store.state.popup_page_data_details = {...values}
                }
            }
            else{
                let tempReq = PopUpPageFields();
                tempReq.requests = {
                    "userId":  this.user_profile_details.userId,
                    "roleCode": this.user_profile_details.role__code,
                    "imdCode":this.user_profile_details.imdCode,
                    "pageCode":this.active_page.code,
                    "sectionCode":currentForm.header.popup_code
                }
                let _details = await this.$store.dispatch("GetRequest", tempReq);
                if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                    let tempFields = this.page_fields.datas;
                    this.popupTitle =  tempFields[0].header.displayName;
                    tempFields.forEach((list, index)=>{
                        if(list.body && list.body.length){
                            this.mapLookUpType(list.body, index)
                        }
                    });
                    this.popupData = tempFields[0].body
                    this.$store.state.popup_page_data_details = {...values}
                    let popupButton = currentForm.header.popup_button;
                    if(popupButton){
                        this.popupButton = popupButton
                    }
                }
            }
        },

        async displayToggleStaticpopup(headerDetails, fieldList,sectionData){
            this.editSection = sectionData;
            console.log('sectionData', sectionData)
           
            let tempFields = fieldList
            tempFields.body = tempFields.body.filter(list=>list.filter_display==true);
            this.popupTitle =  headerDetails.displayName;
            if(tempFields.body && tempFields.body.length){
                this.mapLookUpType(tempFields.body, 0)
            }
            this.popupData = tempFields.body
            this.$store.state.popup_page_data_details = {...sectionData};
            let popupButton = headerDetails.popup_button;

            if(popupButton){
                this.popupButton = popupButton
            }
            this.togglePopup('open','displayFrom');
        },

        

        async saveHierarchyPreference(){
            let tempData = {
                "userId":  this.user_profile_details.userId,
                "roleCode": this.user_profile_details.role__code,
                "imdCode":this.user_profile_details.imdCode,
                "pageCode": "CLAIMREG",
                "sectionCode": "CLAIMREG",
                "corporateUserId": "",
                "msgId":'',
                "fromUserId": this.userIdReplicate,
                "searchUserId": this.$store.state.tabel_filter_result.searchUserId,
                "isEnable": '',
                "message":'',
                 ...this.editSection,
                 ...this.popup_page_data,
            }

            let finalRequest = SaveHierarchyPreference();
            finalRequest.requests = tempData
            let tempRequest = await this.$store.dispatch("PostRequest", finalRequest);
            if(tempRequest.body && tempRequest.body.status && tempRequest.body.status.toLowerCase()=='success'){
                this.togglePopup('close');
                this.isSuccessPopup = true 
                this.success_content = true
               this.$store.state.popup_page_data_details = {}
                this.success_message = 'User Flash message has been successfully.'
                this.GetFormFields(true)
            }
        },

        async saveFlashMessage(){
            let tempData = {
                "userId":  this.user_profile_details.userId,
                "roleCode": this.user_profile_details.role__code,
                "imdCode": this.user_profile_details.imdCode,
                "pageCode": "CLAIMREG",
                "sectionCode": "CLAIMREG",
                "corporateUserId": "",
                "msgId":'',
                "fromUserId": this.userIdReplicate,
                "searchUserId": this.$store.state.tabel_filter_result.searchUserId,
                "isEnable": '',
                "message":'',
                 ...this.editSection,
                 ...this.popup_page_data,
            }

            let finalRequest = SaveFlashMessage();
            finalRequest.requests = tempData
            let tempRequest = await this.$store.dispatch("PostRequest", finalRequest);
            if(tempRequest.body && tempRequest.body.status && tempRequest.body.status.toLowerCase()=='success'){
                this.togglePopup('close');
                this.isSuccessPopup = true 
                this.success_content = true
                this.$store.state.popup_page_data_details = {}
                this.success_message = 'User Flash message has been successfully.'
                this.GetFormFields(true)
            }
        },

         async saveClaimManagament(){
            let form_uploads = new FormData()
            let tempRequest = {
                ...this.editSection,
                ...this.popup_page_data,
                "userId":  this.user_profile_details.userId,
                "roleCode": this.user_profile_details.role__code,
                "imdCode":this.user_profile_details.imdCode,
                "pageCode":this.active_page.pageCode,
                "searchUserId": this.$store.state.tabel_filter_result.searchUserId,
                
            }
            let convertedReq = this.EncodeString(tempRequest);
            form_uploads.append("payload", convertedReq)
            form_uploads.append("file", this.uploadedFile)
            let _temp_details =  SaveHierarchyUserDetails()      
            _temp_details.requests = form_uploads;
            let _details = await this.$store.dispatch("FileUpload", _temp_details);
            if(_details.body && _details.body.status && _details.body.status.toLowerCase()=='success'){ 
                this.togglePopup('close');
                this.isSuccessPopup = true 
                this.success_content = true
                this.$store.state.popup_page_data_details = {}
                this.success_message = 'Client Management has been saved successfully.'
                this.GetFormFields(true)
            }
        },

        async GetChangeFunction(type, values){
            this.getDataTableValues = values
            if(type=='claim_details'){
                this.displayTogglepopup(values)
            }
            else if(type=='menuSearch'){
                this.displayTogglepopup(values, type)
            }
            else if(type=='add-record'){
                let processUpdates = values
                if(processUpdates && processUpdates.fieldDetails){
                    processUpdates.fieldDetails.forEach((list_details, list_index)=>{
                        processUpdates[`display${list_index+1}`] = list_details.fieldName
                        processUpdates[`isActive${list_index+1}`] = list_details.isActive
                    })
                    console.log('processUpdates.fieldDetails', processUpdates)
                }
                this.displayTogglepopup(values, type)
            }
        },



        formateSave(sectionHeaderCode, sectionDetails){
            console.log('sectionDetailsMain', sectionDetails)
            let getApiName = sectionHeaderCode.replace('Filter', '')
            let mockRequest = {
                "userId":  this.user_profile_details.userId,
                "roleCode": this.user_profile_details.role__code,
                "imdCode":this.user_profile_details.imdCode,
                "pageCode":this.active_page.pageCode,
                "sectionCode": "",
                "policyNumber": "",
                "claimStatus": "",
                "policyStartDate": "",
                "policyEndDate": "",
                "claimHandler": "",
                "partnerId": ""
            }
            
            let getUrl = this.getTableUrl(getApiName);
            console.log('getApiName', getApiName, sectionHeaderCode, sectionDetails, getUrl)
            if(getUrl){
                let getTableDetails = this.form_data.find(list=>list.header.sectionObj==getApiName)
                console.log('getTableDetails', getTableDetails, getApiName)
                if(getTableDetails){
                    let table_data = {
                        api_url : '' ,
                        header : '',
                        multi_sort : false,
                        action:true,
                        pagination:true,
                        pagination_mode: "",
                        perpage : 8,
                        api_mode : "",
                    };
                    let formDetils = this.$store.state.tabel_filter_result;
                    let finalData = this.formatePageData(formDetils, getTableDetails.body)
                    let tempDetails = this.EncodeString({...mockRequest, ...finalData});
                    table_data.api_url = TableConfigUrl(tempDetails, {
                        table_url :getUrl.url,
                        main_filter : this.user_profile_details.userId,
                        table_sort : ''
                    },getUrl.inter).url
                   
                    this.displayTable = true;
                   
                    let tempData = this.displayTableObject;
                     this.displayTableObject = {...tempData}
                    console.log('tempDatamain', tempData)
                    tempData[getApiName]['display'] = true;
                    tempData[getApiName]['tableData'] = table_data;
                  
                    table_data.header = this.displayTableObject[getApiName]['tableHeader']
                    console.log("tablealladate",table_data)
                }
            }
            else if(sectionDetails && sectionDetails.attributes && sectionDetails.attributes.displaySection){
                let tempData = this.displayTableObject;
                sectionDetails.attributes.displaySection.forEach((list)=>{
                    if(tempData && tempData[list]){
                        tempData[list]['display'] = true;
                    }
                })
                console.log('tempData', tempData)
                this.displayTableObject = {...tempData}
                this.GetFormFields(true)
            }
        },
        getTableUrl(sectionHeaderCode){
            let getFilterHeader = this.form_data.find(list=>list.header.sectionObj==sectionHeaderCode)
            this.currentActionForm = getFilterHeader
            let routeName = this.$route.params.page_name
            let checkUrl = {
                'userSearch' : {
                    url : 'userSearchSysConfig',
                    isCommon: true,
                    inter : '',
                },
                
                'menuSearch' : {
                    url : 'fetchUserAccess',
                    isCommon: true,
                    inter : '',
                },
                'clientFields' : {
                    url : 'searchRuntimeFieldsConfig',
                    isCommon: false,
                    inter : '',
                },
                'flashMesgSearch' : {
                    url : 'fetchFalshMessageList',
                    inter : 'home',
                    isCommon: true,
                },
            }
            // let updateTableDisplay = {...this.displayTableObject}
            // updateTableDisplay[sectionHeaderCode]['display'] = true;
            // this.displayTableObject = updateTableDisplay
            
            let checkData = checkUrl[routeName];
            if(!checkData){
                checkData = checkUrl[sectionHeaderCode];
            }
            console.log('checkData', checkData)
            return checkData;
        },
        togglePopup(popUpAction='open', targetPopup){
             if(popUpAction=='open'){
                this.isSuccessPopup = false;
            }
            else{
                this.displayPopup = false 
            }
            
            for(let subform in this.formDisplay){
                this.formDisplay[subform] = false;
            }
            if(popUpAction=='close'){
                this.displayPopup = false;
            }
            else{
                this.displayPopup = true;
                this.formDisplay[targetPopup] = true
            }
        },
    }
}
</script>
<style>
.close-button-holder{
    position: absolute;
    right :0px;
}

.model-content-holder{
   height: 500px;
    overflow-y: scroll;
}
.table-active{
  color: #2ECC71;
  background-color: rgba(46, 204, 113, 0.1);
  text-align: center;
  border-radius: 5px;
  width: 100px;
  height: 30px;
  padding: 4px 20px;
}
.table-inactive{
  color: #D63031;
  background-color: rgba(214, 48, 49, 0.1);
  text-align: center;
  border-radius: 5px;
  width: 100px;
  height: 30px;
  padding: 4px 17px;
}
</style>