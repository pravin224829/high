import {CaseStatusDisplay} from '@/shared/custom'

const ClaimsListHeader = (arg) => {
    let header = [
        {
            name: "SNO",    
            sortField: "SNO",
            title: 'S No',
            icon : "",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
        {
            name: (arg === 'NHAI') ? 'uploadnhai' :"actions",
            sortField: "actions",
            title: (arg === 'NHAI') ? 'Upload' :'Actions',
            icon : "",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "policyNumber",
            icon:"policy-number.svg",
            sortField: "Policy Number",
            title: 'Policy Number',
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "insuredName",
            sortField: "insuredName",
            icon : "policy-holder-name.svg",
            title: 'Insured Name',
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "inspectionDate",
            sortField: "inspectionDate",
            title: 'Inception Date',
            icon:"calendar.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "expiryDate",
            sortField: "expiryDate",
            title: 'Expiry Date',
            icon:"calendar.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "productCode",
            sortField: "productCode",
            icon : "policy-imd-channel.svg",
            title: 'Product Code',
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "productDescription",
            sortField: "productDescription",
            title: 'Product Desc.',
            icon : "policy-description.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "imdChannel",
            sortField: "imdChannel",
            title: 'IMD Channel',
            icon : "policy-imd-channel.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "sumInsured",
            sortField: "sumInsured",
            title: 'Sum Insured',
            icon:"policy-sum-insured.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: false,
            togglable: false
        },
    
    
        {
            name: "policyStatus",
            sortField: "policyStatus",
            title: 'Policy Status',
            icon:"policy-status.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
       
    
    ];
    return header
}


const ClaimsListPolicyVerificationHeader = () => {
    let header = [
        {
            name: "SNO",    
            sortField: "SNO",
            title: 'S No',
            icon : "",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
        {
            name: "uploadnhai",
            sortField: "actions",
            title: 'Document',
            icon : "",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
         },

    
        {
            name: "policyNumber",
            icon:"policy-number.svg",
            sortField: "Policy Number",
            title: 'Policy Number',
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "insuredName",
            sortField: "insuredName",
            icon : "policy-holder-name.svg",
            title: 'Insured Name',
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "inspectionDate",
            sortField: "inspectionDate",
            title: 'Inception Date',
            icon:"calendar.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "expiryDate",
            sortField: "expiryDate",
            title: 'Expiry Date',
            icon:"calendar.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "productCode",
            sortField: "productCode",
            icon : "policy-imd-channel.svg",
            title: 'Product Code',
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "productDescription",
            sortField: "productDescription",
            title: 'Product Desc.',
            icon : "policy-description.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "imdChannel",
            sortField: "imdChannel",
            title: 'IMD Channel',
            icon : "policy-imd-channel.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "sumInsured",
            sortField: "sumInsured",
            title: 'Sum Insured',
            icon:"policy-sum-insured.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: false,
            togglable: false
        },
    
    
        {
            name: "policyStatus",
            sortField: "policyStatus",
            title: 'Policy Status',
            icon:"policy-status.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
       
    
    ];
    return header
}

const CliamDocumentUpload = (action, type, page) => {
    let header = [
       
        {
            name: "SNO",    
            sortField: "SNO",
            title: 'S No',
            icon : "",
            titleClass: "text-left",
            dataClass: "text-left",
            moduleList : [],
            displayTable : true,
            filterable: true,
            togglable: true
        },
        {
            name: action,
            sortField: action,
            title: 'Actions',
            moduleList : [],
            icon : "",
            titleClass: "text-left",
            dataClass: "text-left",
            displayTable : true,
            filterable: true,
            togglable: true
        },
    
        {
            name: "claimNumber",
            icon:"hash.svg",
            sortField: "Claim Number",
            title: 'Claim Number',
            titleClass: "text-left",
            moduleList : ['claim-document-upload-list'],
            dataClass: "text-left",
            displayTable : true,
            filterable: true,
            togglable: true
        },
    
        {
            name: "insuredName",
            sortField: "insuredName",
            icon:"insured-name.svg",
            moduleList : ['claim-document-upload-list'],
            title: 'Insured Name',
            titleClass: "text-left",
            dataClass: "text-left",
            displayTable : true,
            filterable: true,
            togglable: true
        },

        {
            name: "policyNumber",
            icon:"hash.svg",
            sortField: "policyNumber",
            moduleList : ['claim-document-upload-list'],
            title: 'Policy Number',
            titleClass: "text-left",
            dataClass: "text-left",
            displayTable : true,
            filterable: true,
            togglable: true
        },

        {
            name: "claimStatus",
            icon:"hash.svg",
            sortField: "Claim Status",
            moduleList : ['claim-document-upload-list'],
            title: 'Claim Status',
            titleClass: "text-left",
            dataClass: "text-left",
            displayTable : false,
            filterable: true,
            togglable: true
        },

       

        {
            name: "pendingAge",
            icon:"hash.svg",
            sortField: "pendingAge",
            moduleList : ['claim-document-upload-list'],
            title: 'Pending Age',
            titleClass: "text-left",
            dataClass: "text-left",
            displayTable : false,
            filterable: true,
            togglable: true
        },

        {
            name: "claimHandler",
            icon:"hash.svg",
            sortField: "claimHandler",
            moduleList : ['claim-document-upload-list'],
            title: 'Claim Handler',
            titleClass: "text-left",
            dataClass: "text-left",
            displayTable : false,
            filterable: true,
            togglable: true
        },
    
        {
            name: "dateOfLoss",
            sortField: "dateOfLoss",
            title: 'Date of Loss',
            moduleList : [],
            icon:"pending-age.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "lossDescriptions",
            sortField: "lossDescriptions",
            title: 'Loss Descriptions',
            moduleList : [],
            icon:"claim-handler.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            displayTable : true,
            filterable: true,
            togglable: true
        },
    
        {
            name: "placeOfLoss",
            sortField: "placeOfLoss",
            moduleList : [],
            icon : "claim-status.svg",
            title: 'Place of Loss',
            titleClass: "text-left",
            dataClass: "text-left",
            displayTable : true,
            filterable: true,
            togglable: true
        },

        {
            name: "imdchannel",
            sortField: "imdchannel",
            moduleList : [],
            title: 'IMD Channel',
            icon : "policy-imd-channel.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            displayTable : true,
            filterable: true,
            togglable: true
        },
    
        {
            name: "productCode",
            sortField: "productCode",
            title: 'Product Code',
            moduleList : [],
            icon : "pending-age.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            displayTable : true,
            filterable: true,
            togglable: true
        },

        {
            name: "productName",
            sortField: "productName",
            title: 'Product Name',
            moduleList : [],
            icon : "pending-age.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            displayTable : true,
            filterable: true,
            togglable: true
        },

        {
            name: "sumInsured",
            sortField: "sumInsured",
            title: 'Sum Insured',
            moduleList : [],
            icon : "pending-age.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            displayTable : true,
            filterable: true,
            togglable: true
        },

        {
            name: "status",
            sortField: "status",
            title: 'Claim Status',
            moduleList : [],
            icon : "pending-age.svg",
            titleClass: "text-left",
            dataClass: "text-left",
            displayTable : true,
            filterable: true,
            togglable: true
        },
       
    ];

    if(type=='page'){
       
         let headerDetails = header.filter((list)=>list.moduleList.includes(page))
         return headerDetails;
    }
    else{
        let headerDetails = header.filter((list)=>list.displayTable==true)
        return headerDetails
    }
}


const CliamReport = () => {
    let header = [
        {
            name: "SNO",    
            sortField: "SNO",
            title: 'S No',
            icon : "",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        {
            name: "docListname",
            sortField: "docListname",
            icon : "",
            title: 'Report Description',
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
        {
            name: "exceldownactions",
            sortField: "exceldownactions",
            title: 'Actions',
            icon : "",
            titleClass: "text-center",
            dataClass: "text-center",
            filterable: true,
            togglable: true
        },
    
    ];
    return header
}

const ClaimDocumentList = () => {
    let header = [
        {
            name: "SNO",    
            sortField: "SNO",
            title: 'S No',
            icon : "",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
        {
            name: "docdownactions",
            sortField: "docdownactions",
            title: 'Actions',
            icon : "",
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
        {
            name: "documentName",
            sortField: "documentName",
            icon : "",
            title: 'Document Name',
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },

        {
            name: "uploadeddate",
            icon:"",
            sortField: "uploadeddate",
            title: 'Uploaded Date',
            titleClass: "text-left",
            dataClass: "text-left",
            filterable: true,
            togglable: true
        },
    
        // {
        //     name: "uploadStatus",
        //     sortField: "uploadStatus",
        //     title: 'Upload Status',
        //     icon:"calendar.svg",
        //     titleClass: "text-left",
        //     dataClass: "text-left",
        //     filterable: true,
        //     togglable: true,
        //     formatter: (value) => { 
        //         if(value){
        //           return CaseStatusDisplay(value);
        //         }
        //         else{
        //             return value;
        //         }
        //     }
        // },
    
    ];
    return header
}


export{
    ClaimsListHeader,
    CliamReport,
    ClaimsListPolicyVerificationHeader,
    CliamDocumentUpload,
    ClaimDocumentList
}