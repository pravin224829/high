// Elements Animation

if($('.wow').length){
    var wow = new WOW(
      {
        boxClass:     'wow',      // animated element css class (default is wow)
        animateClass: 'animated', // animation css class (default is animated)
        offset:       0,          // distance to the element when triggering the animation (default is 0)
        mobile:       true,       // trigger animations on mobile devices (default is true)
        live:         true       // act on asynchronously loaded content (default is true)
      }
    );
    wow.init();
}

AOS.init({
  easing: 'ease-out-back',
  duration: 1000
});

// Testimonial Carousel

// $('#job_carousel').owlCarousel({
//     items: 1,
//     loop: true,
//     nav: true,
//     dots: true,
//     margin: 30,
//     autoplay: true,
//     autoplayTimeout: 9000,
//     autoplayHoverPause: true,
//     smartSpeed: 1500,
//     navText: ["<i class='flaticon-left-arrow'></i>","<i class='flaticon-right-arrow'></i>"],
//     responsive: {
//       0: {
//           items:1
//       },
//       768: {
//           items: 1
//       },
//       992: {
//           items: 2
//       }
//   }
// });


//  Changing navbar background on scroll
// $(document).ready(function(){
//   $(window).scroll(function(){
//   	var scroll = $(window).scrollTop();
// 	  if (scroll>0) {
// 	    $(".navbar").css("background" , "#5A3ECB");
// 	  }
// 	  else{
// 		  $(".navbar").css("background" , "transparent");  	
// 	  }
//   })
// })



