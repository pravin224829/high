(function ($) {
	'use strict';

	var form = $('.contact__form'),
		message = $('.contact__msg'),
		form_data;

	// Success function
	function done_func(response) {
		message.fadeIn().removeClass('alert-bg').addClass('alert-bg');
		message.text(response);
		setTimeout(function () {
			message.fadeOut();
		}, 9000);
		form.find('input:not([type="submit"]), textarea').val('');

	}

	form.submit(function (e) {
		e.preventDefault();
		form_data = $(this).serialize();
		$.ajax({
				type: 'POST',
				url: form.attr('action'),
				data: form_data
			})
			.done(done_func)

	});

})(jQuery);


//Validate

document.getElementById("c_form").onsubmit = function () {
	var cont_name = document.forms["c_form"]["name"].value;
  var cont_email = document.forms["c_form"]["email"].value;
  var cont_phone = document.forms["c_form"]["phone"].value;
  var cont_subject = document.forms["c_form"]["subject"].value;
  var cont_message = document.forms["c_form"]["message"].value;

	var submit = true;

	if (cont_name == null || cont_name == "") {
		nameError = "Please Enter Your Name *";
		document.getElementById("name_error").innerHTML = nameError;
		submit = false;
	}
	if (cont_email == null || cont_email == "") {
		emailError = "Please Enter Your E-mail Address*";
		document.getElementById("email_error").innerHTML = emailError;
		submit = false;
	}
	if (cont_phone == null || cont_phone == "") {
		phoneError = "Please Enter Your Mobile Number*";
		document.getElementById("phone_error").innerHTML = phoneError;
		submit = false;
  }
  if (cont_subject == null || cont_subject == "") {
		subjectError = "Please Enter Your subject *";
		document.getElementById("subject_error").innerHTML = subjectError;
		submit = false;
  }

  if (cont_message == null || cont_message == "") {
		messageError = "Please Enter Your Message *";
		document.getElementById("message_error").innerHTML = messageError;
		submit = false;
	}

	return submit;
}

function removeWarning() {
	document.getElementById(this.id + "_error").innerHTML = "";
}

document.getElementById("name").onkeyup = removeWarning;
document.getElementById("email").onkeyup = removeWarning;
document.getElementById("phone").onkeyup = removeWarning;
document.getElementById("subject").onkeyup = removeWarning;
document.getElementById("message").onkeyup = removeWarning;