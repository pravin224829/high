<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
	
	# FIX: Replace this email with recipient email
    $mail_to = "hello@albegasolutions.com";
    # Sender Data
    $name    = str_replace(array(
        "\r",
        "\n"
    ), array(
        " ",
        " "
    ), strip_tags(trim($_POST["name"])));
    $email   = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $phone = trim($_POST["phone"]);
    $subject = trim($_POST["subject"]);
    $message = trim($_POST["message"]);

    if ( empty($name) OR empty($phone) OR empty($subject) OR empty($message)) {
        # Set a 400 (bad request) response code and exit.
        http_response_code(200);
        echo "Please Complete the Form and try again.";
        exit;
    }
	else
	{
		# Mail Content
		$headers  = 'MIME-Version: 1.0' . "\r\n"
		.'Content-type: text/html; charset=utf-8' . "\r\n"
		.'From: ' . $email . "\r\n";

		$email_content = "<html><body style='text-align:center; dispaly:block; margin:0 auto; background:#f7f7f7;'>"; 
		$email_content .= "<div style='padding:40px; border:1px solid #000;'>";
		$email_content .= "<img src='https://www.albegasolutions.com/assets/images/logo/logo-dark.png' style='width:176px; margin-bottom: 20px;' />";
		$email_content .= "
		<table style='font-family: Arial; margin:0 auto; width:100%'>
		<tbody>
			<tr>
				<td style='background-image: linear-gradient(to left, #5956E9, #4A00E0); padding: 10px; color:#fff; font-size:14px; width: 30%;'> Name</td>
				<td style='background-image: linear-gradient(106deg,#fff,#fff); padding: 10px; font-size:16px; color:#000; border:1px solid #000; width: 70%;'>$name</td>
			</tr>";
		$email_content .= "
			<tr>
				<td style='background-image: linear-gradient(to left, #5956E9, #4A00E0); padding: 10px; color:#fff; font-size:14px; width: 30%;'> Email</td>
				<td style='background-image: linear-gradient(106deg,#fff,#fff); padding: 10px; font-size:16px; color:#000; border:1px solid #000; width: 70%;'>$email</td>
			</tr>
		";
		$email_content .= "
			<tr>
				<td style='background-image: linear-gradient(to left, #5956E9, #4A00E0); padding: 10px; color:#fff; font-size:14px; width: 30%;'> Phone</td>
				<td style='background-image: linear-gradient(106deg,#fff,#fff); padding: 10px; font-size:16px; color:#000; border:1px solid #000; width: 70%;'>$phone</td>
			</tr>
		";
		$email_content .= "
			<tr>
				<td style='background-image: linear-gradient(to left, #5956E9, #4A00E0); padding: 10px; color:#fff; font-size:14px; width: 30%;'> Subject</td>
				<td style='background-image: linear-gradient(106deg,#fff,#fff); padding: 10px; font-size:16px; color:#000; border:1px solid #000; width: 70%;'>$subject</td>
			</tr>
		";
		$email_content .= "
		<tr>
			<td style='background-image: linear-gradient(to left, #5956E9, #4A00E0); padding: 10px; color:#fff; font-size:14px; width: 30%;'> Message </td>
			<td style='background-image: linear-gradient(106deg,#fff,#fff); padding: 10px; font-size:16px; color:#000; border:1px solid #000; width: 70%;'>$message</td>
		</tr>	
		";	
		$email_content .= "<div>";
		$email_content .= '</body></html>';
		# email headers.

	   // $headers .= "Cc: hello@albegasolutions.com";
		# Send the email.
		$success = mail($mail_to, $subject, $email_content, $headers);
		if ($success) {
			# Set a 200 (okay) response code.
			http_response_code(200);
			echo "Thank You! Your message has been sent.";
		}
	}
}